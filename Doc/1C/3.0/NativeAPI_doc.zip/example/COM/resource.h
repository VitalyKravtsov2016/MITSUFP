//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by AddIn.rc
//
#define IDS_PROJNAME                    100
#define IDR_ADDIN                       101
#define IDS_TERM_MSGBOX                 101
#define IDR_ADDINCOM                    102
#define IDS_PROPPAGE_CAPTION            103
#define IDS_MESSAGE_SOURCE              105
#define IDS_TERM_ENABLED                106
#define IDS_TERM_ENABLE                 107
#define IDS_TERM_DISABLE                108
#define IDS_TERM_SHOWSTATUS             109
#define IDS_TERM_STARTTIMER             110
#define IDS_ERROR_SOURCE                111
#define IDS_ERROR_DESCRIPTION           112
#define IDS_TERM_STOPTIMER              113
#define IDS_TERM_TIMERPRESENT           114
#define IDS_TERM_OPENFORM               115
#define IDS_ERROR_OPENFORMERROR         116

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
