﻿
#ifndef __STDAFX_H__
#define __STDAFX_H__

#if defined(_WINDOWS)
    #include <windows.h>
#endif //_WINDOWS

#endif //__STDAFX_H__

