#pragma once
#include "addinlib.h"

extern const char *nameFilePrj;
extern const char *nameFileComponent;
