#include "config.h"

NSMODULE_DEFN(AddInFFModule) = &kAddInModule;
