﻿#include "config.h"

AddInComponentType typeComponent = eAddInNative;
const char *nameFilePrj = ADDNCHROME OS ARCH EXESUFFIX;
const char *nameFileComponent = LIBPREFIX ADDNNATIVE OS ARCH ARCHSUFFIX "_" ADDNVER LIBSUFFIX;
