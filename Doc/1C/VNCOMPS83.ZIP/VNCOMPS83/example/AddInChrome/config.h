﻿#pragma once
#include "addinlib.h"
#include "AddInVersion.h"

extern const char *nameFilePrj;
extern const char *nameFileComponent;
