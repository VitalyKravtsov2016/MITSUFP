#pragma once

enum AddInComponentType
{
    eAddInCom = 1,
    eAddInNative,
    eAddInJava,
    eAddInvalid = -1
};
