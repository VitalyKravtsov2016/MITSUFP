using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace MitsuCube
{
	public class Ticket_CorrectionForm : Form
	{
		private IContainer components = null;

		private GroupBox groupBox_CorrectionData;

		private Panel panel_CorrectionData;

		private RadioButton radio_Corr_Type1;

		private RadioButton radio_Corr_Type0;

		private Label label_Cor_Order;

		private TextBox textBox_CorrPredp;

		private Label label_Cor_Date;

		private DateTimePicker dateTimePicker_CorrCalc;

		private Button button_CorrectionCancel;

		private Button button_CorrectionOK;

		private Panel panel_Ticket_User;

		private GroupBox groupBox_Ticket_User;

		private TextBox textBox_SMail;

		private Label label38;

		private TextBox textBox_CAutomatNumber;

		private Label label70;

		private TextBox textBox_CPlaceCalc;

		private Label label60;

		private TextBox textBox_CAdressCalc;

		private Label label61;

		private Panel panel_CorrectionButtons;

		public string Value
		{
			get
			{
				string value = ((dateTimePicker_CorrCalc.Value.Year < 2018) ? "" : dateTimePicker_CorrCalc.Value.ToString("yyyy-MM-dd"));
				return TagValue(1009, textBox_CAdressCalc) + TagValue(1187, textBox_CPlaceCalc) + TagValue(1036, textBox_CAutomatNumber) + TagValue(1117, textBox_SMail) + TagValue(1173, radio_Corr_Type0.Checked ? "0" : "1") + TagValue(1174, TagValue(1178, value) + TagValue(1179, textBox_CorrPredp));
			}
		}

		public Ticket_CorrectionForm()
		{
			InitializeComponent();
		}

		private string TagValue(int num, string value)
		{
			return string.IsNullOrEmpty(value) ? "" : $"<T{num}>{value}</T{num}>";
		}

		private string TagValue(int num, TextBox t)
		{
			return (t.ForeColor != SystemColors.ControlText) ? "" : TagValue(num, t.Text);
		}

		private void textBox_CAdressCalc_TextChanged(object sender, EventArgs e)
		{
			((TextBox)sender).ForeColor = SystemColors.ControlText;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MitsuCube.Ticket_CorrectionForm));
			this.groupBox_CorrectionData = new System.Windows.Forms.GroupBox();
			this.radio_Corr_Type1 = new System.Windows.Forms.RadioButton();
			this.radio_Corr_Type0 = new System.Windows.Forms.RadioButton();
			this.dateTimePicker_CorrCalc = new System.Windows.Forms.DateTimePicker();
			this.label_Cor_Order = new System.Windows.Forms.Label();
			this.label_Cor_Date = new System.Windows.Forms.Label();
			this.textBox_CorrPredp = new System.Windows.Forms.TextBox();
			this.panel_CorrectionData = new System.Windows.Forms.Panel();
			this.button_CorrectionCancel = new System.Windows.Forms.Button();
			this.button_CorrectionOK = new System.Windows.Forms.Button();
			this.panel_Ticket_User = new System.Windows.Forms.Panel();
			this.groupBox_Ticket_User = new System.Windows.Forms.GroupBox();
			this.textBox_SMail = new System.Windows.Forms.TextBox();
			this.label38 = new System.Windows.Forms.Label();
			this.textBox_CAutomatNumber = new System.Windows.Forms.TextBox();
			this.label70 = new System.Windows.Forms.Label();
			this.textBox_CPlaceCalc = new System.Windows.Forms.TextBox();
			this.label60 = new System.Windows.Forms.Label();
			this.textBox_CAdressCalc = new System.Windows.Forms.TextBox();
			this.label61 = new System.Windows.Forms.Label();
			this.panel_CorrectionButtons = new System.Windows.Forms.Panel();
			this.groupBox_CorrectionData.SuspendLayout();
			this.panel_CorrectionData.SuspendLayout();
			this.panel_Ticket_User.SuspendLayout();
			this.groupBox_Ticket_User.SuspendLayout();
			this.panel_CorrectionButtons.SuspendLayout();
			base.SuspendLayout();
			this.groupBox_CorrectionData.BackColor = System.Drawing.Color.Transparent;
			this.groupBox_CorrectionData.Controls.Add(this.radio_Corr_Type1);
			this.groupBox_CorrectionData.Controls.Add(this.radio_Corr_Type0);
			this.groupBox_CorrectionData.Controls.Add(this.dateTimePicker_CorrCalc);
			this.groupBox_CorrectionData.Controls.Add(this.label_Cor_Order);
			this.groupBox_CorrectionData.Controls.Add(this.label_Cor_Date);
			this.groupBox_CorrectionData.Controls.Add(this.textBox_CorrPredp);
			this.groupBox_CorrectionData.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox_CorrectionData.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_CorrectionData.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_CorrectionData.Location = new System.Drawing.Point(0, 0);
			this.groupBox_CorrectionData.Name = "groupBox_CorrectionData";
			this.groupBox_CorrectionData.Padding = new System.Windows.Forms.Padding(0);
			this.groupBox_CorrectionData.Size = new System.Drawing.Size(502, 73);
			this.groupBox_CorrectionData.TabIndex = 44;
			this.groupBox_CorrectionData.TabStop = false;
			this.groupBox_CorrectionData.Text = "Данные операции коррекции";
			this.radio_Corr_Type1.AutoSize = true;
			this.radio_Corr_Type1.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.radio_Corr_Type1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.radio_Corr_Type1.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.radio_Corr_Type1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radio_Corr_Type1.Location = new System.Drawing.Point(3, 22);
			this.radio_Corr_Type1.MinimumSize = new System.Drawing.Size(110, 0);
			this.radio_Corr_Type1.Name = "radio_Corr_Type1";
			this.radio_Corr_Type1.Size = new System.Drawing.Size(110, 17);
			this.radio_Corr_Type1.TabIndex = 20;
			this.radio_Corr_Type1.Text = "По предписанию";
			this.radio_Corr_Type1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.radio_Corr_Type1.UseVisualStyleBackColor = true;
			this.radio_Corr_Type0.AutoSize = true;
			this.radio_Corr_Type0.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.radio_Corr_Type0.Checked = true;
			this.radio_Corr_Type0.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.radio_Corr_Type0.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.radio_Corr_Type0.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radio_Corr_Type0.Location = new System.Drawing.Point(3, 45);
			this.radio_Corr_Type0.MinimumSize = new System.Drawing.Size(110, 0);
			this.radio_Corr_Type0.Name = "radio_Corr_Type0";
			this.radio_Corr_Type0.Size = new System.Drawing.Size(110, 17);
			this.radio_Corr_Type0.TabIndex = 20;
			this.radio_Corr_Type0.TabStop = true;
			this.radio_Corr_Type0.Text = "Самостоятельно";
			this.radio_Corr_Type0.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.radio_Corr_Type0.UseVisualStyleBackColor = true;
			this.dateTimePicker_CorrCalc.CustomFormat = "";
			this.dateTimePicker_CorrCalc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.dateTimePicker_CorrCalc.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			this.dateTimePicker_CorrCalc.ImeMode = System.Windows.Forms.ImeMode.Off;
			this.dateTimePicker_CorrCalc.Location = new System.Drawing.Point(307, 45);
			this.dateTimePicker_CorrCalc.MaxDate = new System.DateTime(2099, 12, 31, 0, 0, 0, 0);
			this.dateTimePicker_CorrCalc.MinDate = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
			this.dateTimePicker_CorrCalc.Name = "dateTimePicker_CorrCalc";
			this.dateTimePicker_CorrCalc.Size = new System.Drawing.Size(122, 20);
			this.dateTimePicker_CorrCalc.TabIndex = 2;
			this.dateTimePicker_CorrCalc.Value = new System.DateTime(2020, 3, 21, 1, 14, 1, 0);
			this.label_Cor_Order.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_Cor_Order.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Cor_Order.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Cor_Order.Location = new System.Drawing.Point(119, 20);
			this.label_Cor_Order.Margin = new System.Windows.Forms.Padding(3);
			this.label_Cor_Order.Name = "label_Cor_Order";
			this.label_Cor_Order.Size = new System.Drawing.Size(182, 20);
			this.label_Cor_Order.TabIndex = 18;
			this.label_Cor_Order.Text = "Номер предписания";
			this.label_Cor_Order.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.label_Cor_Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_Cor_Date.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Cor_Date.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Cor_Date.Location = new System.Drawing.Point(119, 43);
			this.label_Cor_Date.Margin = new System.Windows.Forms.Padding(3);
			this.label_Cor_Date.Name = "label_Cor_Date";
			this.label_Cor_Date.Size = new System.Drawing.Size(182, 20);
			this.label_Cor_Date.TabIndex = 17;
			this.label_Cor_Date.Text = "Дата корректируемого расчета";
			this.label_Cor_Date.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.textBox_CorrPredp.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.textBox_CorrPredp.ForeColor = System.Drawing.SystemColors.GrayText;
			this.textBox_CorrPredp.Location = new System.Drawing.Point(307, 20);
			this.textBox_CorrPredp.MaxLength = 32;
			this.textBox_CorrPredp.Name = "textBox_CorrPredp";
			this.textBox_CorrPredp.Size = new System.Drawing.Size(50, 20);
			this.textBox_CorrPredp.TabIndex = 3;
			this.textBox_CorrPredp.Text = "01";
			this.textBox_CorrPredp.Click += new System.EventHandler(textBox_CAdressCalc_TextChanged);
			this.panel_CorrectionData.BackColor = System.Drawing.Color.LightCyan;
			this.panel_CorrectionData.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_CorrectionData.Controls.Add(this.groupBox_CorrectionData);
			this.panel_CorrectionData.Location = new System.Drawing.Point(12, 12);
			this.panel_CorrectionData.Name = "panel_CorrectionData";
			this.panel_CorrectionData.Size = new System.Drawing.Size(504, 75);
			this.panel_CorrectionData.TabIndex = 4;
			this.button_CorrectionCancel.BackColor = System.Drawing.Color.Transparent;
			this.button_CorrectionCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.button_CorrectionCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold);
			this.button_CorrectionCancel.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_CorrectionCancel.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_CorrectionCancel.Location = new System.Drawing.Point(373, 3);
			this.button_CorrectionCancel.Name = "button_CorrectionCancel";
			this.button_CorrectionCancel.Size = new System.Drawing.Size(128, 37);
			this.button_CorrectionCancel.TabIndex = 45;
			this.button_CorrectionCancel.Text = "Отмена";
			this.button_CorrectionCancel.UseVisualStyleBackColor = false;
			this.button_CorrectionOK.BackColor = System.Drawing.Color.Transparent;
			this.button_CorrectionOK.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.button_CorrectionOK.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold);
			this.button_CorrectionOK.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_CorrectionOK.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_CorrectionOK.Location = new System.Drawing.Point(239, 3);
			this.button_CorrectionOK.Name = "button_CorrectionOK";
			this.button_CorrectionOK.Size = new System.Drawing.Size(128, 37);
			this.button_CorrectionOK.TabIndex = 46;
			this.button_CorrectionOK.Text = "Чек коррекции";
			this.button_CorrectionOK.UseVisualStyleBackColor = false;
			this.panel_Ticket_User.BackColor = System.Drawing.Color.LightCyan;
			this.panel_Ticket_User.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_Ticket_User.Controls.Add(this.groupBox_Ticket_User);
			this.panel_Ticket_User.Location = new System.Drawing.Point(12, 95);
			this.panel_Ticket_User.Name = "panel_Ticket_User";
			this.panel_Ticket_User.Padding = new System.Windows.Forms.Padding(3);
			this.panel_Ticket_User.Size = new System.Drawing.Size(504, 120);
			this.panel_Ticket_User.TabIndex = 47;
			this.groupBox_Ticket_User.Controls.Add(this.textBox_SMail);
			this.groupBox_Ticket_User.Controls.Add(this.label38);
			this.groupBox_Ticket_User.Controls.Add(this.textBox_CAutomatNumber);
			this.groupBox_Ticket_User.Controls.Add(this.label70);
			this.groupBox_Ticket_User.Controls.Add(this.textBox_CPlaceCalc);
			this.groupBox_Ticket_User.Controls.Add(this.label60);
			this.groupBox_Ticket_User.Controls.Add(this.textBox_CAdressCalc);
			this.groupBox_Ticket_User.Controls.Add(this.label61);
			this.groupBox_Ticket_User.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox_Ticket_User.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_Ticket_User.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_Ticket_User.Location = new System.Drawing.Point(3, 3);
			this.groupBox_Ticket_User.Name = "groupBox_Ticket_User";
			this.groupBox_Ticket_User.Size = new System.Drawing.Size(496, 112);
			this.groupBox_Ticket_User.TabIndex = 2;
			this.groupBox_Ticket_User.TabStop = false;
			this.groupBox_Ticket_User.Text = "Реквизиты пользователя";
			this.textBox_SMail.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_SMail.ForeColor = System.Drawing.Color.DarkGray;
			this.textBox_SMail.Location = new System.Drawing.Point(116, 59);
			this.textBox_SMail.MaxLength = 64;
			this.textBox_SMail.Name = "textBox_SMail";
			this.textBox_SMail.Size = new System.Drawing.Size(371, 20);
			this.textBox_SMail.TabIndex = 3;
			this.textBox_SMail.Text = "user@mail.com";
			this.textBox_SMail.Click += new System.EventHandler(textBox_CAdressCalc_TextChanged);
			this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label38.ForeColor = System.Drawing.SystemColors.ControlText;
			this.label38.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label38.Location = new System.Drawing.Point(4, 58);
			this.label38.Margin = new System.Windows.Forms.Padding(3);
			this.label38.Name = "label38";
			this.label38.Size = new System.Drawing.Size(106, 20);
			this.label38.TabIndex = 3;
			this.label38.Text = "Email:";
			this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.textBox_CAutomatNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_CAutomatNumber.Location = new System.Drawing.Point(116, 80);
			this.textBox_CAutomatNumber.MaxLength = 20;
			this.textBox_CAutomatNumber.Name = "textBox_CAutomatNumber";
			this.textBox_CAutomatNumber.Size = new System.Drawing.Size(43, 20);
			this.textBox_CAutomatNumber.TabIndex = 2;
			this.textBox_CAutomatNumber.Click += new System.EventHandler(textBox_CAdressCalc_TextChanged);
			this.label70.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label70.ForeColor = System.Drawing.SystemColors.ControlText;
			this.label70.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label70.Location = new System.Drawing.Point(4, 79);
			this.label70.Margin = new System.Windows.Forms.Padding(3);
			this.label70.Name = "label70";
			this.label70.Size = new System.Drawing.Size(106, 20);
			this.label70.TabIndex = 2;
			this.label70.Text = "Автомат №";
			this.label70.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.textBox_CPlaceCalc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_CPlaceCalc.ForeColor = System.Drawing.Color.DarkGray;
			this.textBox_CPlaceCalc.Location = new System.Drawing.Point(116, 38);
			this.textBox_CPlaceCalc.MaxLength = 256;
			this.textBox_CPlaceCalc.Name = "textBox_CPlaceCalc";
			this.textBox_CPlaceCalc.Size = new System.Drawing.Size(371, 20);
			this.textBox_CPlaceCalc.TabIndex = 1;
			this.textBox_CPlaceCalc.Text = "Новое место расчета";
			this.textBox_CPlaceCalc.Click += new System.EventHandler(textBox_CAdressCalc_TextChanged);
			this.label60.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label60.ForeColor = System.Drawing.SystemColors.ControlText;
			this.label60.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label60.Location = new System.Drawing.Point(4, 37);
			this.label60.Margin = new System.Windows.Forms.Padding(3);
			this.label60.Name = "label60";
			this.label60.Size = new System.Drawing.Size(106, 20);
			this.label60.TabIndex = 2;
			this.label60.Text = "Место расчетов:";
			this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.textBox_CAdressCalc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_CAdressCalc.ForeColor = System.Drawing.Color.DarkGray;
			this.textBox_CAdressCalc.Location = new System.Drawing.Point(116, 17);
			this.textBox_CAdressCalc.MaxLength = 256;
			this.textBox_CAdressCalc.Name = "textBox_CAdressCalc";
			this.textBox_CAdressCalc.Size = new System.Drawing.Size(371, 20);
			this.textBox_CAdressCalc.TabIndex = 0;
			this.textBox_CAdressCalc.Text = "Новый адрес";
			this.textBox_CAdressCalc.Click += new System.EventHandler(textBox_CAdressCalc_TextChanged);
			this.label61.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label61.ForeColor = System.Drawing.SystemColors.ControlText;
			this.label61.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label61.Location = new System.Drawing.Point(4, 16);
			this.label61.Margin = new System.Windows.Forms.Padding(3);
			this.label61.Name = "label61";
			this.label61.Size = new System.Drawing.Size(106, 20);
			this.label61.TabIndex = 1;
			this.label61.Text = "Адрес расчетов:";
			this.label61.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.panel_CorrectionButtons.Controls.Add(this.button_CorrectionCancel);
			this.panel_CorrectionButtons.Controls.Add(this.button_CorrectionOK);
			this.panel_CorrectionButtons.Location = new System.Drawing.Point(12, 220);
			this.panel_CorrectionButtons.Name = "panel_CorrectionButtons";
			this.panel_CorrectionButtons.Size = new System.Drawing.Size(504, 42);
			this.panel_CorrectionButtons.TabIndex = 48;
			base.AcceptButton = this.button_CorrectionOK;
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.CancelButton = this.button_CorrectionCancel;
			base.ClientSize = new System.Drawing.Size(528, 268);
			base.Controls.Add(this.panel_CorrectionButtons);
			base.Controls.Add(this.panel_Ticket_User);
			base.Controls.Add(this.panel_CorrectionData);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			base.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "Ticket_CorrectionForm";
			base.Padding = new System.Windows.Forms.Padding(12);
			base.ShowIcon = false;
			base.ShowInTaskbar = false;
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Коррекция";
			this.groupBox_CorrectionData.ResumeLayout(false);
			this.groupBox_CorrectionData.PerformLayout();
			this.panel_CorrectionData.ResumeLayout(false);
			this.panel_Ticket_User.ResumeLayout(false);
			this.groupBox_Ticket_User.ResumeLayout(false);
			this.groupBox_Ticket_User.PerformLayout();
			this.panel_CorrectionButtons.ResumeLayout(false);
			base.ResumeLayout(false);
		}
	}
}
