namespace MitsuCube
{
	public class CodeMsg
	{
		public int code { get; set; }

		public string message { get; set; }

		public CodeMsg(int c, string m)
		{
			code = c;
			message = m;
		}
	}
}
