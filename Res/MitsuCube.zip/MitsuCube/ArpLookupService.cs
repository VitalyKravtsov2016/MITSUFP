using System;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;

namespace MitsuCube
{
	public class ArpLookupService
	{
		public struct MIB_IPNETROW
		{
			[MarshalAs(UnmanagedType.U4)]
			public int dwIndex;

			[MarshalAs(UnmanagedType.U4)]
			public int dwPhysAddrLen;

			[MarshalAs(UnmanagedType.U1)]
			public byte mac0;

			[MarshalAs(UnmanagedType.U1)]
			public byte mac1;

			[MarshalAs(UnmanagedType.U1)]
			public byte mac2;

			[MarshalAs(UnmanagedType.U1)]
			public byte mac3;

			[MarshalAs(UnmanagedType.U1)]
			public byte mac4;

			[MarshalAs(UnmanagedType.U1)]
			public byte mac5;

			[MarshalAs(UnmanagedType.U1)]
			public byte mac6;

			[MarshalAs(UnmanagedType.U1)]
			public byte mac7;

			[MarshalAs(UnmanagedType.U4)]
			public int dwAddr;

			[MarshalAs(UnmanagedType.U4)]
			public int dwType;
		}

		private const int ERROR_INSUFFICIENT_BUFFER = 122;

		[DllImport("IpHlpApi.dll")]
		[return: MarshalAs(UnmanagedType.U4)]
		private static extern int GetIpNetTable(IntPtr pIpNetTable, [MarshalAs(UnmanagedType.U4)] ref int pdwSize, bool bOrder);

		[DllImport("IpHlpApi.dll", CharSet = CharSet.Auto, SetLastError = true)]
		internal static extern int FreeMibTable(IntPtr plpNetTable);

		public IpMac[] GetIPAddress()
		{
			int pdwSize = 0;
			int ipNetTable = GetIpNetTable(IntPtr.Zero, ref pdwSize, bOrder: false);
			if (ipNetTable != 122)
			{
				throw new Exception($"Ошибка определения размера буфера, код {ipNetTable}");
			}
			IntPtr intPtr = IntPtr.Zero;
			try
			{
				intPtr = Marshal.AllocCoTaskMem(pdwSize);
				ipNetTable = GetIpNetTable(intPtr, ref pdwSize, bOrder: false);
				if (ipNetTable != 0)
				{
					throw new Exception($"Ошибка получения таблицы ARP, код {ipNetTable}");
				}
				int num = Marshal.ReadInt32(intPtr);
				IntPtr intPtr2 = new IntPtr(intPtr.ToInt64() + Marshal.SizeOf(typeof(int)));
				IpMac[] array = new IpMac[0];
				int i = 0;
				int num2 = 0;
				for (; i < num; i++)
				{
					MIB_IPNETROW mIB_IPNETROW = (MIB_IPNETROW)Marshal.PtrToStructure(new IntPtr(intPtr2.ToInt64() + i * Marshal.SizeOf(typeof(MIB_IPNETROW))), typeof(MIB_IPNETROW));
					IPAddress ip = new IPAddress(BitConverter.GetBytes(mIB_IPNETROW.dwAddr));
					if (num2 == 0 || (array.Count((IpMac p) => ip.Equals(p.ip)) == 0 && (mIB_IPNETROW.mac0 | mIB_IPNETROW.mac1) != 0))
					{
						Array.Resize(ref array, num2 + 1);
						array[num2++] = new IpMac(ip, mIB_IPNETROW.mac0.ToString("X2") + "-" + mIB_IPNETROW.mac1.ToString("X2") + "-" + mIB_IPNETROW.mac2.ToString("X2") + "-" + mIB_IPNETROW.mac3.ToString("X2") + "-" + mIB_IPNETROW.mac4.ToString("X2") + "-" + mIB_IPNETROW.mac5.ToString("X2"), mIB_IPNETROW.dwType);
					}
				}
				return array;
			}
			finally
			{
				FreeMibTable(intPtr);
			}
		}
	}
}
