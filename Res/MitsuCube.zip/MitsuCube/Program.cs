using System;
using System.Windows.Forms;

namespace MitsuCube
{
	internal static class Program
	{
		[STAThread]
		private static void Main()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(defaultValue: false);
			Lng.SetLngRU();
			Application.Run(new MainForm());
		}
	}
}
