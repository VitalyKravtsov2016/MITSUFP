using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Xml.Linq;
using MitsuCube.Properties;

namespace MitsuCube
{
	public class MainForm : Form
	{
		private enum CMD
		{
			GET_DATE,
			GET_TIME,
			GET_VER,
			GET_CASHIER,
			GET_HEADER,
			GET_COM,
			GET_PRINTER,
			GET_INFO,
			GET_DOC,
			GET_LAN,
			GET_OFD,
			GET_OISM,
			GET_OKP,
			GET_CD,
			GET_REG,
			GET_POWER,
			SET_DATE,
			SET_TIME,
			SET_CASHIER,
			SET_HEADER,
			SET_COM,
			SET_LAN,
			SET_OFD,
			SET_OISM,
			SET_OKP,
			SET_PRINTER,
			SET_POWER,
			SET_SERIAL,
			DO_SHIFT,
			DO_CHECK,
			DO_MARK,
			DO_OFD,
			DO_OISM,
			DO_OKP,
			ADD_ITEM,
			ADD_DATA,
			ADD_FORM,
			ADD_BAR,
			ADD_PIC,
			ADD_LINE,
			ADD_BLANK,
			MAKE_REPORT,
			MAKE_FISCAL,
			FLASH_MODE,
			OPTION,
			REG,
			PRINT,
			FEED,
			CUT,
			READ,
			DEVICE_JOB,
			SET,
			FREE,
			CORR_END,
			CHECK_PAY
		}

		private class Command
		{
			public struct SUB
			{
				public string name;

				public string attribute;

				public long timeout;
			}

			public readonly SUB[] cmd_list = new SUB[53]
			{
				new SUB
				{
					name = "GET DATE='?' TIME='?'",
					attribute = "",
					timeout = 500L
				},
				new SUB
				{
					name = "GET",
					attribute = "TIME",
					timeout = 500L
				},
				new SUB
				{
					name = "GET",
					attribute = "VER",
					timeout = 500L
				},
				new SUB
				{
					name = "GET",
					attribute = "CASHIER",
					timeout = 500L
				},
				new SUB
				{
					name = "GET",
					attribute = "HEADER",
					timeout = 1000L
				},
				new SUB
				{
					name = "GET",
					attribute = "COM",
					timeout = 1000L
				},
				new SUB
				{
					name = "GET",
					attribute = "PRINTER",
					timeout = 1000L
				},
				new SUB
				{
					name = "GET",
					attribute = "INFO",
					timeout = 1000L
				},
				new SUB
				{
					name = "GET",
					attribute = "DOC",
					timeout = 1000L
				},
				new SUB
				{
					name = "GET",
					attribute = "LAN",
					timeout = 1000L
				},
				new SUB
				{
					name = "GET",
					attribute = "OFD",
					timeout = 1000L
				},
				new SUB
				{
					name = "GET",
					attribute = "OISM",
					timeout = 1000L
				},
				new SUB
				{
					name = "GET",
					attribute = "OKP",
					timeout = 1000L
				},
				new SUB
				{
					name = "GET",
					attribute = "CD",
					timeout = 1000L
				},
				new SUB
				{
					name = "GET",
					attribute = "REG",
					timeout = 1000L
				},
				new SUB
				{
					name = "GET",
					attribute = "POWER",
					timeout = 500L
				},
				new SUB
				{
					name = "SET",
					attribute = "DATE",
					timeout = 1000L
				},
				new SUB
				{
					name = "SET",
					attribute = "TIME",
					timeout = 1000L
				},
				new SUB
				{
					name = "SET",
					attribute = "CASHIER",
					timeout = 1000L
				},
				new SUB
				{
					name = "SET",
					attribute = "HEADER",
					timeout = 5000L
				},
				new SUB
				{
					name = "SET",
					attribute = "COM",
					timeout = 1000L
				},
				new SUB
				{
					name = "SET",
					attribute = "LAN",
					timeout = 1000L
				},
				new SUB
				{
					name = "SET",
					attribute = "OFD",
					timeout = 1000L
				},
				new SUB
				{
					name = "SET",
					attribute = "OISM",
					timeout = 1000L
				},
				new SUB
				{
					name = "SET",
					attribute = "OKP",
					timeout = 1000L
				},
				new SUB
				{
					name = "SET",
					attribute = "PRINTER",
					timeout = 1000L
				},
				new SUB
				{
					name = "SET",
					attribute = "POWER",
					timeout = 1000L
				},
				new SUB
				{
					name = "SET",
					attribute = "SERIAL",
					timeout = 30000L
				},
				new SUB
				{
					name = "DO",
					attribute = "SHIFT",
					timeout = 15000L
				},
				new SUB
				{
					name = "DO",
					attribute = "CHECK",
					timeout = 5000L
				},
				new SUB
				{
					name = "DO",
					attribute = "MARK",
					timeout = 15000L
				},
				new SUB
				{
					name = "DO",
					attribute = "OFD",
					timeout = 5000L
				},
				new SUB
				{
					name = "DO",
					attribute = "OISM",
					timeout = 5000L
				},
				new SUB
				{
					name = "DO",
					attribute = "OKP",
					timeout = 5000L
				},
				new SUB
				{
					name = "ADD",
					attribute = "ITEM",
					timeout = 15000L
				},
				new SUB
				{
					name = "ADD",
					attribute = "DATA",
					timeout = 1000L
				},
				new SUB
				{
					name = "ADD",
					attribute = "FORM",
					timeout = 1000L
				},
				new SUB
				{
					name = "ADD",
					attribute = "BAR",
					timeout = 1000L
				},
				new SUB
				{
					name = "ADD",
					attribute = "PIC",
					timeout = 1000L
				},
				new SUB
				{
					name = "ADD",
					attribute = "LINE",
					timeout = 1000L
				},
				new SUB
				{
					name = "ADD",
					attribute = "BLANK",
					timeout = 1000L
				},
				new SUB
				{
					name = "MAKE",
					attribute = "REPORT",
					timeout = 5000L
				},
				new SUB
				{
					name = "MAKE",
					attribute = "FISCAL",
					timeout = 15000L
				},
				new SUB
				{
					name = "FLASH",
					attribute = "MODE",
					timeout = 60000L
				},
				new SUB
				{
					name = "OPTION",
					attribute = "",
					timeout = 1000L
				},
				new SUB
				{
					name = "REG",
					attribute = "",
					timeout = 5000L
				},
				new SUB
				{
					name = "PRINT",
					attribute = "",
					timeout = 20000L
				},
				new SUB
				{
					name = "FEED",
					attribute = "N",
					timeout = 1000L
				},
				new SUB
				{
					name = "CUT",
					attribute = "",
					timeout = 2000L
				},
				new SUB
				{
					name = "READ",
					attribute = "",
					timeout = 2000L
				},
				new SUB
				{
					name = "DEVICE",
					attribute = "JOB",
					timeout = 60000L
				},
				new SUB
				{
					name = "SET",
					attribute = "",
					timeout = 30000L
				},
				new SUB
				{
					name = "",
					attribute = "",
					timeout = 30000L
				}
			};

			public string Cmd(CMD command, string a1, string a2 = null, string a3 = null, string v1 = null)
			{
				string attribute = cmd_list[(int)command].attribute;
				string text = "<" + cmd_list[(int)command].name;
				if (!string.IsNullOrEmpty(attribute))
				{
					text = text + " " + attribute + "='" + a1 + "'";
				}
				if (!string.IsNullOrEmpty(a2))
				{
					text += a2;
				}
				if (!string.IsNullOrEmpty(a3))
				{
					text += a3;
				}
				if (!string.IsNullOrEmpty(v1))
				{
					return text + ">" + v1 + "</" + cmd_list[(int)command].name + ">";
				}
				return text + "/>";
			}
		}

		private struct Setup
		{
			public int ComBaudrate;

			public int PrnBaudrate;

			public int PrnModel;

			public int PrnPaper;

			public int PrnWidth;

			public int PrnFont;

			public int PrnLength;

			public int PrnPrst;

			public int PrnPrstTime;

			public int OptLine;

			public int OptQRalign;

			public int OptRound;

			public int OptCut;

			public int OptTest;

			public int OptDrawer;

			public int OptBeeper;

			public int OptQRText;

			public int OptItemCnt;

			public int DrwPin;

			public int DrwPulse;

			public int DrwFall;
		}

		private struct LogColors
		{
			public char mark;

			public Color brush;
		}

		private struct Init_xml
		{
			public string name;

			public string def;
		}

		private struct FW_Status
		{
			public bool Success;

			public char Status;

			public int Lengh;

			public string Mark;

			public string CRC;

			public string emsg;

			public string rmsg;
		}

		private struct Notice
		{
			public int first;

			public int count;

			public int length;

			public Notice(int f, int c)
			{
				first = f;
				count = c;
				length = 0;
			}
		}

		private struct Key
		{
			public int need;

			public string url;

			public int port;

			public int D7;

			public Key(int n)
			{
				need = n;
				url = "";
				port = 0;
				D7 = 0;
			}
		}

		private struct xml_block
		{
			public int Length;

			public int Offset;

			public xml_block(int length, int offset)
			{
				Length = length;
				Offset = offset;
			}
		}

		private readonly string beznal_no = "Type";

		private readonly string mac_address_head = "00-22";

		private readonly string[] phase_no = new string[4] { "0x01", "0x03", "0x07", "0x15" };

		private readonly CultureInfo ci = CultureInfo.InvariantCulture;

		private readonly NumberFormatInfo nfi = CultureInfo.InvariantCulture.NumberFormat;

		private readonly Encoding DeviceEncoding = Encoding.GetEncoding("windows-1251");

		public ShiftOptionForm Shift_Options;

		public Ticket_UserForm User_Data;

		public Ticket_CustomerForm Customer_Data;

		public Ticket_OptionForm Option_Data;

		public Ticket_CorrectionForm Correction_Data;

		public Ticket_TextForm Ticket_Text;

		public Ticket_ItemOptionForm Ticket_ItemOption;

		public ResponseForm Response_Form;

		public Progress_Bar Progress;

		private readonly ComButtons Com;

		private static RadioButton[] radioButton_Header;

		private static DataGridView[] dataGrid_Header;

		public FileStream SparkSerialFile;

		public XDocument x_answer;

		private string answer;

		private string InitFileName;

		private string pic_filename = "";

		private string logo_filename = "";

		private int current_Header = 0;

		private readonly int WM_HOTKEY = 786;

		private readonly int AddItem_Hmin = 170;

		private readonly int AddItem_Hmax = 258;

		private readonly ArpLookupService arp = new ArpLookupService();

		private readonly Command COMMAND = new Command();

		private readonly ListMessages ErrFNMessages = new ListMessages
		{
			new CodeMsg(0, "ОК"),
			new CodeMsg(1, "Неизвестная операция"),
			new CodeMsg(2, "Недостаточно памяти"),
			new CodeMsg(3, "Операция не задана"),
			new CodeMsg(4, "Операция невыполнима: не задана структура хранения данных для ФН"),
			new CodeMsg(5, "Операция невыполнима: не задана структура для выдачи результата ФН"),
			new CodeMsg(6, "Операция невыполнима: не задана структура входящих параметров ФН"),
			new CodeMsg(7, "Операция невыполнима: превышен размер данных для команды ФН"),
			new CodeMsg(8, "Ошибка в классификаторе параметров команды"),
			new CodeMsg(9, "Неизвестная ошибка"),
			new CodeMsg(10, "Операция невыполнима: некорректное состояние ФН"),
			new CodeMsg(11, "Операция невыполнима: не удалось получить статус ФН"),
			new CodeMsg(12, "Не выполнена команда ФН: \"Начать отчет о регистрации\""),
			new CodeMsg(13, "Не выполнена команда ФН: \"Передать данные документа\""),
			new CodeMsg(14, "Не выполнена команда ФН: \"Сформировать отчет о регистрации (перерегистрации)\""),
			new CodeMsg(15, "Не выполнена команда ФН: \"Начать закрытие фискального режима\""),
			new CodeMsg(16, "Не выполнена команда ФН: \"Закрыть фискальный режим\""),
			new CodeMsg(17, "Операция невыполнима: ФН занят"),
			new CodeMsg(18, "Не выполнена команда ФН: \"Начать формирование отчета о расчетах\""),
			new CodeMsg(19, "Не выполнена команда ФН: \"Сформировать отчет о расчетах\""),
			new CodeMsg(20, "Операция ФН невыполнима: смена открыта"),
			new CodeMsg(21, "Операция ФН невыполнима: смена закрыта"),
			new CodeMsg(22, "Операция ФН невыполнима: есть незакрытый документ"),
			new CodeMsg(23, "Не выполнена команда ФН: \"Запрос количества ФД, на которые нет квитанции\""),
			new CodeMsg(24, "Не выполнена команда ФН: \"Запрос срока действия ФН\""),
			new CodeMsg(25, "Не выполнена команда ФН: \"Запрос итогов фискализации ФН\""),
			new CodeMsg(26, "Операция невыполнима: есть неподтвержденные в ОФД документы"),
			new CodeMsg(27, "Не выполнена команда ФН: \"Начать открытие смены\""),
			new CodeMsg(28, "Не выполнена команда ФН: \"Открыть смену\""),
			new CodeMsg(29, "Не выполнена команда ФН: \"Начать закрытие смены\""),
			new CodeMsg(30, "Не выполнена команда ФН: \"Закрыть смену\""),
			new CodeMsg(31, "Не выполнена команда ФН: \"Начать формирование чека\""),
			new CodeMsg(32, "Ошибка определения типа: чек или БСО"),
			new CodeMsg(33, "Операция невыполнима: чек не открыт"),
			new CodeMsg(34, "Ошибка преобразования данных"),
			new CodeMsg(35, "Не выполнена команда ФН: \"Сформировать чек\""),
			new CodeMsg(36, "Не выполнена команда ФН: \"Отменить текущий документ\""),
			new CodeMsg(37, "Операция невыполнима: документ не открыт"),
			new CodeMsg(38, "Операция невыполнима: время смены истекло"),
			new CodeMsg(39, "Операция невыполнима: чек коррекции не открыт"),
			new CodeMsg(40, "Не удалось получить данные счетчиков из ФН"),
			new CodeMsg(41, "Не удалось получить состояния смены из ФН"),
			new CodeMsg(42, "Операция невыполнима: чек пустой, нет предметов расчета"),
			new CodeMsg(43, "Операция невыполнима на текущей стадии формирования чека"),
			new CodeMsg(44, "Не выполнена команда ФН: \"Запрос номера и версии ПО ФН\""),
			new CodeMsg(45, "Операция выполнима только с отладочной ФН (МГМ)"),
			new CodeMsg(46, "Не выполнена команда ФН: \"Сброс ФН\""),
			new CodeMsg(47, "Не удалось получить статус информационного обмена с ОФД"),
			new CodeMsg(48, "Операция невыполнима: чтение сообщения для ОФД уже начато"),
			new CodeMsg(49, "Нет сообщений для ОФД"),
			new CodeMsg(50, "Не выполнена команда ФН: \"Передать статус транспортного соединения с ОФД\""),
			new CodeMsg(51, "Не выполнена команда ФН: \"Начать чтение сообщения для ОФД\""),
			new CodeMsg(52, "Операция невыполнима: чтение сообщения для ОФД еще не начато"),
			new CodeMsg(53, "Не выполнена команда ФН: \"Отменить чтение сообщения для ОФД\""),
			new CodeMsg(54, "Не выполнена команда ФН: \"Прочитать блок сообщения для ОФД\""),
			new CodeMsg(55, "ФН не готов к принятию квитанции от ОФД"),
			new CodeMsg(56, "Не выполнена команда ФН: \"Передать Квитанцию от Сервера ОФД\""),
			new CodeMsg(57, "Ошибка ФН: неверный фискальный признак"),
			new CodeMsg(58, "Ошибка ФН: неверный формат квитанции"),
			new CodeMsg(59, "Ошибка ФН: неверный номер ФД"),
			new CodeMsg(60, "Ошибка ФН: неверный номер ФН"),
			new CodeMsg(61, "Ошибка ФН: неверный CRC"),
			new CodeMsg(62, "Не выполнена команда ФН: \"Запрос данных фискального документа\""),
			new CodeMsg(63, "Не выполнена команда ФН: \"Чтение данных фискального документа\""),
			new CodeMsg(64, "Операция невыполнима: отсутствуют необходимые данные документа в архиве"),
			new CodeMsg(65, "Операция невыполнима: запрошенный из архива документ не является чеком"),
			new CodeMsg(66, "Не выполнена команда ФН: \"Запрос размера данных, переданных командой 07h\""),
			new CodeMsg(67, "Не выполнена команда ФН: \"Запрос формата ФН\""),
			new CodeMsg(68, "Пплучены некорректные данные от ФН"),
			new CodeMsg(69, "Операция невыполнима: ФН отсутствует или неисправен"),
			new CodeMsg(70, "Операция невыполнима: превышено время ожидания ответа от ФН"),
			new CodeMsg(71, "Операция невыполнима: не удалось получить запрос на проверку кода маркировки"),
			new CodeMsg(72, "Операция невыполнима в автономном режиме"),
			new CodeMsg(73, "Операция невыполнима: чтение уведомления уже начато"),
			new CodeMsg(74, "Операция невыполнима: нет уведомлений для передачи"),
			new CodeMsg(75, "Не выполнена команда ФН: \"Начать чтение уведомления\""),
			new CodeMsg(76, "Операция невыполнима: чтение уведомления еще не начато"),
			new CodeMsg(77, "Операция невыполнима: ФН не готов к принятию квитанции по уведомлениям"),
			new CodeMsg(78, "Операция невыполнима: некорректный номер уведомления"),
			new CodeMsg(79, "Операция невыполнима: некорректная длина ответа"),
			new CodeMsg(80, "Операция выполнима только в автономном режиме"),
			new CodeMsg(81, "Запрос на обновление ключей проверки КМ не был сформирован"),
			new CodeMsg(82, "Операция невыполнима: неверный номер запроса в ответе"),
			new CodeMsg(83, "Операция невыполнима: необходимо обновить ключи проверки кодов маркировки"),
			new CodeMsg(84, "Операция невыполнима: необходимо выгрузить уведомления"),
			new CodeMsg(85, "Неизвестная ошибка"),
			new CodeMsg(86, "Неизвестная ошибка"),
			new CodeMsg(87, "Неизвестная ошибка"),
			new CodeMsg(88, "Неизвестная ошибка"),
			new CodeMsg(89, "Неизвестная ошибка"),
			new CodeMsg(90, "Неизвестная ошибка"),
			new CodeMsg(91, "Неизвестная ошибка"),
			new CodeMsg(92, "Неизвестная ошибка"),
			new CodeMsg(93, "Устройство занято..."),
			new CodeMsg(94, "Таймаут приема команды"),
			new CodeMsg(95, "Таймаут ФН..."),
			new CodeMsg(96, "Неизвестные параметры в команде"),
			new CodeMsg(97, "Отсутствуют обязательные параметры"),
			new CodeMsg(98, "Команда содержит параметры, а их не должно быть"),
			new CodeMsg(99, "Неверный формат команды или неизвестная команда"),
			new CodeMsg(100, "Ошибка версии ФФД ККТ"),
			new CodeMsg(101, "Ошибка заводского номера ККТ"),
			new CodeMsg(102, "Ошибка версии ККТ"),
			new CodeMsg(103, "Ошибка регистрационного номера ККТ"),
			new CodeMsg(104, "Ошибка ИНН"),
			new CodeMsg(105, "Ошибка ИНН ОФД"),
			new CodeMsg(106, "Ошибка причины перерегистрации"),
			new CodeMsg(107, "Операция невыполнима: некорректная система налогообложения"),
			new CodeMsg(108, "Некорректный признак расчета"),
			new CodeMsg(109, "Некорректный признак способа расчета"),
			new CodeMsg(110, "Некорректный признак предмета расчета"),
			new CodeMsg(111, "Некорректное наименование"),
			new CodeMsg(112, "Некорректная мера количества"),
			new CodeMsg(113, "Некорректный код товарной номенклатуры"),
			new CodeMsg(114, "Некорректное количество предмета расчета"),
			new CodeMsg(115, "Некорректная цена предмета расчета"),
			new CodeMsg(116, "Некорректная стоимость предмета расчета"),
			new CodeMsg(117, "Некорректная ставка НДС предмета расчета"),
			new CodeMsg(118, "Некорректный размер НДС за единицу предмета расчета"),
			new CodeMsg(119, "Некорректный размер НДС предмета расчета"),
			new CodeMsg(120, "Операция невыполнима: итог чека превысил максимально допустимое значение"),
			new CodeMsg(121, "Операция невыполнима: недостаточная сумма оплат"),
			new CodeMsg(122, "Некорректная сумма оплаты наличными"),
			new CodeMsg(123, "Операция невыполнима: сумма оплат превысила максимально допустимое значение"),
			new CodeMsg(124, "Не удалось считать текущее время от внутренних часов ККТ"),
			new CodeMsg(125, "Операция невыполнима: в чеке с оплатой кредита может быть только один предмет расчета"),
			new CodeMsg(126, "Операция невыполнима: кассир не установлен"),
			new CodeMsg(127, "Некорректный признак агента"),
			new CodeMsg(128, "Операция невыполнима: документ в электронной форме не сформирован"),
			new CodeMsg(129, "Операция невыполнима: превышено допустимое в чеке число товаров с кодом товарной номенклатуры"),
			new CodeMsg(130, "Операция невыполнима: попытка повторного задания уникального параметра"),
			new CodeMsg(131, "Операция невыполнима: не задан ИНН поставщика"),
			new CodeMsg(132, "Операция невыполнима: попытка задания количества уникального товара больше 1"),
			new CodeMsg(133, "Сбой принтера"),
			new CodeMsg(134, "Неудача при записи во флэш память"),
			new CodeMsg(135, "Файл обновления не был загружен"),
			new CodeMsg(136, "Операция невыполнима в текущей версии ФФД ФН"),
			new CodeMsg(137, "Текущая версия ФФД ФН не поддерживается"),
			new CodeMsg(138, "Ошибочная последовательность команд"),
			new CodeMsg(139, "Операция невыполнима: запрещена работа с подакцизными товарами"),
			new CodeMsg(140, "Операция невыполнима: запрещены маркированные товары в чеке расхода"),
			new CodeMsg(141, "Операция невыполнима: Сумма по типам б/н оплат не равна итогу оплаты безналичными"),
			new CodeMsg(200, "Некорректные параметры в команде"),
			new CodeMsg(201, "В команде заданы не все обязательные параметры"),
			new CodeMsg(202, "Некоррекно заданы режимы работы ККТ"),
			new CodeMsg(203, "Некоррекно заданы расширенные режимы работы ККТ"),
			new CodeMsg(204, "Некоррекно заданы дата и/или время"),
			new CodeMsg(205, "Некоррекно задан ИНН"),
			new CodeMsg(206, "Некоррекно задан параметр с битовой маской"),
			new CodeMsg(207, "Превышена допустимая длина строки"),
			new CodeMsg(208, "Некорректные данные"),
			new CodeMsg(209, "Операция выполнима только при использовании внешнего агента обмена с ОФД/ОИСМ"),
			new CodeMsg(300, "ККТ не зарегистрирована"),
			new CodeMsg(401, "Неизвестная команда ФН"),
			new CodeMsg(402, "Некорректное состояние ФН"),
			new CodeMsg(403, "Отказ ФН"),
			new CodeMsg(404, "Отказ КС"),
			new CodeMsg(405, "Первышен срок жизни ФН"),
			new CodeMsg(406, ""),
			new CodeMsg(407, "Некорректная дата и/или время"),
			new CodeMsg(408, "Нет запрошенных данных"),
			new CodeMsg(409, "Некорректное значение параметров команды"),
			new CodeMsg(410, "Некорректная команда"),
			new CodeMsg(411, "Неразрешенные реквизиты"),
			new CodeMsg(412, "Дублирование данных"),
			new CodeMsg(413, "Отсутствуют данные, необходимые для корректного учета в ФН"),
			new CodeMsg(414, "Превышение допустимого числа товарных позиций в чеке"),
			new CodeMsg(415, ""),
			new CodeMsg(416, "Превышение размеров TLV данных"),
			new CodeMsg(417, "Нет транспортного соединения"),
			new CodeMsg(418, "Исчерпан ресурс ФН"),
			new CodeMsg(419, ""),
			new CodeMsg(420, "Ограничение ресурса ФН"),
			new CodeMsg(421, ""),
			new CodeMsg(422, "Превышена продолжительность смены"),
			new CodeMsg(423, "Некорректные данные о промежутке времени между фискальными документами"),
			new CodeMsg(424, "Некорректный реквизит, переданный в ФН"),
			new CodeMsg(425, "Некорректный реквизит с признаком продажи подакцизного товара"),
			new CodeMsg(432, "Сообщение ОФД не может быть принято"),
			new CodeMsg(435, "Ошибка сервиса обновления ключей проверки КМ"),
			new CodeMsg(436, "Неизвестный ответ сервиса обновления ключей проверки кодов проверки"),
			new CodeMsg(448, "Требуется повтор процедуры обновления ключей проверки КМ"),
			new CodeMsg(449, "В реквизите 2007 содержится непроверенный в ФН код маркировки"),
			new CodeMsg(450, "Запрещена работа с маркированным товарами"),
			new CodeMsg(451, "Нарушена последовательность команд для обработки маркировки"),
			new CodeMsg(452, "Работа с маркированными товарами временно заблокирована"),
			new CodeMsg(453, "Переполнена таблица проверки кодов маркировки"),
			new CodeMsg(454, "Превышен период 90 дней со времени обновления ключей проверки"),
			new CodeMsg(460, "В блоке TLV отсутствуют необходимые реквизиты"),
			new CodeMsg(462, "в реквизите 2007 содержится КМ, который ранее не проверялся в ФН"),
			new CodeMsg(500, "Нет бумаги в принтере"),
			new CodeMsg(501, "Крышка принтера открыта"),
			new CodeMsg(502, "Состояние принтера нерабочее (OFFLINE)"),
			new CodeMsg(503, "Ошибка резака"),
			new CodeMsg(504, "Неизвестная ошибка принтера"),
			new CodeMsg(505, "Принтер выключен"),
			new CodeMsg(506, "Бумага заканчивается"),
			new CodeMsg(507, "Сигнал денежного ящика имеет высокий уровень"),
			new CodeMsg(508, "Ошибка денежного ящика"),
			new CodeMsg(509, "Принтер занят, идет печать..."),
			new CodeMsg(510, "Печатная форма документа не завершена (сбой принтера)"),
			new CodeMsg(511, "Нажата кнопка прогона бумаги"),
			new CodeMsg(512, "Задана некорректная ширина бумаги"),
			new CodeMsg(600, "Ошибка встроенных часов при попытке прочитать дату/время ККТ"),
			new CodeMsg(601, "Ошибка встроенных часов при попытке установить дату/время ККТ"),
			new CodeMsg(602, "Запрещена установка даты раньше даты последнего фискального документа"),
			new CodeMsg(603, ""),
			new CodeMsg(604, "Не удалось связаться с сервером ОИСМ"),
			new CodeMsg(605, "Получен пустой ответ от ОИСМ"),
			new CodeMsg(606, "Не удалось связаться с сервером ОКП"),
			new CodeMsg(607, "Получен пустой ответ от ОКП"),
			new CodeMsg(608, "Общая ошибка работы с ОКП")
		};

		private bool stop_scan = true;

		private static readonly LogColors[] MarkColors = new LogColors[7]
		{
			new LogColors
			{
				mark = '<',
				brush = Color.Black
			},
			new LogColors
			{
				mark = '>',
				brush = Color.Blue
			},
			new LogColors
			{
				mark = '!',
				brush = Color.Red
			},
			new LogColors
			{
				mark = '+',
				brush = Color.Brown
			},
			new LogColors
			{
				mark = '-',
				brush = Color.DarkViolet
			},
			new LogColors
			{
				mark = '.',
				brush = Color.Green
			},
			new LogColors
			{
				mark = ' ',
				brush = Color.Brown
			}
		};

		private XDocument init_program;

		private static readonly Init_xml[] init_elements = new Init_xml[24]
		{
			new Init_xml
			{
				name = "LANGUAGE",
				def = "ru"
			},
			new Init_xml
			{
				name = "main_top",
				def = "0"
			},
			new Init_xml
			{
				name = "main_left",
				def = "0"
			},
			new Init_xml
			{
				name = "main_width",
				def = "800"
			},
			new Init_xml
			{
				name = "main_height",
				def = "600"
			},
			new Init_xml
			{
				name = "KKTIP",
				def = "192.168.1.100"
			},
			new Init_xml
			{
				name = "Port",
				def = "8200"
			},
			new Init_xml
			{
				name = "Speed",
				def = "115200"
			},
			new Init_xml
			{
				name = "SERVICEIP",
				def = "127.0.0.1"
			},
			new Init_xml
			{
				name = "SERVICEPort",
				def = "8800"
			},
			new Init_xml
			{
				name = "SERVKKTID",
				def = "0"
			},
			new Init_xml
			{
				name = "OFDIP",
				def = "109.73.43.4"
			},
			new Init_xml
			{
				name = "OFDPort",
				def = "19086"
			},
			new Init_xml
			{
				name = "CASHIER",
				def = "Гадя Петрович Хренова"
			},
			new Init_xml
			{
				name = "COM",
				def = ""
			},
			new Init_xml
			{
				name = "CRC",
				def = ""
			},
			new Init_xml
			{
				name = "Print",
				def = "0"
			},
			new Init_xml
			{
				name = "OISMIP",
				def = "82.202.183.18"
			},
			new Init_xml
			{
				name = "OISMPort",
				def = "21701"
			},
			new Init_xml
			{
				name = "OKPIP",
				def = "prod01.okp-fn.ru"
			},
			new Init_xml
			{
				name = "OKPPort",
				def = "26101"
			},
			new Init_xml
			{
				name = "FWUPLOAD",
				def = "0"
			},
			new Init_xml
			{
				name = "FW_FILE",
				def = ""
			},
			new Init_xml
			{
				name = "KKTSERIAL",
				def = "0"
			}
		};

		private static readonly Init_xml[] init_km_list = new Init_xml[9]
		{
			new Init_xml
			{
				name = "M0",
				def = "010123456789012321M,7aL0JDGbJCWa\\x1D91808B\\x1D92CuE2b4wBhPv9XeoBQDEux9wOKeNR4vf4I+q/QbhqzhRGyYQymkkpgtAZUtPHlfp0THGVN6i+D8ZxZQcbTnvEMg=="
			},
			new Init_xml
			{
				name = "M1",
				def = "010123456789012321XHe\"ImQ>*A&jOL\\x1D91808B\\x1D92BCBr3YRDprM1AAWPkjE/RatPM7XyltEtqOTV4Y9bOtnegQLzeh1OVuOZHMfQDSMqTnXjIcM8Yb20qLr4d+Ykfg=="
			},
			new Init_xml
			{
				name = "M2",
				def = "010464007801637221AgqLybqxM9MbR\\x1D91FFD0\\x1D92dGVzdL31KAYL0YT6592MjmW7a2HkF3IY+muf2pVSKdQ="
			},
			new Init_xml
			{
				name = "M3",
				def = "0104810112011285215w9SXTP,Y?VOC93gbra"
			},
			new Init_xml
			{
				name = "M4",
				def = "0103041094787443215GsjdH\\x1D93dGVz"
			},
			new Init_xml
			{
				name = "M5",
				def = "0103041094787443215fdhd?\\x1D93dGVz"
			},
			new Init_xml
			{
				name = "M6",
				def = "00000046210654vC:Jp87AAPidGVz"
			},
			new Init_xml
			{
				name = "M7",
				def = "00000046210654>i0Tq)PAAPidGVz"
			},
			new Init_xml
			{
				name = "M8",
				def = "029000023778429HsSUuwACW.OdXx"
			}
		};

		private readonly string[] phase_message = new string[4] { ".Готов к регистации", ".Работа с формир.ФД", ".Информ.обмен с ОФД", ".Доступ к архиву ФД" };

		private readonly string[] mark_message = new string[5] { ".Таблица КМ переполнена", ".Нет КМ на проверке", ".Передан КМ (B1)", ".Запрос B5 сформирован", ".Ответ B6 передан" };

		private readonly string[] notice_message = new string[3] { ".Не формируется", ".Начато", ".Заблокировано" };

		private readonly string[] warning_message = new string[5] { " (0-50%)", " (50-80%)", " (80-90%)", " (90-99%)", " (100%)" };

		private readonly string[] notice2_message = new string[3] { ".Не передаются", ".Начато чтение", ".Ожид. квитанции" };

		private readonly string[] client_message = new string[2] { ".Внутренний", ".Внешний" };

		private readonly string[] update_message = new string[3] { ".Обновление не треб.", ".Обновить 15-60 дней", ".Обновить >60 дней" };

		private bool corr = false;

		private bool stop_send = true;

		private Notice notice = new Notice(-1, -1);

		private int[] notice_crc = new int[1000];

		private Key key = new Key(-1);

		private readonly string LogFolder = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + "\\";

		private IContainer components = null;

		private TabControl tabControl_Main;

		private TabPage tabPage_Main;

		private TabPage tabPage_Commands;

		private TabPage tabPage_OISM;

		private TabPage tabPage_Transaction;

		private Panel panel_Ticket_Type_and_Tax;

		private GroupBox groupBox_OCh;

		private Label label_Check_Total;

		private Label label_Check_Items;

		private NumericUpDown nUpDown_VpCheck;

		private NumericUpDown nUpDown_CrCheck;

		private NumericUpDown nUpDown_AvCheck;

		private NumericUpDown nUpDown_ElCheck;

		public TextBox textBox_ItemCnt_Check;

		public TextBox textBox_Total_Check;

		private TabPage tabPage_Registration;

		private TabPage tabPage_OFD;

		private GroupBox groupBox_ReadMSG;

		private Panel panel_ReadMSG;

		private Button button_ReadMSG;

		private Button button_EndMSG;

		private Button button_CancelMSG;

		private Button button_ReadBlockMSG;

		private NumericUpDown numericUpDown_OffsetBlock;

		private NumericUpDown numericUpDown_LengthBlock;

		private Label label_OffsetMSG;

		private Label label_LengthMSG;

		private TextBox textBox_IP_OFD;

		private Label label_PortOFD;

		private Label label_AddressOFD;

		private NumericUpDown numericUpDown_Port_OFD;

		private TabPage tabPage_Settings;

		private GroupBox groupBox_LANSettings;

		private Panel panel_LANSettings;

		private Panel panel_LAN_Buttons;

		private Button button_LAN_Get;

		private Button button_LAN_Set;

		private Button button_Setup_Get;

		private Button button_Setup_Set;

		private GroupBox groupBox_Connection;

		private GroupBox groupBox_FNControl;

		private Panel panel_FNControl;

		private Button button_ResetMGM;

		private TabPage tabPage_Electronic;

		private GroupBox groupBox_EForm;

		private Button button_ReadAllCheck;

		private Panel panel_CheckEF;

		private NumericUpDown numericUpDown_EFCheckNumber;

		private GroupBox groupBox_XML_Document;

		private Panel panel_XML0;

		private Button button_ReadXML;

		private Panel panel_XML2;

		private NumericUpDown numericUpDown_XMLDocNum;

		private GroupBox groupBox_AutoReceipt;

		private Button button_AutoReceipt;

		private TextBox textBox_ItemTemplate;

		private Panel panel_ProduceRcpt;

		private NumericUpDown numericUpDown_AutoReceiptItemNo;

		private CheckBox checkBox_XML_SaveToFile;

		private CheckBox checkBox_SaveElCheck;

		private TabPage tabPage_Header;

		private Button button_SendAllToOFD;

		private Button button_OFD_MSG;

		private CheckBox checkBox_InternalOFD;

		private GroupBox groupBox_ManualCommand;

		private Panel panel_ManualCommand;

		private Button button_ManualCommand;

		private ComboBox comboBox_Setup_Rounding;

		private TextBox textBox_CardNumber;

		private Button button_GetTicketOFD;

		public DataGridView dataGrid_LAN;

		private NumericUpDown numericUpDown_AutoReceiptRepeat;

		private OpenFileDialog openFileDialog1;

		private CheckBox checkBox_StatusLog;

		private CheckBox checkBox_XML_Archive;

		private ComboBox comboBox_Setup_COMBaudrate;

		private GroupBox groupBox_DateTime;

		private Panel panel_DateTimeFW;

		private Button button_SetDateTime;

		private Button button_GetDateTime;

		private GroupBox groupBox_Cashier;

		private Button button_ShiftStatus;

		private Button button_VerKKT;

		private Button button_StatePrinter;

		private Button button_CloseShift;

		private CheckBox checkBox_StatusPrint;

		private GroupBox groupBox_Shift;

		private Button button_OpenShift;

		private GroupBox groupBox_Document;

		private Panel panel_DocControls;

		private Button button_DocCancel;

		private Button button_GetDocStatus;

		private Panel panel_ShiftControls;

		private Button button_FinReport;

		private Panel panel_FD_Type;

		private Button button_GetTypeDoc;

		private TextBox textBox_TypeFD;

		private Button button_PrintDoc_Arc;

		private Button button_PrintDoc;

		private NumericUpDown numericUpDown_FD;

		private Button button_PowerReset;

		private Panel panel_ItemName;

		private Panel panel_AutoReceipt;

		private TabPage tabPage_NonFiscal;

		private Button button_CreateTXTDoc;

		private CheckBox checkBox_IncludeHeader;

		private GroupBox groupBox_TransactionTax;

		private RadioButton radioButton_Tax0;

		private RadioButton radioButton_Tax1;

		private RadioButton radioButton_Tax2;

		private RadioButton radioButton_Tax3;

		private RadioButton radioButton_Tax4;

		private RadioButton radioButton_Tax5;

		private Panel panel_Ticket_Tax;

		private GroupBox groupBox_TransactionType;

		private Panel panel_Ticket_Type;

		private RadioButton radioButton_Type1;

		private RadioButton radioButton_Type2;

		private RadioButton radioButton_Type3;

		private RadioButton radioButton_Type4;

		private Panel panel_TicketClose;

		private Button button_CheckOpen;

		private CheckBox checkBox_Ticket_User;

		private Panel panel_Ticket_Open;

		private Panel panel_Ticket_Item;

		private Button button_CheckCorr;

		private Button button_GetShiftData;

		private Panel panel_Bottom;

		private ToolTip toolTip1;

		private Button button_AddItem;

		private TextBox textBox_ItemName;

		private Label label_ItemPrice;

		private NumericUpDown numeric_ItemPrice;

		private Label label_ItemNDS;

		private ComboBox comboBox_ItemNDS;

		private Label label_ItemAmount;

		private NumericUpDown numeric_ItemQty;

		private Label label_ItemType;

		private ComboBox comboBox_ItemType;

		private NumericUpDown numeric_ItemExcise;

		private Label label_ItemCountry;

		private Label label_ItemExcise;

		private TextBox textBox_ItemCountry;

		private TextBox textBox_ItemCustomNo;

		private CheckBox checkBox_ItemOptions;

		private Panel panel_TicketPay;

		private Button button_Payment;

		private Panel panel_Ticket_Total;

		private Button button_Total;

		public TextBox textBox_Round_Check;

		private Label label_Round_Check;

		private Label label_Pay_Prov;

		private Label label_Pay_Credit;

		private Label label_Pay_Prepaid;

		private Label label_Pay_Card;

		private NumericUpDown nUpDown_NalCheck;

		private Panel panel_Connection;

		private Panel panel_DateTimeFrame;

		private Button button_CCh;

		private Panel panel_CashierFrame;

		private Button button_PrintXreport;

		private Panel panel_DocumentFrame;

		private Panel panel_ShiftFrame;

		private Panel panel_ManualCommandFrame;

		private Panel panel_AutoReceiptFrame;

		private Panel panel_FNControlFrame;

		private Button button_PaperCut;

		private ContextMenuStrip contextMenuStrip_Log;

		private ToolStripMenuItem clearAllToolStripMenuItem;

		private ToolStripMenuItem copyAllToolStripMenuItem;

		private ToolStripMenuItem copyToolStripMenuItem;

		private CheckBox checkBox_Pay_Cash;

		private Label label_VerKKT;

		private Panel panel_ScriptFrame;

		private GroupBox groupBox_Script;

		private Panel panel_Script;

		private Button button_Script;

		private Panel panel_Cashier;

		private Panel panel_CashierName;

		private TextBox textBox_CashierName;

		private Label label_CashierName;

		private Panel panel_CashierTaxID;

		private TextBox textBox_CashierTaxID;

		private Label label_CashierTaxID;

		private Panel panel_SetCashier;

		private Button button_SetCashier;

		private Panel panel_GetCashier;

		private Button button_GetCashier;

		private CheckedListBox checkedListBox_LAN;

		private CheckBox checkBox_LAN_SelectAll;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_LAN;

		private Label label_AutoReceiptName;

		private Label label_AutoReceiptRepeat;

		private Label label_AutoReceiptItemNo;

		private GroupBox groupBox_Setup;

		private Panel panel_Setup_Buttons;

		private CheckBox checkBox_Setup_SelectAll;

		private Panel panel_Setup_SelectAll;

		private Panel panel_Setup_COMBaudrate;

		private CheckBox checkBox_Setup_COMBaudrate;

		private Panel panel_PrinterModel;

		private ComboBox comboBox_Setup_PrinterModel;

		private CheckBox checkBox_Setup_PrinterModel;

		private Panel panel_Setup_FontType;

		private CheckBox checkBox_Setup_FontType;

		private Panel panel_Setup_PaperWidth;

		private CheckBox checkBox_Setup_PaperWidth;

		private Panel panel_Setup_Rounding;

		private CheckBox checkBox_Setup_Rounding;

		private Panel panel_Setup_QRAlign;

		private CheckBox checkBox_Setup_QRAlign;

		private Panel panel_Setup_PaperCut;

		private CheckBox checkBox_Setup_PaperCut;

		private Panel panel_Setup_LineType;

		private ComboBox comboBox_Setup_LineType;

		private CheckBox checkBox_Setup_LineType;

		private Button button_Drawer_Open;

		private Button button_Drawer_Status;

		private ContextMenuStrip contextMenuStrip_Reg;

		private ToolStripMenuItem сalculateToolStripMenuItem;

		private ToolStripMenuItem verifyToolStripMenuItem;

		private Panel panel_Setup;

		private RadioButton radio_Setup_PaperCut_No;

		private RadioButton radio_Setup_PaperCut_Yes;

		private RadioButton radio_Setup_Paper57mm;

		private RadioButton radio_Setup_Paper80mm;

		private RadioButton radio_Setup_FontB;

		private RadioButton radio_Setup_FontA;

		private Panel panel_Setup_80_57;

		private Panel panel_Setup_PaperCut_Y_N;

		private Panel panel_Setup_A_B;

		private Panel panel_Setup_PrBaudrate;

		private ComboBox comboBox_Setup_PrBaudrate;

		private CheckBox checkBox_Setup_PrBaudrate;

		private Panel panel_Reg3;

		private GroupBox groupBox_Reason11;

		private CheckedListBox checkedListBox_Reason11;

		private Panel panel_Reg1;

		private Label label_Calculate;

		private Panel panel_RegBottom;

		private Label label_RegNo;

		private NumericUpDown numericUpDown_ReRegNumber;

		private Button button_GetRegData;

		private Button button_Reg;

		private Button button_PrintReRegTicket;

		private CheckBox checkBox_ReReg;

		private Panel panel_Reg2;

		private CheckedListBox checkedListBox_ModeB;

		private GroupBox groupBox_OpMode;

		private CheckedListBox checkedListBox_ModeA;

		private GroupBox groupBox_Taxes;

		private CheckedListBox checkedListBox_Taxes;

		private GroupBox groupBox_RegData;

		public DataGridView dataGrid_RegData;

		private DataGridViewTextBoxColumn Column_RegData;

		private Label label_RegData;

		private GroupBox groupBox_Header;

		private Panel panel_HeaderSet;

		private Button button_HeaderSet;

		private Button button_HeaderGet;

		private Panel panel_HeaderSel;

		private CheckBox checkBox_HeaderKeep;

		private RadioButton radioButton_Header4;

		private RadioButton radioButton_Header3;

		private RadioButton radioButton_Header2;

		private RadioButton radioButton_Header1;

		private Button button_PowerSet;

		private CheckBox checkBox_PowerFlag;

		private Button button_PowerGet;

		private Label label_Header;

		private Button button_KKTSerialSet;

		private Button button_RunTest;

		private Label label_SerialNo;

		private Panel panel_KKTSerial;

		private NumericUpDown numeric_KKTSerial;

		private GroupBox groupBox_TextLines;

		private Panel panel_TextFormat;

		private Panel panel_TextEntries;

		private Panel panel_TextLines;

		private Panel panel_TextLinesCheckBoxes;

		private CheckedListBox checkedListBox_TextLines;

		private Label label_TextLinesTip;

		private Panel panel_Header;

		private Panel panel_HeaderList;

		public DataGridView dataGrid_Header4;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_Header4;

		public DataGridView dataGrid_Header3;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_Header3;

		public DataGridView dataGrid_Header2;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_Header2;

		public DataGridView dataGrid_Header1;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_Header;

		private Panel panel_HeaderCheckList;

		public DataGridView dataGrid_TextLines;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_TextLines;

		private TextBox textBox_txt_Barcode;

		private CheckBox checkBox_txt_Barcode;

		private CheckBox checkBox_txt_Image;

		private CheckBox checkBox_txt_Line;

		private Panel panel_RegNo;

		private Button button_Verify;

		private Button button_Calculate;

		private Button button_Duplicate0;

		private Panel panel_RadioCOM;

		private Label label_Service_ID;

		private TextBox textBox_Service_Port;

		private Label label_Service_Port;

		private TextBox textBox_Service_IP;

		private Label label_Service_IP;

		private RadioButton Ser_Button;

		private TextBox textBox_PortNo;

		private Panel panel_COMRefresh;

		private Label label_COMBaudRate;

		private ComboBox comboBox_COMBaudRate;

		private RadioButton Lan_Button;

		private Label label_Port;

		private TextBox textBox_KKT_IP;

		private Label label_IPAddress;

		private ComboBox comboBox_Command;

		private Panel panel_XML1;

		private Label label_XML1;

		private Panel panel_XML_Document;

		private Panel panel_XML4;

		private Panel panel_FD0;

		private GroupBox groupBox_FD;

		private Panel panel_FD;

		private Panel panel_FD2;

		private Panel panel_FD1;

		private Label label_FD;

		private GroupBox groupBox_OFD_Ticket;

		private Panel panel_OFD_Ticket;

		private NumericUpDown numericUpDown_OFD_Ticket;

		private Button button_DocFromFN;

		private NumericUpDown numericUpDown_FromFN;

		private TabPage tabPage_Status;

		private GroupBox groupBox_Status_FN;

		private Panel panel_Status_FN;

		private Label label_Status_FN;

		public DataGridView dataGrid_Status_FN;

		private Button button_Status_FN;

		private Panel panel_Totals_FN;

		private Button button_Totals_FN;

		private Panel panel_Status_FN1;

		private Label label_Totals_FN;

		public DataGridView dataGrid_Totals_FN;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;

		private DataGridViewTextBoxColumn Column_Sales_FN;

		private DataGridViewTextBoxColumn Column_Refund_FN;

		private Label label_Totals_Sales;

		private Label label_Totals_Refund;

		public DataGridView dataGrid_Tax_FN;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;

		private Label label_Tax_FN;

		private ComboBox comboBox_Beznal;

		private GroupBox groupBox_Status_OFD;

		private Panel panel_Status_OFD;

		private Panel panel_Status_OFD1;

		private Button button_Status_OFD;

		public DataGridView dataGrid_Status_OFD;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;

		private Label label_Status_OFD;

		private Button button_Status_DM;

		public DataGridView dataGrid_Status_DM1;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;

		private Label label_Status_DM;

		private CheckedListBox checkedListBox_beznal;

		public DataGridView dataGrid_beznal;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;

		private ComboBox comboBox_ItemMeasure;

		private Panel panel_Setup_AutoTest;

		private Panel panel_Setup_AutoTest_Y_N;

		private RadioButton radio_Setup_AutoTest_Yes;

		private RadioButton radio_Setup_AutoTest_No;

		private CheckBox checkBox_Setup_AutoTest;

		private RadioButton radio_txt_QR_Right;

		private RadioButton radio_txt_QR_Left;

		private RadioButton radio_txt_QR_Center;

		private CheckBox checkBox_txt_QR;

		private TextBox textBox_txt_QR;

		private Panel panel_Setup_DrawerOpen;

		private Panel panel_Setup_DrawerOpen_Y_N;

		private CheckBox checkBox_Setup_Cash;

		private CheckBox checkBox_RegNum;

		private Button button_RunSales;

		public TextBox textBox_Accum_Total;

		private Button button_FCh;

		private Button button_FW_Download;

		private GroupBox groupBox_Picture;

		private PictureBox pictureBox_Picture;

		private Panel panel_Picture;

		private Button button_Picture;

		private NumericUpDown numericUpDown_Picture;

		private GroupBox groupBox_Logo;

		private PictureBox pictureBox_Logo;

		private Panel panel_Logo;

		private TextBox textBox_Logo;

		private Button button_Logo;

		private Button button_PictureShow;

		private Button button_LogoShow;

		private CheckBox checkBox_FW_CRC;

		private TextBox textBox_FW_CRC;

		private Panel panel_Setup_Beeper;

		private Panel panel_Setup_Beeper_Y_N;

		private RadioButton radio_Setup_Beeper_Yes;

		private RadioButton radio_Setup_Beeper_No;

		private CheckBox checkBox_Setup_Beeper;

		private Label label_ShiftData;

		private Label label_DocStatus;

		public DataGridView dataGrid_Status_DM2;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;

		private Label label_Status_DM2;

		private Button button_EraseSPI;

		private Button button_FW_Update;

		private Label label_FNS;

		private Button button_DocCancel1;

		private NumericUpDown numericUpDown_Service_ID;

		private Panel panel_Reports;

		private GroupBox groupBox_Reports;

		private Panel panel_ReportControls;

		private Panel panel_Status_FN2;

		private Panel panel_DataMark;

		private Panel panel_Status_FN3;

		private Label label_Acc_Total;

		private Panel panel_Status_OFD3;

		private Panel panel_Status_OFD2;

		private ComboBox comboBox_Language;

		private ComboBox comboBox_Setup_QRAlign;

		private CheckBox checkBox_ItemSeparator;

		private GroupBox groupBox_HeaderAlign;

		private ComboBox comboBox_HeaderAlign;

		private GroupBox groupBox_HeaderUnderline;

		private ComboBox comboBox_HeaderUnderline;

		private GroupBox groupBox_HeaderFont;

		private ComboBox comboBox_HeaderFont;

		private GroupBox groupBox_CharHeight;

		private NumericUpDown numericUpDown_CharHeight;

		private GroupBox groupBox_CharWidth;

		private NumericUpDown numericUpDown_CharWidth;

		private GroupBox groupBox_HeaderInverse;

		private CheckBox checkBox_HeaderInverse;

		private Panel panel_LogoPic;

		private Button button_LogoErase;

		private Button button_PictureErase;

		private CheckBox checkBox_Drawer_Nal;

		private CheckBox checkBox_Drawer_Beznal;

		private Panel panel_FWControlFrame;

		private GroupBox groupBox_FWControl;

		private Panel panel_FWControl;

		private CheckBox checkBox_FW_Hex;

		private Button button_FW_Status;

		private Panel panel_OFDSettings;

		private GroupBox groupBox_OFDSettings;

		public DataGridView dataGrid_OFD;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;

		private CheckedListBox checkedListBox_OFD;

		private Label label_Header_Lines;

		private Button button_HeaderDel;

		private Panel panel_Setup_QRText;

		private Panel panel_Setup_QRText_Y_N;

		private RadioButton radio_Setup_QRText_Yes;

		private RadioButton radio_Setup_QRText_No;

		private CheckBox checkBox_Setup_QRText;

		private Button button_OptShiftData;

		private Panel panel_OISM_Settings;

		private GroupBox groupBox_OISMSettings;

		public DataGridView dataGrid_OISM;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;

		private CheckedListBox checkedListBox_OISM;

		private Panel panel_OKP_Settings;

		private GroupBox groupBox_OKPSettings;

		public DataGridView dataGrid_OKP;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;

		private CheckedListBox checkedListBox_OKP;

		private Label label_LAN_Gateway;

		private Label label_LAN_DNS;

		private Label label_LAN_Port;

		private Label label_LAN_Mask;

		private Label label_LAN_IP;

		private CheckBox checkBox_OFD_Client;

		private Label label_OFD_IP;

		private Label label_OFD_Port;

		private Label label_OFD_TimerOFD;

		private Label label_TimerFN;

		private Label label_OFD_Client;

		private Label label_OKP_IP;

		private Label label_OKP_Port;

		private Label label_OISM_IP;

		private Label label_OISM_Port;

		private Panel panel_Setup_ItemCnt;

		private Panel panel_ItemCntYesNo;

		private RadioButton radio_Setup_ItemCnt_Yes;

		private RadioButton radio_Setup_ItemCnt_No;

		private CheckBox checkBox_Setup_ItemCnt;

		private TextBox textBox_RegDateTime;

		private CheckBox checkBox_Arc;

		private CheckBox checkBox_OptShiftData;

		private Button button_CheckCustomer;

		private Panel panel_beznal;

		private Button button_GetFullData;

		private CheckBox checkBox_Reg_FFD12;

		private Panel panel_txt_Pic_Align;

		private RadioButton radio_txt_Pic_Right;

		private RadioButton radio_txt_Pic_Center;

		private RadioButton radio_txt_Pic_Left;

		private Panel panel_txt_QR_Align;

		private GroupBox groupBox_SendMSG;

		private Panel panel_OFD_Send;

		private Button button_StopSendAllToOFD;

		private TextBox textBox_PendingMSG;

		private Label label_RemainingMSG;

		private Label label_OFD_Ticket;

		private DateTimePicker dateTimePicker_Current;

		private Button button_CheckOptions;

		private Button button_Text;

		private Panel panel_AddItem;

		private GroupBox groupBox_AddItem;

		private Panel panel_TicketOpen;

		private GroupBox groupBox_TicketOpen;

		private Panel panel_Ticket_Option2;

		private Panel panel_Ticket_Option21;

		private Panel panel_Ticket_Option1;

		private Panel panel_Ticket_ItemAddTest;

		private Label label_ItemCustomNo;

		private Label label_PaymentType;

		private CheckBox checkBox_Fraction;

		private Panel panel_Ticket_Option3;

		private NumericUpDown numeric_QtyDenom;

		private NumericUpDown numeric_QtyNom;

		private Panel panel_Ticket_Option31;

		private Label label_PricePerPiece;

		private NumericUpDown numericUpDown_PricePerPiece;

		private TextBox textBox_Ticket_FoivNo;

		private DateTimePicker dateTimePicker_FoivDate;

		private Panel panel_Ticket_Option4;

		private TextBox textBox_Ticket_Foiv;

		private TextBox textBox_Ticket_FoivID;

		private Button button_ItemAgent;

		private Panel panel_Ticket_Option41;

		private Label label_FoivDate;

		private Label label11;

		private Label label12;

		private Label label13;

		private Label label_Qty_Nom_Denom;

		private GroupBox groupBox_Mark;

		private Panel panel_Mark_Data;

		private TextBox textBox_ItemID;

		private Panel panel_Mark_Header;

		private Label label_ItemID;

		private Label label_ItemStatus;

		private TextBox textBox_ItemDR;

		private Label label_ItemDR;

		private ComboBox comboBox_PaymentType;

		private ComboBox comboBox_TypeOfCode;

		private Label label_TypeOfCode;

		private ComboBox comboBox_ItemStatus;

		private NumericUpDown numeric_ItemAmount;

		private Button button_RestartFN;

		private Button button_ResetPrinter;

		private Button button_MarkVerify;

		private CheckBox checkBox_ShowResult;

		private Button button_MarkResult;

		private Button button_CloseFN;

		private GroupBox groupBox_ReadNotice;

		private Panel panel_ReadNotice;

		private NumericUpDown numeric_ReadNoticeLength;

		private Label label_ReadNoticeLength;

		private NumericUpDown numeric_ReadNoticeOffset;

		private Label label_ReadNoticeOffset;

		private Button button_ReadNotice;

		private Button button_ReadNoticeCancel;

		private Button button_ReadNoticeEnd;

		private Button button_ReadNoticeStart;

		private GroupBox groupBox_SendNotice;

		private Panel panel_OISM_Send;

		private Button button_SendNoticeStop;

		private TextBox textBox_PendingNotice;

		private Button button_SendNoticeAll;

		private CheckBox checkBox_NoticeParse;

		private TextBox textBox_AddressOISM;

		private NumericUpDown numericUpDown_PortOISM;

		private Button button_SendNoticeOne;

		private Label label_AddressOISM;

		private Label label_PendingNotice;

		private Label label_PortOISM;

		private GroupBox groupBox_OKP;

		private Panel panel_OKP_Update;

		private Button button_KeyUpdateAll;

		private Button button_KeyUpdate;

		private TextBox textBox_AddressOKP;

		private NumericUpDown numericUpDown_PortOKP;

		private Label label_AddressOKP;

		private Label label_PortOKP;

		private CheckBox checkBox_Autonom;

		private Panel panel_ItemMark;

		private CheckBox checkBox_ItemMark;

		private TextBox textBox_ItemCode;

		private Label label_ItemCode;

		private Button button_MarkReset;

		private Button button_MarkClear;

		private CheckBox checkBox_NoticeAutonom;

		private TextBox textBox_NoticeOffline;

		private Label label_NoticeOffline;

		private Panel panel_NoticeOffline;

		private Label label_NoticeCRC;

		private TextBox textBox_NoticeCRC;

		private Button button_GetTicketXML;

		private SaveFileDialog saveFileDialog_Notice;

		private RichTextBox richTextBox_Log;

		public DataGridView dataGrid_Status_DM3;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;

		private Label label_Status_DM3;

		private ComboBox comboBox_Mark;

		private Panel panel_Baudrate;

		private Panel panel_LAN;

		private Panel panel_Service;

		private Panel panel_RadioButtons;

		private CheckBox checkBox_Agent;

		private CheckBox checkBox_PreCheck;

		private CheckBox checkBox_Foiv;

		private Label label_Beznal;

		private Label label_Beznal_Type;

		private Button button_Log_Dump;

		private TextBox textBox_Dump1;

		private TextBox textBox_Dump2;

		private Panel panel_Setup_PrstTime;

		private NumericUpDown numeric_Setup_PrstTime;

		private CheckBox checkBox_Setup_PrstTime;

		private Panel panel_Setup_Prst;

		private CheckBox checkBox_Setup_Prst;

		private ComboBox comboBox_Setup_Prst;

		private Panel panel_Unused;

		private CheckBox checkBox_StatusAutonom;

		private CheckBox checkBox_ItemSpace;

		private CheckBox checkBox_CashierKeep;

		private Button button_COMScan;

		private Button button_FW_Upload;

		private CheckBox checkBox_Footer;

		private CheckBox checkBox_ItemCount;

		private Panel panel_Setup_COMBaudrateValue;

		private Panel panel_Setup_PrstValue;

		private Panel panel_Setup_LineTypeValue;

		private Panel panel_Setup_RoundingValue;

		private Panel panel_Setup_QRAlignValue;

		private Panel panel_PrinterModelValue;

		private Panel panel_Setup_PrBaudrateValue;

		private Panel panel_Setup_DrawerPin;

		private NumericUpDown numericUpDown_Setup_DrawerPin;

		private CheckBox checkBox_Setup_DrawerPin;

		private Panel panel_Setup_DrawerPulse;

		private NumericUpDown numericUpDown_Setup_DrawerPulse;

		private CheckBox checkBox_Setup_DrawerPulse;

		private Panel panel_Setup_DrawerFall;

		private NumericUpDown numericUpDown_Setup_DrawerFall;

		private CheckBox checkBox_Setup_DrawerFall;

		private Panel panel_Setup_OFDClient;

		private RadioButton radio_Setup_OFDClient_Internal;

		private RadioButton radio_Setup_OFDClient_External;

		private Label label_txt_QR_DotSize;

		private Label label_txt_QR_Level;

		private NumericUpDown numeric_txt_QR_DotSize;

		private NumericUpDown numeric_txt_QR_Level;

		private TextBox textBox_txt_QRText;

		private CheckBox checkBox_txt_QRText;

		private Label label_txt_BarcodeHeight;

		private Label label_txt_BarcodeType;

		private Label label_txt_BarcodeWidth;

		private NumericUpDown numeric_txt_BarcodeHeight;

		private NumericUpDown numeric_txt_BarcodeWidth;

		private ComboBox comboBox_txt_BarcodeType;

		private Label label_txt_PictureNo;

		private Label label_txt_Pic_Align;

		private NumericUpDown numeric_txt_PictureNo;

		private ComboBox comboBox_txt_LineType;

		private Label label_LineType;

		private NumericUpDown numeric_Discount;

		private Label label_Discount;

		private Label label_Script;

		private Label label_Drawer;

		private Label label_PaperCut;

		private Label label_Restart;

		private TextBox textBox_FW_File;

		private Button button_FW_Download_Update;

		private CheckBox checkBox_Setup_Reload;

		private Button button_ReadXML_Arc;

		private string Check_type_and_tax_system => Att("TYPE", radioButton_Type1.Checked ? "1" : (radioButton_Type2.Checked ? "2" : (radioButton_Type3.Checked ? "3" : "4"))) + Att("TAX", radioButton_Tax0.Checked ? "0" : (radioButton_Tax1.Checked ? "1" : (radioButton_Tax2.Checked ? "2" : (radioButton_Tax3.Checked ? "3" : (radioButton_Tax4.Checked ? "4" : "5")))));

		private string Item_attribute => Att("ITEM", numeric_ItemQty.Value.ToString("0.######", nfi)) + Att("UNIT", Item_measure) + ((comboBox_ItemStatus.SelectedIndex < 1) ? "" : Att("ST", comboBox_ItemStatus.Text.Split('.')[0]));

		private string Item_value => (!checkBox_Fraction.Checked) ? "" : ("<QTY" + Att("PART", numeric_QtyNom.Value.ToString()) + Att("OF", numeric_QtyDenom.Value.ToString()) + "/>");

		private string Item_name => Tag("Name", textBox_ItemName.Text);

		private string Item_attributes => Att("Tax", (comboBox_ItemNDS.SelectedIndex + 1).ToString()) + Att("Price", Convert.ToUInt32(numeric_ItemPrice.Value * 100m).ToString()) + Att("Total", amount2string(numeric_ItemAmount)) + Att("Unit", Item_measure) + Att("Type", Item_type) + Att("Mode", combo2string(comboBox_PaymentType)) + Att("T1229", amount2string(numeric_ItemExcise)) + Att("T1230", textBox_ItemCountry.Text) + Att("T1231", textBox_ItemCustomNo.Text) + Att("T1191", (textBox_ItemDR.ForeColor == SystemColors.ControlText) ? textBox_ItemDR.Text : string.Empty);

		private string Item_KM => Tag("KM", HexString(comboBox_Mark.Text));

		private bool Command_Check_Begin => Command_OK(CMD.DO_CHECK, "BEGIN", null, null, null, 0L);

		private bool Command_Corr_Begin => Command_OK(CMD.DO_CHECK, "CORR", Check_type_and_tax_system, null, Correction_Data.Value, 0L);

		private bool Command_Cash_Pay
		{
			get
			{
				XAttribute xAttribute = x_answer.Root.Attribute("TOTAL");
				if (xAttribute == null)
				{
					return false;
				}
				return Command_OK(CMD.DO_CHECK, "PAY", Att("PA", xAttribute.Value), null, null, 0L);
			}
		}

		private bool Command_Check_Total => Command_OK(CMD.DO_CHECK, "TOTAL", null, null, null, 0L);

		private bool Command_Check_End => Command_OK(CMD.DO_CHECK, "END", null, null, null, 9999L);

		private bool Command_Check_Close => Command_OK(CMD.DO_CHECK, "CLOSE", null, null, null, 0L);

		public SerialPort ComFiscalReg { get; private set; } = null;


		public LanDriver LanFiscalReg { get; private set; } = null;


		public LanDriver ServiceFiscalReg { get; private set; } = null;


		private bool ComFiscalReg_IsOpen => ComFiscalReg != null && ComFiscalReg.IsOpen;

		private string Item_measure => comboBox_ItemMeasure.Text.Split('.')[0];

		private string Item_type => (comboBox_ItemType.SelectedIndex == 0) ? "" : comboBox_ItemType.Text.Split('.')[0];

		private string Item_ST
		{
			get
			{
				if (comboBox_ItemStatus.SelectedIndex >= 1)
				{
					return comboBox_ItemStatus.Text.Split('.')[0];
				}
				if (radioButton_Type2.Checked || radioButton_Type4.Checked)
				{
					return (Item_measure == "1" && !checkBox_Fraction.Checked) ? "3" : "4";
				}
				return (Item_measure == "1" && !checkBox_Fraction.Checked) ? "1" : "2";
			}
		}

		private string Item_FOIV
		{
			get
			{
				if (!checkBox_Foiv.Checked)
				{
					return "";
				}
				string text = "";
				if (textBox_Ticket_FoivID.ForeColor == SystemColors.ControlText)
				{
					text += Tag(1262, textBox_Ticket_FoivID.Text);
				}
				if (dateTimePicker_FoivDate.Checked)
				{
					text += Tag(1263, dateTimePicker_FoivDate.Value.ToString("dd.MM.yyyy"));
				}
				if (textBox_Ticket_FoivNo.ForeColor == SystemColors.ControlText)
				{
					text += Tag(1264, textBox_Ticket_FoivNo.Text);
				}
				if (textBox_Ticket_Foiv.ForeColor == SystemColors.ControlText)
				{
					text += Tag(1265, textBox_Ticket_Foiv.Text);
				}
				return Tag(1260, text);
			}
		}

		private bool Skip_OISM => checkedListBox_ModeA.GetItemChecked(6) | checkedListBox_ModeA.GetItemChecked(7) | checkedListBox_ModeB.GetItemChecked(7);

		private string Print_Attribute => checkBox_StatusPrint.Checked ? " Print='1'" : "";

		private string Print_0_Attribute => checkBox_StatusPrint.Checked ? "" : " Print='0'";

		private string Footer_Attribute => checkBox_Footer.Checked ? " F='1'" : "";

		private string beznal_cmt(string typ, string cmt)
		{
			return "<CMT" + typ + ">" + cmt + "</CMT>";
		}

		private void Init_Spark_Mitsu()
		{
			InitFileName = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + "\\MitsuCube.xml";
			SparkSerialFile = new FileStream(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + "\\Mitsu Serial.txt", FileMode.Append);
			LoadLanguage();
			InitializeComponent();
			Text = Lng.GetStr("MITSU Developer's Tool v", "Утилита MITSU v") + typeof(MainForm).Assembly.GetName().Version;
			base.Icon = Resources.Mitsu;
			panel_Service.Visible = false;
			checkBox_CashierKeep.Visible = false;
			label_SerialNo.Text = "06500";
			panel_Setup_ItemCnt.Visible = true;
			checkBox_Footer.Visible = false;
			CheckBox checkBox = checkBox_HeaderKeep;
			bool visible = (checkBox_HeaderKeep.Enabled = false);
			checkBox.Visible = visible;
			Shift_Options = new ShiftOptionForm('T');
			comboBox_Setup_PrinterModel.Items.Clear();
			comboBox_Setup_PrinterModel.Items.AddRange(new object[5] { "Без принтера", "Mitsu RP-809", "Mitsu F80", "N/A", "N/A" });
			checkedListBox_ModeA.Items.Clear();
			checkedListBox_ModeA.Items.AddRange(new object[8] { "Шифрование                 @T1056", "Автономный                 @T1002", "Автоматич.                 @T1001", "Сфера услуг                @T1109", "Режим БСО                  @T1110", "ККТ в Интернет             @T1108", "Общепит                    @DINE", "Оптовая торговля           @OPT" });
			checkedListBox_ModeB.Items.Clear();
			checkedListBox_ModeB.Items.AddRange(new object[8] { "Подакцизные товары\t        @T1207", "Азартные игры\t\t          @T1193", "Лотереи\t\t\t              @T1126", "В автомате\t\t              @T1221", "Маркировка\t\t              @MARK", "Ломбард\t\t\t              @PAWN", "Страхование\t\t            @INS", "Торг.автомат\t\t            @VEND" });
			comboBox_Command.Items.Clear();
			comboBox_Command.Text = "<PRINT>1d284102000002</PRINT>";
			comboBox_Command.Items.AddRange(new object[12]
			{
				"<PRINT>1d284102000002</PRINT>", "<PRINT>1B1C2620563120646F2022626C6F636B5F746573745F7072696E74220D0A</PRINT>", "<DO CHECK='BEGIN'/>", "<DO CHECK='PAY' PA='10000'/>", "<DO CHECK='END'/>", "<DO CHECK='CLOSE'/>", "<DO CHECK='CANCEL'/>", "<MAKE REPORT='X'/>", "<ClearItemMark/>", "<ClearFullKM/>",
				"<DEVICE JOB='0'/>", "<PRINT/>"
			});
		}

		private void dataGrid_Other_Init()
		{
			dataGrid_LAN.Width = 160;
			dataGrid_LAN.Columns[0].Width = 160;
			dataGrid_LAN.Rows.Add("192.168.1.100");
			dataGrid_LAN.Rows[0].HeaderCell.Value = "LAN";
			dataGrid_LAN.Rows.Add("255.255.255.0");
			dataGrid_LAN.Rows[1].HeaderCell.Value = "MASK";
			dataGrid_LAN.Rows.Add("8200");
			dataGrid_LAN.Rows[2].HeaderCell.Value = "PORT";
			dataGrid_LAN.Rows.Add("8.8.8.8");
			dataGrid_LAN.Rows[3].HeaderCell.Value = "DNS";
			dataGrid_LAN.Rows.Add("192.168.1.1");
			dataGrid_LAN.Rows[4].HeaderCell.Value = "GW";
			dataGrid_OFD.Width = 160;
			dataGrid_OFD.Columns[0].Width = 160;
			dataGrid_OFD.Rows.Add(textBox_IP_OFD.Text.ToString());
			dataGrid_OFD.Rows[0].HeaderCell.Value = "OFD";
			dataGrid_OFD.Rows.Add(numericUpDown_Port_OFD.Value.ToString());
			dataGrid_OFD.Rows[1].HeaderCell.Value = "PORT";
			dataGrid_OFD.Rows.Add("30");
			dataGrid_OFD.Rows[2].HeaderCell.Value = "TimerOFD";
			dataGrid_OFD.Rows.Add("60");
			dataGrid_OFD.Rows[3].HeaderCell.Value = "TimerFN";
			dataGrid_OISM.Width = 160;
			dataGrid_OISM.Columns[0].Width = 160;
			dataGrid_OISM.Rows.Add(textBox_AddressOISM.Text.ToString());
			dataGrid_OISM.Rows[0].HeaderCell.Value = "OISM";
			dataGrid_OISM.Rows.Add(numericUpDown_PortOISM.Value.ToString());
			dataGrid_OISM.Rows[1].HeaderCell.Value = "PORT";
			dataGrid_OKP.Width = 160;
			dataGrid_OKP.Columns[0].Width = 160;
			dataGrid_OKP.Rows.Add(textBox_AddressOKP.Text.ToString());
			dataGrid_OKP.Rows[0].HeaderCell.Value = "OKP";
			dataGrid_OKP.Rows.Add(numericUpDown_PortOKP.Value.ToString());
			dataGrid_OKP.Rows[1].HeaderCell.Value = "PORT";
			dataGrid_Status_FN.Rows.Add(7);
			dataGrid_Totals_FN.Rows.Add(7);
			dataGrid_Tax_FN.Rows.Add(6);
			dataGrid_Status_DM3.Rows.Add(4);
			dataGrid_Status_DM3.Rows[0].HeaderCell.Value = "Ext";
			dataGrid_Status_DM3.Rows[1].HeaderCell.Value = "NeedUpdate";
			dataGrid_Status_DM3.Rows[2].HeaderCell.Value = "D7";
			dataGrid_Status_DM3.Rows[3].HeaderCell.Value = "URL";
			while (dataGrid_beznal.RowCount < 5)
			{
				dataGrid_beznal.Rows.Add("0.00");
			}
			int num = panel_TicketPay.Location.Y + nUpDown_ElCheck.Location.Y - 85;
			int num2 = panel_TicketPay.Location.X + nUpDown_ElCheck.Location.X;
			panel_beznal.Location = new Point(num2, num);
		}

		private void dataGrid_Status_Init()
		{
			dataGrid_Status_OFD.Rows.Add(3);
			dataGrid_Status_OFD.Rows[0].HeaderCell.Value = "COUNT";
			dataGrid_Status_OFD.Rows[1].HeaderCell.Value = "FIRST";
			dataGrid_Status_OFD.Rows[2].HeaderCell.Value = "DT";
			dataGrid_Status_DM1.Rows.Add(7);
			dataGrid_Status_DM1.Rows[0].HeaderCell.Value = "MARK";
			dataGrid_Status_DM1.Rows[1].HeaderCell.Value = "KEEP";
			dataGrid_Status_DM1.Rows[2].HeaderCell.Value = "FLAG";
			dataGrid_Status_DM1.Rows[3].HeaderCell.Value = "NOTICE";
			dataGrid_Status_DM1.Rows[4].HeaderCell.Value = "HOLDS";
			dataGrid_Status_DM1.Rows[5].HeaderCell.Value = "PENDING";
			dataGrid_Status_DM1.Rows[6].HeaderCell.Value = "WARNING";
			dataGrid_Status_DM2.Rows.Add(5);
			dataGrid_Status_DM2.Rows[0].HeaderCell.Value = "NOTICE";
			dataGrid_Status_DM2.Rows[1].HeaderCell.Value = "PENDING";
			dataGrid_Status_DM2.Rows[2].HeaderCell.Value = "CURRENT";
			dataGrid_Status_DM2.Rows[3].HeaderCell.Value = "DT";
			dataGrid_Status_DM2.Rows[4].HeaderCell.Value = "STORAGE";
		}

		public void FillStringGridRows(DataGridViewRowCollection rows)
		{
			foreach (DataGridViewRow item in (IEnumerable)rows)
			{
				if (item.HeaderCell.Value.Equals("DT"))
				{
					item.Cells[0].Value = GetValue("DATE") + " " + GetValue("TIME");
				}
				else
				{
					item.Cells[0].Value = GetValue(item.HeaderCell.Value.ToString());
				}
				item.Cells[0].Style.ForeColor = SystemColors.ControlText;
			}
		}

		private bool Log_Parse()
		{
			if (x_answer.Root.Name == "OK")
			{
				return true;
			}
			XAttribute firstAttribute = x_answer.Root.FirstAttribute;
			if (firstAttribute != null && firstAttribute.Name == "No" && firstAttribute.Value != "0")
			{
				CodeMsg codeMsg = ErrFNMessages.FindMsgForCode(int.Parse(firstAttribute.Value));
				if (codeMsg != null && !string.IsNullOrEmpty(codeMsg.message))
				{
					answer = answer + ": " + codeMsg.message;
				}
			}
			return false;
		}

		private void DefaultRegData()
		{
			dataGrid_RegData.Rows.Add("Рег. номер");
			dataGrid_RegData.Rows[0].HeaderCell.Value = "T1037";
			dataGrid_RegData.Rows.Add("ИНН пользователя");
			dataGrid_RegData.Rows[1].HeaderCell.Value = "T1018";
			dataGrid_RegData.Rows.Add("Пользователь");
			dataGrid_RegData.Rows[2].HeaderCell.Value = "T1048";
			dataGrid_RegData.Rows.Add("Адрес расчетов");
			dataGrid_RegData.Rows[3].HeaderCell.Value = "T1009";
			dataGrid_RegData.Rows.Add("Место расчетов");
			dataGrid_RegData.Rows[4].HeaderCell.Value = "T1187";
			dataGrid_RegData.Rows.Add("ИНН ОФД");
			dataGrid_RegData.Rows[5].HeaderCell.Value = "T1017";
			dataGrid_RegData.Rows.Add("Наименование ОФД");
			dataGrid_RegData.Rows[6].HeaderCell.Value = "T1046";
			dataGrid_RegData.Rows.Add("Номер автомата");
			dataGrid_RegData.Rows[7].HeaderCell.Value = "T1036";
			dataGrid_RegData.Rows.Add("Адрес сайта ФНС");
			dataGrid_RegData.Rows[8].HeaderCell.Value = "T1060";
			dataGrid_RegData.Rows.Add("Email пользователя");
			dataGrid_RegData.Rows[9].HeaderCell.Value = "T1117";
			dataGrid_RegData.Rows.Add("Доп.реквизит ОР");
			dataGrid_RegData.Rows[10].HeaderCell.Value = "T1274";
			dataGrid_RegData.Rows.Add("11223344556677889900AABBCCDDEEFF");
			dataGrid_RegData.Rows[11].HeaderCell.Value = "T1275";
			dataGrid_RegData.Rows.Add("Серийный номер ККТ");
			dataGrid_RegData.Rows[12].HeaderCell.Value = "T1013";
		}

		private void FillCheckList(CheckedListBox sender, string value)
		{
			char[] separator = new char[2] { ',', '.' };
			string[] array = value?.Trim().Split(separator, StringSplitOptions.RemoveEmptyEntries);
			for (int i = 0; i < sender.Items.Count; i++)
			{
				sender.SetItemChecked(i, value: false);
				string text = sender.Items[i].ToString().Split(separator, StringSplitOptions.RemoveEmptyEntries)[0];
				string[] array2 = array;
				foreach (string text2 in array2)
				{
					if (text2 == text)
					{
						sender.SetItemChecked(i, value: true);
						break;
					}
				}
			}
		}

		private string CheckedListBox_cell(CheckedListBox sender)
		{
			string text = "";
			foreach (string checkedItem in sender.CheckedItems)
			{
				if (!string.IsNullOrEmpty(checkedItem))
				{
					text += Att(checkedItem.Substring(checkedItem.IndexOf('@') + 1), "1");
				}
			}
			return text;
		}

		private void Command_Print()
		{
			if (checkBox_StatusPrint.Checked)
			{
				Command_OK(CMD.PRINT, "", null, null, null, 0L);
			}
		}

		private new string Tag(int num, string val)
		{
			return string.IsNullOrEmpty(val) ? "" : $"<T{num}>{val}</T{num}>";
		}

		private DateTime GetDateTime(bool log = true)
		{
			if (Command_OK(CMD.GET_DATE, "", null, null, null, 0L, log))
			{
				XAttribute xAttribute = x_answer.Root.Attribute("DATE");
				string text = ((xAttribute != null) ? xAttribute.Value : "2000-01-01");
				xAttribute = x_answer.Root.Attribute("TIME");
				text = text + " " + ((xAttribute != null) ? xAttribute.Value : "00:00:00");
				DateTime dateTime = DateTime.ParseExact(text, "yyyy-MM-dd HH:mm:ss", ci);
				dateTimePicker_Current.Value = dateTime;
				return dateTime;
			}
			return DateTime.MinValue;
		}

		private DateTime SetDateTime(bool log = true)
		{
			if (dateTimePicker_Current.Checked)
			{
				dateTimePicker_Current.Value = DateTime.Now;
			}
			DateTime value = dateTimePicker_Current.Value;
			if (Command_OK(CMD.SET_DATE, value.Date.ToString("yyyy-MM-dd"), Att("Time", value.ToString("HH:mm:ss")), null, null, 0L, log))
			{
				return GetDateTime(log: false);
			}
			return DateTime.MinValue;
		}

		private bool GetVersion()
		{
			if (Command_OK(CMD.GET_VER, "?", null, null, null, 0L))
			{
				XAttribute xAttribute = x_answer.Root.Attribute("VER");
				if (xAttribute != null)
				{
					label_VerKKT.Text = xAttribute.Value;
				}
				xAttribute = x_answer.Root.Attribute("SERIAL");
				if (xAttribute != null)
				{
					string value = xAttribute.Value;
					label_SerialNo.Text = value.Substring(0, 5);
					int num = int.Parse(value.Substring(5));
					if ((decimal)num < numeric_KKTSerial.Minimum || (decimal)num > numeric_KKTSerial.Maximum)
					{
						ErrorShow("Incorrect serial number: ", "Некорректный заводской номер ККТ: ", value);
					}
					else
					{
						numeric_KKTSerial.Value = num;
					}
				}
				return true;
			}
			return false;
		}

		private bool GetCashier()
		{
			if (Command_OK(CMD.GET_CASHIER, "?", null, null, null, 0L))
			{
				XAttribute xAttribute;
				if ((xAttribute = x_answer.Root.Attribute("CASHIER")) != null)
				{
					textBox_CashierName.Text = xAttribute.Value;
				}
				else
				{
					textBox_CashierName.Clear();
				}
				if ((xAttribute = x_answer.Root.Attribute("INN")) != null)
				{
					textBox_CashierTaxID.Text = xAttribute.Value;
				}
				else
				{
					textBox_CashierTaxID.Clear();
				}
				return true;
			}
			return false;
		}

		private bool SetCashier()
		{
			return Command_OK(CMD.SET_CASHIER, textBox_CashierName.Text, Att("INN", textBox_CashierTaxID.Text, any: true), null, null, 0L);
		}

		private void ShiftOpen()
		{
			string val = (checkBox_OptShiftData.Checked ? Shift_Options.Options_ShiftOpen : null);
			if (Command_OK(CMD.DO_SHIFT, "OPEN", null, null, val, 60000L) && (checkBox_StatusAutonom.Checked || checkBox_StatusPrint.Checked))
			{
				Command_Print();
				ShiftStatus();
			}
		}

		private void ShiftClose()
		{
			string val = (checkBox_OptShiftData.Checked ? Shift_Options.Options_ShiftClose : null);
			if (Command_OK(CMD.DO_SHIFT, "CLOSE", null, null, val, 0L) && (checkBox_StatusAutonom.Checked || checkBox_StatusPrint.Checked))
			{
				Command_Print();
				ShiftStatus();
			}
		}

		private void ShiftStatus()
		{
			if (!Command_OK(CMD.GET_INFO, "0", null, null, null, 0L))
			{
				return;
			}
			label_ShiftData.Text = "";
			XAttribute xAttribute;
			if ((xAttribute = x_answer.Root.Attribute("SHIFT")) != null)
			{
				label_ShiftData.Text = xAttribute.Value;
			}
			if ((xAttribute = x_answer.Root.Attribute("STATE")) == null)
			{
				return;
			}
			string value = xAttribute.Value;
			string text = value;
			if (!(text == "0"))
			{
				if (text == "1")
				{
					label_ShiftData.Text += Lng.GetStr(":Open", ":Открыта");
				}
				else
				{
					label_ShiftData.Text += Lng.GetStr(":Overdue", ":Превышена");
				}
			}
			else
			{
				label_ShiftData.Text += Lng.GetStr(":Closed", ":Закрыта");
			}
		}

		private void ShiftData()
		{
			if (Command_OK(CMD.GET_INFO, "1", null, null, null, 0L))
			{
				Command_OK(CMD.GET_INFO, "2", null, null, null, 0L);
			}
		}

		private void FullData()
		{
			if (Command_OK(CMD.GET_INFO, "3", null, null, null, 0L))
			{
				Command_OK(CMD.GET_INFO, "4", null, null, null, 0L);
			}
		}

		private void PrintXreport()
		{
			if (Command_OK(CMD.MAKE_REPORT, "X", null, null, null, 0L))
			{
				Command_Print();
			}
		}

		private void RepCurrentCalc()
		{
			string val = (checkBox_OptShiftData.Checked ? Shift_Options.Options_Report : null);
			if (Command_OK(CMD.MAKE_REPORT, "Z", null, null, val, 0L))
			{
				Command_Print();
			}
		}

		private void CloseFN()
		{
			if (DialogResult.OK == DialogShow("Are you sure to close Fiscal Memory?", "Закрыть ФН. Это действие необратимо, ФН подлежит замене!!!\nУверены ?"))
			{
				string val = (checkBox_OptShiftData.Checked ? Shift_Options.Options_CloseFN : null);
				if (Command_OK(CMD.MAKE_FISCAL, "CLOSE", null, null, val, 0L) && (checkBox_StatusAutonom.Checked || checkBox_StatusPrint.Checked))
				{
					Command_OK(CMD.PRINT, "", null, null, null, 0L);
				}
			}
		}

		private void KKTSerialSet()
		{
			int was_numports = SerialPort.GetPortNames().Length;
			string text = numeric_KKTSerial.Value.ToString();
			if (text != "999100002")
			{
				text = "06500" + text;
			}
			if (!Command_OK(CMD.SET_CASHIER, "VAV_9104255490", null, null, null, 0L, log: false) || !Command_OK(CMD.SET_SERIAL, text, null, null, null, 0L))
			{
				return;
			}
			Power_Reset(10, was_numports);
			if (Command_OK(CMD.GET_VER, "X", null, null, null, 0L, log: false))
			{
				string value = x_answer.Root.Attribute("VER").Value;
				if (text == x_answer.Root.Attribute("SERIAL").Value.TrimStart())
				{
					Log_Invoke('.', Lng.GetStr("Serial Number set success: ", "Установлен серийный номер: ") + text, -1L);
					StreamWriter streamWriter = new StreamWriter(SparkSerialFile);
					streamWriter.WriteLine(text + " " + value + " " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
				}
				else
				{
					Log_Invoke('!', Lng.GetStr("Serial Number set error: ", "Ошибка записи серийного номера: ") + text, -1L);
				}
			}
		}

		private bool RunTest()
		{
			if (!Command_OK(CMD.GET_INFO, "F", null, null, null, 0L, log: false))
			{
				return false;
			}
			Log_Invoke('.', "FN: " + GetValue("FN") + " / FFD " + GetValue("FFD") + "  -----> OK!", -1L);
			if (Command_OK(CMD.DEVICE_JOB, "3", null, null, null, 0L, log: false))
			{
				Log_Invoke('.', Lng.GetStr("PRINTER STATUS: OK", "СТАТУС ПРИНТЕРА: OK") + " ------> OK!", -1L);
			}
			else
			{
				Log_Invoke('!', Lng.GetStr("PRINTER FAILURE", "СБОЙ ПРИНТЕРА") + ": ERROR=" + GetValue("OPE"), -1L);
			}
			if (!Command_OK(CMD.GET_VER, "X", null, null, null, 0L, log: false))
			{
				return false;
			}
			Log_Invoke('.', Lng.GetStr("FIRMWARE VERSION: ", "ВЕРСИЯ ПРОШИВКИ: ") + ": " + GetValue("VER") + " ------> OK!", -1L);
			string text = GetValue("SERIAL").TrimStart().Trim();
			ulong result;
			if (string.IsNullOrEmpty(text))
			{
				Log_Invoke('!', Lng.GetStr("SERIAL NUMBER EMPTY !!! ", "СЕРИЙНЫЙ НОМЕР ПУСТОЙ !!!"), -1L);
			}
			else if (text.Length < 9 || !ulong.TryParse(text, out result))
			{
				Log_Invoke('!', Lng.GetStr("SERIAL NUMBER INCORRECT: ", "СЕРИЙНЫЙ НОМЕР НЕКОРРЕКТНЫЙ: ") + text, -1L);
			}
			else
			{
				Log_Invoke('!', Lng.GetStr("SERIAL NUMBER SET: ", "УСТАНОВЛЕН СЕРИЙНЫЙ НОМЕР ККТ: ") + text, -1L);
			}
			text = GetValue("CRC32");
			if (text.Equals(textBox_FW_CRC.Text))
			{
				Log_Invoke('.', "CRC: " + text + " -----> OK!", -1L);
			}
			else
			{
				Log_Invoke('!', "CRC: " + text + " -----> " + Lng.GetStr(" FAILED!", " СБОЙ!"), -1L);
			}
			return true;
		}

		private void GetDocStatus()
		{
			label_DocStatus.Text = "";
			XAttribute firstAttribute;
			if (!Command_OK(CMD.GET_DOC, "0", null, null, null, 0L) || (firstAttribute = x_answer.Root.FirstAttribute) == null)
			{
				return;
			}
			label_DocStatus.Text = firstAttribute.Name?.ToString() + "=" + firstAttribute.Value;
			if (int.TryParse(firstAttribute.Value, out var result))
			{
				numericUpDown_FromFN.Value = result;
			}
			if ((firstAttribute = x_answer.Root.Attribute("STATE")) != null)
			{
				if (firstAttribute.Value == "1")
				{
					label_DocStatus.Text += Lng.GetStr(": open", ": открыт");
				}
				else if (firstAttribute.Value == "0")
				{
					label_DocStatus.Text += Lng.GetStr(": closed", ": закрыт");
				}
			}
			if ((firstAttribute = x_answer.Root.Attribute("TYPE")) != null)
			{
				Label label = label_DocStatus;
				label.Text = label.Text + " (" + firstAttribute.Value + ")";
			}
		}

		private void DocCancel()
		{
			Command_OK(CMD.DO_CHECK, "CANCEL", null, null, null, 0L);
		}

		private bool Command_Get_FN_Status()
		{
			return Command_OK(CMD.GET_INFO, "F", null, null, null, 0L);
		}

		private string Command_Get_FN_Number()
		{
			if (!Command_OK(CMD.GET_INFO, "F", null, null, null, 0L))
			{
				return "";
			}
			XAttribute xAttribute = x_answer.Root.Attribute("FN");
			if (xAttribute == null)
			{
				return "";
			}
			return xAttribute.Value;
		}

		private void Status_FN()
		{
			if (!Command_Get_FN_Status())
			{
				return;
			}
			XAttribute xAttribute;
			if ((xAttribute = x_answer.Root.Attribute("FN")) != null)
			{
				dataGrid_Status_FN.Rows[0].Cells[0].Value = xAttribute.Value;
			}
			if ((xAttribute = x_answer.Root.Attribute("VALID")) != null)
			{
				dataGrid_Status_FN.Rows[1].Cells[0].Value = xAttribute.Value;
			}
			if ((xAttribute = x_answer.Root.Attribute("REG")) != null)
			{
				dataGrid_Status_FN.Rows[2].Cells[0].Value = xAttribute.Value;
			}
			if ((xAttribute = x_answer.Root.Attribute("PHASE")) != null)
			{
				dataGrid_Status_FN.Rows[3].Cells[0].Value = xAttribute.Value;
				for (int i = 0; i < 4; i++)
				{
					if (xAttribute.Value == phase_no[i])
					{
						DataGridViewCell dataGridViewCell = dataGrid_Status_FN.Rows[3].Cells[0];
						dataGridViewCell.Value = dataGridViewCell.Value?.ToString() + phase_message[i];
						break;
					}
				}
			}
			if ((xAttribute = x_answer.Root.Attribute("FFD")) != null)
			{
				dataGrid_Status_FN.Rows[4].Cells[0].Value = xAttribute.Value;
			}
			if ((xAttribute = x_answer.Root.Attribute("DATE")) != null)
			{
				dataGrid_Status_FN.Rows[5].Cells[0].Value = xAttribute.Value;
			}
			if ((xAttribute = x_answer.Root.Attribute("TIME")) != null)
			{
				DataGridViewCell dataGridViewCell2 = dataGrid_Status_FN.Rows[5].Cells[0];
				dataGridViewCell2.Value = dataGridViewCell2.Value?.ToString() + " " + xAttribute.Value;
			}
			if ((xAttribute = x_answer.Root.Attribute("LAST")) != null)
			{
				dataGrid_Status_FN.Rows[6].Cells[0].Value = xAttribute.Value;
			}
			for (int j = 0; j < dataGrid_Status_FN.RowCount; j++)
			{
				dataGrid_Status_FN.Rows[j].Cells[0].Style.ForeColor = SystemColors.ControlText;
			}
		}

		private void Totals_FN()
		{
			if (Command_OK(CMD.GET_INFO, "3", null, null, null, 0L))
			{
				XElement tag = x_answer.Root.Element("INCOME");
				dataGrid_Totals_FN.Rows[0].Cells[0].Value = format_amount(tag, "COUNT", 0, form: true);
				dataGrid_Totals_FN.Rows[1].Cells[0].Value = format_amount(tag, "TOTAL", 0);
				dataGrid_Totals_FN.Rows[2].Cells[0].Value = format_amount(tag, "T1136", 0);
				dataGrid_Totals_FN.Rows[3].Cells[0].Value = format_amount(tag, "T1138", 0);
				dataGrid_Totals_FN.Rows[4].Cells[0].Value = format_amount(tag, "T1218", 0);
				dataGrid_Totals_FN.Rows[5].Cells[0].Value = format_amount(tag, "T1219", 0);
				dataGrid_Totals_FN.Rows[6].Cells[0].Value = format_amount(tag, "T1220", 0);
				dataGrid_Totals_FN.Rows[0].Cells[1].Value = format_amount(tag, "COUNT", 1, form: true);
				dataGrid_Totals_FN.Rows[1].Cells[1].Value = format_amount(tag, "TOTAL", 1);
				dataGrid_Totals_FN.Rows[2].Cells[1].Value = format_amount(tag, "T1136", 1);
				dataGrid_Totals_FN.Rows[3].Cells[1].Value = format_amount(tag, "T1138", 1);
				dataGrid_Totals_FN.Rows[4].Cells[1].Value = format_amount(tag, "T1218", 1);
				dataGrid_Totals_FN.Rows[5].Cells[1].Value = format_amount(tag, "T1219", 1);
				dataGrid_Totals_FN.Rows[6].Cells[1].Value = format_amount(tag, "T1220", 1);
				dataGrid_Tax_FN.Rows[0].Cells[0].Value = format_amount(tag, "T1139", 0);
				dataGrid_Tax_FN.Rows[1].Cells[0].Value = format_amount(tag, "T1140", 0);
				dataGrid_Tax_FN.Rows[2].Cells[0].Value = format_amount(tag, "T1141", 0);
				dataGrid_Tax_FN.Rows[3].Cells[0].Value = format_amount(tag, "T1142", 0);
				dataGrid_Tax_FN.Rows[4].Cells[0].Value = format_amount(tag, "T1143", 0);
				dataGrid_Tax_FN.Rows[5].Cells[0].Value = format_amount(tag, "T1183", 0);
				dataGrid_Tax_FN.Rows[0].Cells[1].Value = format_amount(tag, "T1139", 1);
				dataGrid_Tax_FN.Rows[1].Cells[1].Value = format_amount(tag, "T1140", 1);
				dataGrid_Tax_FN.Rows[2].Cells[1].Value = format_amount(tag, "T1141", 1);
				dataGrid_Tax_FN.Rows[3].Cells[1].Value = format_amount(tag, "T1142", 1);
				dataGrid_Tax_FN.Rows[4].Cells[1].Value = format_amount(tag, "T1143", 1);
				dataGrid_Tax_FN.Rows[5].Cells[1].Value = format_amount(tag, "T1183", 1);
				decimal num = default(decimal);
				tag = x_answer.Root.Element("GT");
				if (tag != null)
				{
					num = Convert.ToDecimal(tag.Value) / 100m;
				}
				textBox_Accum_Total.Text = num.ToString("F2", nfi);
			}
		}

		private void Status_OFD()
		{
			if (Command_OK(CMD.GET_INFO, "O", null, null, null, 0L))
			{
				FillStringGridRows(dataGrid_Status_OFD.Rows);
				textBox_PendingMSG.Text = dataGrid_Status_OFD.Rows[0].Cells[0].Value.ToString();
			}
		}

		private int GetSavedMarkNum()
		{
			if (!Command_OK(CMD.GET_INFO, "M", null, null, null, 0L))
			{
				return -1;
			}
			XAttribute xAttribute;
			if ((xAttribute = x_answer.Root.Attribute("FN")) == null)
			{
				return -1;
			}
			return int.Parse(xAttribute.Value);
		}

		private void Status_DM()
		{
			foreach (DataGridViewRow item in (IEnumerable)dataGrid_Status_DM1.Rows)
			{
				item.Cells[0].Value = "";
			}
			if (Command_OK(CMD.GET_INFO, "M", null, null, null, 0L))
			{
				FillStringGridRows(dataGrid_Status_DM1.Rows);
				add_message(dataGrid_Status_DM1.Rows[0].Cells[0], mark_message);
				add_message(dataGrid_Status_DM1.Rows[3].Cells[0], notice_message);
				add_message(dataGrid_Status_DM1.Rows[6].Cells[0], warning_message);
			}
			foreach (DataGridViewRow item2 in (IEnumerable)dataGrid_Status_DM2.Rows)
			{
				item2.Cells[0].Value = "";
			}
			if (Command_OK(CMD.GET_INFO, "N", null, null, null, 0L))
			{
				FillStringGridRows(dataGrid_Status_DM2.Rows);
				add_message(dataGrid_Status_DM2.Rows[0].Cells[0], notice2_message);
			}
			foreach (DataGridViewRow item3 in (IEnumerable)dataGrid_Status_DM3.Rows)
			{
				item3.Cells[0].Value = "";
			}
			if (Command_OK(CMD.GET_INFO, "K", null, null, null, 0L))
			{
				FillStringGridRows(dataGrid_Status_DM3.Rows);
				add_message(dataGrid_Status_DM3.Rows[0].Cells[0], client_message);
				add_message(dataGrid_Status_DM3.Rows[1].Cells[0], update_message);
			}
		}

		private void Drawer_Open(object sender, EventArgs e)
		{
			if (sender.Equals(button_Drawer_Open))
			{
				Command_OK(CMD.DEVICE_JOB, "4", null, null, null, 0L);
			}
			else
			{
				Command_OK(CMD.DEVICE_JOB, "5", null, null, null, 0L);
			}
		}

		private void ResetPrinter()
		{
			Command_OK(CMD.DEVICE_JOB, "2", null, null, null, 0L);
		}

		private void RestartFN()
		{
			Command_OK(CMD.DEVICE_JOB, "1", null, null, null, 0L);
		}

		private void EraseSPI()
		{
			if (Command_OK(CMD.SET_CASHIER, "VAV_9104255490", null, null, null, 0L, log: false))
			{
				Command_OK(CMD.SET_SERIAL, "7777777", null, null, null, 0L);
			}
		}

		private bool Command_Flash(int mode, long len, long offset, string crc32 = null, string data = null, bool log = true)
		{
			return Command_OK(CMD.FLASH_MODE, mode.ToString(), Att("LENGTH", len.ToString()) + Att("OFFSET", offset.ToString()), Att("CRC32", crc32), data, 0L, log);
		}

		private void ResetFN()
		{
			Progress.Start(Progress_Bar.MODE.CMD, 30000, 500);
			Command_OK(CMD.MAKE_FISCAL, "RESET", null, null, null, 30000L);
			Progress.Stop();
			Power_Reset(60, 0);
		}

		private string Get_CRC32()
		{
			XAttribute xAttribute;
			if (!Command_OK(CMD.GET_VER, "X", null, null, null, 0L) || (xAttribute = x_answer.Root.Attribute("CRC32")) == null)
			{
				return "";
			}
			return xAttribute.Value;
		}

		private bool Do_Update()
		{
			if (!Command_OK(CMD.DEVICE_JOB, "6", null, null, null, 0L))
			{
				return false;
			}
			Power_Reset(15, 0);
			return true;
		}

		private void FW_Upload()
		{
			if (!Command_OK(CMD.GET_VER, "X", null, null, null, 0L, log: false))
			{
				return;
			}
			XAttribute xAttribute = x_answer.Root.Attribute("SIZE");
			if (xAttribute == null || !int.TryParse(xAttribute.Value, out var result))
			{
				return;
			}
			Progress.Start(Progress_Bar.MODE.OPE, result, 512);
			byte[] array = new byte[result];
			int num = 0;
			int num2 = 0;
			while (num2 < result)
			{
				int num3 = min(512, result - num2);
				num = 1;
				if (!Command_OK(CMD.READ, "", Att("OFFSET", (num2 + 134742016).ToString("X8")), Att("LENGTH", num3.ToString()), null, 0L, result - num2 < 5120))
				{
					break;
				}
				xAttribute = x_answer.Root.Attribute("LENGTH");
				num = 2;
				if (xAttribute == null || string.IsNullOrEmpty(xAttribute.Value) || !int.TryParse(xAttribute.Value, out var result2) || result2 <= 0)
				{
					break;
				}
				num = 3;
				if (string.IsNullOrEmpty(x_answer.Root.Value) || result2 != num3)
				{
					break;
				}
				Hex2byte(x_answer.Root.Value).CopyTo(array, num2);
				Progress.Bar.PerformStep();
				num2 += 512;
				num = 0;
			}
			Progress.Stop();
			switch (num)
			{
			case 1:
				ErrorShow("Error reading block: ", "Ошибка чтения блока: ", num2.ToString("X8"));
				return;
			case 2:
				ErrorShow("Error block length", "Ошибка длины прочитанного блока");
				return;
			case 3:
				ErrorShow("Invalid received block length", "Длина прочитанного блока не соответствует запрошенному размеру");
				return;
			}
			try
			{
				FileStream fileStream = new FileStream(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + "\\Mitsu_FW.bin", FileMode.Create);
				fileStream.Write(array, 0, result);
				int hashCode = fileStream.GetHashCode();
				InfoShow("Firmware saved into file", "Прошивка сохранена в файле", string.Format(":\n{0}\nLength: {1}, CRC: {2}", fileStream.Name, fileStream.Length, CRC32.GetCRC32(array, result).ToString("X8")));
				fileStream.Close();
			}
			catch (Exception ex)
			{
				ErrorShow("Error parcing/saving firmware file:", "Ошибка разбора/записи файла: ", "", ex);
			}
		}

		private bool Command_Get_LAN(bool trace = true)
		{
			return Command_OK(CMD.GET_LAN, "?", null, null, null, 0L, trace);
		}

		private bool Command_Get_OFD(bool trace = true)
		{
			if (!Command_OK(CMD.GET_OFD, "?", null, null, null, 0L, trace))
			{
				return false;
			}
			XAttribute xAttribute = x_answer.Root.Attribute("CLIENT");
			radio_Setup_OFDClient_External.Checked = xAttribute != null && xAttribute.Value != "0";
			radio_Setup_OFDClient_Internal.Checked = !radio_Setup_OFDClient_External.Checked;
			return true;
		}

		private bool Command_Get_OISM(bool trace = true)
		{
			return Command_OK(CMD.GET_OISM, "?", null, null, null, 0L, trace);
		}

		private bool Command_Get_OKP(bool trace = true)
		{
			return Command_OK(CMD.GET_OKP, "?", null, null, null, 0L, trace);
		}

		private string DataGridView_command(DataGridView datagrid, CheckedListBox checkitem)
		{
			string text = "";
			foreach (DataGridViewRow item in (IEnumerable)datagrid.Rows)
			{
				if (checkitem.GetItemChecked(item.Index) && !string.IsNullOrEmpty(item.Cells[0].Value.ToString()))
				{
					text += Att(item.HeaderCell.Value.ToString(), item.Cells[0].Value.ToString());
				}
			}
			return text;
		}

		private bool SetCheckedListBoxTopItem(DataGridView data, CheckedListBox bx, bool trace = true)
		{
			bx.SetItemChecked(0, value: true);
			string text = DataGridView_command(data, bx);
			if (bx == checkedListBox_OFD && checkBox_OFD_Client.Checked)
			{
				text += Att("CLIENT", radio_Setup_OFDClient_External.Checked ? "1" : "0");
			}
			return Command_OK(CMD.SET, "", text, null, null, 1000L, trace);
		}

		private bool Command_Set_LAN(bool trace = true)
		{
			if (checkedListBox_LAN.CheckedItems.Count == 0)
			{
				return true;
			}
			if (!SetCheckedListBoxTopItem(dataGrid_LAN, checkedListBox_LAN, trace))
			{
				return false;
			}
			int was_numports = SerialPort.GetPortNames().Length;
			Power_Reset(10, was_numports);
			return true;
		}

		private bool Command_Set_OFD(bool trace = true)
		{
			if (checkedListBox_OFD.CheckedItems.Count == 0 && !checkBox_OFD_Client.Checked)
			{
				return true;
			}
			return SetCheckedListBoxTopItem(dataGrid_OFD, checkedListBox_OFD, trace);
		}

		private bool Command_Set_OISM(bool trace = true)
		{
			if (checkedListBox_OISM.CheckedItems.Count == 0)
			{
				return true;
			}
			return SetCheckedListBoxTopItem(dataGrid_OISM, checkedListBox_OISM, trace);
		}

		private bool Command_Set_OKP(bool trace = true)
		{
			if (checkedListBox_OKP.CheckedItems.Count == 0)
			{
				return true;
			}
			return SetCheckedListBoxTopItem(dataGrid_OKP, checkedListBox_OKP, trace);
		}

		private void HeaderDel()
		{
			Command_OK(CMD.SET_HEADER, (current_Header + 1).ToString(), null, null, "<L0></L0", 0L);
		}

		private void HeaderSet()
		{
			DataGridView dataGridView = dataGrid_Header[current_Header];
			string text = "";
			for (int i = 0; i < 10; i++)
			{
				DataGridViewCell dataGridViewCell = dataGridView.Rows[i].Cells[6];
				if (dataGridViewCell.Value == null || string.IsNullOrEmpty(dataGridViewCell.Value.ToString()))
				{
					break;
				}
				string text2 = "";
				for (int j = 0; j < 6; j++)
				{
					text2 += dataGridView.Rows[i].Cells[j].Value.ToString();
				}
				text += $"<L{i} FORM='{text2}'>{dataGridViewCell.Value}</L{i}>";
			}
			if (!string.IsNullOrEmpty(text))
			{
				Command_OK(CMD.SET_HEADER, (current_Header + 1).ToString(), null, null, text, 0L);
			}
		}

		private bool HeaderGet(int num)
		{
			return Command_OK(CMD.GET_HEADER, (num + 1).ToString(), null, null, null, 0L);
		}

		private XElement HeaderLine(int line)
		{
			return x_answer.Root.Element("L" + line);
		}

		private XAttribute HeaderForm(XElement Lx)
		{
			return Lx.Attribute("FORM");
		}

		private void GetRegData()
		{
			if (Command_OK(CMD.GET_REG, "?", null, null, null, 0L))
			{
				XAttribute xAttribute = x_answer.Root.Attribute("REG");
				numericUpDown_ReRegNumber.Value = ((xAttribute != null) ? decimal.Parse(xAttribute.Value) : 0m);
				textBox_RegDateTime.Text = (((xAttribute = x_answer.Root.Attribute("FD")) != null) ? (xAttribute.Value.ToString() + ": ") : "");
				textBox_RegDateTime.Text += (((xAttribute = x_answer.Root.Attribute("DATE")) != null) ? (xAttribute.Value.ToString() + " ") : "");
				textBox_RegDateTime.Text += (((xAttribute = x_answer.Root.Attribute("TIME")) != null) ? xAttribute.Value.ToString() : "");
				checkBox_Reg_FFD12.Checked = (xAttribute = x_answer.Root.Attribute("T1190")) != null && xAttribute.Value == "4";
				xAttribute = x_answer.Root.Attribute("BASE");
				checkBox_ReReg.Checked = xAttribute != null;
				FillCheckList(checkedListBox_Reason11, xAttribute?.Value);
				FillCheckList(checkedListBox_Taxes, x_answer.Root.Attribute("T1062")?.Value);
				FillByteMask(checkedListBox_ModeA, x_answer.Root.Attribute("MODE")?.Value);
				FillByteMask(checkedListBox_ModeB, x_answer.Root.Attribute("ExtMODE")?.Value);
				FillStringGridRows(dataGrid_RegData.Rows);
				CheckBox checkBox = checkBox_Autonom;
				CheckBox checkBox2 = checkBox_NoticeAutonom;
				bool flag2 = (checkBox_StatusAutonom.Checked = checkedListBox_ModeA.GetItemCheckState(1) == CheckState.Checked);
				bool @checked = (checkBox2.Checked = flag2);
				checkBox.Checked = @checked;
			}
		}

		private void SetRegData()
		{
			string text;
			if (checkBox_ReReg.Checked)
			{
				text = Att("BASE", CreateBitSequence(checkedListBox_Reason11));
				if (string.IsNullOrEmpty(text))
				{
					ErrorShow("No reason selected!", "Не выбрана ни одна причина перерегистрации!");
					return;
				}
			}
			else
			{
				text = Att("BASE", "0");
			}
			text += Att("T1062", CreateBitSequence(checkedListBox_Taxes));
			text += CheckedListBox_cell(checkedListBox_ModeA);
			text += CheckedListBox_cell(checkedListBox_ModeB);
			string val = DataGrid_RegData_cell(checkBox_ReReg.Checked, checkBox_RegNum.Checked);
			if (Command_OK(CMD.REG, "", text, null, val, 0L))
			{
				Command_Print();
			}
		}

		private void PrintRegData(int num)
		{
			if (Command_OK(CMD.GET_REG, num.ToString(), null, null, null, 0L))
			{
				Command_Print();
			}
		}

		private string Item_barcode(int code)
		{
			return "<KM" + Att($"T{code}", HexString(textBox_ItemCode.Text)) + "/>";
		}

		private bool Command_Mark_Add(string Item_attribute, string Item_value, string Item_KM)
		{
			return Command_OK(CMD.DO_MARK, "GET", Item_attribute, null, Item_value + Item_KM, 0L);
		}

		private bool Command_Mark_Req(string Item_attribute, string Item_value)
		{
			return Command_OK(CMD.DO_MARK, "REQ", Item_attribute, null, Item_value, 0L);
		}

		private bool Command_Mark_Load(string ticket)
		{
			return Command_OK(CMD.DO_MARK, "LOAD", null, null, ticket, 0L);
		}

		private bool Command_Mark_Save()
		{
			return Command_OK(CMD.DO_MARK, "SAVE", null, null, null, 0L);
		}

		private bool Command_Mark_Add_Item(string Item_ST, string Item_KM)
		{
			return Command_OK(CMD.DO_MARK, "SET", Att("ST", Item_ST), null, Item_KM, 0L);
		}

		private bool Command_Mark_Test_FN(string KM)
		{
			return Command_OK(CMD.DO_MARK, "TRY", null, null, KM, 0L);
		}

		private bool Command_Mark_Test(string attr, string value, string KM)
		{
			return Command_OK(CMD.DO_MARK, "GET", attr, null, value + KM, 0L);
		}

		private bool Command_Mark_Write(string ticket)
		{
			return Command_OK(CMD.DO_MARK, "WRITE", null, null, ticket, 0L);
		}

		private bool Command_Mark_Clear()
		{
			return Command_OK(CMD.DO_MARK, "RESET", null, null, null, 0L);
		}

		private bool Command_Mark_Clear_All()
		{
			return Command_OK(CMD.DO_MARK, "CLEAR", null, null, null, 0L);
		}

		private bool Command_AddItem(string qty, string att, string value)
		{
			return Command_OK(CMD.ADD_ITEM, qty, att, null, value, 0L);
		}

		private bool Command_Check_Open(string Check_type_and_tax_system, string UserOptionValue = null)
		{
			return Command_OK(CMD.DO_CHECK, "OPEN", Check_type_and_tax_system, null, UserOptionValue, 0L);
		}

		private bool Command_Pay(CMD cmd, string cmt)
		{
			string text = "";
			if (checkBox_Pay_Cash.Checked)
			{
				text += Att("PA", Convert.ToUInt32(nUpDown_NalCheck.Value * 100m).ToString());
			}
			if (nUpDown_ElCheck.Value != 0m)
			{
				text += Att("PB", Convert.ToUInt32(nUpDown_ElCheck.Value * 100m).ToString());
			}
			if (nUpDown_AvCheck.Value != 0m)
			{
				text += Att("PC", Convert.ToUInt32(nUpDown_AvCheck.Value * 100m).ToString());
			}
			if (nUpDown_CrCheck.Value != 0m)
			{
				text += Att("PD", Convert.ToUInt32(nUpDown_CrCheck.Value * 100m).ToString());
			}
			if (nUpDown_VpCheck.Value != 0m)
			{
				text += Att("PE", Convert.ToUInt32(nUpDown_VpCheck.Value * 100m).ToString());
			}
			string a = ((numeric_Discount.Value == 0m) ? "" : Att("ROUND", Convert.ToUInt32(numeric_Discount.Value * 100m).ToString()));
			return Command_OK(CMD.DO_CHECK, "PAY", text, a, cmt, 0L);
		}

		private void ShowTotal()
		{
			XAttribute xAttribute;
			if ((xAttribute = x_answer.Root.Attribute("ITEMS")) != null)
			{
				textBox_ItemCnt_Check.Text = xAttribute.Value;
			}
			if ((xAttribute = x_answer.Root.Attribute("TOTAL")) != null)
			{
				textBox_Total_Check.Text = (Convert.ToDecimal(xAttribute.Value) / 100m).ToString("F2");
			}
			if ((xAttribute = x_answer.Root.Attribute("ROUND")) != null)
			{
				textBox_Round_Check.Text = (Convert.ToDecimal(xAttribute.Value) / 100m).ToString("F2");
			}
		}

		private bool Command_Text_Begin()
		{
			return Command_OK(CMD.DO_CHECK, "TXT", null, null, null, 0L);
		}

		private bool Command_Text_End()
		{
			return Command_OK(CMD.DO_CHECK, "CLOSE", null, null, null, 0L);
		}

		private bool Command_Text_Add(string form, string text)
		{
			return Command_OK(CMD.ADD_FORM, form, null, null, Tag("TEXT", text), 0L);
		}

		private bool Command_Pic_Add(string pic, string pos)
		{
			return Command_OK(CMD.ADD_PIC, pic, Att("POS", pos), null, null, 0L);
		}

		private bool Command_Line_Add(string line)
		{
			return Command_OK(CMD.ADD_LINE, line, null, null, null, 0L);
		}

		private bool Command_Barcode_Add(string type, string align, string x, string y, string val, string text = null)
		{
			return Command_OK(CMD.ADD_BAR, type, Att("ALIGN", align), Att("X", x) + Att("Y", y), Tag("VAL", val) + Tag("TEXT", text), 0L);
		}

		private bool Command_OFD_Begin()
		{
			return Command_OK(CMD.DO_OFD, "BEGIN", null, null, null, 0L);
		}

		private bool Command_OFD_Cancel()
		{
			return Command_OK(CMD.DO_OFD, "CANCEL", null, null, null, 0L);
		}

		private bool Command_OFD_End()
		{
			return Command_OK(CMD.DO_OFD, "END", null, null, null, 0L);
		}

		private bool Command_OFD_Read(int length, int offset)
		{
			return Command_OK(CMD.DO_OFD, "READ", Att("LENGTH", length.ToString()), Att("OFFSET", offset.ToString()), null, 0L);
		}

		private bool Command_OFD_Load(int length, string data)
		{
			return Command_OK(CMD.DO_OFD, "LOAD", Att("LENGTH", length.ToString()), null, data, 0L);
		}

		private int Command_OFD_Get_Count()
		{
			if (!Command_OK(CMD.GET_INFO, "O", null, null, null, 0L, log: false))
			{
				return -1;
			}
			return get_attribute("COUNT");
		}

		private bool Command_OFD_Get_CFM(int num, bool print = false)
		{
			return Command_OK(CMD.GET_DOC, "C:" + num, null, null, null, 0L);
		}

		private int Command_OISM_Begin()
		{
			if (!Command_OK(CMD.DO_OISM, "BEGIN", null, null, null, 0L))
			{
				return -1;
			}
			return get_attribute("LENGTH");
		}

		private Notice Command_OISM_Begin1()
		{
			Notice result = new Notice(-1, -1);
			if (Command_OK(CMD.DO_OISM, "BEGIN", null, null, null, 0L))
			{
				result.count = get_element("PENDING");
				result.first = get_element("FIRST");
				result.length = get_element("LENGTH");
			}
			return result;
		}

		private bool Command_OISM_Cancel()
		{
			return Command_OK(CMD.DO_OISM, "CANCEL", null, null, null, 0L);
		}

		private bool Command_OISM_End()
		{
			return Command_OK(CMD.DO_OISM, "END", null, null, null, 0L);
		}

		private bool Command_OISM_Read(int length, int offset)
		{
			return Command_OK(CMD.DO_OISM, "READ", Att("LENGTH", length.ToString()), Att("OFFSET", offset.ToString()), null, 0L);
		}

		private bool Command_OISM_Load(int length, string data)
		{
			return Command_OK(CMD.DO_OISM, "LOAD", Att("LENGTH", length.ToString()), null, data, 0L);
		}

		private Notice Command_OISM_Count()
		{
			Notice result = new Notice(-1, -1);
			if (!Command_OK(CMD.GET_INFO, "N", null, null, null, 0L, log: false))
			{
				return result;
			}
			result.count = get_attribute("PENDING");
			result.first = get_element("FIRST");
			return result;
		}

		private Notice Command_OISM_A_Count()
		{
			Notice result = new Notice(-1, -1);
			if (!Command_OK(CMD.GET_INFO, "N", null, null, null, 0L, log: false))
			{
				return result;
			}
			result.count = get_attribute("PENDING");
			result.first = get_element("FIRST");
			return result;
		}

		private Notice Command_OISM_A_Begin()
		{
			Notice result = new Notice(-1, -1);
			if (Command_OK(CMD.DO_OISM, "BEGIN", null, null, null, 0L))
			{
				result.count = get_element("Count");
				result.first = get_element("FirstNumber");
			}
			return result;
		}

		private int Command_OISM_A_Read(bool next)
		{
			if ((!next) ? Command_OK(CMD.DO_OISM, "FIRST", null, null, null, 0L) : Command_OK(CMD.DO_OISM, "NEXT", null, null, null, 0L))
			{
				return get_attribute("NUMBER");
			}
			return -1;
		}

		private int Command_OISM_A_Confirm(int num, int crc, ref int cnt)
		{
			if (!Command_OK(CMD.DO_OISM, "CONF", Att("No", num.ToString()), Att("CRC", crc.ToString()), null, 0L))
			{
				return -1;
			}
			cnt = get_attribute("COUNT");
			return get_attribute("NEXT");
		}

		private Key Command_OKP_Get_Status(string mod = null)
		{
			Key result = new Key(-1);
			if (!Command_OK(CMD.GET_INFO, "K", null, null, null, 0L))
			{
				return result;
			}
			XAttribute xAttribute = x_answer.Root.Attribute("NeedUpdate");
			if (xAttribute == null || string.IsNullOrEmpty(xAttribute.Value))
			{
				return result;
			}
			result.need = int.Parse(xAttribute.Value);
			xAttribute = x_answer.Root.Attribute("D7");
			if (xAttribute == null || !int.TryParse(xAttribute.Value, out result.D7))
			{
				result.D7 = 0;
			}
			XElement xElement = x_answer.Root.Element("URL");
			if (xElement == null || string.IsNullOrEmpty(xElement.Value))
			{
				return result;
			}
			int num = xElement.Value.IndexOf("://");
			num = ((num >= 0) ? (num + 3) : 0);
			string[] array = xElement.Value.Substring(num).Split(':');
			if (!int.TryParse(array[1], out var result2))
			{
				return result;
			}
			result.port = result2;
			result.url = array[0];
			return result;
		}

		private bool Command_OKP_Get_Req()
		{
			return Command_OK(CMD.DO_OKP, "READ", null, null, null, 0L);
		}

		private bool Command_OKP_Load(int len, byte[] ticket)
		{
			return Command_OK(CMD.DO_OKP, "LOAD", Att("LENGTH", len.ToString()), null, HexString(ticket), 0L);
		}

		private byte[] CreateHeaderNF()
		{
			if (!Command_OK(CMD.GET_REG, "?", null, null, null, 0L))
			{
				return null;
			}
			XAttribute xAttribute;
			if ((xAttribute = x_answer.Root.Attribute("T1037")) == null)
			{
				return null;
			}
			XAttribute xAttribute2;
			if ((xAttribute2 = x_answer.Root.Attribute("T1041")) == null)
			{
				return null;
			}
			if (GetNoticeCount() <= 0)
			{
				return null;
			}
			int num = get_attribute("FIRST");
			if (num <= 0)
			{
				ErrorShow("Invalid number current notice", "Некорректный номер текущего уведомления");
				return null;
			}
			int num2 = get_attribute("CURRENT");
			if (num2 <= 0)
			{
				ErrorShow("Invalid or zero number of notices in current session", "Ошибка или нет уведомлений для выгрузки в этой сессии");
				return null;
			}
			int num3 = num + num2 - 1;
			byte[] array = new byte[375];
			for (int i = 0; i < array.Length; i++)
			{
				array[i] = 32;
			}
			Encoding.GetEncoding("cp866").GetBytes("Отчет о реализации маркированного товара").CopyTo(array, 0);
			Encoding.GetEncoding("cp866").GetBytes("\"Утилита MITSU для ККТ Mitsu-1-F\", версия " + typeof(MainForm).Assembly.GetName().Version?.ToString() + "(c) ООО \"ВиЭйВи\", 2023").CopyTo(array, 66);
			Encoding.GetEncoding("cp866").GetBytes(xAttribute.Value, 0, 16, array, 322);
			Encoding.GetEncoding("cp866").GetBytes(xAttribute2.Value, 0, 16, array, 342);
			array[358] = 4;
			Encoding.ASCII.GetBytes(num.ToString("D4")).CopyTo(array, 359);
			Encoding.ASCII.GetBytes(num3.ToString("D4")).CopyTo(array, 363);
			Encoding.ASCII.GetBytes(num2.ToString("D4")).CopyTo(array, 367);
			return array;
		}

		private void DocFromFN(bool arc, decimal num)
		{
			if (Command_OK(CMD.GET_DOC, (arc ? "A" : "") + num, null, null, null, 0L))
			{
				Command_Print();
			}
		}

		private bool FN_Doc_Type(decimal num)
		{
			return Command_OK(CMD.GET_DOC, num.ToString(), null, null, null, 0L);
		}

		private xml_block FN_Doc_XML(bool arc, decimal num)
		{
			xml_block result = new xml_block(0, -1);
			if (!Command_OK(CMD.GET_DOC, (arc ? "A:" : "X:") + num, null, null, null, 0L))
			{
				throw new Exception();
			}
			XAttribute xAttribute = x_answer.Root.Attribute("LENGTH");
			if (xAttribute != null && !string.IsNullOrEmpty(xAttribute.Value))
			{
				result.Length = int.Parse(xAttribute.Value);
			}
			xAttribute = x_answer.Root.Attribute("OFFSET");
			if (xAttribute != null && !string.IsNullOrEmpty(xAttribute.Value))
			{
				result.Offset = int.Parse(xAttribute.Value, NumberStyles.HexNumber, CultureInfo.InvariantCulture);
			}
			return result;
		}

		private bool FN_Get_XML(int length, int offset)
		{
			return Command_OK(CMD.READ, "", Att("LENGTH", length.ToString()), Att("OFFSET", offset.ToString("X8")), null, 0L);
		}

		private XDocument FN_Parse_XML(string message)
		{
			message = Hex2string(message);
			message = message.Replace("&amp;", "&").Replace("&", "&amp;");
			return XDocument.Parse(message);
		}

		private void PowerReset()
		{
			int was_numports = SerialPort.GetPortNames().Length;
			if (Command_OK(CMD.DEVICE_JOB, "0", null, null, null, 0L))
			{
				Power_Reset(10, was_numports);
			}
		}

		private void PowerSet()
		{
			Command_OK(CMD.SET_POWER, checkBox_PowerFlag.Checked ? "1" : "0", null, null, null, 0L);
		}

		private void PowerGet()
		{
			if (Command_OK(CMD.GET_POWER, "?", null, null, null, 0L))
			{
				checkBox_PowerFlag.Checked = x_answer.Root.Attribute("POWER").Value.ToString() != "0";
			}
		}

		private void StatePrinter()
		{
			Command_OK(CMD.DEVICE_JOB, "3", null, null, null, 0L);
		}

		private Setup Setup_Get(bool trace = true)
		{
			Setup setup = default(Setup);
			setup.ComBaudrate = -1;
			setup.PrnBaudrate = -1;
			setup.PrnModel = -1;
			setup.PrnPaper = -1;
			setup.PrnWidth = -1;
			setup.PrnFont = -1;
			setup.PrnLength = -1;
			setup.PrnPrst = -1;
			setup.PrnPrstTime = -1;
			setup.OptLine = -1;
			setup.OptQRalign = -1;
			setup.OptRound = -1;
			setup.OptCut = -1;
			setup.OptTest = -1;
			setup.OptDrawer = -1;
			setup.OptBeeper = -1;
			setup.OptQRText = -1;
			setup.OptItemCnt = -1;
			setup.DrwPin = 0;
			setup.DrwPulse = 0;
			setup.DrwFall = 0;
			Setup result = setup;
			XAttribute xAttribute;
			if (Command_OK(CMD.GET_COM, "?", null, null, null, 0L, trace) && (xAttribute = x_answer.Root.Attribute("COM")) != null && int.TryParse(xAttribute.Value.ToString(), out var result2))
			{
				result.ComBaudrate = result2;
			}
			if (Command_OK(CMD.GET_PRINTER, "?", null, null, null, 0L, trace))
			{
				if ((xAttribute = x_answer.Root.Attribute("BAUDRATE")) != null && int.TryParse(xAttribute.Value.ToString(), out result2))
				{
					result.PrnBaudrate = result2;
				}
				if ((xAttribute = x_answer.Root.Attribute("PRINTER")) != null && int.TryParse(xAttribute.Value.ToString(), out result2))
				{
					result.PrnModel = result2;
				}
				if ((xAttribute = x_answer.Root.Attribute("PAPER")) != null && int.TryParse(xAttribute.Value.ToString(), out result2))
				{
					result.PrnPaper = result2;
				}
				if ((xAttribute = x_answer.Root.Attribute("WIDTH")) != null && int.TryParse(xAttribute.Value.ToString(), out result2))
				{
					result.PrnWidth = result2;
				}
				if ((xAttribute = x_answer.Root.Attribute("FONT")) != null && int.TryParse(xAttribute.Value.ToString(), out result2))
				{
					result.PrnFont = result2;
				}
				if ((xAttribute = x_answer.Root.Attribute("LENGTH")) != null && int.TryParse(xAttribute.Value.ToString(), out result2))
				{
					result.PrnLength = result2;
				}
				if ((xAttribute = x_answer.Root.Attribute("PRST")) != null && int.TryParse(xAttribute.Value.ToString(), out result2))
				{
					result.PrnPrst = result2;
				}
				if ((xAttribute = x_answer.Root.Attribute("PRSTTIME")) != null && int.TryParse(xAttribute.Value.ToString(), out result2))
				{
					result.PrnPrstTime = result2;
				}
			}
			if (Command_OK(CMD.OPTION, "", null, null, null, 0L, trace))
			{
				if ((xAttribute = x_answer.Root.Attribute("b0")) != null && int.TryParse(xAttribute.Value.ToString(), out result2))
				{
					result.OptLine = result2;
				}
				if ((xAttribute = x_answer.Root.Attribute("b1")) != null && int.TryParse(xAttribute.Value.ToString(), out result2))
				{
					result.OptQRalign = result2;
				}
				if ((xAttribute = x_answer.Root.Attribute("b2")) != null && int.TryParse(xAttribute.Value.ToString(), out result2))
				{
					result.OptRound = result2;
				}
				if ((xAttribute = x_answer.Root.Attribute("b3")) != null && int.TryParse(xAttribute.Value.ToString(), out result2))
				{
					result.OptCut = result2;
				}
				if ((xAttribute = x_answer.Root.Attribute("b4")) != null && int.TryParse(xAttribute.Value.ToString(), out result2))
				{
					result.OptTest = result2;
				}
				if ((xAttribute = x_answer.Root.Attribute("b5")) != null && int.TryParse(xAttribute.Value.ToString(), out result2))
				{
					result.OptDrawer = result2;
				}
				if ((xAttribute = x_answer.Root.Attribute("b6")) != null && int.TryParse(xAttribute.Value.ToString(), out result2))
				{
					result.OptBeeper = result2;
				}
				if ((xAttribute = x_answer.Root.Attribute("b7")) != null && int.TryParse(xAttribute.Value.ToString(), out result2))
				{
					result.OptQRText = result2;
				}
				if ((xAttribute = x_answer.Root.Attribute("b8")) != null && int.TryParse(xAttribute.Value.ToString(), out result2))
				{
					result.OptItemCnt = result2;
				}
			}
			if (Command_OK(CMD.GET_CD, "?", null, null, null, 0L, trace))
			{
				if ((xAttribute = x_answer.Root.Attribute("CD")) != null && int.TryParse(xAttribute.Value.ToString(), out result2))
				{
					result.DrwPin = result2;
				}
				if ((xAttribute = x_answer.Root.Attribute("Rise")) != null && int.TryParse(xAttribute.Value.ToString(), out result2))
				{
					result.DrwPulse = result2;
				}
				if ((xAttribute = x_answer.Root.Attribute("Fall")) != null && int.TryParse(xAttribute.Value.ToString(), out result2))
				{
					result.DrwFall = result2;
				}
			}
			return result;
		}

		private bool Setup_COM(string rate)
		{
			return Command_OK(CMD.SET_COM, rate, null, null, null, 0L);
		}

		private bool Setup_Set(Setup Set, bool trace = true)
		{
			if (Set.ComBaudrate >= 0 && !Command_OK(CMD.SET_COM, Set.ComBaudrate.ToString(), null, null, null, 0L, trace))
			{
				return false;
			}
			string text = "";
			if (Set.PrnModel >= 0)
			{
				if (Set.PrnBaudrate >= 0)
				{
					text += Att("BAUDRATE", Set.PrnBaudrate.ToString());
				}
				if (Set.PrnPaper >= 0)
				{
					text += Att("PAPER", Set.PrnPaper.ToString());
				}
				if (Set.PrnFont >= 0)
				{
					text += Att("FONT", Set.PrnFont.ToString());
				}
				if (!Command_OK(CMD.SET_PRINTER, Set.PrnModel.ToString(), text, null, null, 0L, trace))
				{
					return false;
				}
			}
			text = "";
			if (Set.OptLine >= 0)
			{
				text += Att("b0", Set.OptLine.ToString());
			}
			if (Set.OptQRalign >= 0)
			{
				text += Att("b1", Set.OptQRalign.ToString());
			}
			if (Set.OptRound >= 0)
			{
				text += Att("b2", Set.OptRound.ToString());
			}
			if (Set.OptCut >= 0)
			{
				text += Att("b3", Set.OptCut.ToString());
			}
			if (Set.OptTest >= 0)
			{
				text += Att("b4", Set.OptTest.ToString());
			}
			if (Set.OptDrawer >= 0)
			{
				text += Att("b5", Set.OptDrawer.ToString());
			}
			if (Set.OptBeeper >= 0)
			{
				text += Att("b6", Set.OptBeeper.ToString());
			}
			if (Set.OptQRText >= 0)
			{
				text += Att("b7", Set.OptQRText.ToString());
			}
			if (Set.OptItemCnt >= 0)
			{
				text += Att("b8", Set.OptItemCnt.ToString());
			}
			if (!string.IsNullOrEmpty(text) && !Command_OK(CMD.OPTION, "", text, null, null, 0L, trace))
			{
				return false;
			}
			text = "";
			if (Set.DrwPin > 0)
			{
				text += Att("CD", Set.DrwPin.ToString());
			}
			if (Set.DrwPulse > 0)
			{
				text += Att("Rise", Set.DrwPulse.ToString());
			}
			if (Set.DrwFall > 0)
			{
				text += Att("Fall", Set.DrwFall.ToString());
			}
			if (!string.IsNullOrEmpty(text))
			{
				return Command_OK(CMD.SET, "", text, null, null, 5000L, trace);
			}
			return true;
		}

		[DllImport("user32.dll")]
		private static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);

		protected override void WndProc(ref Message m)
		{
			if (m.HWnd == base.Handle && m.Msg == WM_HOTKEY)
			{
				switch (m.WParam.ToInt32())
				{
				case 2:
					richTextBox_Log.Clear();
					break;
				case 3:
				{
					CheckBox checkBox = checkBox_StatusPrint;
					checkBox.Visible = !checkBox.Visible;
					checkBox_StatusPrint.Update();
					Button button = button_KKTSerialSet;
					NumericUpDown numericUpDown = numeric_KKTSerial;
					Button button2 = button_KKTSerialSet;
					bool flag2 = (button2.Visible = !button2.Visible);
					bool enabled = (numericUpDown.Enabled = flag2);
					button.Enabled = enabled;
					numeric_KKTSerial.ReadOnly = !numeric_KKTSerial.Enabled;
					button_KKTSerialSet.Update();
					Button button3 = button_FW_Upload;
					button3.Visible = !button3.Visible;
					button_FW_Upload.Update();
					break;
				}
				}
			}
			base.WndProc(ref m);
		}

		public MainForm()
		{
			Init_Spark_Mitsu();
			LoadTunings();
			CheckBox_ReReg_CheckedChanged(null, null);
			RegisterHotKey(base.Handle, 2, 3u, 27u);
			RegisterHotKey(base.Handle, 3, 3u, 80u);
			Com = new ComButtons();
			User_Data = new Ticket_UserForm();
			Customer_Data = new Ticket_CustomerForm();
			Option_Data = new Ticket_OptionForm();
			Correction_Data = new Ticket_CorrectionForm();
			Ticket_Text = new Ticket_TextForm();
			Ticket_ItemOption = new Ticket_ItemOptionForm();
			Response_Form = new ResponseForm();
			Progress = new Progress_Bar("CmdProgress", base.ClientSize.Width);
			base.Controls.Add(Progress.Bar);
			Progress.Bar.BringToFront();
			radio_txt_QR_Left.Checked = true;
			comboBox_Beznal.SelectedIndex = 0;
			panel_AddItem.Height = AddItem_Hmin;
			comboBox_ItemMeasure.SelectedIndex = 0;
			comboBox_ItemType.SelectedIndex = 1;
			comboBox_TypeOfCode.SelectedIndex = 5;
			comboBox_ItemNDS.SelectedIndex = 0;
			comboBox_ItemStatus.SelectedIndex = 1;
			comboBox_Mark.SelectedIndex = -1;
			comboBox_txt_BarcodeType.SelectedIndex = 2;
			comboBox_txt_LineType.SelectedIndex = 0;
			dataGrid_Header_Init();
			dataGrid_TextLines_Init();
			dataGrid_Other_Init();
			dataGrid_Status_Init();
		}

		private void dataGrid_Header_Init()
		{
			radioButton_Header = new RadioButton[4] { radioButton_Header1, radioButton_Header2, radioButton_Header3, radioButton_Header4 };
			dataGrid_Header = new DataGridView[4] { dataGrid_Header1, dataGrid_Header2, dataGrid_Header3, dataGrid_Header4 };
			DataGridView[] array = dataGrid_Header;
			foreach (DataGridView dataGridView in array)
			{
				dataGridView.Columns.Add(Lng.GetStr("Inverse", "Инверсия"), "0");
				dataGridView.Columns.Add(Lng.GetStr("Width", "Ширина"), "0");
				dataGridView.Columns.Add(Lng.GetStr("Height", "Высота"), "0");
				dataGridView.Columns.Add(Lng.GetStr("Font", "Шрифт"), "0");
				dataGridView.Columns.Add(Lng.GetStr("Underline", "Подчеркивание"), "0");
				dataGridView.Columns.Add(Lng.GetStr("Align", "Выравнивание"), "0");
				for (int j = 0; j < 10; j++)
				{
					dataGridView.Rows.Add("0", "0", "0", "0", "0", "0", "");
				}
				for (int k = 0; k < 6; k++)
				{
					dataGridView.Columns[k].Width = 16;
					dataGridView.Columns[k].CellTemplate.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
					dataGridView.Columns[k].Resizable = DataGridViewTriState.False;
				}
			}
		}

		private void dataGrid_TextLines_Init()
		{
			dataGrid_TextLines.Columns.Add(Lng.GetStr("Inverse", "Инверсия"), "0");
			dataGrid_TextLines.Columns.Add(Lng.GetStr("Width", "Ширина"), "0");
			dataGrid_TextLines.Columns.Add(Lng.GetStr("Height", "Высота"), "0");
			dataGrid_TextLines.Columns.Add(Lng.GetStr("Font", "Шрифт"), "0");
			dataGrid_TextLines.Columns.Add(Lng.GetStr("Underline", "Подчеркивание"), "0");
			dataGrid_TextLines.Columns.Add(Lng.GetStr("Align", "Выравнивание"), "0");
			dataGrid_TextLines.Rows.Add(0, 0, 0, 0, 0, 0, "******************************************");
			dataGrid_TextLines.Rows.Add(0, 1, 1, 0, 0, 1, Lng.GetStr("William Shakespeare", "А.С.Пушкин"));
			dataGrid_TextLines.Rows.Add(1, 2, 1, 0, 0, 1, Lng.GetStr("Hamlet", "Евгений Онегин"));
			dataGrid_TextLines.Rows.Add(0, 3, 1, 0, 1, 1, Lng.GetStr("Spoken by Hamlet", "ГЛАВА ПЕРВАЯ"));
			dataGrid_TextLines.Rows.Add(0, 0, 0, 2, 0, 2, Lng.GetStr("Act III\nSceen I", "И жить торопится, и чувствовать спешит.\n Кн.Вяземский."));
			dataGrid_TextLines.Rows.Add(0, 4, 4, 0, 0, 1, "*** I ***");
			dataGrid_TextLines.Rows.Add(0, 0, 0, 0, 0, 0, Lng.GetStr("To be, or not to be, that is the question:\r\nWhether 'tis nobler in the mind to suffer\r\nThe slings and arrows of outrageous fortune,\r\nOr to take arms against a sea of troubles\r\nAnd by opposing end them. To die—to sleep,\r\nNo more; and by a sleep to say we end\r\nThe heart-ache and the thousand natural shocks\r\nThat flesh is heir to: 'tis a consummation", "Мой дядя самых честных правил,\r\nКогда не в шутку занемог,\r\nОн уважать себя заставил\r\nИ лучше выдумать не мог.\r\nЕго пример другим наука;\r\nНо, боже мой, какая скука\r\nС больным сидеть и день и ночь,\r\nНе отходя ни шагу прочь!"));
			dataGrid_TextLines.Rows.Add(0, 0, 0, 0, 0, 0, Lng.GetStr("Devoutly to be wish'd. To die, to sleep;\r\nTo sleep, perchance to dream—ay, there's the rub:\r\nFor in that sleep of death what dreams may come,\r\nWhen we have shuffled off this mortal coil,\r\nMust give us pause—there's the respect\r\nThat makes calamity of so long life.", "Какое низкое коварство\r\nПолуживого забавлять,\r\nЕму подушки поправлять,\r\nПечально подносить лекарство,\r\nВздыхать и думать про себя:\r\nКогда же черт возьмет тебя!"));
			dataGrid_TextLines.Rows.Add(0, 0, 0, 0, 0, 0, "------------------------------------------");
			dataGrid_TextLines.Rows.Add(1, 3, 1, 0, 2, 1, Lng.GetStr("THE END", "КОНЕЦ"));
			for (int i = 0; i < 6; i++)
			{
				dataGrid_TextLines.Columns[i].Width = 16;
				dataGrid_TextLines.Columns[i].CellTemplate.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
				dataGrid_TextLines.Columns[i].Resizable = DataGridViewTriState.False;
			}
			for (int j = 0; j < checkedListBox_TextLines.Items.Count; j++)
			{
				checkedListBox_TextLines.SetItemChecked(j, value: true);
			}
		}

		private void TabControl1_DrawItem(object sender, DrawItemEventArgs e)
		{
			Graphics graphics = e.Graphics;
			TabPage tabPage = tabControl_Main.TabPages[e.Index];
			Rectangle tabRect = tabControl_Main.GetTabRect(e.Index);
			Font font = tabPage.Font;
			Brush brush;
			if (e.State == DrawItemState.Selected)
			{
				brush = new SolidBrush(Color.Black);
				graphics.FillRectangle(Brushes.LightCyan, e.Bounds);
			}
			else
			{
				brush = new SolidBrush(e.ForeColor);
				graphics.FillRectangle(Brushes.LightGray, e.Bounds);
			}
			StringFormat format = new StringFormat
			{
				Alignment = StringAlignment.Center,
				LineAlignment = StringAlignment.Center
			};
			graphics.DrawString(tabPage.Text, font, brush, tabRect, format);
		}

		public string GetExceptionMessage(Exception z)
		{
			if (z == null)
			{
				return "";
			}
			try
			{
				return z.Message + " " + GetExceptionMessage(z.InnerException);
			}
			catch (Exception ex)
			{
				return ex.Message;
			}
		}

		private string CreateBitSequence(CheckedListBox sender)
		{
			string text = "";
			foreach (object checkedItem in sender.CheckedItems)
			{
				text = text + ((text.Length > 0) ? "," : "") + checkedItem.ToString().Split('.')[0];
			}
			return text;
		}

		private string CreateBitSequence(DataGridView sender, string tag, int num = 0)
		{
			if (sender.ColumnCount < 1 || !(sender.Columns[0] is DataGridViewCheckBoxColumn) || sender.RowCount <= 0)
			{
				return "";
			}
			string text = "";
			for (int i = 0; i < sender.RowCount; i++)
			{
				if ((DataGridViewCheckBoxCell)sender.Rows[i].Cells[0] != null && ((DataGridViewCheckBoxCell)sender.Rows[i].Cells[0]).Value != null && Convert.ToBoolean(((DataGridViewCheckBoxCell)sender.Rows[i].Cells[0]).Value))
				{
					if (text.Length > 0)
					{
						text += ",";
					}
					text += i + num;
				}
			}
			return string.IsNullOrEmpty(text) ? "" : ("<" + tag + ">" + text + "</" + tag + ">");
		}

		private string GetValue(string name)
		{
			if (x_answer == null)
			{
				return string.Empty;
			}
			XAttribute xAttribute;
			if ((xAttribute = x_answer.Root.Attribute(name)) != null)
			{
				return xAttribute.Value.Trim();
			}
			XElement xElement;
			if ((xElement = x_answer.Root.Element(name)) != null)
			{
				return xElement.Value.Trim();
			}
			return string.Empty;
		}

		private void FillByteMask(CheckedListBox list, string value)
		{
			byte result = 0;
			if (value != null)
			{
				byte.TryParse(value.Trim(), out result);
			}
			for (int i = 0; i < list.Items.Count; i++)
			{
				list.SetItemChecked(i, (result & (1 << i)) != 0);
			}
		}

		private void CellBeginEdit_ListBoxCheck(object sender, DataGridViewCellCancelEventArgs e)
		{
			dataGrid_CellBeginEdit(sender, e);
			CheckedListBox checkedListBox;
			if (sender == dataGrid_LAN)
			{
				checkedListBox = checkedListBox_LAN;
			}
			else if (sender == dataGrid_OFD)
			{
				checkedListBox = checkedListBox_OFD;
			}
			else if (sender == dataGrid_OISM)
			{
				checkedListBox = checkedListBox_OISM;
			}
			else
			{
				if (sender != dataGrid_OKP)
				{
					return;
				}
				checkedListBox = checkedListBox_OKP;
			}
			checkedListBox.SetItemChecked(e.RowIndex, value: true);
		}

		public bool IsHexChar(string S)
		{
			string text = S.ToUpper();
			foreach (char c in text)
			{
				if (c < '0' || 'F' < c || ('9' < c && c < 'A'))
				{
					return false;
				}
			}
			return true;
		}

		public string HexString(string symbols)
		{
			for (int num = symbols.IndexOf('\\'); num >= 0; num = symbols.IndexOf('\\'))
			{
				symbols = symbols[num + 1] switch
				{
					'x' => symbols.Replace(symbols.Substring(num, 4), Hex2string(symbols.Substring(num + 2, 2))), 
					'u' => symbols.Replace(symbols.Substring(num, 6), Hex2string(symbols.Substring(num + 4, 2))), 
					_ => symbols.Remove(num, 1), 
				};
			}
			byte[] bytes = Encoding.GetEncoding("cp866").GetBytes(symbols);
			string text = "";
			for (int i = 0; i < bytes.Count(); i++)
			{
				text += bytes[i].ToString("X2");
			}
			return text;
		}

		public string HexString(byte[] data)
		{
			string text = "";
			for (int i = 0; i < data.Length; i++)
			{
				text += data[i].ToString("X2");
			}
			return text;
		}

		public byte[] Hex2byte(string hex)
		{
			if (string.IsNullOrEmpty(hex))
			{
				return null;
			}
			byte[] array = new byte[hex.Length / 2];
			for (int i = 0; i < array.Length; i++)
			{
				if (!byte.TryParse(hex.Substring(i * 2, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out array[i]))
				{
					return null;
				}
			}
			return array;
		}

		public string Hex2string(string hex)
		{
			if (string.IsNullOrEmpty(hex))
			{
				return null;
			}
			byte[] bytes = Hex2byte(hex);
			return Encoding.GetEncoding("windows-1251").GetString(bytes);
		}

		public ushort CRC16_CCITT(byte[] Data)
		{
			ushort num = ushort.MaxValue;
			ushort num2 = 4129;
			for (int i = 0; i < Data.Length; i++)
			{
				num ^= (ushort)(Data[i] << 8);
				for (int j = 0; j < 8; j++)
				{
					num = (((num & 0x8000) == 0) ? ((ushort)(num << 1)) : ((ushort)((num << 1) ^ num2)));
				}
			}
			return num;
		}

		public ushort CRC16_CCITT(byte[] Data, int start, int stop)
		{
			ushort num = ushort.MaxValue;
			ushort num2 = 4129;
			for (int i = 0; i < Data.Length; i++)
			{
				if (i < start || i > stop)
				{
					num ^= (ushort)(Data[i] << 8);
					for (int j = 0; j < 8; j++)
					{
						num = (((num & 0x8000) == 0) ? ((ushort)(num << 1)) : ((ushort)((num << 1) ^ num2)));
					}
				}
			}
			return num;
		}

		public ushort CRC16_CCITT(byte[] Data, int with, int start, int stop)
		{
			ushort num = ushort.MaxValue;
			ushort num2 = 4129;
			for (int i = with; i < Data.Length; i++)
			{
				if (i < start + with || i > stop + with)
				{
					num ^= (ushort)(Data[i] << 8);
					for (int j = 0; j < 8; j++)
					{
						num = (((num & 0x8000) == 0) ? ((ushort)(num << 1)) : ((ushort)((num << 1) ^ num2)));
					}
				}
			}
			return num;
		}

		private bool CheckRTC(DateTime dt, string message)
		{
			if (dt.Date.Equals(DateTime.MinValue))
			{
				Log_Invoke('!', message + Lng.GetStr(": COMMUNICATION FAILED !!! ", ": СБОЙ СВЯЗИ !!! "), -1L);
				return false;
			}
			char dir = (dt.Date.Equals(DateTime.Now.Date) ? '.' : '!');
			Log_Invoke(dir, message + Lng.GetStr(" Date/Time ", " Дата/время ") + dt.ToString("yyyy-MM-dd HH:mm:ss"), -1L);
			return true;
		}

		private new string Tag(string tag, string val)
		{
			return string.IsNullOrEmpty(val) ? "" : ("<" + tag + ">" + val + "</" + tag + ">");
		}

		private string Att(string atr, string val, bool any = false)
		{
			if (string.IsNullOrEmpty(val) && !any)
			{
				return "";
			}
			if (string.IsNullOrEmpty(atr))
			{
				return " " + val;
			}
			return " " + atr + "='" + val + "'";
		}

		private string format_amount(XElement tag, string attr, int index, bool form = false)
		{
			decimal num = default(decimal);
			if (tag != null)
			{
				XAttribute xAttribute = tag.Attribute(attr);
				if (xAttribute != null)
				{
					string[] array = xAttribute.Value.Split('|');
					num = Convert.ToDecimal(array[index]);
				}
			}
			if (form)
			{
				return num.ToString("F0", nfi);
			}
			return (num / 100m).ToString("F2", nfi);
		}

		private string amount2string(NumericUpDown box)
		{
			return (box.Value == 0m) ? "" : Convert.ToUInt32(box.Value * 100m).ToString();
		}

		private string combo2string(ComboBox combo)
		{
			return (string.IsNullOrEmpty(combo.Text) || combo.SelectedIndex < 1) ? "" : combo.SelectedIndex.ToString();
		}

		private int get_attribute(string attr)
		{
			XAttribute xAttribute = x_answer.Root.Attribute(attr);
			if (xAttribute == null || string.IsNullOrEmpty(xAttribute.Value) || !int.TryParse(xAttribute.Value, out var result))
			{
				return -1;
			}
			return result;
		}

		private int get_element(string tag)
		{
			XElement xElement = x_answer.Root.Element(tag);
			if (xElement == null || string.IsNullOrEmpty(xElement.Value) || !int.TryParse(xElement.Value, out var result))
			{
				return -1;
			}
			return result;
		}

		public int max(int x, int y)
		{
			return (x >= y) ? x : y;
		}

		public int min(int x, int y)
		{
			return (x < y) ? x : y;
		}

		private void Initialize_LAN_button()
		{
			IpMac[] iPAddress = arp.GetIPAddress();
			for (int i = 0; i < iPAddress.Length; i++)
			{
				IpMac ipMac = iPAddress[i];
				if (ipMac.mac.Substring(0, 5).Equals(mac_address_head))
				{
					textBox_KKT_IP.Text = ipMac.ip.ToString();
					Lan_Button.Checked = true;
					Log_Invoke('.', string.Format("LAN: {0} (MAC = {1}) --> {2}", ipMac.ip.ToString(), ipMac.mac, Lng.GetStr("Device detected!", "Есть контакт!")), 0L);
				}
			}
		}

		private void Initialize_COM_buttons(object sender, EventArgs e)
		{
			Initialize_LAN_button();
			int num = Com.SetButtons();
			bool visible;
			if (num == 0)
			{
				Label label = label_COMBaudRate;
				visible = (comboBox_COMBaudRate.Visible = false);
				label.Visible = visible;
				return;
			}
			label_COMBaudRate.Location = new Point(409, (num < 409) ? 2 : 25);
			comboBox_COMBaudRate.Location = new Point(496, label_COMBaudRate.Top);
			Label label2 = label_COMBaudRate;
			visible = (comboBox_COMBaudRate.Visible = true);
			label2.Visible = visible;
			stop_scan = false;
			button_RunTest.Text = Lng.GetStr("Stop scan", "Остановить");
			button_RunTest.Visible = true;
			button_RunTest.Select();
			Progress.Start(Progress_Bar.MODE.OPE, Com.Buttons.Length * 5);
			RadioButton[] buttons = Com.Buttons;
			foreach (RadioButton radioButton in buttons)
			{
				panel_RadioButtons.Controls.Add(radioButton);
				radioButton.CheckedChanged += radioButton_COM_CheckedChanged;
				radioButton.BringToFront();
				radioButton.Enabled = false;
			}
			int[] array = new int[5] { 115200, 57600, 38400, 19200, 9600 };
			try
			{
				int[] array2 = array;
				for (int j = 0; j < array2.Length; j++)
				{
					int num2 = array2[j];
					RadioButton[] buttons2 = Com.Buttons;
					foreach (RadioButton radioButton2 in buttons2)
					{
						Progress.Bar.PerformStep();
						Application.DoEvents();
						if (stop_scan)
						{
							throw new Exception();
						}
						if (!radioButton2.Enabled && COM_Connect(radioButton2, num2))
						{
							if (COM_CommandExecute(COMMAND.Cmd(CMD.GET_DATE, ""), 23040000 / num2) == 0)
							{
								visible = (radioButton2.Enabled = true);
								radioButton2.Checked = visible;
								comboBox_COMBaudRate.Text = num2.ToString();
								Com.Selected = radioButton2;
							}
							COM_Disconnect();
						}
					}
				}
			}
			catch
			{
			}
			stop_scan = false;
			button_RunTest.Text = "ТЕСТ\r\nCOM+USB+LAN";
			button_RunTest.Visible = 1 < Com.Buttons.Count((RadioButton radio) => radio.Enabled);
			if (Com.Selected != null)
			{
				Log_Invoke('.', Com.Selected.Text + ": " + comboBox_COMBaudRate.Text + Lng.GetStr(" --> Device detected!", " --> Есть контакт!"), 0L);
			}
			Progress.Stop();
		}

		public void radioButton_COM_CheckedChanged(object sender, EventArgs e)
		{
			RadioButton radioButton = (RadioButton)sender;
			if (radioButton.Enabled && radioButton.Checked)
			{
				Com.Selected = radioButton;
				Lan_Button.Checked = false;
				Ser_Button.Checked = false;
			}
		}

		private void Lan_Button_CheckedChanged(object sender, EventArgs e)
		{
			if (Lan_Button.Checked)
			{
				if (Com.Selected != null)
				{
					Com.Selected.Checked = false;
				}
				Com.Selected = null;
				Ser_Button.Checked = false;
			}
		}

		private void Ser_Button_CheckedChanged(object sender, EventArgs e)
		{
			if (ServiceFiscalReg != null)
			{
				ServiceFiscalReg.Dispose();
				ServiceFiscalReg = null;
			}
			if (!Ser_Button.Checked)
			{
				return;
			}
			try
			{
				ServiceFiscalReg = new LanDriver(IPAddress.Parse(textBox_Service_IP.Text), Convert.ToInt32(textBox_Service_Port.Text));
				ServiceFiscalReg.WriteData(DeviceEncoding.GetBytes(numericUpDown_Service_ID.Text + "|!spark_init"));
				ReadFromService();
				if (answer.StartsWith("OK"))
				{
					if (Com.Selected != null)
					{
						Com.Selected.Checked = false;
					}
					Lan_Button.Checked = false;
					Com.Selected = null;
				}
				else
				{
					TestErrorFromService(answer, ok: true);
				}
			}
			catch (Exception ex)
			{
				if (ServiceFiscalReg != null)
				{
					ServiceFiscalReg.Dispose();
					ServiceFiscalReg = null;
				}
				ErrorShow("Error using Service", "Ошибка при работе через сервис", ": ", ex);
				Ser_Button.Checked = false;
			}
		}

		private void COM_Disconnect()
		{
			if (ComFiscalReg == null)
			{
				return;
			}
			try
			{
				if (ComFiscalReg.IsOpen)
				{
					ComFiscalReg.Close();
				}
			}
			catch
			{
			}
			ComFiscalReg.Dispose();
			ComFiscalReg = null;
		}

		private bool COM_Connect(RadioButton radio, int baud = 0)
		{
			if (radio == null)
			{
				ErrorShow("COM port not selected!", "СОМ-порт не выбран!");
				return false;
			}
			int result = baud;
			if (baud == 0 && !int.TryParse(comboBox_COMBaudRate.Text, out result))
			{
				ErrorShow("Invalid baudrate: " + comboBox_COMBaudRate.Text + ". Using 115200...", "Некорректная скорость: " + comboBox_COMBaudRate.Text + ". Используем 115200...");
				comboBox_COMBaudRate.Text = "115200";
				result = 115200;
			}
			try
			{
				if (ComFiscalReg != null)
				{
					ComFiscalReg.Dispose();
				}
				ComFiscalReg = new SerialPort(radio.Text, result)
				{
					WriteTimeout = 10000,
					ReadTimeout = 15000
				};
				ComFiscalReg.Open();
			}
			catch (Exception ex)
			{
				if (baud == 0)
				{
					ErrorShow("Error opening port: ", "Не удалось открыть порт: ", radio.Text + "\r\n", ex);
				}
				return false;
			}
			return true;
		}

		private bool COM_WriteLine(string data)
		{
			if (string.IsNullOrEmpty(data))
			{
				return false;
			}
			if (ComFiscalReg.BytesToRead > 0)
			{
				ComFiscalReg.DiscardInBuffer();
			}
			IEnumerable<byte> first = new byte[3]
			{
				2,
				Convert.ToByte(data.Length % 256),
				Convert.ToByte(data.Length / 256)
			};
			first = first.Concat(DeviceEncoding.GetBytes(data + "\u0003"));
			first = first.Concat(new byte[1] { (byte)first.Aggregate(0, (int current, byte b) => current ^ b) });
			try
			{
				ComFiscalReg.Write(first.ToArray(), 0, first.Count());
			}
			catch (Exception ex)
			{
				ErrorShow("Error sending command to port: ", "Ошибка передачи команды в порт: ", ComFiscalReg.PortName + "\r\n", ex);
				return false;
			}
			return true;
		}

		private bool COM_timeout(long ticks)
		{
			Stopwatch stopwatch = Stopwatch.StartNew();
			bool flag;
			do
			{
				Thread.Sleep(1);
				if (!ComFiscalReg_IsOpen)
				{
					ErrorShow("Connection lost, port: ", "Нет соединения, порт ", Com.Selected.Text);
					stopwatch.Stop();
					return false;
				}
				if (Progress.Cmd_Visible && stopwatch.ElapsedMilliseconds > Progress.Bar.Value)
				{
					Progress.Bar.PerformStep();
				}
				flag = ComFiscalReg.BytesToRead == 0;
			}
			while (flag && stopwatch.ElapsedMilliseconds <= ticks);
			stopwatch.Stop();
			return flag;
		}

		private byte COM_CommandExecute(string command, long timeout)
		{
			byte[] array = new byte[2];
			if (!ComFiscalReg_IsOpen)
			{
				return 1;
			}
			for (int i = 0; i < 2; i++)
			{
				Array.Clear(array, 0, 2);
				if (command != null && !COM_WriteLine(command))
				{
					return 1;
				}
				if (COM_timeout(timeout))
				{
					return 2;
				}
				try
				{
					ComFiscalReg.Read(array, 0, 1);
					switch (array[0])
					{
					case 21:
						Thread.Sleep(500);
						break;
					case 60:
						answer = Encoding.Default.GetString(array, 0, 1);
						ComFiscalReg.NewLine = "\u0003";
						ComFiscalReg.Encoding = Encoding.Default;
						answer += ComFiscalReg.ReadLine();
						ComFiscalReg.Read(array, 1, 1);
						return 0;
					default:
						return 5;
					}
				}
				catch (Exception ex)
				{
					ErrorShow("Error reading from port: ", "Ошибка чтения из устройства: ", ComFiscalReg.PortName + "\r\n", ex);
					return 3;
				}
			}
			return 4;
		}

		private bool LAN_CommandExecute(string command)
		{
			bool result = true;
			try
			{
				if (LanFiscalReg != null)
				{
					LanFiscalReg.Dispose();
					LanFiscalReg = null;
				}
				LanFiscalReg = new LanDriver(IPAddress.Parse(textBox_KKT_IP.Text), Convert.ToInt32(textBox_PortNo.Text));
				answer = "";
				if (command != null)
				{
					int num = command.Length;
					int num2 = 0;
					while (num >= 537)
					{
						LanFiscalReg.WriteData(DeviceEncoding.GetBytes(command.Substring(num2, 535) + "\u0017"));
						num2 += 535;
						num -= 535;
					}
					LanFiscalReg.WriteData(DeviceEncoding.GetBytes(command.Substring(num2)));
				}
				long num3 = (Progress.Cmd_Visible ? Progress.Bar.Maximum : 60000);
				Stopwatch stopwatch = Stopwatch.StartNew();
				do
				{
					Thread.Sleep(1);
					if (Progress.Cmd_Visible && stopwatch.ElapsedMilliseconds > Progress.Bar.Value)
					{
						Progress.Bar.PerformStep();
					}
				}
				while (!LanFiscalReg.Available && stopwatch.ElapsedMilliseconds <= num3);
				stopwatch.Stop();
				byte[] array = null;
				int read_length = 0;
				while ((array = LanFiscalReg.ReadData(2000, out read_length)) != null)
				{
					answer += Encoding.Default.GetString(array, 0, read_length);
				}
			}
			catch (Exception ex)
			{
				ErrorShow("Communication error via LAN: ", "Ошибка при работе через локальную сеть: ", "", ex);
				result = false;
			}
			finally
			{
				LanFiscalReg.Dispose();
				LanFiscalReg = null;
			}
			return result;
		}

		private void ReadFromService()
		{
			long num = (Progress.Cmd_Visible ? Progress.Bar.Maximum : 60000);
			Stopwatch stopwatch = Stopwatch.StartNew();
			do
			{
				Thread.Sleep(1);
				if (Progress.Cmd_Visible && stopwatch.ElapsedMilliseconds > Progress.Bar.Value)
				{
					Progress.Bar.PerformStep();
				}
			}
			while (!ServiceFiscalReg.Available && stopwatch.ElapsedMilliseconds <= num);
			stopwatch.Stop();
			answer = "";
			byte[] bytes;
			int read_length;
			while ((bytes = ServiceFiscalReg.ReadData(1000, out read_length)) != null)
			{
				answer += Encoding.Default.GetString(bytes, 0, read_length);
			}
		}

		private void TestErrorFromService(string str, bool ok = false)
		{
			try
			{
				switch (str)
				{
				case "ERR_UNKNOWN":
					throw new Exception("Неизвестная ошибка");
				case "ERR_CONNECTION":
					throw new Exception("Ошибка подключения к ККТ");
				case "ERR_WAITING_INIT":
					throw new Exception("Необходимо выдать команду на инициализацию ККТ");
				case "ERR_RUNTIME":
					throw new Exception("Ошибка выполнения команды");
				}
				if (ok)
				{
					throw new Exception("Ошибка инициализации ККТ");
				}
			}
			catch (Exception ex)
			{
				Log_Invoke('!', str, 0L);
				throw ex;
			}
		}

		private bool Service_CommandExecute(string command)
		{
			bool result = true;
			try
			{
				ServiceFiscalReg.WriteData(DeviceEncoding.GetBytes(numericUpDown_Service_ID.Text + "|" + command));
				ReadFromService();
				TestErrorFromService(answer);
			}
			catch (Exception ex)
			{
				ErrorShow("Communication error via Service: ", "Ошибка при работе через сервис: ", "", ex);
				result = false;
			}
			return result;
		}

		private void clearAllToolStripMenuItem_Click(object sender, EventArgs e)
		{
			richTextBox_Log.Clear();
		}

		private void copyToolStripMenuItem_Click(object sender, EventArgs e)
		{
			int firstCharIndexOfCurrentLine = richTextBox_Log.GetFirstCharIndexOfCurrentLine();
			int lineFromCharIndex = richTextBox_Log.GetLineFromCharIndex(firstCharIndexOfCurrentLine);
			richTextBox_Log.Select(firstCharIndexOfCurrentLine + 16, richTextBox_Log.Lines[lineFromCharIndex].Length - 16);
			richTextBox_Log.Copy();
		}

		private void copyAllToolStripMenuItem_Click(object sender, EventArgs e)
		{
			richTextBox_Log.SelectAll();
			richTextBox_Log.Copy();
		}

		private void Log_Invoke(char dir, string message, long ticks = -1L)
		{
			if (!checkBox_StatusLog.Checked)
			{
				return;
			}
			Color color = Color.Black;
			LogColors[] markColors = MarkColors;
			for (int i = 0; i < markColors.Length; i++)
			{
				LogColors logColors = markColors[i];
				if (dir == logColors.mark)
				{
					color = logColors.brush;
					break;
				}
			}
			if (ticks == 0)
			{
				AddLine(string.Format("{0,12} {1}{1} {2}", DateTime.Now.ToString("HH:mm:ss.fff"), dir, message), color);
			}
			else if (ticks < 0)
			{
				AddLine(string.Format("{0,14}{0} {1}", dir, message), color);
			}
			else if (ticks < 10000000)
			{
				AddLine(string.Format("{0,12:d} {1}{1} {2}", ticks / 10000, dir, message), color);
			}
			else
			{
				AddLine(string.Format("{0,12:F3} {1}{1} {2}", (decimal)ticks / 10000000m, dir, message), color);
			}
		}

		private void AddLine(string text, Color color, int highlight = 0)
		{
			if (string.IsNullOrEmpty(text))
			{
				return;
			}
			int length = richTextBox_Log.Text.Length;
			richTextBox_Log.AppendText(text + "\n");
			highlight |= ((!(color == Color.Black)) ? 1 : 0);
			if (highlight != 0)
			{
				richTextBox_Log.SelectionStart = length;
				richTextBox_Log.SelectionLength = text.Length;
				if (((uint)highlight & (true ? 1u : 0u)) != 0)
				{
					richTextBox_Log.SelectionColor = color;
				}
				if (((uint)highlight & 2u) != 0)
				{
					richTextBox_Log.SelectionFont = new Font(richTextBox_Log.Font, FontStyle.Bold);
				}
				if (((uint)highlight & 4u) != 0)
				{
					richTextBox_Log.SelectionAlignment = HorizontalAlignment.Center;
				}
				richTextBox_Log.SelectionLength = 0;
			}
			richTextBox_Log.ScrollToCaret();
		}

		private bool Command_OK(CMD cmd, string a1 = "", string a2 = null, string a3 = null, string val = null, long t = 0L, bool log = true)
		{
			string text = ((cmd == CMD.FREE) ? a1 : COMMAND.Cmd(cmd, a1, a2, a3, val));
			if (t == 0)
			{
				t = COMMAND.cmd_list[(int)cmd].timeout;
			}
			if (log)
			{
				Log_Invoke('<', text, 0L);
			}
			long ticks = DateTime.Now.Ticks;
			bool flag = false;
			if (Lan_Button.Checked)
			{
				flag = LAN_CommandExecute(text);
			}
			else if (Ser_Button.Checked)
			{
				flag = Service_CommandExecute(text);
			}
			else
			{
				if (!ComFiscalReg_IsOpen)
				{
					COM_Connect(Com.Selected);
				}
				switch (COM_CommandExecute(text, t))
				{
				case 0:
					flag = true;
					break;
				case 2:
					Log_Invoke('!', Lng.GetStr("Timeout", "Таймаут ответа от ККТ"), -1L);
					break;
				case 4:
					Log_Invoke('!', "NAK", -1L);
					break;
				case 5:
					Log_Invoke('!', Lng.GetStr("Received garbage", "Получен мусор"), -1L);
					break;
				}
				COM_Disconnect();
			}
			ticks = DateTime.Now.Ticks - ticks;
			if (!flag)
			{
				GC.Collect();
				return false;
			}
			try
			{
				x_answer = XDocument.Parse(answer);
				if (x_answer == null)
				{
					Log_Invoke('!', Lng.GetStr("Empty response!", "Пустой ответ от ККТ!"), -1L);
					return false;
				}
				flag = Log_Parse();
				if (log)
				{
					Log_Invoke(flag ? '>' : '!', answer, ticks);
				}
				GC.Collect();
				return flag;
			}
			catch (Exception ex)
			{
				ErrorShow("Error parsing FP response: ", "Ошибка разбора ответа: ", answer, ex);
				GC.Collect();
				return false;
			}
		}

		private bool Try_Command(string command)
		{
			if (string.IsNullOrEmpty(command))
			{
				return true;
			}
			try
			{
				x_answer = XDocument.Parse(command);
				return Command_OK(CMD.FREE, command, null, null, null, 0L);
			}
			catch (Exception ex)
			{
				ErrorShow("Error parsing command", "Ошибка разбора команды", ": ", ex);
				return false;
			}
		}

		public XElement CreateNodeXML(string name, string data, XElement root = null)
		{
			if (root == null)
			{
				root = init_program.Root;
			}
			XElement xElement = root.Element(name);
			if (xElement == null)
			{
				root.Add(xElement = new XElement(name));
			}
			xElement.Value = (string.IsNullOrEmpty(data) ? "" : data);
			return xElement;
		}

		public void CreateNodeXML(int num, string data)
		{
			XElement xElement = init_program.Root.Element(init_elements[num].name);
			if (xElement != null)
			{
				xElement.Value = (string.IsNullOrEmpty(data) ? "" : data);
			}
			else
			{
				init_program.Root.Add(new XElement(init_elements[num].name, data));
			}
		}

		public string GetStrXML(int num, string def = "")
		{
			XElement xElement = init_program.Root.Element(init_elements[num].name);
			return (xElement == null) ? def : xElement.Value;
		}

		public int GetIntXML(int num, int def = 0)
		{
			XElement xElement = init_program.Root.Element(init_elements[num].name);
			try
			{
				return (xElement == null) ? def : Convert.ToInt32(xElement.Value);
			}
			catch
			{
			}
			return def;
		}

		private void LoadLanguage()
		{
			Lng.Current = "ru";
			try
			{
				init_program = XDocument.Load(InitFileName);
			}
			catch
			{
				return;
			}
			XElement xElement = init_program.Root.Element("LANGUAGE");
			if (xElement != null)
			{
				Lng.Current = xElement.Value.ToString().ToLower();
			}
		}

		private void DefaultTunings()
		{
			init_program = new XDocument(new XDeclaration("1.0", "windows-1251", "true"), new XElement("ini", ""));
			Init_xml[] array = init_elements;
			for (int i = 0; i < array.Length; i++)
			{
				Init_xml init_xml = array[i];
				init_program.Root.Add(new XElement(init_xml.name, init_xml.def));
			}
			DefaultKMData();
			init_program.Save(InitFileName);
		}

		private XElement DefaultKMData()
		{
			XElement xElement = CreateNodeXML("KM", "");
			Init_xml[] array = init_km_list;
			for (int i = 0; i < array.Length; i++)
			{
				Init_xml init_xml = array[i];
				xElement.Add(new XElement(init_xml.name, init_xml.def));
			}
			return xElement;
		}

		private void LoadTunings()
		{
			try
			{
				if ((init_program = XDocument.Load(InitFileName)) == null)
				{
					DefaultTunings();
					DefaultRegData();
				}
				base.Top = max(GetIntXML(1), 0);
				base.Left = max(GetIntXML(2), 0);
				base.Width = max(GetIntXML(3), 800);
				base.Height = max(GetIntXML(4), 600);
				textBox_KKT_IP.Text = GetStrXML(5);
				textBox_PortNo.Text = GetIntXML(6, 8200).ToString();
				comboBox_COMBaudRate.Text = GetIntXML(7, 115200).ToString();
				textBox_Service_IP.Text = GetStrXML(8);
				textBox_Service_Port.Text = GetIntXML(9, 8800).ToString();
				numericUpDown_Service_ID.Value = GetIntXML(10, 1);
				textBox_IP_OFD.Text = GetStrXML(11);
				numericUpDown_Port_OFD.Value = GetIntXML(12, 19086);
				textBox_CashierName.Text = GetStrXML(13);
				GetStrXML(14);
				textBox_FW_CRC.Text = GetStrXML(15);
				checkBox_StatusPrint.Checked = GetIntXML(16) == 1;
				textBox_AddressOISM.Text = GetStrXML(17);
				numericUpDown_PortOISM.Value = GetIntXML(18, 21701);
				textBox_AddressOKP.Text = GetStrXML(19);
				numericUpDown_PortOKP.Value = GetIntXML(20, 31101);
				button_FW_Upload.Visible = GetIntXML(21) == 1;
				textBox_FW_File.Text = GetStrXML(22);
				int intXML = GetIntXML(23);
				bool flag = intXML != 0;
				Button button = button_KKTSerialSet;
				Button button2 = button_KKTSerialSet;
				bool flag3 = (numeric_KKTSerial.Enabled = flag);
				bool visible = (button2.Enabled = flag3);
				button.Visible = visible;
				numeric_KKTSerial.ReadOnly = !flag;
				if (flag)
				{
					numeric_KKTSerial.Value = intXML;
				}
				DefaultRegData();
				XElement xElement = init_program.Root.Element("REG");
				if (xElement != null)
				{
					XElement xElement2;
					foreach (DataGridViewRow item in (IEnumerable)dataGrid_RegData.Rows)
					{
						xElement2 = xElement.Element(item.HeaderCell.Value.ToString());
						if (xElement2 != null)
						{
							item.Cells[0].Value = xElement2.Value;
						}
					}
					if ((xElement2 = xElement.Element("TAX")) != null)
					{
						uint num = Convert.ToUInt16(xElement2.Value, 16);
						int num2 = 0;
						while (num2 < checkedListBox_Taxes.Items.Count)
						{
							checkedListBox_Taxes.SetItemChecked(num2, (num & 1) != 0);
							num2++;
							num >>= 1;
						}
					}
					if ((xElement2 = xElement.Element("ModeA")) != null)
					{
						uint num = Convert.ToUInt16(xElement2.Value, 16);
						int num3 = 0;
						while (num3 < checkedListBox_ModeA.Items.Count)
						{
							checkedListBox_ModeA.SetItemChecked(num3, (num & 1) != 0);
							num3++;
							num >>= 1;
						}
						CheckBox checkBox = checkBox_Autonom;
						visible = (checkBox_StatusAutonom.Checked = checkedListBox_ModeA.GetItemChecked(1));
						checkBox.Checked = visible;
					}
					if ((xElement2 = xElement.Element("ModeB")) != null)
					{
						uint num = Convert.ToUInt16(xElement2.Value, 16);
						int num4 = 0;
						while (num4 < checkedListBox_ModeB.Items.Count)
						{
							checkedListBox_ModeB.SetItemChecked(num4, (num & 1) != 0);
							num4++;
							num >>= 1;
						}
					}
				}
				xElement = init_program.Root.Element("KM");
				if (xElement == null)
				{
					xElement = DefaultKMData();
				}
				IEnumerable<XElement> enumerable = xElement.Elements();
				foreach (XElement item2 in enumerable)
				{
					comboBox_Mark.Items.Add(item2.Value.ToString());
				}
			}
			catch
			{
				DefaultTunings();
				DefaultRegData();
			}
		}

		private void Form1_FormClosed(object sender, FormClosedEventArgs e)
		{
			CreateNodeXML(0, Lng.Current.ToString());
			CreateNodeXML(1, Convert.ToString(base.Top));
			CreateNodeXML(2, Convert.ToString(base.Left));
			CreateNodeXML(3, Convert.ToString(base.Width));
			CreateNodeXML(4, Convert.ToString(base.Height));
			CreateNodeXML(5, textBox_KKT_IP.Text);
			CreateNodeXML(6, textBox_PortNo.Text);
			CreateNodeXML(7, comboBox_COMBaudRate.Text);
			CreateNodeXML(8, textBox_Service_IP.Text);
			CreateNodeXML(9, textBox_Service_Port.Text);
			CreateNodeXML(10, numericUpDown_Service_ID.Text);
			CreateNodeXML(11, textBox_IP_OFD.Text);
			CreateNodeXML(12, numericUpDown_Port_OFD.Value.ToString());
			CreateNodeXML(13, textBox_CashierName.Text);
			if (Com.Selected != null)
			{
				CreateNodeXML(14, Com.Selected.Text);
			}
			else if (Lan_Button.Checked)
			{
				CreateNodeXML(14, "LAN");
			}
			else if (Ser_Button.Checked)
			{
				CreateNodeXML(14, "SERVICE");
			}
			CreateNodeXML(15, textBox_FW_CRC.Text);
			CreateNodeXML(16, checkBox_StatusPrint.Checked ? "1" : "0");
			CreateNodeXML(17, textBox_AddressOISM.Text);
			CreateNodeXML(18, numericUpDown_PortOISM.Value.ToString());
			CreateNodeXML(19, textBox_AddressOKP.Text);
			CreateNodeXML(20, numericUpDown_PortOKP.Value.ToString());
			CreateNodeXML(21, button_FW_Upload.Visible ? "1" : "0");
			CreateNodeXML(22, textBox_FW_File.Text);
			if (button_KKTSerialSet.Visible)
			{
				CreateNodeXML(23, Convert.ToString(numeric_KKTSerial.Text));
			}
			XElement root = CreateNodeXML("REG", "");
			foreach (DataGridViewRow item in (IEnumerable)dataGrid_RegData.Rows)
			{
				CreateNodeXML(item.HeaderCell.Value.ToString(), item.Cells[0].Value?.ToString(), root);
			}
			int num = 0;
			for (int i = 0; i < checkedListBox_Taxes.Items.Count; i++)
			{
				if (checkedListBox_Taxes.GetItemChecked(i))
				{
					num |= 1 << i;
				}
			}
			CreateNodeXML("TAX", num.ToString("X2"), root);
			num = 0;
			for (int j = 0; j < checkedListBox_ModeA.Items.Count; j++)
			{
				if (checkedListBox_ModeA.GetItemChecked(j))
				{
					num |= 1 << j;
				}
			}
			CreateNodeXML("ModeA", num.ToString("X2"), root);
			num = 0;
			for (int k = 0; k < checkedListBox_ModeB.Items.Count; k++)
			{
				if (checkedListBox_ModeB.GetItemChecked(k))
				{
					num |= 1 << k;
				}
			}
			CreateNodeXML("ModeB", num.ToString("X2"), root);
			root = CreateNodeXML("KM", "");
			for (int l = 0; l < comboBox_Mark.Items.Count; l++)
			{
				CreateNodeXML($"M{l}", comboBox_Mark.Items[l].ToString(), root);
			}
			init_program.Root.Save(InitFileName);
			StreamWriter streamWriter = new StreamWriter(SparkSerialFile);
			streamWriter.Flush();
			streamWriter.Close();
			SparkSerialFile.Close();
		}

		private void Form1_Resize(object sender, EventArgs e)
		{
			if (Progress != null)
			{
				Progress.Resize(base.ClientSize.Width);
			}
		}

		private void Form1_Shown(object sender, EventArgs e)
		{
			Form1_Resize(sender, e);
			numericUpDown_ItemLimit_ValueChanged(null, e);
			Initialize_COM_buttons(null, null);
		}

		private void comboBox_Language_SelectedIndexChanged(object sender, EventArgs e)
		{
			Lng.Current = comboBox_Language.Text.ToLower();
		}

		private void CheckDateTime()
		{
			DateTime dateTime = GetDateTime();
			if (!dateTime.Equals(DateTime.MinValue))
			{
				DateTime now = DateTime.Now;
				double totalSeconds = dateTime.TimeOfDay.Subtract(now.TimeOfDay).TotalSeconds;
				if (!dateTime.Date.Equals(now.Date))
				{
					throw new Exception($"Дата в ККТ [{dateTime:d}] отличается от текущей !!!");
				}
				if (totalSeconds >= 300.0 || totalSeconds < -300.0)
				{
					throw new Exception($"Время в ККТ [{dateTime:t}] отличается от текущего более, чем на 5 минут !!!");
				}
			}
		}

		private void Button_GetDateTime_Click(object sender, EventArgs e)
		{
			try
			{
				CheckDateTime();
			}
			catch (Exception ex)
			{
				Log_Invoke('!', ex.Message, -1L);
			}
		}

		private void Button_SetDateTime_Click(object sender, EventArgs e)
		{
			SetDateTime();
		}

		private void Button_VerKKT_Click(object sender, EventArgs e)
		{
			GetVersion();
		}

		private void Button_GetCashier_Click(object sender, EventArgs e)
		{
			GetCashier();
		}

		private void Button_SetCashier_Click(object sender, EventArgs e)
		{
			SetCashier();
		}

		private void Button_OpenShift_Click(object sender, EventArgs e)
		{
			ShiftOpen();
		}

		private void Button_CloseShift_Click(object sender, EventArgs e)
		{
			ShiftClose();
		}

		private void Button_OptShiftData_Click(object sender, EventArgs e)
		{
			Shift_Options.ShowDialog();
		}

		private void Button_ShiftStatus_Click(object sender, EventArgs e)
		{
			ShiftStatus();
		}

		private void Button_GetShiftData_Click(object sender, EventArgs e)
		{
			ShiftData();
		}

		private void Button_GetFullData_Click(object sender, EventArgs e)
		{
			FullData();
		}

		private void Button_PrintXreport_Click(object sender, EventArgs e)
		{
			PrintXreport();
		}

		private void Button_RepCurrentCalc_Click(object sender, EventArgs e)
		{
			RepCurrentCalc();
		}

		private void Button_CloseFN_Click(object sender, EventArgs e)
		{
			CloseFN();
		}

		private void Button_KKTSerialSet_Click(object sender, EventArgs e)
		{
			KKTSerialSet();
		}

		private void Button_GetDocStatus_Click(object sender, EventArgs e)
		{
			GetDocStatus();
		}

		private void Button_DocCancel_Click(object sender, EventArgs e)
		{
			DocCancel();
			button_CheckOpen.Text = Lng.GetStr("OPEN", "ЧЕК");
			Button button = button_CheckOpen;
			Button button2 = button_CCh;
			bool flag2 = (button_FCh.Enabled = true);
			bool enabled = (button2.Enabled = flag2);
			button.Enabled = enabled;
			Button button3 = button_CCh;
			enabled = (button_FCh.Visible = true);
			button3.Visible = !enabled;
			corr = false;
		}

		private void Button_DocFromFN_Click(object sender, EventArgs e)
		{
			DocFromFN(checkBox_Arc.Checked, numericUpDown_FromFN.Value);
		}

		private void Button_RunTest_Click(object sender, EventArgs e)
		{
			if (button_RunTest.Text == Lng.GetStr("Stop scan", "Остановить"))
			{
				stop_scan = true;
				return;
			}
			clearAllToolStripMenuItem_Click(sender, e);
			if (Com.Buttons.Count((RadioButton p) => p.Enabled) < 2)
			{
				Log_Invoke('!', Lng.GetStr("2 COM PORTS CONNECTION NEEDED !!! ", "НЕОБХОДИМО ПОДКЛЮЧЕНИЕ ПО 2-м COM ПОРТАМ !!! "), -1L);
				return;
			}
			RadioButton radioButton = Com.Buttons.First((RadioButton p) => p.Enabled);
			radioButton.Checked = true;
			DateTime dateTime = GetDateTime(log: false);
			if (!CheckRTC(dateTime, radioButton.Text))
			{
				return;
			}
			RadioButton radioButton2 = Com.Buttons.Last((RadioButton p) => p.Enabled);
			radioButton2.Checked = true;
			dateTime = SetDateTime(log: false);
			if (!CheckRTC(dateTime, radioButton2.Text))
			{
				return;
			}
			Lan_Button.Checked = true;
			dateTime = GetDateTime(log: false);
			if (CheckRTC(dateTime, "LAN " + textBox_KKT_IP.Text))
			{
				radioButton2.Checked = true;
				if (RunTest())
				{
					Log_Invoke('.', Lng.GetStr("TEST COMPLETED SUCCESSFULLY!!!", "ТЕСТ ЗАВЕРШЕН УСПЕШНО!!!"), -1L);
				}
				else
				{
					Log_Invoke('!', Lng.GetStr("TEST: SOMETHING WENT WRONG!!!", "ТЕСТ: ЧТО-ТО ПОШЛО НЕ ТАК!!!"), -1L);
				}
			}
		}

		private void add_message(DataGridViewCell cell, string[] mess)
		{
			string text = cell.Value.ToString();
			if (int.TryParse(text, out var result) && result >= 0 && result < mess.Length)
			{
				cell.Value = text + mess[result];
			}
		}

		private void Button_Status_FN_Click(object sender, EventArgs e)
		{
			Status_FN();
		}

		private void button_Totals_FN_Click(object sender, EventArgs e)
		{
			Totals_FN();
		}

		private void button_Status_OFD_Click(object sender, EventArgs e)
		{
			Status_OFD();
		}

		private void button_Status_DM_Click(object sender, EventArgs e)
		{
			Status_DM();
		}

		private void numericUpDown_ItemLimit_ValueChanged(object sender, EventArgs e)
		{
			numericUpDown_AutoReceiptRepeat.Enabled = numericUpDown_AutoReceiptItemNo.Value < 11m;
		}

		private void button_Script_Click(object sender, EventArgs e)
		{
			openFileDialog1.Title = "Выберите файл скрипта";
			openFileDialog1.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
			if (openFileDialog1.ShowDialog() != DialogResult.OK)
			{
				return;
			}
			FileStream fileStream = null;
			TextReader textReader = null;
			try
			{
				fileStream = new FileStream(openFileDialog1.FileName, FileMode.Open, FileAccess.Read);
				textReader = new StreamReader(fileStream);
			}
			catch (Exception ex)
			{
				ErrorShow("Error opening script file", "Ошибка открытия файла скрипта", ": ", ex);
				textReader?.Close();
				fileStream?.Close();
				return;
			}
			finally
			{
			}
			int num = 1;
			richTextBox_Log.SuspendLayout();
			try
			{
				string command;
				while ((command = textReader.ReadLine()) != null)
				{
					num++;
					if (!Try_Command(command))
					{
						break;
					}
				}
			}
			catch (Exception ex2)
			{
				ErrorShow($"Error reading line #{num} from script file", $"Ошибка чтения строки # {num} файла скрипта", "", ex2);
			}
			finally
			{
				richTextBox_Log.ResumeLayout();
				textReader.Close();
				fileStream.Close();
			}
		}

		private void Button_PaperCut(object sender, EventArgs e)
		{
			if (Command_OK(CMD.FEED, "24", null, null, null, 0L))
			{
				Command_OK(CMD.CUT, "", null, null, null, 0L);
			}
		}

		private void button_ManualCommand_Click(object sender, EventArgs e)
		{
			if (string.IsNullOrEmpty(comboBox_Command.Text.Trim()))
			{
				ErrorShow("Command not specified", "Команда не задана");
				return;
			}
			try
			{
				XDocument.Parse(comboBox_Command.Text);
			}
			catch (Exception ex)
			{
				ErrorShow("Error while command parsing", "Ошибка разбора команды", ": ", ex);
				return;
			}
			Try_Command(comboBox_Command.Text);
		}

		private void comboBox_Command_KeyPressed(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Return)
			{
				button_ManualCommand_Click(sender, e);
			}
		}

		private void Button_Drawer_Open_Click(object sender, EventArgs e)
		{
			Drawer_Open(sender, e);
		}

		private void Button_ResetPrinter_Click(object sender, EventArgs e)
		{
			ResetPrinter();
		}

		private void Button_RestartFN_Click(object sender, EventArgs e)
		{
			RestartFN();
		}

		private void Button_EraseSPI_Click(object sender, EventArgs e)
		{
			EraseSPI();
		}

		private void Button_ResetFN_Click(object sender, EventArgs e)
		{
			ResetFN();
		}

		private void Button_Do_Update_Click(object sender, EventArgs e)
		{
			Setup set = Setup_Get(trace: false);
			if (checkBox_Setup_Reload.Checked)
			{
				Log_Invoke(' ', Lng.GetStr("Reading current settings...", "Считывание текущих настроек..."), -1L);
				richTextBox_Log.Refresh();
				if (Command_Get_LAN(trace: false))
				{
					FillStringGridRows(dataGrid_LAN.Rows);
				}
				if (Command_Get_OFD(trace: false))
				{
					FillStringGridRows(dataGrid_OFD.Rows);
				}
				if (Command_Get_OISM(trace: false))
				{
					FillStringGridRows(dataGrid_OISM.Rows);
				}
				if (Command_Get_OKP(trace: false))
				{
					FillStringGridRows(dataGrid_OKP.Rows);
				}
				richTextBox_Log.Undo();
				Log_Invoke('.', Lng.GetStr("Reading current settings -> OK.", "Считывание текущих настроек -> ОК."), -1L);
			}
			Log_Invoke(' ', Lng.GetStr("Firmware is being installed. Device will be restarted...", "Обновление устанавливается. Устройство будет перезагружено..."), -1L);
			richTextBox_Log.Refresh();
			Do_Update();
			string cRC = Get_CRC32();
			if (checkBox_FW_CRC.Checked && !string.IsNullOrEmpty(cRC))
			{
				if (cRC.Equals(textBox_FW_CRC.Text))
				{
					Log_Invoke('.', Lng.GetStr("Firmware installed OK, true CRC: ", "Прошивка установлена успешно, CRC: ") + cRC, -1L);
				}
				else
				{
					Log_Invoke('!', Lng.GetStr("Firmware Download Failed, false CRC: ", "Ошибка CRC: ") + cRC, -1L);
				}
				richTextBox_Log.Refresh();
			}
			if (checkBox_Setup_Reload.Checked)
			{
				Setup setup = Setup_Get(trace: false);
				if (setup.ComBaudrate != set.ComBaudrate)
				{
					Log_Invoke('!', Lng.GetStr("COM baudrate changed. Restoring ", "Скорость COM порта слетела. Восстанавливаем ") + set.ComBaudrate, -1L);
				}
				if (setup.PrnBaudrate != -1 && setup.PrnBaudrate == set.PrnBaudrate)
				{
					set.PrnBaudrate = -1;
				}
				if (setup.PrnModel != -1 && setup.PrnModel == set.PrnModel)
				{
					set.PrnModel = -1;
				}
				if (setup.PrnPaper != -1 && setup.PrnPaper == set.PrnPaper)
				{
					set.PrnPaper = -1;
				}
				if (setup.PrnWidth != -1 && setup.PrnWidth == set.PrnWidth)
				{
					set.PrnWidth = -1;
				}
				if (setup.PrnFont != -1 && setup.PrnFont == set.PrnFont)
				{
					set.PrnFont = -1;
				}
				if (setup.PrnLength != -1 && setup.PrnLength == set.PrnLength)
				{
					set.PrnLength = -1;
				}
				if (setup.PrnPrst != -1 && setup.PrnPrst == set.PrnPrst)
				{
					set.PrnPrst = -1;
				}
				if (setup.PrnPrstTime != -1 && setup.PrnPrstTime == set.PrnPrstTime)
				{
					set.PrnPrstTime = -1;
				}
				if (setup.OptLine != -1 && setup.OptLine == set.OptLine)
				{
					set.OptLine = -1;
				}
				if (setup.OptQRalign != -1 && setup.OptQRalign == set.OptQRalign)
				{
					set.OptQRalign = -1;
				}
				if (setup.OptRound != -1 && setup.OptRound == set.OptRound)
				{
					set.OptRound = -1;
				}
				if (setup.OptCut != -1 && setup.OptCut == set.OptCut)
				{
					set.OptCut = -1;
				}
				if (setup.OptTest != -1 && setup.OptTest == set.OptTest)
				{
					set.OptTest = -1;
				}
				if (setup.OptDrawer != -1 && setup.OptDrawer == set.OptDrawer)
				{
					set.OptDrawer = -1;
				}
				if (setup.OptBeeper != -1 && setup.OptBeeper == set.OptBeeper)
				{
					set.OptBeeper = -1;
				}
				if (setup.OptQRText != -1 && setup.OptQRText == set.OptQRText)
				{
					set.OptQRText = -1;
				}
				if (setup.OptItemCnt != -1 && setup.OptItemCnt == set.OptItemCnt)
				{
					set.OptItemCnt = -1;
				}
				if (setup.DrwPin != 0 && setup.DrwPin == set.DrwPin)
				{
					set.DrwPin = 0;
				}
				if (setup.DrwPulse != 0 && setup.DrwPulse == set.DrwPulse)
				{
					set.DrwPulse = 0;
				}
				if (setup.DrwFall != 0 && setup.DrwFall == set.DrwFall)
				{
					set.DrwFall = 0;
				}
				Log_Invoke(' ', Lng.GetStr("Restoring original settings...", "Восстановление настроек..."), -1L);
				richTextBox_Log.Refresh();
				Setup_Set(set, trace: false);
				checkBox_LAN_SelectAll.Checked = true;
				if (Command_Set_OKP(trace: false) && Command_Set_OISM(trace: false) && Command_Set_OFD(trace: false))
				{
					Command_Set_LAN(trace: false);
				}
				checkBox_LAN_SelectAll.Checked = false;
			}
		}

		private void Button_FW_Upload_Click(object sender, EventArgs e)
		{
			FW_Upload();
		}

		private FW_Status Check_FW_Status(bool trace = true)
		{
			FW_Status fW_Status = default(FW_Status);
			fW_Status.Success = false;
			fW_Status.Status = '0';
			fW_Status.Lengh = 0;
			fW_Status.Mark = "";
			fW_Status.CRC = "";
			fW_Status.emsg = "";
			fW_Status.rmsg = "";
			FW_Status result = fW_Status;
			if (!Command_Flash(4, 0L, 123L, null, null, trace))
			{
				return result;
			}
			XAttribute xAttribute = x_answer.Root.Attribute("FLASH");
			XAttribute xAttribute2 = x_answer.Root.Attribute("LENGTH");
			XAttribute xAttribute3 = x_answer.Root.Attribute("MARK");
			XAttribute xAttribute4 = x_answer.Root.Attribute("CRC32");
			result.Success = xAttribute != null && xAttribute2 != null && xAttribute3 != null && xAttribute4 != null;
			if (xAttribute != null)
			{
				result.Status = xAttribute.Value.ToString()[3];
			}
			if (xAttribute2 != null)
			{
				result.Lengh = int.Parse(xAttribute2.Value.ToString());
			}
			if (xAttribute3 != null)
			{
				result.Mark = xAttribute3.Value.ToString();
			}
			if (xAttribute4 != null)
			{
				result.CRC = xAttribute4.Value.ToString();
			}
			result.emsg = "Status = " + result.Status + ": ";
			result.rmsg = "Статус = " + result.Status + ": ";
			switch (result.Status)
			{
			case '0':
				result.emsg += "FW not uploaded!";
				result.rmsg += "Прошивка не загружена!";
				result.Success = false;
				break;
			case '1':
				result.emsg += "FW uploaded!";
				result.rmsg = "Прошивка загружена!";
				break;
			case '3':
				result.emsg += "FW ready for update!";
				result.rmsg = "Прошивка готова к установке!";
				break;
			case '7':
				result.emsg += "FW already updated!";
				result.rmsg = "Прошивка установлена!";
				break;
			default:
				result.emsg += "Unknown status!";
				result.rmsg = "Некорректный статус!";
				result.Success = false;
				break;
			}
			result.emsg += $"\r\nLength = {result.Lengh} byte";
			result.rmsg += $"\r\nРазмер = {result.Lengh} байт";
			if (result.Mark.Equals("DEADBEEF"))
			{
				ref string emsg = ref result.emsg;
				emsg = emsg + "\r\nMark = " + result.Mark + ": File is correct!";
				ref string rmsg = ref result.rmsg;
				rmsg = rmsg + "\r\nПризнак = " + result.Mark + ": Файл записан корректно!";
			}
			else
			{
				ref string emsg2 = ref result.emsg;
				emsg2 = emsg2 + "\r\nMark = " + result.Mark + ": File empty or corrupted!";
				ref string rmsg2 = ref result.rmsg;
				rmsg2 = rmsg2 + "\r\nПризнак = " + result.Mark + ": Файл пустой или некорректный!";
				result.Success = false;
			}
			if (result.CRC.Equals(textBox_FW_CRC.Text))
			{
				ref string emsg3 = ref result.emsg;
				emsg3 = emsg3 + "\r\nCRC32 = " + result.CRC + ": CRC32 correct!";
				ref string rmsg3 = ref result.rmsg;
				rmsg3 = rmsg3 + "\r\nCRC32 = " + result.CRC + ": Контрольная сумма корректная!";
			}
			else
			{
				ref string emsg4 = ref result.emsg;
				emsg4 = emsg4 + "\r\nCRC32 = " + result.CRC + ": CRC32 incorrect!";
				ref string rmsg4 = ref result.rmsg;
				rmsg4 = rmsg4 + "\r\nCRC32 = " + result.CRC + ": Контрольная сумма некорректна!";
				result.Success = false;
			}
			return result;
		}

		private void Button_FW_Status_Click(object sender, EventArgs e)
		{
			FW_Status fW_Status = Check_FW_Status();
			if (fW_Status.Success)
			{
				InfoShow(fW_Status.emsg, fW_Status.rmsg);
			}
			else
			{
				ErrorShow(fW_Status.emsg, fW_Status.rmsg);
			}
		}

		private void Button_FW_Download_Click(object sender, EventArgs e)
		{
			string text = ((textBox_FW_File.Text.LastIndexOf('\\') != -1) ? "" : (Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + "\\")) + textBox_FW_File.Text;
			if (string.IsNullOrEmpty(text) || !File.Exists(text))
			{
				openFileDialog1.Title = Lng.GetStr("Select Firmware file", "Выбор файла прошивки");
				openFileDialog1.Filter = Lng.GetStr("Binary files (*.bin)|*.bin|All files (*.*)|*.*", "Бинарные файлы (*.bin)|*.bin|Все файлы (*.*)|*.*");
				if (openFileDialog1.ShowDialog(this) != DialogResult.OK)
				{
					return;
				}
				text = openFileDialog1.FileName;
				if (string.IsNullOrEmpty(text) || !File.Exists(text))
				{
					ErrorShow("File not found!\n", "Файл прошивки не найден!\n", text);
					return;
				}
				textBox_FW_File.Text = text;
			}
			richTextBox_Log.Clear();
			bool flag = sender.Equals(button_FW_Download_Update);
			Cursor.Current = Cursors.WaitCursor;
			using FileStream fileStream = new FileStream(text, FileMode.Open, FileAccess.Read, FileShare.Read);
			try
			{
				Crc32Calculator crc32Calculator = new Crc32Calculator();
				textBox_FW_CRC.Text = crc32Calculator.CalculateStreamCrc(fileStream).ToString("X8");
				string crc = (checkBox_FW_CRC.Checked ? textBox_FW_CRC.Text : "");
				Log_Invoke(' ', Lng.GetStr("Flashing SPI memory...", "Очистка SPI памяти..."), -1L);
				richTextBox_Log.Refresh();
				Progress.Start(Progress_Bar.MODE.CMD, 5000, 500);
				if (!Command_Flash(1, fileStream.Length, 123L, crc, null, !flag))
				{
					Log_Parse();
					throw new Exception(string.Format(Lng.GetStr("Failed to erase SPI memory", "Не удалось очистить SPI память") + ": {0}", answer));
				}
				Progress.Stop();
				DateTime now = DateTime.Now;
				Log_Invoke(' ', Lng.GetStr("Downloading file...", "Загрузка файла прошивки..."), -1L);
				fileStream.Position = 0L;
				richTextBox_Log.Refresh();
				Progress.Start(Progress_Bar.MODE.OPE, Convert.ToInt32(fileStream.Length));
				long num = fileStream.Length;
				while (num > 0)
				{
					int num2 = min((int)num, 256);
					byte[] array = new byte[num2];
					long position = fileStream.Position;
					fileStream.Read(array, 0, num2);
					StringBuilder stringBuilder = new StringBuilder(num2 * 2);
					byte[] array2 = array;
					foreach (byte b in array2)
					{
						stringBuilder.Append(b.ToString("X2"));
					}
					if (!Command_Flash(2, num2, position, null, stringBuilder.ToString(), num2 < 256))
					{
						throw new Exception(string.Format(Lng.GetStr("Failed to download at", "Сбой загрузки файла на") + " {0:d}/{1:d}", position, fileStream.Length));
					}
					Progress.Bar.Increment(num2);
					num -= num2;
				}
				if (!Command_Flash(3, 0L, 0L, null, null, !flag))
				{
					Log_Parse();
					throw new Exception(string.Format(Lng.GetStr("Failed to download", "Сбой при загрузке файла") + ": {0}", answer));
				}
				TimeSpan timeSpan = DateTime.Now.Subtract(now);
				Log_Invoke(' ', string.Format(Lng.GetStr("File download complete, total bytes:", "Загрузка файла завершена, всего байт:") + " {0:d}", fileStream.Position), -1L);
				Progress.Stop();
				Cursor.Current = Cursors.Default;
				Log_Invoke(' ', Lng.GetStr("Checking downloaded file integrity...", "Проверка корректности загруженного файла..."), -1L);
				FW_Status fW_Status = Check_FW_Status(!flag);
				if (!fW_Status.Success)
				{
					ErrorShow(fW_Status.emsg, fW_Status.rmsg);
					throw new Exception(Lng.GetStr(fW_Status.emsg, fW_Status.rmsg));
				}
				timeSpan = DateTime.Now.Subtract(now);
				string text2 = $"FW file downloaded OK in {timeSpan.TotalSeconds:F2} sec and ready to install!";
				string text3 = $"Прошивка успешно загружена за {timeSpan.TotalSeconds:F2} сек и готова к установке!";
				Log_Invoke(' ', Lng.GetStr(text2, text3), -1L);
				ref string emsg = ref fW_Status.emsg;
				emsg = emsg + "\n" + text2 + "\n   Update FW now?";
				ref string rmsg = ref fW_Status.rmsg;
				rmsg = rmsg + "\n" + text3 + "\n   Обновить прошивку сейчас?";
				if (flag || DialogResult.OK == DialogShow(fW_Status.emsg, fW_Status.rmsg))
				{
					Button_Do_Update_Click(sender, e);
				}
			}
			catch (Exception ex)
			{
				Log_Invoke('!', ex.Message, -1L);
				Progress.Stop();
				Cursor.Current = Cursors.Default;
			}
			finally
			{
				richTextBox_Log.Refresh();
				fileStream.Close();
			}
		}

		private string do_dump(TextBox box)
		{
			return "";
		}

		private void button_Log_Dump_Click(object sender, EventArgs e)
		{
			bool @checked = checkBox_StatusLog.Checked;
			checkBox_StatusLog.Checked = false;
			textBox_Dump1.Visible = true;
			textBox_Dump2.Visible = true;
			string text = do_dump(textBox_Dump1);
			string text2 = do_dump(textBox_Dump2);
			InfoShow("Logs saved into files", "Логи сохранены в файлах", ":\n" + text + text2);
			checkBox_StatusLog.Checked = @checked;
			textBox_Dump2.Visible = false;
			textBox_Dump1.Visible = false;
		}

		private void button_AutoReceipt_Click(object sender, EventArgs e)
		{
			int num = Convert.ToInt32(numericUpDown_AutoReceiptItemNo.Value);
			int num2 = Convert.ToInt32(numericUpDown_AutoReceiptRepeat.Value);
			bool @checked = checkBox_ItemOptions.Checked;
			checkBox_ItemOptions.Checked = false;
			if (checkBox_StatusPrint.Checked && num2 > 10)
			{
				num2 = 10;
			}
			for (int i = 0; i < num2; i++)
			{
				if (!SetCashier() || !Command_Check_Open(Check_type_and_tax_system) || !Command_Check_Begin)
				{
					return;
				}
				for (int j = 0; j < num; j++)
				{
					if (!AddItemOK())
					{
						break;
					}
				}
				if (!Command_Check_Total || !Command_Cash_Pay || !Command_Check_End || !Command_Check_Close)
				{
					return;
				}
			}
			checkBox_ItemOptions.Checked = @checked;
		}

		private void radioButton_Header_CheckedChanged(object sender, EventArgs e)
		{
			for (int i = 0; i < 4; i++)
			{
				dataGrid_Header[i].Visible = radioButton_Header[i].Checked;
				if (radioButton_Header[i].Checked)
				{
					current_Header = i;
				}
			}
			Header_Format_Set(dataGrid_Header[current_Header].CurrentRow);
		}

		private void button_HeaderDel_Click(object sender, EventArgs e)
		{
			HeaderDel();
		}

		private void button_HeaderSet_Click(object sender, EventArgs e)
		{
			HeaderSet();
		}

		private void button_HeaderGet_Click(object sender, EventArgs e)
		{
			DataGridView dataGridView = dataGrid_Header[current_Header];
			if (HeaderGet(current_Header))
			{
				for (int i = 0; i < 10; i++)
				{
					XElement xElement = HeaderLine(i);
					if (xElement == null)
					{
						for (int j = 0; j < 6; j++)
						{
							dataGridView.Rows[i].Cells[j].Value = "0";
						}
						dataGridView.Rows[i].Cells[6].Value = "";
						continue;
					}
					XAttribute xAttribute = HeaderForm(xElement);
					if (xAttribute != null && !string.IsNullOrEmpty(xAttribute.Value))
					{
						for (int k = 0; k < 6; k++)
						{
							dataGridView.Rows[i].Cells[k].Value = xAttribute.Value.Substring(k, 1);
						}
					}
					dataGridView.Rows[i].Cells[6].Value = xElement.Value;
				}
			}
			Header_Format_Set(dataGridView.CurrentRow);
		}

		private void Header_Format_Set(DataGridViewRow row)
		{
			try
			{
				checkBox_HeaderInverse.Checked = Convert.ToInt32(row.Cells[0].Value) != 0;
				numericUpDown_CharWidth.Value = Convert.ToInt32(row.Cells[1].Value);
				numericUpDown_CharHeight.Value = Convert.ToInt32(row.Cells[2].Value);
				comboBox_HeaderFont.SelectedIndex = Convert.ToInt32(row.Cells[3].Value);
				comboBox_HeaderUnderline.SelectedIndex = Convert.ToInt32(row.Cells[4].Value);
				comboBox_HeaderAlign.SelectedIndex = Convert.ToInt32(row.Cells[5].Value);
			}
			catch (Exception ex)
			{
				ErrorShow("Invalid entry!", "Недопустимое значение!", "\r\n", ex);
			}
		}

		private void dataGrid_Header_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{
			Header_Format_Set(((DataGridView)sender).Rows[e.RowIndex]);
		}

		private void checkBox_HeaderInverse_CheckedChanged(object sender, EventArgs e)
		{
			dataGrid_Header[current_Header].CurrentRow.Cells[0].Value = (checkBox_HeaderInverse.Checked ? "1" : "0");
		}

		private void numericUpDown_CharWidth_ValueChanged(object sender, EventArgs e)
		{
			dataGrid_Header[current_Header].CurrentRow.Cells[1].Value = numericUpDown_CharWidth.Value;
		}

		private void numericUpDown_CharHeight_ValueChanged(object sender, EventArgs e)
		{
			dataGrid_Header[current_Header].CurrentRow.Cells[2].Value = numericUpDown_CharHeight.Value;
		}

		private void comboBox_HeaderFont_SelectedIndexChanged(object sender, EventArgs e)
		{
			dataGrid_Header[current_Header].CurrentRow.Cells[3].Value = comboBox_HeaderFont.SelectedIndex;
		}

		private void comboBox_HeaderUnderline_SelectedIndexChanged(object sender, EventArgs e)
		{
			dataGrid_Header[current_Header].CurrentRow.Cells[4].Value = comboBox_HeaderUnderline.SelectedIndex;
		}

		private void comboBox_HeaderAlign_SelectedIndexChanged(object sender, EventArgs e)
		{
			dataGrid_Header[current_Header].CurrentRow.Cells[5].Value = comboBox_HeaderAlign.SelectedIndex;
		}

		private void Button_LogoShow_Click(object sender, EventArgs e)
		{
			openFileDialog1.Filter = "Bitmap файлы (*.bmp)|*.bmp|Все файлы (*.*)|*.*";
			PictureBox pictureBox;
			if (sender.Equals(button_LogoShow))
			{
				openFileDialog1.Title = Lng.GetStr("Select Logo file", "Выбор файла логотипа");
				pictureBox = pictureBox_Logo;
			}
			else
			{
				openFileDialog1.Title = Lng.GetStr("Select Picture file", "Выбор файла рисунка");
				pictureBox = pictureBox_Picture;
			}
			if (openFileDialog1.ShowDialog() == DialogResult.OK)
			{
				string fileName = openFileDialog1.FileName;
				Bitmap image;
				try
				{
					image = new Bitmap(fileName);
				}
				catch
				{
					image = new Bitmap(pictureBox.Width, pictureBox.Height);
				}
				pictureBox.Image = image;
				pictureBox.Image.RotateFlip(RotateFlipType.Rotate180FlipX);
				if (sender.Equals(button_LogoShow))
				{
					logo_filename = fileName;
					button_Logo.Enabled = true;
				}
				else
				{
					pic_filename = fileName;
					button_Picture.Enabled = true;
				}
			}
		}

		private void Button_LogoErase_Click(object sender, EventArgs e)
		{
			int num = (sender.Equals(button_LogoErase) ? 100 : (100 + (int)numericUpDown_Picture.Value));
			StringBuilder stringBuilder = new StringBuilder(52);
			for (int i = 0; i < 52; i++)
			{
				stringBuilder.Append("0");
			}
			Command_Flash(1, 26L, num);
			Command_Flash(2, 26L, 0L, null, stringBuilder.ToString());
			Command_Flash(3, 0L, 0L);
		}

		private void Button_Logo_Download_Click(object sender, EventArgs e)
		{
			string text;
			int num;
			if (sender.Equals(button_Logo))
			{
				text = logo_filename;
				num = 100;
			}
			else
			{
				text = pic_filename;
				num = 100 + (int)numericUpDown_Picture.Value;
			}
			if (string.IsNullOrEmpty(text))
			{
				return;
			}
			using FileStream fileStream = new FileStream(text, FileMode.Open, FileAccess.Read, FileShare.Read);
			long num2 = fileStream.Length;
			if (!Command_Flash(1, num2, num))
			{
				return;
			}
			Progress.Start(Progress_Bar.MODE.OPE, Convert.ToInt32(num2));
			fileStream.Position = 0L;
			Cursor.Current = Cursors.WaitCursor;
			int num3 = 0;
			while (num2 > 0)
			{
				int num4 = (int)((256 < num2) ? 256 : num2);
				byte[] array = new byte[num4];
				fileStream.Read(array, 0, num4);
				StringBuilder stringBuilder = new StringBuilder(num4 * 2);
				byte[] array2 = array;
				foreach (byte b in array2)
				{
					stringBuilder.Append(b.ToString("X2"));
				}
				Command_Flash(2, num4, num3, null, stringBuilder.ToString(), log: false);
				num3 += num4;
				Progress.Bar.Increment(num4);
				num2 -= num4;
			}
			Command_Flash(3, 0L, 0L);
			Progress.Stop();
			Cursor.Current = Cursors.Default;
			fileStream.Close();
		}

		private void button_Setup_Get_ClearAll()
		{
			comboBox_Setup_COMBaudrate.Text = "";
			comboBox_Setup_PrBaudrate.Text = "";
			comboBox_Setup_PrinterModel.Text = "";
			RadioButton radioButton = radio_Setup_Paper80mm;
			bool @checked = (radio_Setup_Paper57mm.Checked = false);
			radioButton.Checked = @checked;
			RadioButton radioButton2 = radio_Setup_FontA;
			@checked = (radio_Setup_FontB.Checked = false);
			radioButton2.Checked = @checked;
			checkBox_Setup_PaperWidth.Text = Lng.GetStr("Width", "Ширина");
			checkBox_Setup_FontType.Text = Lng.GetStr("Font", "Шрифт");
			comboBox_Setup_Prst.Text = "";
			numeric_Setup_PrstTime.Value = numeric_Setup_PrstTime.Minimum;
			comboBox_Setup_LineType.Text = "";
			comboBox_Setup_QRAlign.Text = "";
			comboBox_Setup_Rounding.Text = "";
			RadioButton radioButton3 = radio_Setup_PaperCut_No;
			@checked = (radio_Setup_PaperCut_Yes.Checked = false);
			radioButton3.Checked = @checked;
			RadioButton radioButton4 = radio_Setup_AutoTest_No;
			@checked = (radio_Setup_AutoTest_Yes.Checked = false);
			radioButton4.Checked = @checked;
			CheckBox checkBox = checkBox_Drawer_Nal;
			@checked = (checkBox_Drawer_Beznal.Checked = false);
			checkBox.Checked = @checked;
			RadioButton radioButton5 = radio_Setup_Beeper_No;
			@checked = (radio_Setup_Beeper_Yes.Checked = false);
			radioButton5.Checked = @checked;
			RadioButton radioButton6 = radio_Setup_QRText_No;
			@checked = (radio_Setup_QRText_Yes.Checked = false);
			radioButton6.Checked = @checked;
			RadioButton radioButton7 = radio_Setup_ItemCnt_No;
			@checked = (radio_Setup_ItemCnt_Yes.Checked = false);
			radioButton7.Checked = @checked;
		}

		private void button_Setup_Get_Click(object sender, EventArgs e)
		{
			button_Setup_Get_ClearAll();
			Setup setup = Setup_Get();
			int comBaudrate = setup.ComBaudrate;
			if (comBaudrate >= 0)
			{
				comboBox_Setup_COMBaudrate.Text = comBaudrate.ToString();
			}
			comBaudrate = setup.PrnBaudrate;
			if (comBaudrate >= 0)
			{
				comboBox_Setup_PrBaudrate.Text = comBaudrate.ToString();
			}
			comBaudrate = setup.PrnModel;
			if (comBaudrate >= 0 && comBaudrate < comboBox_Setup_PrinterModel.Items.Count)
			{
				comboBox_Setup_PrinterModel.SelectedIndex = comBaudrate;
			}
			comBaudrate = setup.PrnPaper;
			bool flag2;
			if (comBaudrate >= 0)
			{
				RadioButton radioButton = radio_Setup_Paper80mm;
				flag2 = (radio_Setup_Paper57mm.Checked = comBaudrate < 59);
				radioButton.Checked = !flag2;
			}
			comBaudrate = setup.PrnWidth;
			if (comBaudrate >= 0)
			{
				checkBox_Setup_PaperWidth.Text = string.Format("{0} ({1} {2})", Lng.GetStr("Width", "Ширина"), comBaudrate, Lng.GetStr("pix", "точек"));
			}
			comBaudrate = setup.PrnFont;
			if (comBaudrate >= 0)
			{
				RadioButton radioButton2 = radio_Setup_FontB;
				flag2 = (radio_Setup_FontA.Checked = comBaudrate == 0);
				radioButton2.Checked = !flag2;
			}
			comBaudrate = setup.PrnLength;
			if (comBaudrate >= 0)
			{
				checkBox_Setup_FontType.Text = string.Format("{0} ({1} {2})", Lng.GetStr("Font", "Шрифт"), comBaudrate, Lng.GetStr("char", "симв."));
			}
			comBaudrate = setup.PrnPrst;
			if (comBaudrate >= 0 && comBaudrate < comboBox_Setup_Prst.Items.Count)
			{
				comboBox_Setup_Prst.SelectedIndex = comBaudrate;
			}
			comBaudrate = setup.PrnPrstTime;
			if (comBaudrate >= 0 && comBaudrate < 256)
			{
				numeric_Setup_PrstTime.Value = comBaudrate;
			}
			Panel panel = panel_Setup_Prst;
			flag2 = (panel_Setup_PrstTime.Visible = setup.PrnModel >= 3 && setup.PrnModel < 7);
			panel.Visible = flag2;
			comBaudrate = setup.OptLine;
			if (comBaudrate >= 0 && comBaudrate < comboBox_Setup_LineType.Items.Count)
			{
				comboBox_Setup_LineType.SelectedIndex = comBaudrate;
			}
			comBaudrate = setup.OptQRalign;
			if (comBaudrate >= 0 && comBaudrate < comboBox_Setup_QRAlign.Items.Count)
			{
				comboBox_Setup_QRAlign.SelectedIndex = comBaudrate;
			}
			comBaudrate = setup.OptRound;
			if (comBaudrate >= 0 && comBaudrate < comboBox_Setup_Rounding.Items.Count)
			{
				comboBox_Setup_Rounding.SelectedIndex = comBaudrate;
			}
			comBaudrate = setup.OptCut;
			if (comBaudrate >= 0)
			{
				RadioButton radioButton3 = radio_Setup_PaperCut_Yes;
				flag2 = (radio_Setup_PaperCut_No.Checked = comBaudrate == 0);
				radioButton3.Checked = !flag2;
			}
			comBaudrate = setup.OptTest;
			if (comBaudrate >= 0)
			{
				RadioButton radioButton4 = radio_Setup_AutoTest_Yes;
				flag2 = (radio_Setup_AutoTest_No.Checked = comBaudrate == 0);
				radioButton4.Checked = !flag2;
			}
			comBaudrate = setup.OptDrawer;
			if (comBaudrate >= 0)
			{
				checkBox_Drawer_Nal.Checked = (comBaudrate & 1) != 0;
				checkBox_Drawer_Beznal.Checked = (comBaudrate & 2) != 0;
			}
			comBaudrate = setup.OptBeeper;
			if (comBaudrate >= 0)
			{
				RadioButton radioButton5 = radio_Setup_Beeper_Yes;
				flag2 = (radio_Setup_Beeper_No.Checked = comBaudrate == 0);
				radioButton5.Checked = !flag2;
			}
			comBaudrate = setup.OptQRText;
			if (comBaudrate >= 0)
			{
				RadioButton radioButton6 = radio_Setup_QRText_Yes;
				flag2 = (radio_Setup_QRText_No.Checked = comBaudrate == 0);
				radioButton6.Checked = !flag2;
			}
			comBaudrate = setup.OptItemCnt;
			if (comBaudrate >= 0)
			{
				RadioButton radioButton7 = radio_Setup_ItemCnt_Yes;
				flag2 = (radio_Setup_ItemCnt_No.Checked = comBaudrate == 0);
				radioButton7.Checked = !flag2;
			}
			comBaudrate = setup.DrwPin;
			if (comBaudrate > 0)
			{
				numericUpDown_Setup_DrawerPin.Value = comBaudrate;
			}
			comBaudrate = setup.DrwPulse;
			if (comBaudrate > 0)
			{
				numericUpDown_Setup_DrawerPulse.Value = comBaudrate;
			}
			comBaudrate = setup.DrwFall;
			if (comBaudrate > 0)
			{
				numericUpDown_Setup_DrawerFall.Value = comBaudrate;
			}
			checkBox_Setup_SelectAll.Checked = false;
			checkBox_Setup_SelectAll_CheckedChanged(this, null);
		}

		private void button_Setup_Set_Click(object sender, EventArgs e)
		{
			Setup setup = default(Setup);
			setup.ComBaudrate = -1;
			setup.PrnBaudrate = -1;
			setup.PrnModel = -1;
			setup.PrnPaper = -1;
			setup.PrnWidth = -1;
			setup.PrnFont = -1;
			setup.PrnLength = -1;
			setup.PrnPrst = -1;
			setup.PrnPrstTime = -1;
			setup.OptLine = -1;
			setup.OptQRalign = -1;
			setup.OptRound = -1;
			setup.OptCut = -1;
			setup.OptTest = -1;
			setup.OptDrawer = -1;
			setup.OptBeeper = -1;
			setup.OptQRText = -1;
			setup.OptItemCnt = -1;
			setup.DrwPin = 0;
			setup.DrwPulse = 0;
			setup.DrwFall = 0;
			Setup set = setup;
			if (checkBox_Setup_COMBaudrate.Checked)
			{
				set.ComBaudrate = int.Parse(comboBox_Setup_COMBaudrate.Text);
			}
			if (checkBox_Setup_PrinterModel.Checked || checkBox_Setup_PrBaudrate.Checked || checkBox_Setup_PaperWidth.Checked || checkBox_Setup_FontType.Checked)
			{
				checkBox_Setup_PrinterModel.Checked = true;
			}
			if (checkBox_Setup_PrinterModel.Checked)
			{
				set.PrnModel = ((comboBox_Setup_PrinterModel.SelectedIndex == 11) ? 6 : comboBox_Setup_PrinterModel.SelectedIndex);
			}
			if (checkBox_Setup_PrBaudrate.Checked)
			{
				set.PrnBaudrate = int.Parse(comboBox_Setup_PrBaudrate.Text);
			}
			if (checkBox_Setup_PaperWidth.Checked)
			{
				set.PrnPaper = (radio_Setup_Paper57mm.Checked ? 57 : 80);
			}
			if (checkBox_Setup_FontType.Checked)
			{
				set.PrnFont = ((!radio_Setup_FontA.Checked) ? 1 : 0);
			}
			if (checkBox_Setup_LineType.Checked)
			{
				set.OptLine = comboBox_Setup_LineType.SelectedIndex;
			}
			if (checkBox_Setup_QRAlign.Checked)
			{
				set.OptQRalign = comboBox_Setup_QRAlign.SelectedIndex;
			}
			if (checkBox_Setup_Rounding.Checked)
			{
				set.OptRound = comboBox_Setup_Rounding.SelectedIndex;
			}
			if (checkBox_Setup_PaperCut.Checked)
			{
				set.OptCut = (radio_Setup_PaperCut_Yes.Checked ? 1 : 0);
			}
			if (checkBox_Setup_AutoTest.Checked)
			{
				set.OptTest = (radio_Setup_AutoTest_Yes.Checked ? 1 : 0);
			}
			if (checkBox_Setup_Cash.Checked)
			{
				set.OptDrawer = (checkBox_Drawer_Nal.Checked ? 1 : 0) + (checkBox_Drawer_Beznal.Checked ? 2 : 0);
			}
			if (checkBox_Setup_Beeper.Checked)
			{
				set.OptBeeper = (radio_Setup_Beeper_Yes.Checked ? 1 : 0);
			}
			if (checkBox_Setup_QRText.Checked)
			{
				set.OptQRText = (radio_Setup_QRText_Yes.Checked ? 1 : 0);
			}
			if (checkBox_Setup_DrawerPin.Checked)
			{
				set.DrwPin = (int)numericUpDown_Setup_DrawerPin.Value;
			}
			if (checkBox_Setup_DrawerPulse.Checked)
			{
				set.DrwPulse = (int)numericUpDown_Setup_DrawerPulse.Value;
			}
			if (checkBox_Setup_DrawerFall.Checked)
			{
				set.DrwFall = (int)numericUpDown_Setup_DrawerFall.Value;
			}
			if (panel_Setup_ItemCnt != null && checkBox_Setup_ItemCnt.Checked)
			{
				set.OptItemCnt = (radio_Setup_ItemCnt_Yes.Checked ? 1 : 0);
			}
			if (panel_Setup_Prst.Visible && checkBox_Setup_Prst.Checked)
			{
				set.PrnPrst = comboBox_Setup_Prst.SelectedIndex;
			}
			if (panel_Setup_PrstTime.Visible && checkBox_Setup_PrstTime.Checked)
			{
				set.PrnPrstTime = (int)numeric_Setup_PrstTime.Value;
			}
			if (Setup_Set(set))
			{
			}
		}

		private void SetCheckedListBoxItems(object e, bool set)
		{
			CheckedListBox checkedListBox = (CheckedListBox)e;
			for (int i = 0; i < checkedListBox.Items.Count; i++)
			{
				checkedListBox.SetItemChecked(i, set);
			}
		}

		private void button_GetLAN_Click(object sender, EventArgs e)
		{
			if (!Command_Get_LAN())
			{
				return;
			}
			FillStringGridRows(dataGrid_LAN.Rows);
			if (!Command_Get_OFD())
			{
				return;
			}
			FillStringGridRows(dataGrid_OFD.Rows);
			textBox_IP_OFD.Text = dataGrid_OFD.Rows[0].Cells[0].Value.ToString();
			numericUpDown_Port_OFD.Value = decimal.Parse(dataGrid_OFD.Rows[1].Cells[0].Value.ToString());
			if (Command_Get_OISM())
			{
				FillStringGridRows(dataGrid_OISM.Rows);
				textBox_AddressOISM.Text = dataGrid_OISM.Rows[0].Cells[0].Value.ToString();
				numericUpDown_PortOISM.Value = decimal.Parse(dataGrid_OISM.Rows[1].Cells[0].Value.ToString());
				if (Command_Get_OKP())
				{
					FillStringGridRows(dataGrid_OKP.Rows);
					textBox_AddressOKP.Text = dataGrid_OKP.Rows[0].Cells[0].Value.ToString();
					numericUpDown_PortOKP.Value = decimal.Parse(dataGrid_OKP.Rows[1].Cells[0].Value.ToString());
					checkBox_LAN_SelectAll.Checked = false;
					checkBox_LAN_SelectAll_CheckedChanged(null, null);
				}
			}
		}

		private void button_SetLAN_Click(object sender, EventArgs e)
		{
			if (Command_Set_OKP() && Command_Set_OISM() && Command_Set_OFD())
			{
				Command_Set_LAN();
			}
		}

		private void checkBox_LAN_SelectAll_CheckedChanged(object sender, EventArgs e)
		{
			SetCheckedListBoxItems(checkedListBox_LAN, checkBox_LAN_SelectAll.Checked);
			SetCheckedListBoxItems(checkedListBox_OFD, checkBox_LAN_SelectAll.Checked);
			SetCheckedListBoxItems(checkedListBox_OISM, checkBox_LAN_SelectAll.Checked);
			SetCheckedListBoxItems(checkedListBox_OKP, checkBox_LAN_SelectAll.Checked);
			checkBox_OFD_Client.Checked = checkBox_LAN_SelectAll.Checked;
		}

		private void radio_Setup_OFDClient_External_CheckedChanged(object sender, EventArgs e)
		{
			checkBox_OFD_Client.Checked = true;
		}

		private void checkBox_Setup_SelectAll_CheckedChanged(object sender, EventArgs e)
		{
			CheckBox checkBox = checkBox_Setup_COMBaudrate;
			CheckBox checkBox2 = checkBox_Setup_PrBaudrate;
			CheckBox checkBox3 = checkBox_Setup_PrinterModel;
			CheckBox checkBox4 = checkBox_Setup_PaperWidth;
			CheckBox checkBox5 = checkBox_Setup_FontType;
			CheckBox checkBox6 = checkBox_Setup_QRAlign;
			CheckBox checkBox7 = checkBox_Setup_Rounding;
			CheckBox checkBox8 = checkBox_Setup_LineType;
			CheckBox checkBox9 = checkBox_Setup_PaperCut;
			CheckBox checkBox10 = checkBox_Setup_AutoTest;
			CheckBox checkBox11 = checkBox_Setup_Beeper;
			CheckBox checkBox12 = checkBox_Setup_QRText;
			CheckBox checkBox13 = checkBox_Setup_Cash;
			CheckBox checkBox14 = checkBox_Setup_DrawerPin;
			CheckBox checkBox15 = checkBox_Setup_DrawerPulse;
			CheckBox checkBox16 = checkBox_Setup_DrawerFall;
			CheckBox checkBox17 = checkBox_Setup_Prst;
			CheckBox checkBox18 = checkBox_Setup_PrstTime;
			bool flag = (checkBox_Setup_ItemCnt.Checked = checkBox_Setup_SelectAll.Checked);
			bool flag3 = (checkBox18.Checked = flag);
			bool flag5 = (checkBox17.Checked = flag3);
			bool flag7 = (checkBox16.Checked = flag5);
			bool flag9 = (checkBox15.Checked = flag7);
			bool flag11 = (checkBox14.Checked = flag9);
			bool flag13 = (checkBox13.Checked = flag11);
			bool flag15 = (checkBox12.Checked = flag13);
			bool flag17 = (checkBox11.Checked = flag15);
			bool flag19 = (checkBox10.Checked = flag17);
			bool flag21 = (checkBox9.Checked = flag19);
			bool flag23 = (checkBox8.Checked = flag21);
			bool flag25 = (checkBox7.Checked = flag23);
			bool flag27 = (checkBox6.Checked = flag25);
			bool flag29 = (checkBox5.Checked = flag27);
			bool flag31 = (checkBox4.Checked = flag29);
			bool flag33 = (checkBox3.Checked = flag31);
			bool checked2 = (checkBox2.Checked = flag33);
			checkBox.Checked = checked2;
		}

		private void comboBox_Setup_COMBaudrate_SelectedIndexChanged(object sender, EventArgs e)
		{
			checkBox_Setup_COMBaudrate.Checked = true;
		}

		private void comboBox_Setup_PRNBaudrate_SelectedIndexChanged(object sender, EventArgs e)
		{
			checkBox_Setup_PrBaudrate.Checked = true;
		}

		private void comboBox_Setup_PrinterModel_SelectedIndexChanged(object sender, EventArgs e)
		{
			checkBox_Setup_PrinterModel.Checked = true;
			int selectedIndex = comboBox_Setup_PrinterModel.SelectedIndex;
			Panel panel = panel_Setup_Prst;
			bool visible = (panel_Setup_PrstTime.Visible = selectedIndex >= 3 && selectedIndex < 7);
			panel.Visible = visible;
		}

		private void comboBox_Setup_Rounding_SelectedIndexChanged(object sender, EventArgs e)
		{
			checkBox_Setup_Rounding.Checked = true;
		}

		private void comboBox_Setup_LineType_SelectedIndexChanged(object sender, EventArgs e)
		{
			checkBox_Setup_LineType.Checked = true;
		}

		private void comboBox_Setup_QRAlign_SelectedIndexChanged(object sender, EventArgs e)
		{
			checkBox_Setup_QRAlign.Checked = true;
		}

		private void radio_Setup_PaperCut_Yes_CheckedChanged(object sender, EventArgs e)
		{
			checkBox_Setup_PaperCut.Checked = true;
		}

		private void radio_Setup_Paper80mm_CheckedChanged(object sender, EventArgs e)
		{
			checkBox_Setup_PaperWidth.Checked = true;
			checkBox_Setup_PaperWidth.Text = Lng.GetStr("Width", "Ширина");
		}

		private void radio_Setup_FontA_CheckedChanged(object sender, EventArgs e)
		{
			checkBox_Setup_FontType.Checked = true;
			checkBox_Setup_FontType.Text = Lng.GetStr("Font", "Шрифт");
		}

		private void radio_Setup_AutoTest_Yes_CheckedChanged(object sender, EventArgs e)
		{
			checkBox_Setup_AutoTest.Checked = true;
		}

		private void radio_Setup_Beeper_Yes_CheckedChanged(object sender, EventArgs e)
		{
			checkBox_Setup_Beeper.Checked = true;
		}

		private void checkBox_Drawer_CheckedChanged(object sender, EventArgs e)
		{
			checkBox_Setup_Cash.Checked = true;
		}

		private void radio_Setup_QRText_Yes_CheckedChanged(object sender, EventArgs e)
		{
			checkBox_Setup_QRText.Checked = true;
		}

		private void radio_Setup_ItemCnt_Yes_CheckedChanged(object sender, EventArgs e)
		{
			checkBox_Setup_ItemCnt.Checked = true;
		}

		private void comboBox_Setup_Prst1_SelectedIndexChanged(object sender, EventArgs e)
		{
			checkBox_Setup_Prst.Checked = true;
		}

		private void numeric_Setup_PrstTime_ValueChanged(object sender, EventArgs e)
		{
			checkBox_Setup_PrstTime.Checked = true;
		}

		private void numericUpDown_Setup_DrawerPin_ValueChanged(object sender, EventArgs e)
		{
			checkBox_Setup_DrawerPin.Checked = true;
		}

		private void numericUpDown_Setup_DrawerPulse_ValueChanged(object sender, EventArgs e)
		{
			checkBox_Setup_DrawerPulse.Checked = true;
		}

		private void numericUpDown_Setup_DrawerFall_ValueChanged(object sender, EventArgs e)
		{
			checkBox_Setup_DrawerFall.Checked = true;
		}

		private void сalculateToolStripMenuItem_Click(object sender, EventArgs e)
		{
			string text = dataGrid_RegData.Rows[0].Cells[0].Value.ToString().Trim();
			string text2 = dataGrid_RegData.Rows[1].Cells[0].Value.ToString().Trim();
			string text3 = dataGrid_RegData.Rows[12].Cells[0].Value.ToString().Trim();
			string text4 = "";
			text4 += ((text.Length > 10) ? text.Substring(0, 10) : text).PadLeft(10, '0');
			text = text4;
			text4 += ((text2.Length > 12) ? text2.Substring(0, 12) : text2).PadLeft(12, '0');
			text4 += ((text3.Length > 20) ? text3.Substring(0, 20) : text3).PadLeft(20, '0');
			int length = text4.Length;
			byte[] array = new byte[length];
			for (int i = 0; i < length; i++)
			{
				array[i] = (byte)text4.ElementAt(i);
			}
			text += CRC16_CCITT(array).ToString("000000");
			dataGrid_RegData.Rows[0].Cells[0].Value = text;
		}

		private void verifyToolStripMenuItem_Click(object sender, EventArgs e)
		{
			string text = dataGrid_RegData.Rows[0].Cells[0].Value.ToString().Trim();
			string text2 = dataGrid_RegData.Rows[1].Cells[0].Value.ToString().Trim();
			string text3 = dataGrid_RegData.Rows[12].Cells[0].Value.ToString().Trim();
			string text4 = "";
			text4 += text.PadLeft(10, '0').Substring(0, 10);
			text4 += text2.PadLeft(12, '0').Substring(0, 12);
			text4 += text3.PadLeft(20, '0').Substring(0, 20);
			text = ((text.Length <= 10) ? "0" : text.Remove(0, 10));
			byte[] bytes = DeviceEncoding.GetBytes(text4);
			ushort num = CRC16_CCITT(bytes);
			ushort num2 = ushort.Parse(text);
			if (num == num2)
			{
				InfoShow("CRC is correct", "Контрольное число CRC корректное");
			}
			else
			{
				ErrorShow("CRC <" + text + "> incorrect!! Should be ", "Контрольное число CRC <" + text + "> некорректное!! Должно быть ", num.ToString("000000"));
			}
		}

		private void label_FNS_Click(object sender, EventArgs e)
		{
			dataGrid_RegData.Rows[8].Cells[0].Value = "www.nalog.gov.ru";
		}

		private void CheckBox_ReReg_CheckedChanged(object sender, EventArgs e)
		{
			checkedListBox_Reason11.Visible = checkBox_ReReg.Checked;
			checkBox_RegNum.Enabled = checkBox_ReReg.Checked;
			checkBox_RegNum.Checked = !checkBox_ReReg.Checked;
			if (checkBox_ReReg.Checked)
			{
				button_Reg.Text = Lng.GetStr("New Reg", "Пере-\nрегистрация");
			}
			else
			{
				button_Reg.Text = Lng.GetStr("Registr.", "Регистрация");
			}
		}

		private string DataGrid_RegData_cell(bool rereg, bool regno)
		{
			string text = "";
			foreach (DataGridViewRow item in (IEnumerable)dataGrid_RegData.Rows)
			{
				if (item.Cells[0].Value == null)
				{
					continue;
				}
				string text2 = item.HeaderCell.Value.ToString();
				string val = item.Cells[0].Value.ToString();
				switch (text2.Substring(1))
				{
				case "1018":
					if (rereg)
					{
						continue;
					}
					break;
				case "1037":
					if (rereg && !regno)
					{
						continue;
					}
					break;
				case "1013":
					continue;
				}
				text += Tag(text2, val);
			}
			return text;
		}

		private void dataGrid_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
		{
			DataGridView dataGridView = (DataGridView)sender;
			dataGridView.Rows[e.RowIndex].Cells[0].Style.ForeColor = SystemColors.ControlText;
		}

		private void Button_PrintReRegTicket_Click(object sender, EventArgs e)
		{
			PrintRegData((int)numericUpDown_ReRegNumber.Value);
		}

		private void Button_Reg_Click(object sender, EventArgs e)
		{
			try
			{
				CheckDateTime();
			}
			catch (Exception ex)
			{
				Response_Form.ClearText();
				Response_Form.Text = "Операция (пере)регистрации ККТ";
				Response_Form.AddLine(ex.Message);
				Response_Form.AddLine(string.Format("\nТекущие дата-время: {0:d} {0:t}", DateTime.Now));
				Response_Form.AddLine("\nУстановить дату-время и продолжить ?", 5);
				Response_Form.ShowDialog();
				if (Response_Form.DialogResult != DialogResult.OK)
				{
					return;
				}
				dateTimePicker_Current.Checked = true;
				SetDateTime();
			}
			SetRegData();
		}

		private void Button_GetRegData_Click(object sender, EventArgs e)
		{
			GetRegData();
		}

		private void Numeric_ItemPrice_ValueChanged(object sender, EventArgs e)
		{
			ulong num = Convert.ToUInt64(numeric_ItemPrice.Value * 100m);
			ulong num2 = Convert.ToUInt64(Math.Truncate(numeric_ItemQty.Value));
			ulong num3 = Convert.ToUInt64(Math.Truncate((numeric_ItemQty.Value - (decimal)num2) * 1000000m));
			num = num * num2 + (num * num3 + 500000) / 1000000;
			numeric_ItemAmount.Value = (decimal)num / 100m;
		}

		private void Numeric_NalCheck_ValueChanged(object sender, EventArgs e)
		{
			checkBox_Pay_Cash.Checked = true;
		}

		private void ComboBox_Beznal_SelectedIndexChanged(object sender, EventArgs e)
		{
			panel_beznal.Visible = comboBox_Beznal.SelectedIndex == 6;
		}

		private void DataGrid_beznal_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{
			checkedListBox_beznal.SetItemChecked(e.RowIndex, value: true);
		}

		private void button_MarkResult_Click(object sender, EventArgs e)
		{
			Response_Form.ShowDialog();
		}

		private void Button_CheckOpen_Click(object sender, EventArgs e)
		{
			if (button_CheckOpen.Text.Equals(Lng.GetStr("BEGIN", "НАЧАТЬ")))
			{
				button_CheckOpen.Enabled = !Command_Check_Begin;
				button_CheckOpen.Text = Lng.GetStr("OPEN", "ЧЕК");
				return;
			}
			Button_SetCashier_Click(sender, e);
			string userOptionValue = "";
			if (checkBox_Ticket_User.Checked)
			{
				User_Data.ShowDialog();
				if (User_Data.DialogResult != DialogResult.OK)
				{
					return;
				}
				userOptionValue = User_Data.UserOptionValue;
			}
			if (Command_Check_Open(Check_type_and_tax_system, userOptionValue))
			{
				button_CheckOpen.Text = Lng.GetStr("BEGIN", "НАЧАТЬ");
				Button button = button_CCh;
				bool flag2 = (button_FCh.Visible = false);
				button.Visible = !flag2;
				corr = false;
			}
		}

		private void Button_CheckCorr_Click(object sender, EventArgs e)
		{
			Correction_Data.ShowDialog();
			if (Correction_Data.DialogResult == DialogResult.OK)
			{
				corr = Command_Corr_Begin;
				if (corr)
				{
					Button button = button_CheckOpen;
					Button button2 = button_CCh;
					bool flag2 = (button_FCh.Enabled = false);
					bool enabled = (button2.Enabled = flag2);
					button.Enabled = enabled;
				}
			}
		}

		private void Button_CheckCustomer_Click(object sender, EventArgs e)
		{
			Customer_Data.ShowDialog();
			if (Customer_Data.DialogResult == DialogResult.OK)
			{
				Command_OK(CMD.ADD_DATA, "", null, null, Customer_Data.Value, 0L);
			}
		}

		private void Button_CheckOptions_Click(object sender, EventArgs e)
		{
			Option_Data.ShowDialog();
			if (Option_Data.DialogResult == DialogResult.OK)
			{
				Command_OK(CMD.ADD_DATA, "", null, null, Option_Data.Value, 0L);
			}
		}

		private bool MarkVerify_Online()
		{
			string value = x_answer.Root.Value;
			XAttribute xAttribute = x_answer.Root.Attribute("Ext");
			int num = ((xAttribute == null) ? 1 : int.Parse(xAttribute.Value));
			if (xAttribute == null)
			{
				Log_Invoke('!', "В ответе ККТ нет признака режима проверки КМ. Проверяем...", -1L);
			}
			bool flag = num == 2 || num == 3;
			if (num == 4)
			{
				Log_Invoke('!', "В ответе ККТ - признак автономного режима !!!", -1L);
			}
			if (checkBox_Autonom.Checked)
			{
				Response_Form.AddLine("\nАвтономный режим ККТ. Пропускаем проверку в ОИСМ...");
				return true;
			}
			if (flag)
			{
				Response_Form.AddLine("В ККТ установлен режим без проверки КМ (общепит/опт/вендинг)!");
				Response_Form.AddLine("Проверить все равно [ОК] или пропустить [Отмена] ?", 5);
				Response_Form.ShowDialog();
				if (DialogResult.OK != Response_Form.DialogResult)
				{
					return true;
				}
			}
			if (num == 0 || num == 2)
			{
				if (Command_Mark_Req(Item_attribute, Item_value))
				{
					Response_Form.res_2004(x_answer, "КМ проверен в ОИСМ внутренним клиентом ККТ.");
					Response_Form.res_2005(x_answer, "Ответ ОИСМ загружен в ФН.");
				}
				else
				{
					Response_Form.AddLine("\nОшибка при формировании и/или проверке запроса в ОИСМ !!!", 5);
					Response_Form.AddLine("\nПродолжить [ОК] или [Отмена] ?", 5);
					Response_Form.ShowDialog();
					if (DialogResult.OK != Response_Form.DialogResult)
					{
						return false;
					}
				}
				return true;
			}
			if (string.IsNullOrEmpty(value))
			{
				if (!Command_Mark_Req(Item_attribute, Item_value))
				{
					return false;
				}
				value = x_answer.Root.Value;
			}
			if (Skip_OISM)
			{
				Response_Form.AddLine("В настройках установлен режим без проверки КМ (общепит/опт/вендинг)!");
				Response_Form.AddLine("Проверить все равно [ОК] или пропустить [Отмена] ?", 5);
				Response_Form.ShowDialog();
				if (DialogResult.OK != Response_Form.DialogResult)
				{
					return true;
				}
			}
			if (string.IsNullOrEmpty(value))
			{
				Log_Invoke('!', "От ККТ не получен запрос на проверку кода маркировки", -1L);
				Response_Form.AddLine("\nОт ККТ не получен запрос на проверку КМ !!!", 5);
				Response_Form.AddLine("\nПродолжить без проверки [ОК] или [Отмена] ?", 5);
				Response_Form.ShowDialog();
				return DialogResult.OK == Response_Form.DialogResult;
			}
			if (value.Length % 2 != 0)
			{
				ErrorShow("Incorrect length", "Неверная длина запроса на проверку КМ");
				return false;
			}
			byte[] array = Hex2byte(value);
			if (array == null)
			{
				ErrorShow("Incorrect hex data format", "Ошибка преобразования запроса на проверку кода маркировки в массив байт");
				return false;
			}
			Fdo fdo = new Fdo();
			try
			{
				Log_Invoke('.', "Передача кода маркировки на проверку в ОИСМ...", -1L);
				byte[] array2 = fdo.SendPacket(array, dataGrid_OISM.Rows[0].Cells[0].Value.ToString(), int.Parse(dataGrid_OISM.Rows[1].Cells[0].Value.ToString()), Fdo.OPERATOR.OISM);
				if (array2 == null)
				{
					ErrorShow("Received empty packet", "Получен пустой пакет от ОИСМ: ");
					return false;
				}
				Log_Invoke('.', "Получен ответ от ОИСМ", -1L);
				if (checkBox_PreCheck.Checked)
				{
					if (!Command_Mark_Write(HexString(array2)))
					{
						return false;
					}
				}
				else if (!Command_Mark_Load(HexString(array2)))
				{
					return false;
				}
				Response_Form.AddLine("КМ передан в ОИСМ для проверки. Получен ответ.");
				Response_Form.res_2005(x_answer, "Ответ ОИСМ загружен в ФН.");
			}
			catch (Exception z)
			{
				Log_Invoke('!', "Ошибка передачи запроса на проверку кода маркировки: " + GetExceptionMessage(z), -1L);
				Response_Form.AddLine("\nОт ОИСМ не получен ответ по проверке КМ !!!", 5);
				Response_Form.AddLine("\nПродолжить [ОК] или [Отмена] ?", 5);
				Response_Form.ShowDialog();
				return DialogResult.OK == Response_Form.DialogResult;
			}
			return true;
		}

		private void Button_MarkVerify_Click(object sender, EventArgs e)
		{
			if (string.IsNullOrEmpty(comboBox_Mark.Text) || comboBox_Mark.ForeColor != SystemColors.ControlText)
			{
				return;
			}
			Response_Form.ClearText();
			Response_Form.Text = "Результаты проверки КМ";
			if (!checkBox_PreCheck.Checked)
			{
				if (Command_Mark_Test_FN(Item_KM))
				{
					Response_Form.res_2004(x_answer, "Проверка в ФН.");
					Response_Form.ShowDialog();
				}
			}
			else
			{
				if (!Command_Mark_Test(Item_attribute, Item_value, Item_KM))
				{
					return;
				}
				Response_Form.res_2004R(x_answer, "Проверка КМ перед чеком.");
				if (MarkVerify_Online() && Command_Mark_Save())
				{
					Response_Form.res_2005(x_answer, "Марка сохранена для чека.");
					if (checkBox_ShowResult.Checked)
					{
						Response_Form.ShowDialog();
					}
					checkBox_PreCheck.Checked = true;
				}
			}
		}

		private bool AddItemOK()
		{
			if (checkBox_ItemOptions.Checked && checkBox_ItemMark.Checked && !string.IsNullOrEmpty(comboBox_Mark.Text) && comboBox_Mark.ForeColor == SystemColors.ControlText)
			{
				if (checkBox_PreCheck.Checked)
				{
					if (GetSavedMarkNum() < 1)
					{
						ErrorShow("No verified marks saved", "Нет сохраненных результатов проверки КМ");
						return false;
					}
				}
				else
				{
					if (!Command_Mark_Add(Item_attribute, Item_value, Item_KM))
					{
						return false;
					}
					Response_Form.ClearText();
					Response_Form.Text = "Результаты проверки КМ";
					Response_Form.res_2004R(x_answer, "Проверка КМ в ФН и получение запроса для ОИСМ...");
					if (!MarkVerify_Online())
					{
						return false;
					}
					if (!Command_Mark_Save())
					{
						return false;
					}
					Response_Form.res_2005(x_answer, "Марка сохранена для чека.");
				}
				if (!Command_Mark_Add_Item(Item_ST, Item_KM))
				{
					return false;
				}
				Response_Form.AddLine("Марка добавлена в чек.");
				if (checkBox_ShowResult.Checked)
				{
					Response_Form.AddLine("\nПродолжить [OK] или [Отмена] ?", 5);
					Response_Form.ShowDialog();
					if (DialogResult.OK != Response_Form.DialogResult)
					{
						return false;
					}
				}
			}
			string qty = numeric_ItemQty.Value.ToString("0.######", nfi);
			string item_attributes = Item_attributes;
			string text = Item_value + Item_name;
			text += ((!checkBox_Agent.Checked) ? "" : Ticket_ItemOption.Value);
			if (checkBox_ItemOptions.Checked && !checkBox_ItemMark.Checked)
			{
				int num = 1300 + comboBox_TypeOfCode.SelectedIndex;
				if (num > 1309)
				{
					num += 10;
				}
				text += Item_barcode(num);
			}
			text += Item_FOIV;
			return Command_AddItem(qty, item_attributes, text);
		}

		private bool PaymentOK()
		{
			string text = "";
			string text2 = "";
			if (nUpDown_ElCheck.Value != 0m)
			{
				int selectedIndex = comboBox_Beznal.SelectedIndex;
				if (selectedIndex == 7)
				{
					string val = Tag(1085, "Способ оплаты") + Tag(1086, "СБП");
					val = Tag(1084, val);
					Command_OK(CMD.ADD_DATA, "", null, null, val, 0L);
				}
				if (!string.IsNullOrEmpty(textBox_CardNumber.Text.Trim()))
				{
					text = textBox_CardNumber.Text.Trim();
				}
				if (selectedIndex > 0 && selectedIndex < 6)
				{
					text2 += Att("TYPE", comboBox_Beznal.SelectedIndex.ToString());
				}
				else if (selectedIndex == 6)
				{
					for (int i = 0; i < checkedListBox_beznal.Items.Count; i++)
					{
						if (checkedListBox_beznal.GetItemChecked(i))
						{
							string text3 = dataGrid_beznal.Rows[i].Cells[0].Value.ToString().Replace(".", "");
							text2 += Att(beznal_no + (i + 1), text3.ToString());
						}
					}
				}
				if (!string.IsNullOrEmpty(text) || !string.IsNullOrEmpty(text2))
				{
					text = beznal_cmt(text2, text);
				}
			}
			panel_beznal.Visible = false;
			bool flag = Command_Pay(corr ? CMD.CORR_END : CMD.CHECK_PAY, text);
			if (corr && flag)
			{
				Command_Print();
			}
			corr = false;
			Button button = button_CheckOpen;
			Button button2 = button_CCh;
			bool flag3 = (button_FCh.Enabled = true);
			bool enabled = (button2.Enabled = flag3);
			button.Enabled = enabled;
			return flag;
		}

		private void Button_Text_Click(object sender, EventArgs e)
		{
			Ticket_Text.ShowDialog();
			if (Ticket_Text.DialogResult == DialogResult.Cancel)
			{
				return;
			}
			for (int i = 0; i < Ticket_Text.text_form.Length; i++)
			{
				if (Ticket_Text.text_form[i].Length > 0 && !Command_Text_Add(Ticket_Text.text_form[i], Ticket_Text.text_line[i]))
				{
					return;
				}
			}
			if ((Ticket_Text.qrcode_val.Length <= 0 || Command_OK(CMD.ADD_BAR, "9", Ticket_Text.qrcode_atr, null, Ticket_Text.qrcode_val, 0L)) && (Ticket_Text.barcode_val.Length <= 0 || Command_OK(CMD.ADD_BAR, Ticket_Text.barcode_no, Ticket_Text.barcode_atr, null, Ticket_Text.barcode_val, 0L)) && (Ticket_Text.picture_atr.Length <= 0 || Command_OK(CMD.ADD_PIC, Ticket_Text.picture_no, Ticket_Text.picture_atr, null, null, 0L)) && Ticket_Text.line_atr.Length > 0)
			{
				Command_OK(CMD.ADD_LINE, Ticket_Text.line_atr, null, null, null, 0L);
			}
		}

		private void Button_AddItem_Click(object sender, EventArgs e)
		{
			if (AddItemOK())
			{
				ShowTotal();
				checkBox_ItemOptions.Checked = false;
				if (checkBox_ItemSeparator.Checked)
				{
					Command_OK(CMD.ADD_LINE, "0", null, null, null, 0L);
				}
				if (checkBox_ItemSpace.Checked)
				{
					Command_OK(CMD.ADD_BLANK, "1", null, null, null, 0L);
				}
			}
			else
			{
				button_CheckOpen.Enabled = true;
			}
		}

		private void Button_Total_Click(object sender, EventArgs e)
		{
			if (Command_Check_Total)
			{
				ShowTotal();
			}
		}

		private void Button_Payment_Click(object sender, EventArgs e)
		{
			PaymentOK();
		}

		private void Button_CCh_Click(object sender, EventArgs e)
		{
			if (Command_Check_End)
			{
			}
			Button button = button_CCh;
			bool flag2 = (button_FCh.Visible = true);
			button.Visible = !flag2;
			button_CheckOpen.Enabled = true;
		}

		private void Button_FCh_Click(object sender, EventArgs e)
		{
			if (Command_Check_Close)
			{
				Command_Print();
			}
			Button button = button_CCh;
			bool flag2 = (button_FCh.Visible = false);
			button.Visible = !flag2;
			button_CheckOpen.Enabled = true;
		}

		private void Button_RunSales_Click(object sender, EventArgs e)
		{
			Button_SetCashier_Click(sender, e);
			if (Command_Check_Open(Check_type_and_tax_system) && Command_Check_Begin && AddItemOK() && Command_Check_Total && PaymentOK() && Command_Check_End && Command_Check_Close)
			{
			}
		}

		private void CheckBox_ItemOptions_CheckedChanged(object sender, EventArgs e)
		{
			Panel panel = panel_Ticket_Total;
			bool visible = (panel_TicketPay.Visible = !checkBox_ItemOptions.Checked);
			panel.Visible = visible;
			panel_AddItem.Height = (checkBox_ItemOptions.Checked ? AddItem_Hmax : AddItem_Hmin);
		}

		private void Button_ItemAgent_Click(object sender, EventArgs e)
		{
			Ticket_ItemOption.ShowDialog();
			if (Ticket_ItemOption.DialogResult == DialogResult.OK)
			{
				checkBox_Agent.Checked = true;
			}
		}

		private void checkBox_PreCheck_CheckedChanged(object sender, EventArgs e)
		{
			button_MarkVerify.Text = (checkBox_PreCheck.Checked ? "Пречек" : "Тест ФН");
		}

		private void comboBox_Mark_TextChanged(object sender, EventArgs e)
		{
			if (!string.IsNullOrEmpty(comboBox_Mark.Text))
			{
				string km = comboBox_Mark.Text.Replace("\\x1D", "\u001d");
				int typeOfKM = ItemCode.GetTypeOfKM(km);
				comboBox_TypeOfCode.SelectedIndex = typeOfKM - 1300;
				textBox_ItemCode.Text = ItemCode.GetKMID(km);
				textBox_ItemID.Text = ItemCode.GetKMID(km);
			}
		}

		private void comboBox_Mark_TextClick(object sender, EventArgs e)
		{
			comboBox_Mark.ForeColor = SystemColors.ControlText;
			checkBox_ItemMark.Checked = true;
			comboBox_Mark_TextChanged(sender, e);
		}

		private void dateTimePicker_FoivDate_ValueChanged(object sender, EventArgs e)
		{
			if (dateTimePicker_FoivDate.Checked)
			{
				checkBox_Foiv.Checked = true;
			}
		}

		private void button_ClearLast_Click(object sender, EventArgs e)
		{
			Command_Mark_Clear();
		}

		private void button_ClearAll_Click(object sender, EventArgs e)
		{
			Command_Mark_Clear_All();
		}

		private void button_CreateTXTDoc_Click(object sender, EventArgs e)
		{
			if (!Command_Text_Begin())
			{
				return;
			}
			for (int i = 0; i < 10; i++)
			{
				DataGridViewCell dataGridViewCell = dataGrid_TextLines.Rows[i].Cells[6];
				if (checkedListBox_TextLines.GetItemChecked(i))
				{
					string text = "";
					for (int j = 0; j < 6; j++)
					{
						text += dataGrid_TextLines.Rows[i].Cells[j].Value.ToString();
					}
					string text2 = "";
					if (dataGridViewCell.Value != null && !string.IsNullOrEmpty(dataGridViewCell.Value.ToString()))
					{
						text2 = dataGridViewCell.Value.ToString();
					}
					if (!Command_Text_Add(text, text2))
					{
						return;
					}
				}
			}
			if (checkBox_txt_QR.Checked)
			{
				string align = (radio_txt_QR_Left.Checked ? "0" : (radio_txt_QR_Center.Checked ? "1" : "2"));
				if (!Command_Barcode_Add("9", align, numeric_txt_QR_Level.Value.ToString(), numeric_txt_QR_DotSize.Value.ToString(), textBox_txt_QR.Text, checkBox_txt_QRText.Checked ? textBox_txt_QRText.Text : null))
				{
					return;
				}
			}
			if (!checkBox_txt_Barcode.Checked || Command_Barcode_Add(comboBox_txt_BarcodeType.SelectedIndex.ToString(), null, numeric_txt_BarcodeWidth.Value.ToString(), numeric_txt_BarcodeHeight.Value.ToString(), textBox_txt_Barcode.Text))
			{
				if (checkBox_txt_Image.Checked)
				{
					Command_Pic_Add(numeric_txt_PictureNo.Value.ToString(), radio_txt_Pic_Left.Checked ? "0" : (radio_txt_Pic_Center.Checked ? "1" : "2"));
				}
				if (checkBox_txt_Line.Checked)
				{
					Command_Line_Add(comboBox_txt_LineType.SelectedIndex.ToString());
				}
				Command_Text_End();
			}
		}

		private void button_ReadMSG_Click(object sender, EventArgs e)
		{
			Command_OFD_Begin();
		}

		private void button_EndMSG_Click(object sender, EventArgs e)
		{
			if (Command_OFD_End())
			{
				numericUpDown_OffsetBlock.Value = 0m;
			}
		}

		private void button_CancelMSG_Click(object sender, EventArgs e)
		{
			if (Command_OFD_Cancel())
			{
				numericUpDown_OffsetBlock.Value = 0m;
			}
		}

		private void button_ReadBlockMSG_Click(object sender, EventArgs e)
		{
			if (Command_OFD_Read((int)numericUpDown_LengthBlock.Value, (int)numericUpDown_OffsetBlock.Value))
			{
				numericUpDown_OffsetBlock.Value += numericUpDown_LengthBlock.Value;
			}
		}

		private bool TryToSendOFD()
		{
			if (!Command_OFD_Begin())
			{
				ErrorShow("Error or missing pending docs", "Ошибка или отсутствуют непереданные документы");
				return false;
			}
			XAttribute xAttribute = x_answer.Root.Attribute("LENGTH");
			if (xAttribute == null || string.IsNullOrEmpty(xAttribute.Value) || !int.TryParse(xAttribute.Value, out var result) || result <= 0)
			{
				ErrorShow("Missing or invalid message length", "Ошибка получения длины сообщения");
				return false;
			}
			string text = "";
			for (int i = 0; i < result; i += x_answer.Root.Value.Length / 2)
			{
				Thread.Sleep(1);
				if (!Command_OFD_Read(500, i))
				{
					return false;
				}
				if (string.IsNullOrEmpty(x_answer.Root.Value) || x_answer.Root.Value.Length % 2 != 0)
				{
					ErrorShow("Invalid size of data received", "Некорректный размер принятого блока");
					return false;
				}
				text += x_answer.Root.Value;
			}
			Thread.Sleep(1);
			if (!Command_OFD_End())
			{
				return false;
			}
			byte[] array = Hex2byte(text);
			if (array == null)
			{
				ErrorShow("Hex data conversion failure", "Ошибка преобразования 16-ричных данных");
				return false;
			}
			Fdo fdo = new Fdo();
			byte[] array2;
			try
			{
				Log_Invoke('.', Lng.GetStr("Sending document to OFD...", "Передача документа в ОФД..."), -1L);
				array2 = fdo.SendPacket(array, textBox_IP_OFD.Text.Trim(), (int)numericUpDown_Port_OFD.Value);
				if (array2 == null)
				{
					ErrorShow("Received empty packet !", "Получен пустой пакет !");
					return false;
				}
				Log_Invoke('.', Lng.GetStr("Received OFD response !", "Получен ответ от ОФД !"), -1L);
			}
			catch (Exception ex)
			{
				ErrorShow("Error sending message to OFD:", "Ошибка отправки сообщения ОФД: ", "", ex);
				Log_Invoke('!', Lng.GetStr("No response from OFD !!", "Нет ответа от ОФД !!"), -1L);
				return false;
			}
			text = HexString(array2);
			Thread.Sleep(1);
			return Command_OFD_Load(array2.Length, text);
		}

		private bool SendOFD()
		{
			int num;
			if ((num = Command_OFD_Get_Count()) < 0)
			{
				ErrorShow("Received invalid number of unsent documents", "Ошибка получения количества непереданных сообщений");
				return false;
			}
			textBox_PendingMSG.Text = num.ToString();
			if (num == 0)
			{
				ErrorShow("No pending docs", "Непереданных документов нет");
				return false;
			}
			Thread.Sleep(10);
			Cursor.Current = Cursors.WaitCursor;
			bool flag = TryToSendOFD();
			Cursor.Current = Cursors.Default;
			if (!flag)
			{
				Command_OFD_Cancel();
			}
			if ((num = Command_OFD_Get_Count()) < 0)
			{
				return false;
			}
			textBox_PendingMSG.Text = num.ToString();
			return flag;
		}

		private void button_OFD_MSG_Click(object sender, EventArgs e)
		{
			SendOFD();
		}

		private void button_SendAllToOFD_Click(object sender, EventArgs e)
		{
			stop_send = false;
			button_SendAllToOFD.Enabled = false;
			button_StopSendAllToOFD.Enabled = true;
			button_StopSendAllToOFD.Select();
			while (SendOFD())
			{
				Application.DoEvents();
				if (stop_send)
				{
					break;
				}
			}
			button_SendAllToOFD.Enabled = true;
			button_StopSendAllToOFD.Enabled = false;
		}

		private void button_StopSendAllToOFD_Click(object sender, EventArgs e)
		{
			stop_send = true;
			button_SendAllToOFD.Enabled = true;
			button_StopSendAllToOFD.Enabled = false;
			button_SendAllToOFD.Select();
		}

		private void button_GetTicketOFD_Click(object sender, EventArgs e)
		{
			if (Command_OFD_Get_CFM((int)numericUpDown_OFD_Ticket.Value, checkBox_StatusPrint.Checked))
			{
				string value = x_answer.Root.Value;
				string[] array = value.Split(new string[1] { "#0A;" }, StringSplitOptions.RemoveEmptyEntries);
				string[] array2 = array;
				foreach (string message in array2)
				{
					Log_Invoke('+', message, -1L);
				}
				Command_Print();
			}
		}

		private void button_ReadNoticeStart_Click(object sender, EventArgs e)
		{
			if (checkBox_NoticeAutonom.Checked)
			{
				notice = Command_OISM_A_Begin();
				if (notice.count < 0)
				{
					textBox_NoticeOffline.Text = "";
				}
				else
				{
					textBox_NoticeOffline.Text = $"{notice.first} ({notice.count})";
					button_ReadNotice.Text = "Прочитать";
				}
				for (int i = 0; i < notice_crc.Length; i++)
				{
					notice_crc[i] = 0;
				}
			}
			else
			{
				notice.length = Command_OISM_Begin();
				if (notice.length >= 0)
				{
					numeric_ReadNoticeLength.Value = min(500, notice.length);
				}
			}
			textBox_NoticeCRC.Text = "";
			numeric_ReadNoticeOffset.Value = 0m;
		}

		private bool Read_A_Notice()
		{
			if (notice.first < 0)
			{
				ErrorShow("Reading should be after [Begin]", "Пропущена операция [Начать]");
				return false;
			}
			notice.count = Command_OISM_A_Read(button_ReadNotice.Text != "Прочитать");
			if (notice.count < 0)
			{
				ErrorShow("Failed getting notice number", "Ошибка получения номера уведомления");
				return false;
			}
			notice.length = get_attribute("LENGTH");
			int num = get_attribute("CRC16");
			textBox_NoticeCRC.Text = notice.count + ":" + num;
			notice_crc[notice.count - notice.first] = num;
			numeric_ReadNoticeOffset.Value = 0m;
			int num2 = 0;
			while (notice.length > 0)
			{
				numeric_ReadNoticeOffset.Value += (decimal)num2;
				numeric_ReadNoticeLength.Value = min(notice.length, 512);
				if (!Command_OISM_Read((int)numeric_ReadNoticeLength.Value, (int)numeric_ReadNoticeOffset.Value))
				{
					return false;
				}
				num2 = get_attribute("LENGTH");
				notice.length -= num2;
			}
			return true;
		}

		private void button_ReadNotice_Click(object sender, EventArgs e)
		{
			if (checkBox_NoticeAutonom.Checked)
			{
				if (Read_A_Notice())
				{
					button_ReadNotice.Text = "Следующее";
				}
			}
			else if (Command_OISM_Read((int)numeric_ReadNoticeLength.Value, (int)numeric_ReadNoticeOffset.Value))
			{
				numeric_ReadNoticeOffset.Value += (decimal)get_attribute("LENGTH");
				if (numeric_ReadNoticeOffset.Value >= (decimal)notice.length)
				{
					button_ReadNotice.Text = "Прочитать";
					return;
				}
				numeric_ReadNoticeLength.Value = min((int)numeric_ReadNoticeLength.Value, notice.length - (int)numeric_ReadNoticeOffset.Value);
				button_ReadNotice.Text = "Прочитать еще";
			}
		}

		private void button_ReadNoticeEnd_Click(object sender, EventArgs e)
		{
			if (checkBox_NoticeAutonom.Checked)
			{
				int num = notice.first;
				while (num != 0)
				{
					int cnt = 0;
					num = Command_OISM_A_Confirm(num, notice_crc[num - notice.first], ref cnt);
					if (num < 0)
					{
						return;
					}
					textBox_NoticeOffline.Text = $"{num} ({cnt})";
				}
			}
			else if (Command_OISM_End())
			{
				numeric_ReadNoticeOffset.Value = 0m;
				numeric_ReadNoticeLength.Value = 500m;
			}
			notice.length = 0;
		}

		private void button_ReadNoticeCancel_Click(object sender, EventArgs e)
		{
			if (checkBox_NoticeAutonom.Checked)
			{
				ReadAllNoticeAutonom();
			}
			else if (Command_OISM_Cancel())
			{
				numeric_ReadNoticeOffset.Value = 0m;
				numeric_ReadNoticeLength.Value = 500m;
			}
		}

		private int GetNoticeCount()
		{
			Notice notice = ((!checkBox_NoticeAutonom.Checked) ? Command_OISM_Count() : Command_OISM_A_Count());
			if (notice.count < 0)
			{
				ErrorShow("Failed getting number of pending notices", "Ошибка получения числа уведомлений в очереди");
			}
			else if (notice.count == 0)
			{
				ErrorShow("No pending notices", "Непереданных уведомлений нет");
			}
			else
			{
				textBox_PendingNotice.Text = notice.count.ToString();
			}
			return notice.count;
		}

		private bool TryToSendOISM()
		{
			notice.length = Command_OISM_Begin();
			if (notice.length < 0)
			{
				ErrorShow("Error or missing pending docs", "Ошибка или отсутствуют непереданные уведомления");
				return false;
			}
			if (notice.length == 0)
			{
				ErrorShow("Missing or invalid message length", "Ошибка получения длины сообщения");
				return false;
			}
			int num = notice.length;
			string text = "";
			for (int i = 0; i < notice.length; i += num)
			{
				Thread.Sleep(1);
				if (!Command_OISM_Read(min(500, num), i))
				{
					return false;
				}
				if ((num = get_attribute("LENGTH")) <= 0)
				{
					ErrorShow("Missing or invalid block length", "Ошибка получения длины блока");
					return false;
				}
				if (string.IsNullOrEmpty(x_answer.Root.Value) || x_answer.Root.Value.Length != num * 2)
				{
					ErrorShow("Invalid size of data received", "Некорректный размер принятого блока");
					return false;
				}
				text += x_answer.Root.Value;
			}
			Thread.Sleep(1);
			if (!Command_OISM_End())
			{
				return false;
			}
			byte[] packet = Hex2byte(text);
			Fdo fdo = new Fdo();
			byte[] array;
			try
			{
				Log_Invoke('.', Lng.GetStr("Sending notice to OISM...", "Передача уведомления в ОИСМ..."), -1L);
				array = fdo.SendPacket(packet, textBox_AddressOISM.Text, (int)numericUpDown_PortOISM.Value, Fdo.OPERATOR.OISM);
				if (array == null)
				{
					ErrorShow("Received empty packet !", "Получен пустой пакет !");
					return false;
				}
				Log_Invoke('.', Lng.GetStr("Received OISM response !", "Получен ответ от ОИСМ !"), -1L);
			}
			catch (Exception ex)
			{
				ErrorShow("Error sending message to OISM:", "Ошибка передачи уведомления в ОИСМ: ", null, ex);
				return false;
			}
			text = HexString(array);
			Thread.Sleep(1);
			return Command_OISM_Load(array.Length, text);
		}

		private bool SendNoticeOne()
		{
			Thread.Sleep(10);
			Cursor.Current = Cursors.WaitCursor;
			bool result = TryToSendOISM();
			Cursor.Current = Cursors.Default;
			return result;
		}

		private void button_SendNoticeOne_Click(object sender, EventArgs e)
		{
			if (Command_Get_OISM() && GetNoticeCount() > 0)
			{
				if (SendNoticeOne())
				{
					GetNoticeCount();
				}
				else
				{
					Command_OISM_Cancel();
				}
			}
		}

		private void button_SendNoticeAll_Click(object sender, EventArgs e)
		{
			stop_send = false;
			Button button = button_SendNoticeAll;
			bool flag2 = (button_SendNoticeStop.Enabled = true);
			button.Enabled = !flag2;
			button_SendNoticeStop.Select();
			while (SendNoticeOne())
			{
				GetNoticeCount();
				Application.DoEvents();
				if (stop_send)
				{
					break;
				}
			}
		}

		private void button_SendNoticeStop_Click(object sender, EventArgs e)
		{
			stop_send = true;
			Button button = button_SendNoticeAll;
			bool flag2 = (button_SendNoticeStop.Enabled = false);
			button.Enabled = !flag2;
			button_SendAllToOFD.Select();
		}

		private void button_KeyUpdate_Click(object sender, EventArgs e)
		{
			key = Command_OKP_Get_Status();
			switch (key.need)
			{
			case -1:
				return;
			case 0:
				Log_Invoke('.', "Нет необходимости обновлять ключи проверки КМ", -1L);
				if (DialogResult.OK != DialogShow("Key update not needed.\nTry to update anyway?", "Нет необходимости обновлять ключи проверки КМ.\nОбновить все равно?"))
				{
					return;
				}
				break;
			case 1:
				Log_Invoke('.', "После последнего обновления КП прошло от 15 до 60 дней. Необходимо обновить!", -1L);
				if (DialogResult.OK != DialogShow("Is' been 15 to 60 days since last update.\nWant to update?", "После последнего обновления КП прошло от 15 до 60 дней.\nОбновить ключи?"))
				{
					return;
				}
				break;
			case 2:
				Log_Invoke('!', "После последнего обновления КП прошло свыше 60 дней. Обратитесь в службу техподдержки!", -1L);
				if (DialogResult.OK != DialogShow("Is' been more than 60 days since last update.\nWant to update?", "После последнего обновления КП прошло более 60 дней.\nОбновить ключи?"))
				{
					return;
				}
				break;
			}
			if (string.IsNullOrEmpty(key.url))
			{
				Log_Invoke('!', "Нет удалось получить адрес и порт сервера ОКП. Используем данные по умолчанию", -1L);
				key.url = textBox_AddressOKP.Text;
			}
			if (key.port == 0)
			{
				Log_Invoke('!', "Некорректное значение номера порта сервера ОКП. Используем данные по умолчанию", -1L);
				key.port = (int)numericUpDown_PortOKP.Value;
			}
			if ((!key.url.Equals(textBox_AddressOKP.Text) || key.port != (int)numericUpDown_PortOKP.Value) && DialogResult.OK != DialogShow("URL address and/or port of server in FN differ from settings.\nAccept?", "Адрес и/или порт сервера ОКП отличаются от установленных в настройках ККТ.\nИспользовать данные, полученные из ФН?"))
			{
				key.url = textBox_AddressOKP.Text;
				key.port = (int)numericUpDown_PortOKP.Value;
			}
			if (!Command_OKP_Get_Req())
			{
				return;
			}
			XAttribute xAttribute = x_answer.Root.Attribute("LENGTH");
			if (xAttribute == null || string.IsNullOrEmpty(xAttribute.Value) || !int.TryParse(xAttribute.Value, out var result) || result <= 0)
			{
				Log_Invoke('!', "Нет длины запроса на обновление ключей проверки КМ", -1L);
				return;
			}
			string value = x_answer.Root.Value;
			byte[] packet = Hex2byte(value);
			Thread.Sleep(10);
			Fdo fdo = new Fdo();
			byte[] array;
			try
			{
				Log_Invoke('.', Lng.GetStr("Sending enquiry for key update to OKP", "Передача запроса на обновление ключей серверу ОКП"), -1L);
				array = fdo.SendPacket(packet, key.url, key.port, Fdo.OPERATOR.OKP);
				if (array == null)
				{
					ErrorShow("Received empty packet !", "Получен пустой пакет !");
					return;
				}
				Log_Invoke('.', Lng.GetStr("Received response from OKP", "Получен ответ от сервера ОКП"), -1L);
			}
			catch (Exception z)
			{
				Log_Invoke('!', "Ошибка передачи запроса на обновление ключей проверки КМ: " + GetExceptionMessage(z), -1L);
				return;
			}
			Thread.Sleep(10);
			if (Command_OKP_Load(array.Length, array))
			{
				Log_Invoke('.', "Обновление ключей завершено", -1L);
				return;
			}
			xAttribute = x_answer.Root.Attribute("RC");
			if (xAttribute != null && xAttribute.Value == "448")
			{
				Log_Invoke('.', "Еще не все ключи обновлены. Надо повторить!", -1L);
			}
		}

		private void checkBox_NoticeAutonom_CheckedChanged(object sender, EventArgs e)
		{
			if (checkBox_NoticeAutonom.Checked)
			{
				panel_NoticeOffline.Visible = true;
				button_ReadNoticeStart.Text = "Начать";
				button_ReadNotice.Text = "Прочитать";
				button_ReadNoticeEnd.Text = "Подтвердить";
				button_ReadNoticeCancel.Text = "Выгрузить все!";
				checkBox_StatusAutonom.Checked = true;
			}
			else
			{
				panel_NoticeOffline.Visible = false;
				button_ReadNoticeStart.Text = "Начать";
				button_ReadNotice.Text = "Прочитать";
				button_ReadNoticeEnd.Text = "Завершить";
				button_ReadNoticeCancel.Text = "Отменить";
				checkBox_StatusAutonom.Checked = false;
			}
		}

		private void ReadAllNoticeAutonom()
		{
			FileStream fileStream = null;
			Dictionary<int, int> dictionary = new Dictionary<int, int>();
			bool next = false;
			bool flag = false;
			byte[] array = null;
			saveFileDialog_Notice.FileName = Command_Get_FN_Number();
			if (string.IsNullOrEmpty(saveFileDialog_Notice.FileName))
			{
				return;
			}
			SaveFileDialog saveFileDialog = saveFileDialog_Notice;
			saveFileDialog.FileName = saveFileDialog.FileName + "_" + DateTime.Now.ToString("yyyyMMddHHmmss");
			saveFileDialog_Notice.DefaultExt = "crpt";
			if (saveFileDialog_Notice.ShowDialog() != DialogResult.OK)
			{
				return;
			}
			try
			{
				array = CreateHeaderNF();
				notice = Command_OISM_A_Begin();
				if (notice.count <= 0)
				{
					return;
				}
				fileStream = new FileStream(saveFileDialog_Notice.FileName, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite);
				int num = 0;
				while (num < notice.count)
				{
					if (!GetNoticeToFile(ref array, dictionary, next))
					{
						flag = true;
						return;
					}
					num++;
					next = true;
				}
				uint cRC = CRC32.GetCRC32(array, array.Length, 371, 374);
				byte[] bytes = BitConverter.GetBytes(cRC);
				PutBytesInArray(array, bytes, 371u, 4u);
				fileStream.Write(array, 0, array.Count());
				next = false;
				int cnt = 0;
				foreach (KeyValuePair<int, int> item in dictionary)
				{
					if (0 >= Command_OISM_A_Confirm(item.Key, item.Value, ref cnt))
					{
						return;
					}
				}
				InfoShow("Notices saved into file and confirmed", "Уведомления сохранены в файл и подтверждены");
			}
			catch (Exception ex)
			{
				ErrorShow("Error uploading notices: ", "Ошибка выгрузки уведомлений: ", "", ex);
			}
			finally
			{
				fileStream?.Close();
				dictionary?.Clear();
				GC.Collect();
				if (flag)
				{
					try
					{
						File.Delete(saveFileDialog_Notice.FileName);
					}
					catch
					{
					}
				}
			}
		}

		private bool GetNoticeToFile(ref byte[] buffer, Dictionary<int, int> notices, bool next = false)
		{
			int num = Command_OISM_A_Read(next);
			if (num < 0)
			{
				return false;
			}
			int num2 = get_attribute("LENGTH");
			Encoding.ASCII.GetBytes(num.ToString("D4")).CopyTo(buffer, 363);
			if (!next)
			{
				Encoding.ASCII.GetBytes(num.ToString("D4")).CopyTo(buffer, 359);
			}
			notices.Add(num, 0);
			Encoding.ASCII.GetBytes(notices.Count.ToString("D4")).CopyTo(buffer, 367);
			ushort num3 = (ushort)buffer.Length;
			ushort value = (ushort)num2;
			byte[] bytes = BitConverter.GetBytes(value);
			byte[] bytes2 = BitConverter.GetBytes((ushort)201);
			Array.Resize(ref buffer, buffer.Length + 4 + num2);
			PutBytesInArray(buffer, bytes2, num3, 2u);
			PutBytesInArray(buffer, bytes, (uint)(num3 + 2), 2u);
			string text = "";
			int num4;
			for (int i = 0; i < num2; i += num4)
			{
				Thread.Sleep(10);
				if (!Command_OISM_Read(500, i))
				{
					return false;
				}
				num4 = get_attribute("LENGTH");
				if (num4 <= 0)
				{
					ErrorShow("Invalid block length", "Некорректная длина блока");
					return false;
				}
				if (string.IsNullOrEmpty(x_answer.Root.Value) || x_answer.Root.Value.Length != num4 * 2)
				{
					ErrorShow("Invalid block length", "Некорректная длина блока");
					return false;
				}
				if (!IsHexChar(x_answer.Root.Value))
				{
					ErrorShow("Not HEX data", "Некорректные данные");
					return false;
				}
				text += x_answer.Root.Value;
			}
			for (int j = 0; j < text.Length; j += 2)
			{
				if (!byte.TryParse(text.Substring(j, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out buffer[j / 2 + (num3 + 4)]))
				{
					ErrorShow("Error data conversion", "Ошибка преобразования сообщения в массив байт");
					return false;
				}
			}
			notices[num] = CRC16_CCITT(buffer, num3 + 4, 2, 3);
			return true;
		}

		private void PutBytesInArray(byte[] ToStr, byte[] InStr, uint from = 0u, uint count = 0u)
		{
			uint num = ((from + count <= ToStr.Length) ? from : 0u);
			uint num2 = ((count == 0 || from + count > ToStr.Length) ? ((uint)ToStr.Length) : count);
			uint num3 = 0u;
			if (num2 > InStr.Length)
			{
				num3 = num2 - (uint)InStr.Length;
				num2 = (uint)InStr.Length;
			}
			for (uint num4 = num; num4 < num + num2; num4++)
			{
				ToStr[num4] = InStr[num4 - num];
			}
			for (uint num5 = num + num2; num5 < num + num2 + num3; num5++)
			{
				ToStr[num5] = 32;
			}
		}

		private string TypeFD(string type)
		{
			return type switch
			{
				"1" => Lng.GetStr("Registration Report", "Отчет о регистрации"), 
				"2" => Lng.GetStr("Daily Shift Open Report", "Отчет об открытии смены"), 
				"3" => Lng.GetStr("Sales/Refund Check", "Кассовый чек"), 
				"4" => Lng.GetStr("Mandatory Ticket", "БСО"), 
				"5" => Lng.GetStr("Daily Shift Closing Report", "Отчет о закрытии смены"), 
				"6" => Lng.GetStr("Fiscal Memory Closing Report", "Отчет о закрытии ФН"), 
				"7" => Lng.GetStr("Operator Confirmation Ticket", "Квитанция ОФД"), 
				"11" => Lng.GetStr("Registration Update Report", "Отчет о перерегистрации"), 
				"21" => Lng.GetStr("Current Financial Report", "Отчет о текущем состоянии расчетов"), 
				"31" => Lng.GetStr("Correction Check", "Чек коррекции"), 
				"41" => Lng.GetStr("Correction Ticket", "БСО коррекции"), 
				_ => Lng.GetStr(" Unknown document!", "Неизвестный документ!"), 
			};
		}

		private void button_GetTypeDoc_Click(object sender, EventArgs e)
		{
			if (FN_Doc_Type(numericUpDown_FD.Value))
			{
				XAttribute xAttribute = x_answer.Root.Attribute("TYPE");
				string text = ((xAttribute == null) ? "" : xAttribute.Value);
				textBox_TypeFD.Text = (string.IsNullOrEmpty(text) ? "" : (text.ToString() + ": " + TypeFD(text)));
			}
		}

		private void button_PrintDoc_Click(object sender, EventArgs e)
		{
			DocFromFN((Button)sender == button_PrintDoc_Arc, numericUpDown_FD.Value);
		}

		private void button_ReadXML_Click(object sender, EventArgs e)
		{
			try
			{
				xml_block b = FN_Doc_XML((Button)sender == button_ReadXML_Arc, numericUpDown_XMLDocNum.Value);
				if (b.Length <= 0 || b.Offset < 0)
				{
					ErrorShow("Invalid length/offset", "Неверная длина/смещение");
				}
				else
				{
					LoadXMLDoc(b);
				}
			}
			catch
			{
			}
		}

		private bool LoadXMLDoc(xml_block b)
		{
			string text = "";
			try
			{
				while (b.Length > 0)
				{
					Thread.Sleep(10);
					int num = min(500, b.Length);
					if (!FN_Get_XML(num, b.Offset))
					{
						throw new Exception("Ошибка команды чтения блока " + b.Offset);
					}
					XAttribute xAttribute = x_answer.Root.Attribute("LENGTH");
					if (xAttribute == null || string.IsNullOrEmpty(xAttribute.Value) || !int.TryParse(xAttribute.Value, out var result) || result <= 0)
					{
						throw new Exception(Lng.GetStr("Error block length", "Ошибка длины прочитанного блока"));
					}
					if (string.IsNullOrEmpty(x_answer.Root.Value) || result != num)
					{
						throw new Exception(Lng.GetStr("Invalid received block length", "Длина прочитанного блока не соответствует его размеру"));
					}
					text += x_answer.Root.Value;
					b.Length -= result;
					b.Offset += result;
				}
			}
			catch (Exception ex)
			{
				ErrorShow("", "", "", ex);
				return false;
			}
			try
			{
				x_answer = FN_Parse_XML(text);
			}
			catch (Exception ex2)
			{
				ErrorShow("Error parcing answer:", "Ошибка разбора полученного документа: ", "", ex2);
				return false;
			}
			Response_Form.ClearText();
			Response_Form.Text = "XML: состав тегов документа из ФН";
			if (checkBox_XML_SaveToFile.Checked)
			{
				try
				{
					x_answer.Save(LogFolder + "XML_Doc-" + numericUpDown_XMLDocNum.Value + ".xml");
					Response_Form.AddLine(Lng.GetStr("<-- XML saved into file: -->", "<-- XML документ сохранен в файле: -->"));
					Response_Form.AddLine($"<-- {LogFolder}XML_Doc-{numericUpDown_XMLDocNum.Value}.xml -->");
				}
				catch (Exception ex3)
				{
					ErrorShow("Error saving doc XML form: ", "Ошибка сохранения полученной XML-формы документа: ", "", ex3);
				}
			}
			string[] array = x_answer.ToString().Split(new string[1] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
			Response_Form.AddLine("<-- " + TypeFD(x_answer.Root.FirstAttribute.Value) + " -->");
			string[] array2 = array;
			foreach (string text2 in array2)
			{
				Response_Form.AddLine(text2.Replace("&amp;", "&").Replace("&quot;", "\"").Replace("&apos;", "'")
					.Replace("&equ;", "="));
			}
			Response_Form.ShowDialog();
			return true;
		}

		private void button_GetTicketXML_Click(object sender, EventArgs e)
		{
			if (!Command_OFD_Get_CFM((int)numericUpDown_OFD_Ticket.Value, checkBox_StatusPrint.Checked))
			{
				return;
			}
			Command_Print();
			xml_block b = new xml_block(0, 0);
			XAttribute xAttribute = x_answer.Root.Attribute("LENGTH");
			if (xAttribute == null || string.IsNullOrEmpty(xAttribute.Value) || !int.TryParse(xAttribute.Value, out b.Length) || b.Length <= 0)
			{
				ErrorShow("Invalid length", "Некорректная длина XML формы");
				return;
			}
			xAttribute = x_answer.Root.Attribute("OFFSET");
			if (xAttribute == null || string.IsNullOrEmpty(xAttribute.Value) || !int.TryParse(xAttribute.Value, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out b.Offset) || b.Offset < 0)
			{
				ErrorShow("Invalid offset", "Неверное смещение");
			}
			else
			{
				LoadXMLDoc(b);
			}
		}

		private void button_ReadAllCheck_Click(object sender, EventArgs e)
		{
		}

		public void ErrorShow(string enStr, string ruStr, string msg = "", Exception ex = null)
		{
			string text = Lng.GetStr(enStr, ruStr) + msg + ((ex == null) ? "" : GetExceptionMessage(ex));
			MessageBox.Show(text, Text, MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}

		public void InfoShow(string enStr, string ruStr, string msg = "")
		{
			MessageBox.Show(Lng.GetStr(enStr, ruStr) + msg, Text, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}

		public DialogResult DialogShow(string enStr, string ruStr)
		{
			return MessageBox.Show(Lng.GetStr(enStr, ruStr), Text, MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
		}

		private void checkBox_Arc_CheckedChanged(object sender, EventArgs e)
		{
			button_DocFromFN.Text = (checkBox_Arc.Checked ? Lng.GetStr("From Archive", "Док. из архива") : Lng.GetStr("From FN", "Док. из ФН"));
		}

		private void Button_Duplicate0_Click(object sender, EventArgs e)
		{
			Command_OK(CMD.PRINT, "", null, null, null, 0L);
		}

		private void Button_StatePrinter_Click(object sender, EventArgs e)
		{
			StatePrinter();
		}

		private void Button_PowerGet_Click(object sender, EventArgs e)
		{
			PowerGet();
		}

		private void Button_PowerSet_Click(object sender, EventArgs e)
		{
			PowerSet();
		}

		private void Power_Reset(int seconds, int was_numports)
		{
			RadioButton selected = Com.Selected;
			RadioButton lan_Button = Lan_Button;
			RadioButton ser_Button = Ser_Button;
			Progress.Start(Progress_Bar.MODE.OPE, seconds * 5);
			Thread.Sleep(1000);
			int num = 200;
			while (Progress.Bar.Value < Progress.Bar.Maximum)
			{
				Progress.Bar.PerformStep();
				if (num == 200 && SerialPort.GetPortNames().Length >= was_numports)
				{
					num = 20;
				}
				Thread.Sleep(num);
			}
			Progress.Stop();
			if (was_numports == 0)
			{
				return;
			}
			Initialize_COM_buttons(null, null);
			if (lan_Button.Checked)
			{
				Lan_Button.Checked = true;
			}
			else if (ser_Button.Checked)
			{
				Ser_Button.Checked = true;
			}
			else if (Com.Buttons != null)
			{
				RadioButton[] buttons = Com.Buttons;
				foreach (RadioButton radioButton in buttons)
				{
					if (selected != null && radioButton.Text == selected.Text && radioButton.Enabled)
					{
						radioButton.Checked = true;
						break;
					}
				}
			}
			Progress.Stop();
		}

		private void Button_PowerReset_Click(object sender, EventArgs e)
		{
			PowerReset();
		}

		private void textBox_TextChanged(object sender, EventArgs e)
		{
			((TextBox)sender).ForeColor = SystemColors.ControlText;
			checkBox_Foiv.Checked = true;
		}

		private void checkBox_Foiv_CheckedChanged(object sender, EventArgs e)
		{
			textBox_Ticket_Foiv.ForeColor = (checkBox_Foiv.Checked ? SystemColors.ControlText : SystemColors.GrayText);
		}

		private void checkBox_ItemMark_CheckedChanged(object sender, EventArgs e)
		{
			comboBox_Mark.ForeColor = (checkBox_ItemMark.Checked ? SystemColors.ControlText : SystemColors.GrayText);
			button_MarkVerify.Enabled = checkBox_ItemMark.Checked;
		}

		private void checkBox_StatusAutonom_CheckedChanged(object sender, EventArgs e)
		{
			CheckBox checkBox = checkBox_Autonom;
			bool checked2 = (checkBox_NoticeAutonom.Checked = checkBox_StatusAutonom.Checked);
			checkBox.Checked = checked2;
		}

		private void HideForTest()
		{
			panel_AutoReceiptFrame.Hide();
			panel_ShiftFrame.Hide();
			panel_DocumentFrame.Hide();
			panel_Reports.Hide();
			groupBox_Status_OFD.Hide();
			panel_Status_FN3.Hide();
			panel_Totals_FN.Hide();
			panel_AutoReceiptFrame.Hide();
			button_KKTSerialSet.Hide();
			button_EraseSPI.Hide();
			tabControl_Main.Controls.Remove(tabPage_Header);
			tabControl_Main.Controls.Remove(tabPage_Registration);
			tabControl_Main.Controls.Remove(tabPage_Transaction);
			tabControl_Main.Controls.Remove(tabPage_NonFiscal);
			tabControl_Main.Controls.Remove(tabPage_OFD);
			tabControl_Main.Controls.Remove(tabPage_OISM);
			tabControl_Main.Controls.Remove(tabPage_Electronic);
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MitsuCube.MainForm));
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
			this.tabControl_Main = new System.Windows.Forms.TabControl();
			this.tabPage_Main = new System.Windows.Forms.TabPage();
			this.panel_Reports = new System.Windows.Forms.Panel();
			this.groupBox_Reports = new System.Windows.Forms.GroupBox();
			this.panel_ReportControls = new System.Windows.Forms.Panel();
			this.button_CloseFN = new System.Windows.Forms.Button();
			this.button_FinReport = new System.Windows.Forms.Button();
			this.button_GetFullData = new System.Windows.Forms.Button();
			this.button_GetShiftData = new System.Windows.Forms.Button();
			this.button_PrintXreport = new System.Windows.Forms.Button();
			this.panel_DocumentFrame = new System.Windows.Forms.Panel();
			this.groupBox_Document = new System.Windows.Forms.GroupBox();
			this.panel_DocControls = new System.Windows.Forms.Panel();
			this.checkBox_Arc = new System.Windows.Forms.CheckBox();
			this.button_DocFromFN = new System.Windows.Forms.Button();
			this.numericUpDown_FromFN = new System.Windows.Forms.NumericUpDown();
			this.button_DocCancel = new System.Windows.Forms.Button();
			this.button_GetDocStatus = new System.Windows.Forms.Button();
			this.label_DocStatus = new System.Windows.Forms.Label();
			this.panel_ShiftFrame = new System.Windows.Forms.Panel();
			this.groupBox_Shift = new System.Windows.Forms.GroupBox();
			this.panel_ShiftControls = new System.Windows.Forms.Panel();
			this.checkBox_OptShiftData = new System.Windows.Forms.CheckBox();
			this.button_OptShiftData = new System.Windows.Forms.Button();
			this.button_CloseShift = new System.Windows.Forms.Button();
			this.button_OpenShift = new System.Windows.Forms.Button();
			this.button_ShiftStatus = new System.Windows.Forms.Button();
			this.label_ShiftData = new System.Windows.Forms.Label();
			this.panel_CashierFrame = new System.Windows.Forms.Panel();
			this.groupBox_Cashier = new System.Windows.Forms.GroupBox();
			this.panel_Cashier = new System.Windows.Forms.Panel();
			this.panel_CashierName = new System.Windows.Forms.Panel();
			this.checkBox_CashierKeep = new System.Windows.Forms.CheckBox();
			this.textBox_CashierName = new System.Windows.Forms.TextBox();
			this.label_CashierName = new System.Windows.Forms.Label();
			this.panel_CashierTaxID = new System.Windows.Forms.Panel();
			this.textBox_CashierTaxID = new System.Windows.Forms.TextBox();
			this.label_CashierTaxID = new System.Windows.Forms.Label();
			this.panel_SetCashier = new System.Windows.Forms.Panel();
			this.button_SetCashier = new System.Windows.Forms.Button();
			this.panel_GetCashier = new System.Windows.Forms.Panel();
			this.button_GetCashier = new System.Windows.Forms.Button();
			this.panel_DateTimeFrame = new System.Windows.Forms.Panel();
			this.groupBox_DateTime = new System.Windows.Forms.GroupBox();
			this.panel_DateTimeFW = new System.Windows.Forms.Panel();
			this.dateTimePicker_Current = new System.Windows.Forms.DateTimePicker();
			this.panel_KKTSerial = new System.Windows.Forms.Panel();
			this.numeric_KKTSerial = new System.Windows.Forms.NumericUpDown();
			this.label_SerialNo = new System.Windows.Forms.Label();
			this.button_KKTSerialSet = new System.Windows.Forms.Button();
			this.label_VerKKT = new System.Windows.Forms.Label();
			this.button_VerKKT = new System.Windows.Forms.Button();
			this.button_GetDateTime = new System.Windows.Forms.Button();
			this.button_SetDateTime = new System.Windows.Forms.Button();
			this.panel_Connection = new System.Windows.Forms.Panel();
			this.groupBox_Connection = new System.Windows.Forms.GroupBox();
			this.panel_RadioCOM = new System.Windows.Forms.Panel();
			this.comboBox_Language = new System.Windows.Forms.ComboBox();
			this.panel_COMRefresh = new System.Windows.Forms.Panel();
			this.button_RunTest = new System.Windows.Forms.Button();
			this.panel_LAN = new System.Windows.Forms.Panel();
			this.textBox_PortNo = new System.Windows.Forms.TextBox();
			this.label_Port = new System.Windows.Forms.Label();
			this.textBox_KKT_IP = new System.Windows.Forms.TextBox();
			this.label_IPAddress = new System.Windows.Forms.Label();
			this.Lan_Button = new System.Windows.Forms.RadioButton();
			this.panel_Service = new System.Windows.Forms.Panel();
			this.numericUpDown_Service_ID = new System.Windows.Forms.NumericUpDown();
			this.label_Service_ID = new System.Windows.Forms.Label();
			this.textBox_Service_Port = new System.Windows.Forms.TextBox();
			this.label_Service_Port = new System.Windows.Forms.Label();
			this.textBox_Service_IP = new System.Windows.Forms.TextBox();
			this.label_Service_IP = new System.Windows.Forms.Label();
			this.Ser_Button = new System.Windows.Forms.RadioButton();
			this.panel_RadioButtons = new System.Windows.Forms.Panel();
			this.panel_Baudrate = new System.Windows.Forms.Panel();
			this.comboBox_COMBaudRate = new System.Windows.Forms.ComboBox();
			this.label_COMBaudRate = new System.Windows.Forms.Label();
			this.button_COMScan = new System.Windows.Forms.Button();
			this.tabPage_Status = new System.Windows.Forms.TabPage();
			this.groupBox_Status_OFD = new System.Windows.Forms.GroupBox();
			this.panel_Status_OFD = new System.Windows.Forms.Panel();
			this.panel_Status_OFD3 = new System.Windows.Forms.Panel();
			this.dataGrid_Status_DM3 = new System.Windows.Forms.DataGridView();
			this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.label_Status_DM3 = new System.Windows.Forms.Label();
			this.label_Status_DM = new System.Windows.Forms.Label();
			this.dataGrid_Status_DM1 = new System.Windows.Forms.DataGridView();
			this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.label_Status_DM2 = new System.Windows.Forms.Label();
			this.dataGrid_Status_DM2 = new System.Windows.Forms.DataGridView();
			this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.panel_DataMark = new System.Windows.Forms.Panel();
			this.button_Status_DM = new System.Windows.Forms.Button();
			this.panel_Status_OFD2 = new System.Windows.Forms.Panel();
			this.label_Status_OFD = new System.Windows.Forms.Label();
			this.dataGrid_Status_OFD = new System.Windows.Forms.DataGridView();
			this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.panel_Status_OFD1 = new System.Windows.Forms.Panel();
			this.button_Status_OFD = new System.Windows.Forms.Button();
			this.groupBox_Status_FN = new System.Windows.Forms.GroupBox();
			this.panel_Status_FN = new System.Windows.Forms.Panel();
			this.panel_Status_FN3 = new System.Windows.Forms.Panel();
			this.label_Totals_FN = new System.Windows.Forms.Label();
			this.textBox_Accum_Total = new System.Windows.Forms.TextBox();
			this.label_Acc_Total = new System.Windows.Forms.Label();
			this.dataGrid_Totals_FN = new System.Windows.Forms.DataGridView();
			this.Column_Sales_FN = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Column_Refund_FN = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.label_Tax_FN = new System.Windows.Forms.Label();
			this.dataGrid_Tax_FN = new System.Windows.Forms.DataGridView();
			this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.panel_Totals_FN = new System.Windows.Forms.Panel();
			this.button_Totals_FN = new System.Windows.Forms.Button();
			this.label_Totals_Refund = new System.Windows.Forms.Label();
			this.label_Totals_Sales = new System.Windows.Forms.Label();
			this.panel_Status_FN2 = new System.Windows.Forms.Panel();
			this.label_Status_FN = new System.Windows.Forms.Label();
			this.dataGrid_Status_FN = new System.Windows.Forms.DataGridView();
			this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.panel_Status_FN1 = new System.Windows.Forms.Panel();
			this.button_Status_FN = new System.Windows.Forms.Button();
			this.tabPage_Commands = new System.Windows.Forms.TabPage();
			this.panel_FWControlFrame = new System.Windows.Forms.Panel();
			this.groupBox_FWControl = new System.Windows.Forms.GroupBox();
			this.panel_FWControl = new System.Windows.Forms.Panel();
			this.textBox_FW_File = new System.Windows.Forms.TextBox();
			this.button_FW_Download_Update = new System.Windows.Forms.Button();
			this.checkBox_Setup_Reload = new System.Windows.Forms.CheckBox();
			this.button_FW_Upload = new System.Windows.Forms.Button();
			this.checkBox_FW_Hex = new System.Windows.Forms.CheckBox();
			this.button_FW_Update = new System.Windows.Forms.Button();
			this.checkBox_FW_CRC = new System.Windows.Forms.CheckBox();
			this.textBox_FW_CRC = new System.Windows.Forms.TextBox();
			this.button_FW_Status = new System.Windows.Forms.Button();
			this.button_FW_Download = new System.Windows.Forms.Button();
			this.panel_FNControlFrame = new System.Windows.Forms.Panel();
			this.groupBox_FNControl = new System.Windows.Forms.GroupBox();
			this.panel_FNControl = new System.Windows.Forms.Panel();
			this.button_EraseSPI = new System.Windows.Forms.Button();
			this.button_ResetMGM = new System.Windows.Forms.Button();
			this.panel_ManualCommandFrame = new System.Windows.Forms.Panel();
			this.groupBox_ManualCommand = new System.Windows.Forms.GroupBox();
			this.panel_ManualCommand = new System.Windows.Forms.Panel();
			this.comboBox_Command = new System.Windows.Forms.ComboBox();
			this.button_ManualCommand = new System.Windows.Forms.Button();
			this.panel_AutoReceiptFrame = new System.Windows.Forms.Panel();
			this.groupBox_AutoReceipt = new System.Windows.Forms.GroupBox();
			this.panel_AutoReceipt = new System.Windows.Forms.Panel();
			this.panel_ItemName = new System.Windows.Forms.Panel();
			this.textBox_ItemTemplate = new System.Windows.Forms.TextBox();
			this.label_AutoReceiptName = new System.Windows.Forms.Label();
			this.panel_ProduceRcpt = new System.Windows.Forms.Panel();
			this.button_AutoReceipt = new System.Windows.Forms.Button();
			this.numericUpDown_AutoReceiptItemNo = new System.Windows.Forms.NumericUpDown();
			this.label_AutoReceiptItemNo = new System.Windows.Forms.Label();
			this.label_AutoReceiptRepeat = new System.Windows.Forms.Label();
			this.numericUpDown_AutoReceiptRepeat = new System.Windows.Forms.NumericUpDown();
			this.panel_ScriptFrame = new System.Windows.Forms.Panel();
			this.groupBox_Script = new System.Windows.Forms.GroupBox();
			this.panel_Script = new System.Windows.Forms.Panel();
			this.label_Script = new System.Windows.Forms.Label();
			this.label_Drawer = new System.Windows.Forms.Label();
			this.label_PaperCut = new System.Windows.Forms.Label();
			this.label_Restart = new System.Windows.Forms.Label();
			this.button_RestartFN = new System.Windows.Forms.Button();
			this.button_ResetPrinter = new System.Windows.Forms.Button();
			this.button_PaperCut = new System.Windows.Forms.Button();
			this.button_Drawer_Status = new System.Windows.Forms.Button();
			this.button_Drawer_Open = new System.Windows.Forms.Button();
			this.button_Script = new System.Windows.Forms.Button();
			this.tabPage_Settings = new System.Windows.Forms.TabPage();
			this.panel_LAN_Buttons = new System.Windows.Forms.Panel();
			this.button_LAN_Get = new System.Windows.Forms.Button();
			this.button_LAN_Set = new System.Windows.Forms.Button();
			this.panel_OKP_Settings = new System.Windows.Forms.Panel();
			this.groupBox_OKPSettings = new System.Windows.Forms.GroupBox();
			this.label_OKP_IP = new System.Windows.Forms.Label();
			this.label_OKP_Port = new System.Windows.Forms.Label();
			this.dataGrid_OKP = new System.Windows.Forms.DataGridView();
			this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.checkedListBox_OKP = new System.Windows.Forms.CheckedListBox();
			this.panel_OISM_Settings = new System.Windows.Forms.Panel();
			this.groupBox_OISMSettings = new System.Windows.Forms.GroupBox();
			this.label_OISM_IP = new System.Windows.Forms.Label();
			this.label_OISM_Port = new System.Windows.Forms.Label();
			this.dataGrid_OISM = new System.Windows.Forms.DataGridView();
			this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.checkedListBox_OISM = new System.Windows.Forms.CheckedListBox();
			this.panel_OFDSettings = new System.Windows.Forms.Panel();
			this.groupBox_OFDSettings = new System.Windows.Forms.GroupBox();
			this.panel_Setup_OFDClient = new System.Windows.Forms.Panel();
			this.radio_Setup_OFDClient_Internal = new System.Windows.Forms.RadioButton();
			this.radio_Setup_OFDClient_External = new System.Windows.Forms.RadioButton();
			this.checkBox_OFD_Client = new System.Windows.Forms.CheckBox();
			this.label_OFD_IP = new System.Windows.Forms.Label();
			this.label_OFD_Port = new System.Windows.Forms.Label();
			this.label_OFD_TimerOFD = new System.Windows.Forms.Label();
			this.label_TimerFN = new System.Windows.Forms.Label();
			this.label_OFD_Client = new System.Windows.Forms.Label();
			this.dataGrid_OFD = new System.Windows.Forms.DataGridView();
			this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.checkedListBox_OFD = new System.Windows.Forms.CheckedListBox();
			this.panel_Setup = new System.Windows.Forms.Panel();
			this.groupBox_Setup = new System.Windows.Forms.GroupBox();
			this.panel_Setup_PrstTime = new System.Windows.Forms.Panel();
			this.numeric_Setup_PrstTime = new System.Windows.Forms.NumericUpDown();
			this.checkBox_Setup_PrstTime = new System.Windows.Forms.CheckBox();
			this.panel_Setup_Prst = new System.Windows.Forms.Panel();
			this.checkBox_Setup_Prst = new System.Windows.Forms.CheckBox();
			this.panel_Setup_PrstValue = new System.Windows.Forms.Panel();
			this.comboBox_Setup_Prst = new System.Windows.Forms.ComboBox();
			this.panel_Setup_DrawerFall = new System.Windows.Forms.Panel();
			this.numericUpDown_Setup_DrawerFall = new System.Windows.Forms.NumericUpDown();
			this.checkBox_Setup_DrawerFall = new System.Windows.Forms.CheckBox();
			this.panel_Setup_DrawerPulse = new System.Windows.Forms.Panel();
			this.numericUpDown_Setup_DrawerPulse = new System.Windows.Forms.NumericUpDown();
			this.checkBox_Setup_DrawerPulse = new System.Windows.Forms.CheckBox();
			this.panel_Setup_DrawerPin = new System.Windows.Forms.Panel();
			this.numericUpDown_Setup_DrawerPin = new System.Windows.Forms.NumericUpDown();
			this.checkBox_Setup_DrawerPin = new System.Windows.Forms.CheckBox();
			this.panel_Setup_ItemCnt = new System.Windows.Forms.Panel();
			this.panel_ItemCntYesNo = new System.Windows.Forms.Panel();
			this.radio_Setup_ItemCnt_Yes = new System.Windows.Forms.RadioButton();
			this.radio_Setup_ItemCnt_No = new System.Windows.Forms.RadioButton();
			this.checkBox_Setup_ItemCnt = new System.Windows.Forms.CheckBox();
			this.panel_Setup_DrawerOpen = new System.Windows.Forms.Panel();
			this.panel_Setup_DrawerOpen_Y_N = new System.Windows.Forms.Panel();
			this.checkBox_Drawer_Beznal = new System.Windows.Forms.CheckBox();
			this.checkBox_Drawer_Nal = new System.Windows.Forms.CheckBox();
			this.checkBox_Setup_Cash = new System.Windows.Forms.CheckBox();
			this.panel_Setup_AutoTest = new System.Windows.Forms.Panel();
			this.panel_Setup_AutoTest_Y_N = new System.Windows.Forms.Panel();
			this.radio_Setup_AutoTest_Yes = new System.Windows.Forms.RadioButton();
			this.radio_Setup_AutoTest_No = new System.Windows.Forms.RadioButton();
			this.checkBox_Setup_AutoTest = new System.Windows.Forms.CheckBox();
			this.panel_Setup_Beeper = new System.Windows.Forms.Panel();
			this.panel_Setup_Beeper_Y_N = new System.Windows.Forms.Panel();
			this.radio_Setup_Beeper_Yes = new System.Windows.Forms.RadioButton();
			this.radio_Setup_Beeper_No = new System.Windows.Forms.RadioButton();
			this.checkBox_Setup_Beeper = new System.Windows.Forms.CheckBox();
			this.panel_Setup_PaperCut = new System.Windows.Forms.Panel();
			this.panel_Setup_PaperCut_Y_N = new System.Windows.Forms.Panel();
			this.radio_Setup_PaperCut_Yes = new System.Windows.Forms.RadioButton();
			this.radio_Setup_PaperCut_No = new System.Windows.Forms.RadioButton();
			this.checkBox_Setup_PaperCut = new System.Windows.Forms.CheckBox();
			this.panel_Setup_QRText = new System.Windows.Forms.Panel();
			this.panel_Setup_QRText_Y_N = new System.Windows.Forms.Panel();
			this.radio_Setup_QRText_Yes = new System.Windows.Forms.RadioButton();
			this.radio_Setup_QRText_No = new System.Windows.Forms.RadioButton();
			this.checkBox_Setup_QRText = new System.Windows.Forms.CheckBox();
			this.panel_Setup_FontType = new System.Windows.Forms.Panel();
			this.panel_Setup_A_B = new System.Windows.Forms.Panel();
			this.radio_Setup_FontB = new System.Windows.Forms.RadioButton();
			this.radio_Setup_FontA = new System.Windows.Forms.RadioButton();
			this.checkBox_Setup_FontType = new System.Windows.Forms.CheckBox();
			this.panel_Setup_PaperWidth = new System.Windows.Forms.Panel();
			this.panel_Setup_80_57 = new System.Windows.Forms.Panel();
			this.radio_Setup_Paper57mm = new System.Windows.Forms.RadioButton();
			this.radio_Setup_Paper80mm = new System.Windows.Forms.RadioButton();
			this.checkBox_Setup_PaperWidth = new System.Windows.Forms.CheckBox();
			this.panel_Setup_LineType = new System.Windows.Forms.Panel();
			this.panel_Setup_LineTypeValue = new System.Windows.Forms.Panel();
			this.comboBox_Setup_LineType = new System.Windows.Forms.ComboBox();
			this.checkBox_Setup_LineType = new System.Windows.Forms.CheckBox();
			this.panel_Setup_Rounding = new System.Windows.Forms.Panel();
			this.checkBox_Setup_Rounding = new System.Windows.Forms.CheckBox();
			this.panel_Setup_RoundingValue = new System.Windows.Forms.Panel();
			this.comboBox_Setup_Rounding = new System.Windows.Forms.ComboBox();
			this.panel_Setup_QRAlign = new System.Windows.Forms.Panel();
			this.panel_Setup_QRAlignValue = new System.Windows.Forms.Panel();
			this.comboBox_Setup_QRAlign = new System.Windows.Forms.ComboBox();
			this.checkBox_Setup_QRAlign = new System.Windows.Forms.CheckBox();
			this.panel_PrinterModel = new System.Windows.Forms.Panel();
			this.checkBox_Setup_PrinterModel = new System.Windows.Forms.CheckBox();
			this.panel_PrinterModelValue = new System.Windows.Forms.Panel();
			this.comboBox_Setup_PrinterModel = new System.Windows.Forms.ComboBox();
			this.panel_Setup_Buttons = new System.Windows.Forms.Panel();
			this.button_Setup_Set = new System.Windows.Forms.Button();
			this.button_Setup_Get = new System.Windows.Forms.Button();
			this.panel_Setup_PrBaudrate = new System.Windows.Forms.Panel();
			this.panel_Setup_PrBaudrateValue = new System.Windows.Forms.Panel();
			this.comboBox_Setup_PrBaudrate = new System.Windows.Forms.ComboBox();
			this.checkBox_Setup_PrBaudrate = new System.Windows.Forms.CheckBox();
			this.panel_Setup_COMBaudrate = new System.Windows.Forms.Panel();
			this.panel_Setup_COMBaudrateValue = new System.Windows.Forms.Panel();
			this.comboBox_Setup_COMBaudrate = new System.Windows.Forms.ComboBox();
			this.checkBox_Setup_COMBaudrate = new System.Windows.Forms.CheckBox();
			this.panel_Setup_SelectAll = new System.Windows.Forms.Panel();
			this.checkBox_Setup_SelectAll = new System.Windows.Forms.CheckBox();
			this.panel_LANSettings = new System.Windows.Forms.Panel();
			this.groupBox_LANSettings = new System.Windows.Forms.GroupBox();
			this.checkBox_LAN_SelectAll = new System.Windows.Forms.CheckBox();
			this.label_LAN_Gateway = new System.Windows.Forms.Label();
			this.label_LAN_DNS = new System.Windows.Forms.Label();
			this.label_LAN_Port = new System.Windows.Forms.Label();
			this.label_LAN_Mask = new System.Windows.Forms.Label();
			this.checkedListBox_LAN = new System.Windows.Forms.CheckedListBox();
			this.label_LAN_IP = new System.Windows.Forms.Label();
			this.dataGrid_LAN = new System.Windows.Forms.DataGridView();
			this.dataGridViewTextBoxColumn_LAN = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.tabPage_Header = new System.Windows.Forms.TabPage();
			this.panel_LogoPic = new System.Windows.Forms.Panel();
			this.groupBox_Picture = new System.Windows.Forms.GroupBox();
			this.pictureBox_Picture = new System.Windows.Forms.PictureBox();
			this.panel_Picture = new System.Windows.Forms.Panel();
			this.button_PictureErase = new System.Windows.Forms.Button();
			this.button_PictureShow = new System.Windows.Forms.Button();
			this.button_Picture = new System.Windows.Forms.Button();
			this.numericUpDown_Picture = new System.Windows.Forms.NumericUpDown();
			this.groupBox_Logo = new System.Windows.Forms.GroupBox();
			this.pictureBox_Logo = new System.Windows.Forms.PictureBox();
			this.panel_Logo = new System.Windows.Forms.Panel();
			this.button_LogoErase = new System.Windows.Forms.Button();
			this.button_LogoShow = new System.Windows.Forms.Button();
			this.textBox_Logo = new System.Windows.Forms.TextBox();
			this.button_Logo = new System.Windows.Forms.Button();
			this.groupBox_Header = new System.Windows.Forms.GroupBox();
			this.panel_Header = new System.Windows.Forms.Panel();
			this.panel_HeaderSet = new System.Windows.Forms.Panel();
			this.groupBox_HeaderAlign = new System.Windows.Forms.GroupBox();
			this.comboBox_HeaderAlign = new System.Windows.Forms.ComboBox();
			this.groupBox_HeaderUnderline = new System.Windows.Forms.GroupBox();
			this.comboBox_HeaderUnderline = new System.Windows.Forms.ComboBox();
			this.groupBox_HeaderFont = new System.Windows.Forms.GroupBox();
			this.comboBox_HeaderFont = new System.Windows.Forms.ComboBox();
			this.groupBox_CharHeight = new System.Windows.Forms.GroupBox();
			this.numericUpDown_CharHeight = new System.Windows.Forms.NumericUpDown();
			this.groupBox_CharWidth = new System.Windows.Forms.GroupBox();
			this.numericUpDown_CharWidth = new System.Windows.Forms.NumericUpDown();
			this.groupBox_HeaderInverse = new System.Windows.Forms.GroupBox();
			this.checkBox_HeaderInverse = new System.Windows.Forms.CheckBox();
			this.panel_HeaderList = new System.Windows.Forms.Panel();
			this.dataGrid_Header2 = new System.Windows.Forms.DataGridView();
			this.dataGridViewTextBoxColumn_Header2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGrid_Header1 = new System.Windows.Forms.DataGridView();
			this.dataGridViewTextBoxColumn_Header = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGrid_Header4 = new System.Windows.Forms.DataGridView();
			this.dataGridViewTextBoxColumn_Header4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGrid_Header3 = new System.Windows.Forms.DataGridView();
			this.dataGridViewTextBoxColumn_Header3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.panel_HeaderCheckList = new System.Windows.Forms.Panel();
			this.label_Header_Lines = new System.Windows.Forms.Label();
			this.panel_HeaderSel = new System.Windows.Forms.Panel();
			this.button_HeaderDel = new System.Windows.Forms.Button();
			this.button_HeaderSet = new System.Windows.Forms.Button();
			this.label_Header = new System.Windows.Forms.Label();
			this.button_HeaderGet = new System.Windows.Forms.Button();
			this.checkBox_HeaderKeep = new System.Windows.Forms.CheckBox();
			this.radioButton_Header4 = new System.Windows.Forms.RadioButton();
			this.radioButton_Header3 = new System.Windows.Forms.RadioButton();
			this.radioButton_Header2 = new System.Windows.Forms.RadioButton();
			this.radioButton_Header1 = new System.Windows.Forms.RadioButton();
			this.tabPage_Registration = new System.Windows.Forms.TabPage();
			this.checkBox_ReReg = new System.Windows.Forms.CheckBox();
			this.checkBox_Reg_FFD12 = new System.Windows.Forms.CheckBox();
			this.panel_RegNo = new System.Windows.Forms.Panel();
			this.button_Verify = new System.Windows.Forms.Button();
			this.button_Calculate = new System.Windows.Forms.Button();
			this.panel_Reg3 = new System.Windows.Forms.Panel();
			this.groupBox_Reason11 = new System.Windows.Forms.GroupBox();
			this.checkedListBox_Reason11 = new System.Windows.Forms.CheckedListBox();
			this.panel_Reg1 = new System.Windows.Forms.Panel();
			this.panel_RegBottom = new System.Windows.Forms.Panel();
			this.textBox_RegDateTime = new System.Windows.Forms.TextBox();
			this.button_Reg = new System.Windows.Forms.Button();
			this.label_RegNo = new System.Windows.Forms.Label();
			this.numericUpDown_ReRegNumber = new System.Windows.Forms.NumericUpDown();
			this.button_GetRegData = new System.Windows.Forms.Button();
			this.button_PrintReRegTicket = new System.Windows.Forms.Button();
			this.panel_Reg2 = new System.Windows.Forms.Panel();
			this.groupBox_OpMode = new System.Windows.Forms.GroupBox();
			this.checkedListBox_ModeB = new System.Windows.Forms.CheckedListBox();
			this.checkedListBox_ModeA = new System.Windows.Forms.CheckedListBox();
			this.groupBox_Taxes = new System.Windows.Forms.GroupBox();
			this.checkedListBox_Taxes = new System.Windows.Forms.CheckedListBox();
			this.groupBox_RegData = new System.Windows.Forms.GroupBox();
			this.checkBox_RegNum = new System.Windows.Forms.CheckBox();
			this.label_FNS = new System.Windows.Forms.Label();
			this.label_Calculate = new System.Windows.Forms.Label();
			this.contextMenuStrip_Reg = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.сalculateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.verifyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.dataGrid_RegData = new System.Windows.Forms.DataGridView();
			this.Column_RegData = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.label_RegData = new System.Windows.Forms.Label();
			this.tabPage_Transaction = new System.Windows.Forms.TabPage();
			this.panel_beznal = new System.Windows.Forms.Panel();
			this.checkedListBox_beznal = new System.Windows.Forms.CheckedListBox();
			this.dataGrid_beznal = new System.Windows.Forms.DataGridView();
			this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.panel_AddItem = new System.Windows.Forms.Panel();
			this.groupBox_AddItem = new System.Windows.Forms.GroupBox();
			this.panel_Ticket_Item = new System.Windows.Forms.Panel();
			this.groupBox_Mark = new System.Windows.Forms.GroupBox();
			this.panel_Mark_Data = new System.Windows.Forms.Panel();
			this.textBox_ItemCode = new System.Windows.Forms.TextBox();
			this.textBox_ItemID = new System.Windows.Forms.TextBox();
			this.comboBox_ItemStatus = new System.Windows.Forms.ComboBox();
			this.comboBox_TypeOfCode = new System.Windows.Forms.ComboBox();
			this.panel_Mark_Header = new System.Windows.Forms.Panel();
			this.label_ItemCode = new System.Windows.Forms.Label();
			this.label_ItemID = new System.Windows.Forms.Label();
			this.label_ItemStatus = new System.Windows.Forms.Label();
			this.label_TypeOfCode = new System.Windows.Forms.Label();
			this.panel_ItemMark = new System.Windows.Forms.Panel();
			this.comboBox_Mark = new System.Windows.Forms.ComboBox();
			this.checkBox_ItemMark = new System.Windows.Forms.CheckBox();
			this.panel_Ticket_Option4 = new System.Windows.Forms.Panel();
			this.textBox_ItemDR = new System.Windows.Forms.TextBox();
			this.dateTimePicker_FoivDate = new System.Windows.Forms.DateTimePicker();
			this.textBox_Ticket_FoivNo = new System.Windows.Forms.TextBox();
			this.textBox_Ticket_Foiv = new System.Windows.Forms.TextBox();
			this.textBox_Ticket_FoivID = new System.Windows.Forms.TextBox();
			this.checkBox_Foiv = new System.Windows.Forms.CheckBox();
			this.panel_Ticket_Option41 = new System.Windows.Forms.Panel();
			this.label_ItemDR = new System.Windows.Forms.Label();
			this.label_FoivDate = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.label13 = new System.Windows.Forms.Label();
			this.panel_Ticket_Option3 = new System.Windows.Forms.Panel();
			this.textBox_ItemCountry = new System.Windows.Forms.TextBox();
			this.textBox_ItemCustomNo = new System.Windows.Forms.TextBox();
			this.comboBox_PaymentType = new System.Windows.Forms.ComboBox();
			this.numericUpDown_PricePerPiece = new System.Windows.Forms.NumericUpDown();
			this.numeric_QtyDenom = new System.Windows.Forms.NumericUpDown();
			this.numeric_QtyNom = new System.Windows.Forms.NumericUpDown();
			this.checkBox_Fraction = new System.Windows.Forms.CheckBox();
			this.panel_Ticket_Option31 = new System.Windows.Forms.Panel();
			this.label_ItemCountry = new System.Windows.Forms.Label();
			this.label_ItemCustomNo = new System.Windows.Forms.Label();
			this.label_PaymentType = new System.Windows.Forms.Label();
			this.label_PricePerPiece = new System.Windows.Forms.Label();
			this.label_Qty_Nom_Denom = new System.Windows.Forms.Label();
			this.panel_Ticket_Option2 = new System.Windows.Forms.Panel();
			this.numeric_ItemAmount = new System.Windows.Forms.NumericUpDown();
			this.comboBox_ItemNDS = new System.Windows.Forms.ComboBox();
			this.numeric_ItemExcise = new System.Windows.Forms.NumericUpDown();
			this.numeric_ItemPrice = new System.Windows.Forms.NumericUpDown();
			this.comboBox_ItemType = new System.Windows.Forms.ComboBox();
			this.panel_Ticket_Option21 = new System.Windows.Forms.Panel();
			this.label_ItemNDS = new System.Windows.Forms.Label();
			this.label_ItemExcise = new System.Windows.Forms.Label();
			this.label_ItemAmount = new System.Windows.Forms.Label();
			this.label_ItemPrice = new System.Windows.Forms.Label();
			this.label_ItemType = new System.Windows.Forms.Label();
			this.panel_Ticket_Option1 = new System.Windows.Forms.Panel();
			this.comboBox_ItemMeasure = new System.Windows.Forms.ComboBox();
			this.numeric_ItemQty = new System.Windows.Forms.NumericUpDown();
			this.textBox_ItemName = new System.Windows.Forms.TextBox();
			this.panel_Ticket_ItemAddTest = new System.Windows.Forms.Panel();
			this.checkBox_Agent = new System.Windows.Forms.CheckBox();
			this.checkBox_PreCheck = new System.Windows.Forms.CheckBox();
			this.button_MarkClear = new System.Windows.Forms.Button();
			this.checkBox_ShowResult = new System.Windows.Forms.CheckBox();
			this.checkBox_Autonom = new System.Windows.Forms.CheckBox();
			this.button_MarkReset = new System.Windows.Forms.Button();
			this.button_MarkResult = new System.Windows.Forms.Button();
			this.button_MarkVerify = new System.Windows.Forms.Button();
			this.button_ItemAgent = new System.Windows.Forms.Button();
			this.button_AddItem = new System.Windows.Forms.Button();
			this.checkBox_ItemOptions = new System.Windows.Forms.CheckBox();
			this.panel_TicketClose = new System.Windows.Forms.Panel();
			this.checkBox_ItemCount = new System.Windows.Forms.CheckBox();
			this.checkBox_ItemSpace = new System.Windows.Forms.CheckBox();
			this.checkBox_ItemSeparator = new System.Windows.Forms.CheckBox();
			this.button_DocCancel1 = new System.Windows.Forms.Button();
			this.button_RunSales = new System.Windows.Forms.Button();
			this.button_FCh = new System.Windows.Forms.Button();
			this.button_CCh = new System.Windows.Forms.Button();
			this.panel_Ticket_Total = new System.Windows.Forms.Panel();
			this.label_Discount = new System.Windows.Forms.Label();
			this.numeric_Discount = new System.Windows.Forms.NumericUpDown();
			this.textBox_Round_Check = new System.Windows.Forms.TextBox();
			this.label_Round_Check = new System.Windows.Forms.Label();
			this.textBox_Total_Check = new System.Windows.Forms.TextBox();
			this.label_Check_Total = new System.Windows.Forms.Label();
			this.textBox_ItemCnt_Check = new System.Windows.Forms.TextBox();
			this.label_Check_Items = new System.Windows.Forms.Label();
			this.button_Total = new System.Windows.Forms.Button();
			this.panel_TicketOpen = new System.Windows.Forms.Panel();
			this.groupBox_TicketOpen = new System.Windows.Forms.GroupBox();
			this.panel_Ticket_Open = new System.Windows.Forms.Panel();
			this.button_Text = new System.Windows.Forms.Button();
			this.button_CheckOptions = new System.Windows.Forms.Button();
			this.button_CheckCustomer = new System.Windows.Forms.Button();
			this.checkBox_Ticket_User = new System.Windows.Forms.CheckBox();
			this.button_CheckCorr = new System.Windows.Forms.Button();
			this.button_CheckOpen = new System.Windows.Forms.Button();
			this.groupBox_OCh = new System.Windows.Forms.GroupBox();
			this.panel_TicketPay = new System.Windows.Forms.Panel();
			this.label_Beznal_Type = new System.Windows.Forms.Label();
			this.label_Beznal = new System.Windows.Forms.Label();
			this.checkBox_Pay_Cash = new System.Windows.Forms.CheckBox();
			this.textBox_CardNumber = new System.Windows.Forms.TextBox();
			this.comboBox_Beznal = new System.Windows.Forms.ComboBox();
			this.label_Pay_Prov = new System.Windows.Forms.Label();
			this.label_Pay_Credit = new System.Windows.Forms.Label();
			this.label_Pay_Prepaid = new System.Windows.Forms.Label();
			this.label_Pay_Card = new System.Windows.Forms.Label();
			this.nUpDown_VpCheck = new System.Windows.Forms.NumericUpDown();
			this.nUpDown_CrCheck = new System.Windows.Forms.NumericUpDown();
			this.nUpDown_AvCheck = new System.Windows.Forms.NumericUpDown();
			this.nUpDown_ElCheck = new System.Windows.Forms.NumericUpDown();
			this.nUpDown_NalCheck = new System.Windows.Forms.NumericUpDown();
			this.button_Payment = new System.Windows.Forms.Button();
			this.panel_Ticket_Type_and_Tax = new System.Windows.Forms.Panel();
			this.groupBox_TransactionTax = new System.Windows.Forms.GroupBox();
			this.panel_Ticket_Tax = new System.Windows.Forms.Panel();
			this.radioButton_Tax0 = new System.Windows.Forms.RadioButton();
			this.radioButton_Tax1 = new System.Windows.Forms.RadioButton();
			this.radioButton_Tax4 = new System.Windows.Forms.RadioButton();
			this.radioButton_Tax3 = new System.Windows.Forms.RadioButton();
			this.radioButton_Tax2 = new System.Windows.Forms.RadioButton();
			this.radioButton_Tax5 = new System.Windows.Forms.RadioButton();
			this.groupBox_TransactionType = new System.Windows.Forms.GroupBox();
			this.panel_Ticket_Type = new System.Windows.Forms.Panel();
			this.radioButton_Type1 = new System.Windows.Forms.RadioButton();
			this.radioButton_Type2 = new System.Windows.Forms.RadioButton();
			this.radioButton_Type3 = new System.Windows.Forms.RadioButton();
			this.radioButton_Type4 = new System.Windows.Forms.RadioButton();
			this.tabPage_NonFiscal = new System.Windows.Forms.TabPage();
			this.groupBox_TextLines = new System.Windows.Forms.GroupBox();
			this.panel_TextFormat = new System.Windows.Forms.Panel();
			this.comboBox_txt_LineType = new System.Windows.Forms.ComboBox();
			this.label_LineType = new System.Windows.Forms.Label();
			this.label_txt_PictureNo = new System.Windows.Forms.Label();
			this.label_txt_Pic_Align = new System.Windows.Forms.Label();
			this.numeric_txt_PictureNo = new System.Windows.Forms.NumericUpDown();
			this.label_txt_BarcodeHeight = new System.Windows.Forms.Label();
			this.label_txt_BarcodeType = new System.Windows.Forms.Label();
			this.label_txt_BarcodeWidth = new System.Windows.Forms.Label();
			this.numeric_txt_BarcodeHeight = new System.Windows.Forms.NumericUpDown();
			this.numeric_txt_BarcodeWidth = new System.Windows.Forms.NumericUpDown();
			this.comboBox_txt_BarcodeType = new System.Windows.Forms.ComboBox();
			this.textBox_txt_QR = new System.Windows.Forms.TextBox();
			this.textBox_txt_QRText = new System.Windows.Forms.TextBox();
			this.checkBox_txt_QRText = new System.Windows.Forms.CheckBox();
			this.label_txt_QR_DotSize = new System.Windows.Forms.Label();
			this.label_txt_QR_Level = new System.Windows.Forms.Label();
			this.numeric_txt_QR_DotSize = new System.Windows.Forms.NumericUpDown();
			this.numeric_txt_QR_Level = new System.Windows.Forms.NumericUpDown();
			this.panel_txt_Pic_Align = new System.Windows.Forms.Panel();
			this.radio_txt_Pic_Right = new System.Windows.Forms.RadioButton();
			this.radio_txt_Pic_Center = new System.Windows.Forms.RadioButton();
			this.radio_txt_Pic_Left = new System.Windows.Forms.RadioButton();
			this.panel_txt_QR_Align = new System.Windows.Forms.Panel();
			this.radio_txt_QR_Right = new System.Windows.Forms.RadioButton();
			this.radio_txt_QR_Center = new System.Windows.Forms.RadioButton();
			this.radio_txt_QR_Left = new System.Windows.Forms.RadioButton();
			this.checkBox_txt_QR = new System.Windows.Forms.CheckBox();
			this.checkBox_txt_Line = new System.Windows.Forms.CheckBox();
			this.checkBox_txt_Image = new System.Windows.Forms.CheckBox();
			this.checkBox_txt_Barcode = new System.Windows.Forms.CheckBox();
			this.button_CreateTXTDoc = new System.Windows.Forms.Button();
			this.checkBox_IncludeHeader = new System.Windows.Forms.CheckBox();
			this.textBox_txt_Barcode = new System.Windows.Forms.TextBox();
			this.panel_TextEntries = new System.Windows.Forms.Panel();
			this.panel_TextLines = new System.Windows.Forms.Panel();
			this.label_TextLinesTip = new System.Windows.Forms.Label();
			this.dataGrid_TextLines = new System.Windows.Forms.DataGridView();
			this.dataGridViewTextBoxColumn_TextLines = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.panel_TextLinesCheckBoxes = new System.Windows.Forms.Panel();
			this.checkedListBox_TextLines = new System.Windows.Forms.CheckedListBox();
			this.tabPage_OFD = new System.Windows.Forms.TabPage();
			this.groupBox_OFD_Ticket = new System.Windows.Forms.GroupBox();
			this.panel_OFD_Ticket = new System.Windows.Forms.Panel();
			this.label_OFD_Ticket = new System.Windows.Forms.Label();
			this.numericUpDown_OFD_Ticket = new System.Windows.Forms.NumericUpDown();
			this.button_GetTicketXML = new System.Windows.Forms.Button();
			this.button_GetTicketOFD = new System.Windows.Forms.Button();
			this.groupBox_SendMSG = new System.Windows.Forms.GroupBox();
			this.panel_OFD_Send = new System.Windows.Forms.Panel();
			this.button_StopSendAllToOFD = new System.Windows.Forms.Button();
			this.textBox_PendingMSG = new System.Windows.Forms.TextBox();
			this.button_SendAllToOFD = new System.Windows.Forms.Button();
			this.checkBox_InternalOFD = new System.Windows.Forms.CheckBox();
			this.textBox_IP_OFD = new System.Windows.Forms.TextBox();
			this.numericUpDown_Port_OFD = new System.Windows.Forms.NumericUpDown();
			this.button_OFD_MSG = new System.Windows.Forms.Button();
			this.label_AddressOFD = new System.Windows.Forms.Label();
			this.label_RemainingMSG = new System.Windows.Forms.Label();
			this.label_PortOFD = new System.Windows.Forms.Label();
			this.groupBox_ReadMSG = new System.Windows.Forms.GroupBox();
			this.panel_ReadMSG = new System.Windows.Forms.Panel();
			this.numericUpDown_LengthBlock = new System.Windows.Forms.NumericUpDown();
			this.label_LengthMSG = new System.Windows.Forms.Label();
			this.numericUpDown_OffsetBlock = new System.Windows.Forms.NumericUpDown();
			this.label_OffsetMSG = new System.Windows.Forms.Label();
			this.button_ReadBlockMSG = new System.Windows.Forms.Button();
			this.button_CancelMSG = new System.Windows.Forms.Button();
			this.button_EndMSG = new System.Windows.Forms.Button();
			this.button_ReadMSG = new System.Windows.Forms.Button();
			this.tabPage_OISM = new System.Windows.Forms.TabPage();
			this.groupBox_OKP = new System.Windows.Forms.GroupBox();
			this.panel_OKP_Update = new System.Windows.Forms.Panel();
			this.textBox_AddressOKP = new System.Windows.Forms.TextBox();
			this.numericUpDown_PortOKP = new System.Windows.Forms.NumericUpDown();
			this.label_AddressOKP = new System.Windows.Forms.Label();
			this.label_PortOKP = new System.Windows.Forms.Label();
			this.button_KeyUpdateAll = new System.Windows.Forms.Button();
			this.button_KeyUpdate = new System.Windows.Forms.Button();
			this.groupBox_SendNotice = new System.Windows.Forms.GroupBox();
			this.panel_OISM_Send = new System.Windows.Forms.Panel();
			this.button_SendNoticeStop = new System.Windows.Forms.Button();
			this.textBox_PendingNotice = new System.Windows.Forms.TextBox();
			this.button_SendNoticeAll = new System.Windows.Forms.Button();
			this.checkBox_NoticeParse = new System.Windows.Forms.CheckBox();
			this.textBox_AddressOISM = new System.Windows.Forms.TextBox();
			this.numericUpDown_PortOISM = new System.Windows.Forms.NumericUpDown();
			this.button_SendNoticeOne = new System.Windows.Forms.Button();
			this.label_AddressOISM = new System.Windows.Forms.Label();
			this.label_PendingNotice = new System.Windows.Forms.Label();
			this.label_PortOISM = new System.Windows.Forms.Label();
			this.groupBox_ReadNotice = new System.Windows.Forms.GroupBox();
			this.panel_ReadNotice = new System.Windows.Forms.Panel();
			this.panel_NoticeOffline = new System.Windows.Forms.Panel();
			this.label_NoticeOffline = new System.Windows.Forms.Label();
			this.label_NoticeCRC = new System.Windows.Forms.Label();
			this.textBox_NoticeOffline = new System.Windows.Forms.TextBox();
			this.textBox_NoticeCRC = new System.Windows.Forms.TextBox();
			this.checkBox_NoticeAutonom = new System.Windows.Forms.CheckBox();
			this.numeric_ReadNoticeLength = new System.Windows.Forms.NumericUpDown();
			this.label_ReadNoticeLength = new System.Windows.Forms.Label();
			this.numeric_ReadNoticeOffset = new System.Windows.Forms.NumericUpDown();
			this.label_ReadNoticeOffset = new System.Windows.Forms.Label();
			this.button_ReadNotice = new System.Windows.Forms.Button();
			this.button_ReadNoticeCancel = new System.Windows.Forms.Button();
			this.button_ReadNoticeEnd = new System.Windows.Forms.Button();
			this.button_ReadNoticeStart = new System.Windows.Forms.Button();
			this.tabPage_Electronic = new System.Windows.Forms.TabPage();
			this.panel_Unused = new System.Windows.Forms.Panel();
			this.groupBox_EForm = new System.Windows.Forms.GroupBox();
			this.panel_CheckEF = new System.Windows.Forms.Panel();
			this.textBox_Dump1 = new System.Windows.Forms.TextBox();
			this.checkBox_XML_Archive = new System.Windows.Forms.CheckBox();
			this.button_Log_Dump = new System.Windows.Forms.Button();
			this.textBox_Dump2 = new System.Windows.Forms.TextBox();
			this.checkBox_SaveElCheck = new System.Windows.Forms.CheckBox();
			this.button_ReadAllCheck = new System.Windows.Forms.Button();
			this.numericUpDown_EFCheckNumber = new System.Windows.Forms.NumericUpDown();
			this.panel_FD0 = new System.Windows.Forms.Panel();
			this.groupBox_FD = new System.Windows.Forms.GroupBox();
			this.panel_FD = new System.Windows.Forms.Panel();
			this.panel_FD_Type = new System.Windows.Forms.Panel();
			this.textBox_TypeFD = new System.Windows.Forms.TextBox();
			this.button_GetTypeDoc = new System.Windows.Forms.Button();
			this.button_PrintDoc_Arc = new System.Windows.Forms.Button();
			this.button_PrintDoc = new System.Windows.Forms.Button();
			this.panel_FD2 = new System.Windows.Forms.Panel();
			this.numericUpDown_FD = new System.Windows.Forms.NumericUpDown();
			this.panel_FD1 = new System.Windows.Forms.Panel();
			this.label_FD = new System.Windows.Forms.Label();
			this.panel_XML0 = new System.Windows.Forms.Panel();
			this.groupBox_XML_Document = new System.Windows.Forms.GroupBox();
			this.panel_XML_Document = new System.Windows.Forms.Panel();
			this.panel_XML4 = new System.Windows.Forms.Panel();
			this.checkBox_XML_SaveToFile = new System.Windows.Forms.CheckBox();
			this.button_ReadXML_Arc = new System.Windows.Forms.Button();
			this.button_ReadXML = new System.Windows.Forms.Button();
			this.panel_XML2 = new System.Windows.Forms.Panel();
			this.numericUpDown_XMLDocNum = new System.Windows.Forms.NumericUpDown();
			this.panel_XML1 = new System.Windows.Forms.Panel();
			this.label_XML1 = new System.Windows.Forms.Label();
			this.button_StatePrinter = new System.Windows.Forms.Button();
			this.checkBox_StatusPrint = new System.Windows.Forms.CheckBox();
			this.checkBox_StatusLog = new System.Windows.Forms.CheckBox();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.panel_Bottom = new System.Windows.Forms.Panel();
			this.button_PowerGet = new System.Windows.Forms.Button();
			this.button_PowerSet = new System.Windows.Forms.Button();
			this.checkBox_PowerFlag = new System.Windows.Forms.CheckBox();
			this.checkBox_StatusAutonom = new System.Windows.Forms.CheckBox();
			this.button_Duplicate0 = new System.Windows.Forms.Button();
			this.button_PowerReset = new System.Windows.Forms.Button();
			this.checkBox_Footer = new System.Windows.Forms.CheckBox();
			this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
			this.contextMenuStrip_Log = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.clearAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.copyAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.richTextBox_Log = new System.Windows.Forms.RichTextBox();
			this.saveFileDialog_Notice = new System.Windows.Forms.SaveFileDialog();
			this.tabControl_Main.SuspendLayout();
			this.tabPage_Main.SuspendLayout();
			this.panel_Reports.SuspendLayout();
			this.groupBox_Reports.SuspendLayout();
			this.panel_ReportControls.SuspendLayout();
			this.panel_DocumentFrame.SuspendLayout();
			this.groupBox_Document.SuspendLayout();
			this.panel_DocControls.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_FromFN).BeginInit();
			this.panel_ShiftFrame.SuspendLayout();
			this.groupBox_Shift.SuspendLayout();
			this.panel_ShiftControls.SuspendLayout();
			this.panel_CashierFrame.SuspendLayout();
			this.groupBox_Cashier.SuspendLayout();
			this.panel_Cashier.SuspendLayout();
			this.panel_CashierName.SuspendLayout();
			this.panel_CashierTaxID.SuspendLayout();
			this.panel_SetCashier.SuspendLayout();
			this.panel_GetCashier.SuspendLayout();
			this.panel_DateTimeFrame.SuspendLayout();
			this.groupBox_DateTime.SuspendLayout();
			this.panel_DateTimeFW.SuspendLayout();
			this.panel_KKTSerial.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.numeric_KKTSerial).BeginInit();
			this.panel_Connection.SuspendLayout();
			this.groupBox_Connection.SuspendLayout();
			this.panel_RadioCOM.SuspendLayout();
			this.panel_COMRefresh.SuspendLayout();
			this.panel_LAN.SuspendLayout();
			this.panel_Service.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_Service_ID).BeginInit();
			this.panel_RadioButtons.SuspendLayout();
			this.panel_Baudrate.SuspendLayout();
			this.tabPage_Status.SuspendLayout();
			this.groupBox_Status_OFD.SuspendLayout();
			this.panel_Status_OFD.SuspendLayout();
			this.panel_Status_OFD3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.dataGrid_Status_DM3).BeginInit();
			((System.ComponentModel.ISupportInitialize)this.dataGrid_Status_DM1).BeginInit();
			((System.ComponentModel.ISupportInitialize)this.dataGrid_Status_DM2).BeginInit();
			this.panel_DataMark.SuspendLayout();
			this.panel_Status_OFD2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.dataGrid_Status_OFD).BeginInit();
			this.panel_Status_OFD1.SuspendLayout();
			this.groupBox_Status_FN.SuspendLayout();
			this.panel_Status_FN.SuspendLayout();
			this.panel_Status_FN3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.dataGrid_Totals_FN).BeginInit();
			((System.ComponentModel.ISupportInitialize)this.dataGrid_Tax_FN).BeginInit();
			this.panel_Totals_FN.SuspendLayout();
			this.panel_Status_FN2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.dataGrid_Status_FN).BeginInit();
			this.panel_Status_FN1.SuspendLayout();
			this.tabPage_Commands.SuspendLayout();
			this.panel_FWControlFrame.SuspendLayout();
			this.groupBox_FWControl.SuspendLayout();
			this.panel_FWControl.SuspendLayout();
			this.panel_FNControlFrame.SuspendLayout();
			this.groupBox_FNControl.SuspendLayout();
			this.panel_FNControl.SuspendLayout();
			this.panel_ManualCommandFrame.SuspendLayout();
			this.groupBox_ManualCommand.SuspendLayout();
			this.panel_ManualCommand.SuspendLayout();
			this.panel_AutoReceiptFrame.SuspendLayout();
			this.groupBox_AutoReceipt.SuspendLayout();
			this.panel_AutoReceipt.SuspendLayout();
			this.panel_ItemName.SuspendLayout();
			this.panel_ProduceRcpt.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_AutoReceiptItemNo).BeginInit();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_AutoReceiptRepeat).BeginInit();
			this.panel_ScriptFrame.SuspendLayout();
			this.groupBox_Script.SuspendLayout();
			this.panel_Script.SuspendLayout();
			this.tabPage_Settings.SuspendLayout();
			this.panel_LAN_Buttons.SuspendLayout();
			this.panel_OKP_Settings.SuspendLayout();
			this.groupBox_OKPSettings.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.dataGrid_OKP).BeginInit();
			this.panel_OISM_Settings.SuspendLayout();
			this.groupBox_OISMSettings.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.dataGrid_OISM).BeginInit();
			this.panel_OFDSettings.SuspendLayout();
			this.groupBox_OFDSettings.SuspendLayout();
			this.panel_Setup_OFDClient.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.dataGrid_OFD).BeginInit();
			this.panel_Setup.SuspendLayout();
			this.groupBox_Setup.SuspendLayout();
			this.panel_Setup_PrstTime.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.numeric_Setup_PrstTime).BeginInit();
			this.panel_Setup_Prst.SuspendLayout();
			this.panel_Setup_PrstValue.SuspendLayout();
			this.panel_Setup_DrawerFall.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_Setup_DrawerFall).BeginInit();
			this.panel_Setup_DrawerPulse.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_Setup_DrawerPulse).BeginInit();
			this.panel_Setup_DrawerPin.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_Setup_DrawerPin).BeginInit();
			this.panel_Setup_ItemCnt.SuspendLayout();
			this.panel_ItemCntYesNo.SuspendLayout();
			this.panel_Setup_DrawerOpen.SuspendLayout();
			this.panel_Setup_DrawerOpen_Y_N.SuspendLayout();
			this.panel_Setup_AutoTest.SuspendLayout();
			this.panel_Setup_AutoTest_Y_N.SuspendLayout();
			this.panel_Setup_Beeper.SuspendLayout();
			this.panel_Setup_Beeper_Y_N.SuspendLayout();
			this.panel_Setup_PaperCut.SuspendLayout();
			this.panel_Setup_PaperCut_Y_N.SuspendLayout();
			this.panel_Setup_QRText.SuspendLayout();
			this.panel_Setup_QRText_Y_N.SuspendLayout();
			this.panel_Setup_FontType.SuspendLayout();
			this.panel_Setup_A_B.SuspendLayout();
			this.panel_Setup_PaperWidth.SuspendLayout();
			this.panel_Setup_80_57.SuspendLayout();
			this.panel_Setup_LineType.SuspendLayout();
			this.panel_Setup_LineTypeValue.SuspendLayout();
			this.panel_Setup_Rounding.SuspendLayout();
			this.panel_Setup_RoundingValue.SuspendLayout();
			this.panel_Setup_QRAlign.SuspendLayout();
			this.panel_Setup_QRAlignValue.SuspendLayout();
			this.panel_PrinterModel.SuspendLayout();
			this.panel_PrinterModelValue.SuspendLayout();
			this.panel_Setup_Buttons.SuspendLayout();
			this.panel_Setup_PrBaudrate.SuspendLayout();
			this.panel_Setup_PrBaudrateValue.SuspendLayout();
			this.panel_Setup_COMBaudrate.SuspendLayout();
			this.panel_Setup_COMBaudrateValue.SuspendLayout();
			this.panel_Setup_SelectAll.SuspendLayout();
			this.panel_LANSettings.SuspendLayout();
			this.groupBox_LANSettings.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.dataGrid_LAN).BeginInit();
			this.tabPage_Header.SuspendLayout();
			this.panel_LogoPic.SuspendLayout();
			this.groupBox_Picture.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.pictureBox_Picture).BeginInit();
			this.panel_Picture.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_Picture).BeginInit();
			this.groupBox_Logo.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.pictureBox_Logo).BeginInit();
			this.panel_Logo.SuspendLayout();
			this.groupBox_Header.SuspendLayout();
			this.panel_Header.SuspendLayout();
			this.panel_HeaderSet.SuspendLayout();
			this.groupBox_HeaderAlign.SuspendLayout();
			this.groupBox_HeaderUnderline.SuspendLayout();
			this.groupBox_HeaderFont.SuspendLayout();
			this.groupBox_CharHeight.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_CharHeight).BeginInit();
			this.groupBox_CharWidth.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_CharWidth).BeginInit();
			this.groupBox_HeaderInverse.SuspendLayout();
			this.panel_HeaderList.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.dataGrid_Header2).BeginInit();
			((System.ComponentModel.ISupportInitialize)this.dataGrid_Header1).BeginInit();
			((System.ComponentModel.ISupportInitialize)this.dataGrid_Header4).BeginInit();
			((System.ComponentModel.ISupportInitialize)this.dataGrid_Header3).BeginInit();
			this.panel_HeaderCheckList.SuspendLayout();
			this.panel_HeaderSel.SuspendLayout();
			this.tabPage_Registration.SuspendLayout();
			this.panel_RegNo.SuspendLayout();
			this.panel_Reg3.SuspendLayout();
			this.groupBox_Reason11.SuspendLayout();
			this.panel_Reg1.SuspendLayout();
			this.panel_RegBottom.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_ReRegNumber).BeginInit();
			this.panel_Reg2.SuspendLayout();
			this.groupBox_OpMode.SuspendLayout();
			this.groupBox_Taxes.SuspendLayout();
			this.groupBox_RegData.SuspendLayout();
			this.contextMenuStrip_Reg.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.dataGrid_RegData).BeginInit();
			this.tabPage_Transaction.SuspendLayout();
			this.panel_beznal.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.dataGrid_beznal).BeginInit();
			this.panel_AddItem.SuspendLayout();
			this.groupBox_AddItem.SuspendLayout();
			this.panel_Ticket_Item.SuspendLayout();
			this.groupBox_Mark.SuspendLayout();
			this.panel_Mark_Data.SuspendLayout();
			this.panel_Mark_Header.SuspendLayout();
			this.panel_ItemMark.SuspendLayout();
			this.panel_Ticket_Option4.SuspendLayout();
			this.panel_Ticket_Option41.SuspendLayout();
			this.panel_Ticket_Option3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_PricePerPiece).BeginInit();
			((System.ComponentModel.ISupportInitialize)this.numeric_QtyDenom).BeginInit();
			((System.ComponentModel.ISupportInitialize)this.numeric_QtyNom).BeginInit();
			this.panel_Ticket_Option31.SuspendLayout();
			this.panel_Ticket_Option2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.numeric_ItemAmount).BeginInit();
			((System.ComponentModel.ISupportInitialize)this.numeric_ItemExcise).BeginInit();
			((System.ComponentModel.ISupportInitialize)this.numeric_ItemPrice).BeginInit();
			this.panel_Ticket_Option21.SuspendLayout();
			this.panel_Ticket_Option1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.numeric_ItemQty).BeginInit();
			this.panel_Ticket_ItemAddTest.SuspendLayout();
			this.panel_TicketClose.SuspendLayout();
			this.panel_Ticket_Total.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.numeric_Discount).BeginInit();
			this.panel_TicketOpen.SuspendLayout();
			this.groupBox_TicketOpen.SuspendLayout();
			this.panel_Ticket_Open.SuspendLayout();
			this.panel_TicketPay.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.nUpDown_VpCheck).BeginInit();
			((System.ComponentModel.ISupportInitialize)this.nUpDown_CrCheck).BeginInit();
			((System.ComponentModel.ISupportInitialize)this.nUpDown_AvCheck).BeginInit();
			((System.ComponentModel.ISupportInitialize)this.nUpDown_ElCheck).BeginInit();
			((System.ComponentModel.ISupportInitialize)this.nUpDown_NalCheck).BeginInit();
			this.panel_Ticket_Type_and_Tax.SuspendLayout();
			this.groupBox_TransactionTax.SuspendLayout();
			this.panel_Ticket_Tax.SuspendLayout();
			this.groupBox_TransactionType.SuspendLayout();
			this.panel_Ticket_Type.SuspendLayout();
			this.tabPage_NonFiscal.SuspendLayout();
			this.groupBox_TextLines.SuspendLayout();
			this.panel_TextFormat.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.numeric_txt_PictureNo).BeginInit();
			((System.ComponentModel.ISupportInitialize)this.numeric_txt_BarcodeHeight).BeginInit();
			((System.ComponentModel.ISupportInitialize)this.numeric_txt_BarcodeWidth).BeginInit();
			((System.ComponentModel.ISupportInitialize)this.numeric_txt_QR_DotSize).BeginInit();
			((System.ComponentModel.ISupportInitialize)this.numeric_txt_QR_Level).BeginInit();
			this.panel_txt_Pic_Align.SuspendLayout();
			this.panel_txt_QR_Align.SuspendLayout();
			this.panel_TextEntries.SuspendLayout();
			this.panel_TextLines.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.dataGrid_TextLines).BeginInit();
			this.panel_TextLinesCheckBoxes.SuspendLayout();
			this.tabPage_OFD.SuspendLayout();
			this.groupBox_OFD_Ticket.SuspendLayout();
			this.panel_OFD_Ticket.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_OFD_Ticket).BeginInit();
			this.groupBox_SendMSG.SuspendLayout();
			this.panel_OFD_Send.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_Port_OFD).BeginInit();
			this.groupBox_ReadMSG.SuspendLayout();
			this.panel_ReadMSG.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_LengthBlock).BeginInit();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_OffsetBlock).BeginInit();
			this.tabPage_OISM.SuspendLayout();
			this.groupBox_OKP.SuspendLayout();
			this.panel_OKP_Update.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_PortOKP).BeginInit();
			this.groupBox_SendNotice.SuspendLayout();
			this.panel_OISM_Send.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_PortOISM).BeginInit();
			this.groupBox_ReadNotice.SuspendLayout();
			this.panel_ReadNotice.SuspendLayout();
			this.panel_NoticeOffline.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.numeric_ReadNoticeLength).BeginInit();
			((System.ComponentModel.ISupportInitialize)this.numeric_ReadNoticeOffset).BeginInit();
			this.tabPage_Electronic.SuspendLayout();
			this.panel_Unused.SuspendLayout();
			this.groupBox_EForm.SuspendLayout();
			this.panel_CheckEF.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_EFCheckNumber).BeginInit();
			this.panel_FD0.SuspendLayout();
			this.groupBox_FD.SuspendLayout();
			this.panel_FD.SuspendLayout();
			this.panel_FD_Type.SuspendLayout();
			this.panel_FD2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_FD).BeginInit();
			this.panel_FD1.SuspendLayout();
			this.panel_XML0.SuspendLayout();
			this.groupBox_XML_Document.SuspendLayout();
			this.panel_XML_Document.SuspendLayout();
			this.panel_XML4.SuspendLayout();
			this.panel_XML2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_XMLDocNum).BeginInit();
			this.panel_XML1.SuspendLayout();
			this.panel_Bottom.SuspendLayout();
			this.contextMenuStrip_Log.SuspendLayout();
			base.SuspendLayout();
			this.tabControl_Main.Alignment = System.Windows.Forms.TabAlignment.Left;
			this.tabControl_Main.Controls.Add(this.tabPage_Main);
			this.tabControl_Main.Controls.Add(this.tabPage_Status);
			this.tabControl_Main.Controls.Add(this.tabPage_Commands);
			this.tabControl_Main.Controls.Add(this.tabPage_Settings);
			this.tabControl_Main.Controls.Add(this.tabPage_Header);
			this.tabControl_Main.Controls.Add(this.tabPage_Registration);
			this.tabControl_Main.Controls.Add(this.tabPage_Transaction);
			this.tabControl_Main.Controls.Add(this.tabPage_NonFiscal);
			this.tabControl_Main.Controls.Add(this.tabPage_OFD);
			this.tabControl_Main.Controls.Add(this.tabPage_OISM);
			this.tabControl_Main.Controls.Add(this.tabPage_Electronic);
			this.tabControl_Main.Dock = System.Windows.Forms.DockStyle.Top;
			this.tabControl_Main.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed;
			this.tabControl_Main.ItemSize = new System.Drawing.Size(38, 150);
			this.tabControl_Main.Location = new System.Drawing.Point(0, 0);
			this.tabControl_Main.Multiline = true;
			this.tabControl_Main.Name = "tabControl_Main";
			this.tabControl_Main.Padding = new System.Drawing.Point(3, 3);
			this.tabControl_Main.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.tabControl_Main.SelectedIndex = 0;
			this.tabControl_Main.ShowToolTips = true;
			this.tabControl_Main.Size = new System.Drawing.Size(784, 432);
			this.tabControl_Main.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
			this.tabControl_Main.TabIndex = 0;
			this.tabControl_Main.DrawItem += new System.Windows.Forms.DrawItemEventHandler(TabControl1_DrawItem);
			this.tabPage_Main.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.tabPage_Main.Controls.Add(this.panel_Reports);
			this.tabPage_Main.Controls.Add(this.panel_DocumentFrame);
			this.tabPage_Main.Controls.Add(this.panel_ShiftFrame);
			this.tabPage_Main.Controls.Add(this.panel_CashierFrame);
			this.tabPage_Main.Controls.Add(this.panel_DateTimeFrame);
			this.tabPage_Main.Controls.Add(this.panel_Connection);
			this.tabPage_Main.Location = new System.Drawing.Point(154, 4);
			this.tabPage_Main.Name = "tabPage_Main";
			this.tabPage_Main.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage_Main.Size = new System.Drawing.Size(626, 424);
			this.tabPage_Main.TabIndex = 0;
			this.tabPage_Main.Text = "Стартовая";
			this.tabPage_Main.UseVisualStyleBackColor = true;
			this.panel_Reports.Controls.Add(this.groupBox_Reports);
			this.panel_Reports.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Reports.Location = new System.Drawing.Point(3, 366);
			this.panel_Reports.Name = "panel_Reports";
			this.panel_Reports.Size = new System.Drawing.Size(618, 54);
			this.panel_Reports.TabIndex = 23;
			this.groupBox_Reports.BackColor = System.Drawing.Color.Transparent;
			this.groupBox_Reports.Controls.Add(this.panel_ReportControls);
			this.groupBox_Reports.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox_Reports.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_Reports.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_Reports.Location = new System.Drawing.Point(0, 0);
			this.groupBox_Reports.Name = "groupBox_Reports";
			this.groupBox_Reports.Size = new System.Drawing.Size(618, 50);
			this.groupBox_Reports.TabIndex = 15;
			this.groupBox_Reports.TabStop = false;
			this.groupBox_Reports.Text = "О т ч е т ы";
			this.panel_ReportControls.BackColor = System.Drawing.Color.LightCyan;
			this.panel_ReportControls.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_ReportControls.Controls.Add(this.button_CloseFN);
			this.panel_ReportControls.Controls.Add(this.button_FinReport);
			this.panel_ReportControls.Controls.Add(this.button_GetFullData);
			this.panel_ReportControls.Controls.Add(this.button_GetShiftData);
			this.panel_ReportControls.Controls.Add(this.button_PrintXreport);
			this.panel_ReportControls.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel_ReportControls.Location = new System.Drawing.Point(3, 17);
			this.panel_ReportControls.Name = "panel_ReportControls";
			this.panel_ReportControls.Size = new System.Drawing.Size(612, 30);
			this.panel_ReportControls.TabIndex = 1;
			this.button_CloseFN.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.button_CloseFN.ForeColor = System.Drawing.Color.Brown;
			this.button_CloseFN.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_CloseFN.Location = new System.Drawing.Point(487, 3);
			this.button_CloseFN.Name = "button_CloseFN";
			this.button_CloseFN.Size = new System.Drawing.Size(119, 22);
			this.button_CloseFN.TabIndex = 18;
			this.button_CloseFN.Text = "Закрыть ФН";
			this.button_CloseFN.UseVisualStyleBackColor = true;
			this.button_CloseFN.Click += new System.EventHandler(Button_CloseFN_Click);
			this.button_FinReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.button_FinReport.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_FinReport.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_FinReport.Location = new System.Drawing.Point(366, 3);
			this.button_FinReport.Name = "button_FinReport";
			this.button_FinReport.Size = new System.Drawing.Size(118, 22);
			this.button_FinReport.TabIndex = 17;
			this.button_FinReport.Text = "Отчет о расчетах";
			this.button_FinReport.UseVisualStyleBackColor = true;
			this.button_FinReport.Click += new System.EventHandler(Button_RepCurrentCalc_Click);
			this.button_GetFullData.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.button_GetFullData.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_GetFullData.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_GetFullData.Location = new System.Drawing.Point(124, 3);
			this.button_GetFullData.Name = "button_GetFullData";
			this.button_GetFullData.Size = new System.Drawing.Size(118, 22);
			this.button_GetFullData.TabIndex = 0;
			this.button_GetFullData.Text = "Итоги ФН";
			this.button_GetFullData.UseVisualStyleBackColor = true;
			this.button_GetFullData.Click += new System.EventHandler(Button_GetFullData_Click);
			this.button_GetShiftData.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.button_GetShiftData.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_GetShiftData.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_GetShiftData.Location = new System.Drawing.Point(3, 3);
			this.button_GetShiftData.Name = "button_GetShiftData";
			this.button_GetShiftData.Size = new System.Drawing.Size(118, 22);
			this.button_GetShiftData.TabIndex = 0;
			this.button_GetShiftData.Text = "Итоги смены";
			this.button_GetShiftData.UseVisualStyleBackColor = true;
			this.button_GetShiftData.Click += new System.EventHandler(Button_GetShiftData_Click);
			this.button_PrintXreport.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.button_PrintXreport.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_PrintXreport.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_PrintXreport.Location = new System.Drawing.Point(245, 3);
			this.button_PrintXreport.Name = "button_PrintXreport";
			this.button_PrintXreport.Size = new System.Drawing.Size(118, 22);
			this.button_PrintXreport.TabIndex = 0;
			this.button_PrintXreport.Text = "X отчет";
			this.button_PrintXreport.UseVisualStyleBackColor = true;
			this.button_PrintXreport.Click += new System.EventHandler(Button_PrintXreport_Click);
			this.panel_DocumentFrame.Controls.Add(this.groupBox_Document);
			this.panel_DocumentFrame.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_DocumentFrame.Location = new System.Drawing.Point(3, 306);
			this.panel_DocumentFrame.Name = "panel_DocumentFrame";
			this.panel_DocumentFrame.Size = new System.Drawing.Size(618, 60);
			this.panel_DocumentFrame.TabIndex = 22;
			this.groupBox_Document.BackColor = System.Drawing.Color.Transparent;
			this.groupBox_Document.Controls.Add(this.panel_DocControls);
			this.groupBox_Document.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox_Document.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_Document.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_Document.Location = new System.Drawing.Point(0, 0);
			this.groupBox_Document.Name = "groupBox_Document";
			this.groupBox_Document.Size = new System.Drawing.Size(618, 50);
			this.groupBox_Document.TabIndex = 16;
			this.groupBox_Document.TabStop = false;
			this.groupBox_Document.Text = "Д о к у м е н т";
			this.panel_DocControls.BackColor = System.Drawing.Color.LightCyan;
			this.panel_DocControls.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_DocControls.Controls.Add(this.checkBox_Arc);
			this.panel_DocControls.Controls.Add(this.button_DocFromFN);
			this.panel_DocControls.Controls.Add(this.numericUpDown_FromFN);
			this.panel_DocControls.Controls.Add(this.button_DocCancel);
			this.panel_DocControls.Controls.Add(this.button_GetDocStatus);
			this.panel_DocControls.Controls.Add(this.label_DocStatus);
			this.panel_DocControls.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel_DocControls.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_DocControls.Location = new System.Drawing.Point(3, 17);
			this.panel_DocControls.Name = "panel_DocControls";
			this.panel_DocControls.Size = new System.Drawing.Size(612, 30);
			this.panel_DocControls.TabIndex = 0;
			this.checkBox_Arc.AutoSize = true;
			this.checkBox_Arc.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_Arc.Location = new System.Drawing.Point(432, 6);
			this.checkBox_Arc.Name = "checkBox_Arc";
			this.checkBox_Arc.Size = new System.Drawing.Size(56, 17);
			this.checkBox_Arc.TabIndex = 12;
			this.checkBox_Arc.Text = "Архив";
			this.toolTip1.SetToolTip(this.checkBox_Arc, "Печать документа из архива ФН");
			this.checkBox_Arc.UseVisualStyleBackColor = true;
			this.checkBox_Arc.CheckedChanged += new System.EventHandler(checkBox_Arc_CheckedChanged);
			this.button_DocFromFN.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_DocFromFN.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_DocFromFN.Location = new System.Drawing.Point(490, 3);
			this.button_DocFromFN.Name = "button_DocFromFN";
			this.button_DocFromFN.Size = new System.Drawing.Size(116, 22);
			this.button_DocFromFN.TabIndex = 5;
			this.button_DocFromFN.Text = "Печать из ФН";
			this.button_DocFromFN.UseVisualStyleBackColor = true;
			this.button_DocFromFN.Click += new System.EventHandler(Button_DocFromFN_Click);
			this.numericUpDown_FromFN.Location = new System.Drawing.Point(357, 4);
			this.numericUpDown_FromFN.Maximum = new decimal(new int[4] { 999999999, 0, 0, 0 });
			this.numericUpDown_FromFN.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			this.numericUpDown_FromFN.Name = "numericUpDown_FromFN";
			this.numericUpDown_FromFN.Size = new System.Drawing.Size(70, 20);
			this.numericUpDown_FromFN.TabIndex = 0;
			this.numericUpDown_FromFN.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.toolTip1.SetToolTip(this.numericUpDown_FromFN, "Номер документа");
			this.numericUpDown_FromFN.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			this.button_DocCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.button_DocCancel.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_DocCancel.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_DocCancel.Location = new System.Drawing.Point(281, 3);
			this.button_DocCancel.Name = "button_DocCancel";
			this.button_DocCancel.Size = new System.Drawing.Size(70, 22);
			this.button_DocCancel.TabIndex = 0;
			this.button_DocCancel.Text = "Отменить";
			this.toolTip1.SetToolTip(this.button_DocCancel, "Отменить текущий документ (если открыт)");
			this.button_DocCancel.UseVisualStyleBackColor = true;
			this.button_DocCancel.Click += new System.EventHandler(Button_DocCancel_Click);
			this.button_GetDocStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.button_GetDocStatus.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_GetDocStatus.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_GetDocStatus.Location = new System.Drawing.Point(3, 3);
			this.button_GetDocStatus.Name = "button_GetDocStatus";
			this.button_GetDocStatus.Size = new System.Drawing.Size(70, 22);
			this.button_GetDocStatus.TabIndex = 0;
			this.button_GetDocStatus.Text = "Статус";
			this.toolTip1.SetToolTip(this.button_GetDocStatus, "Наличие открытого документа");
			this.button_GetDocStatus.UseVisualStyleBackColor = true;
			this.button_GetDocStatus.Click += new System.EventHandler(Button_GetDocStatus_Click);
			this.label_DocStatus.BackColor = System.Drawing.Color.Cyan;
			this.label_DocStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.label_DocStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold);
			this.label_DocStatus.ForeColor = System.Drawing.Color.Blue;
			this.label_DocStatus.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_DocStatus.Location = new System.Drawing.Point(75, 4);
			this.label_DocStatus.Margin = new System.Windows.Forms.Padding(3);
			this.label_DocStatus.Name = "label_DocStatus";
			this.label_DocStatus.Size = new System.Drawing.Size(203, 20);
			this.label_DocStatus.TabIndex = 11;
			this.label_DocStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.panel_ShiftFrame.Controls.Add(this.groupBox_Shift);
			this.panel_ShiftFrame.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_ShiftFrame.Location = new System.Drawing.Point(3, 246);
			this.panel_ShiftFrame.Name = "panel_ShiftFrame";
			this.panel_ShiftFrame.Size = new System.Drawing.Size(618, 60);
			this.panel_ShiftFrame.TabIndex = 21;
			this.groupBox_Shift.BackColor = System.Drawing.Color.Transparent;
			this.groupBox_Shift.Controls.Add(this.panel_ShiftControls);
			this.groupBox_Shift.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox_Shift.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_Shift.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_Shift.Location = new System.Drawing.Point(0, 0);
			this.groupBox_Shift.Name = "groupBox_Shift";
			this.groupBox_Shift.Size = new System.Drawing.Size(618, 50);
			this.groupBox_Shift.TabIndex = 15;
			this.groupBox_Shift.TabStop = false;
			this.groupBox_Shift.Text = "С м е н а";
			this.panel_ShiftControls.BackColor = System.Drawing.Color.LightCyan;
			this.panel_ShiftControls.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_ShiftControls.Controls.Add(this.checkBox_OptShiftData);
			this.panel_ShiftControls.Controls.Add(this.button_OptShiftData);
			this.panel_ShiftControls.Controls.Add(this.button_CloseShift);
			this.panel_ShiftControls.Controls.Add(this.button_OpenShift);
			this.panel_ShiftControls.Controls.Add(this.button_ShiftStatus);
			this.panel_ShiftControls.Controls.Add(this.label_ShiftData);
			this.panel_ShiftControls.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel_ShiftControls.Location = new System.Drawing.Point(3, 17);
			this.panel_ShiftControls.Name = "panel_ShiftControls";
			this.panel_ShiftControls.Size = new System.Drawing.Size(612, 30);
			this.panel_ShiftControls.TabIndex = 1;
			this.checkBox_OptShiftData.AutoSize = true;
			this.checkBox_OptShiftData.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f);
			this.checkBox_OptShiftData.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_OptShiftData.Location = new System.Drawing.Point(355, 7);
			this.checkBox_OptShiftData.Name = "checkBox_OptShiftData";
			this.checkBox_OptShiftData.Size = new System.Drawing.Size(15, 14);
			this.checkBox_OptShiftData.TabIndex = 12;
			this.toolTip1.SetToolTip(this.checkBox_OptShiftData, "Включить дополнительные реквизиты в состав:\r\nа) отчета об открытии смены\r\nб) отчета о закрытии смены\r\nв) отчета о текущем состоянии расчетов\r\nг) отчета о закрытии ФН");
			this.checkBox_OptShiftData.UseVisualStyleBackColor = true;
			this.button_OptShiftData.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.button_OptShiftData.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_OptShiftData.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_OptShiftData.Location = new System.Drawing.Point(372, 3);
			this.button_OptShiftData.Name = "button_OptShiftData";
			this.button_OptShiftData.Size = new System.Drawing.Size(234, 22);
			this.button_OptShiftData.TabIndex = 2;
			this.button_OptShiftData.Text = "Реквизиты (ООС...ОЗФН)";
			this.button_OptShiftData.UseVisualStyleBackColor = true;
			this.button_OptShiftData.Click += new System.EventHandler(Button_OptShiftData_Click);
			this.button_CloseShift.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.button_CloseShift.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_CloseShift.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_CloseShift.Location = new System.Drawing.Point(281, 3);
			this.button_CloseShift.Name = "button_CloseShift";
			this.button_CloseShift.Size = new System.Drawing.Size(70, 22);
			this.button_CloseShift.TabIndex = 2;
			this.button_CloseShift.Text = "Закрыть";
			this.button_CloseShift.UseVisualStyleBackColor = true;
			this.button_CloseShift.Click += new System.EventHandler(Button_CloseShift_Click);
			this.button_OpenShift.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.button_OpenShift.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_OpenShift.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_OpenShift.Location = new System.Drawing.Point(208, 3);
			this.button_OpenShift.Name = "button_OpenShift";
			this.button_OpenShift.Size = new System.Drawing.Size(70, 22);
			this.button_OpenShift.TabIndex = 2;
			this.button_OpenShift.Text = "Открыть";
			this.button_OpenShift.UseVisualStyleBackColor = true;
			this.button_OpenShift.Click += new System.EventHandler(Button_OpenShift_Click);
			this.button_ShiftStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.button_ShiftStatus.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_ShiftStatus.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_ShiftStatus.Location = new System.Drawing.Point(3, 3);
			this.button_ShiftStatus.Name = "button_ShiftStatus";
			this.button_ShiftStatus.Size = new System.Drawing.Size(70, 22);
			this.button_ShiftStatus.TabIndex = 0;
			this.button_ShiftStatus.Text = "Статус";
			this.button_ShiftStatus.UseVisualStyleBackColor = true;
			this.button_ShiftStatus.Click += new System.EventHandler(Button_ShiftStatus_Click);
			this.label_ShiftData.BackColor = System.Drawing.Color.Cyan;
			this.label_ShiftData.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.label_ShiftData.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold);
			this.label_ShiftData.ForeColor = System.Drawing.Color.Blue;
			this.label_ShiftData.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_ShiftData.Location = new System.Drawing.Point(75, 4);
			this.label_ShiftData.Margin = new System.Windows.Forms.Padding(3);
			this.label_ShiftData.Name = "label_ShiftData";
			this.label_ShiftData.Size = new System.Drawing.Size(130, 20);
			this.label_ShiftData.TabIndex = 11;
			this.label_ShiftData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.panel_CashierFrame.Controls.Add(this.groupBox_Cashier);
			this.panel_CashierFrame.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_CashierFrame.Location = new System.Drawing.Point(3, 176);
			this.panel_CashierFrame.Name = "panel_CashierFrame";
			this.panel_CashierFrame.Size = new System.Drawing.Size(618, 70);
			this.panel_CashierFrame.TabIndex = 19;
			this.groupBox_Cashier.BackColor = System.Drawing.Color.Transparent;
			this.groupBox_Cashier.Controls.Add(this.panel_Cashier);
			this.groupBox_Cashier.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox_Cashier.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_Cashier.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_Cashier.Location = new System.Drawing.Point(0, 0);
			this.groupBox_Cashier.Name = "groupBox_Cashier";
			this.groupBox_Cashier.Size = new System.Drawing.Size(618, 60);
			this.groupBox_Cashier.TabIndex = 13;
			this.groupBox_Cashier.TabStop = false;
			this.groupBox_Cashier.Text = "К а с с и р";
			this.panel_Cashier.BackColor = System.Drawing.Color.LightCyan;
			this.panel_Cashier.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_Cashier.Controls.Add(this.panel_CashierName);
			this.panel_Cashier.Controls.Add(this.panel_CashierTaxID);
			this.panel_Cashier.Controls.Add(this.panel_SetCashier);
			this.panel_Cashier.Controls.Add(this.panel_GetCashier);
			this.panel_Cashier.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel_Cashier.Location = new System.Drawing.Point(3, 17);
			this.panel_Cashier.Name = "panel_Cashier";
			this.panel_Cashier.Size = new System.Drawing.Size(612, 40);
			this.panel_Cashier.TabIndex = 4;
			this.panel_CashierName.Controls.Add(this.checkBox_CashierKeep);
			this.panel_CashierName.Controls.Add(this.textBox_CashierName);
			this.panel_CashierName.Controls.Add(this.label_CashierName);
			this.panel_CashierName.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel_CashierName.Location = new System.Drawing.Point(148, 0);
			this.panel_CashierName.MinimumSize = new System.Drawing.Size(334, 0);
			this.panel_CashierName.Name = "panel_CashierName";
			this.panel_CashierName.Padding = new System.Windows.Forms.Padding(1);
			this.panel_CashierName.Size = new System.Drawing.Size(378, 38);
			this.panel_CashierName.TabIndex = 18;
			this.checkBox_CashierKeep.AutoSize = true;
			this.checkBox_CashierKeep.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_CashierKeep.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_CashierKeep.Location = new System.Drawing.Point(361, 18);
			this.checkBox_CashierKeep.Name = "checkBox_CashierKeep";
			this.checkBox_CashierKeep.Size = new System.Drawing.Size(15, 14);
			this.checkBox_CashierKeep.TabIndex = 13;
			this.toolTip1.SetToolTip(this.checkBox_CashierKeep, "Задать кассира постоянным");
			this.checkBox_CashierKeep.UseVisualStyleBackColor = true;
			this.textBox_CashierName.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox_CashierName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_CashierName.Location = new System.Drawing.Point(1, 14);
			this.textBox_CashierName.MaxLength = 64;
			this.textBox_CashierName.Name = "textBox_CashierName";
			this.textBox_CashierName.Size = new System.Drawing.Size(376, 20);
			this.textBox_CashierName.TabIndex = 2;
			this.label_CashierName.Dock = System.Windows.Forms.DockStyle.Top;
			this.label_CashierName.Font = new System.Drawing.Font("Microsoft Sans Serif", 7f, System.Drawing.FontStyle.Italic);
			this.label_CashierName.ForeColor = System.Drawing.Color.Blue;
			this.label_CashierName.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_CashierName.Location = new System.Drawing.Point(1, 1);
			this.label_CashierName.Margin = new System.Windows.Forms.Padding(0);
			this.label_CashierName.Name = "label_CashierName";
			this.label_CashierName.Size = new System.Drawing.Size(376, 13);
			this.label_CashierName.TabIndex = 0;
			this.label_CashierName.Text = "Имя";
			this.panel_CashierTaxID.Controls.Add(this.textBox_CashierTaxID);
			this.panel_CashierTaxID.Controls.Add(this.label_CashierTaxID);
			this.panel_CashierTaxID.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel_CashierTaxID.Location = new System.Drawing.Point(526, 0);
			this.panel_CashierTaxID.Name = "panel_CashierTaxID";
			this.panel_CashierTaxID.Padding = new System.Windows.Forms.Padding(1);
			this.panel_CashierTaxID.Size = new System.Drawing.Size(84, 38);
			this.panel_CashierTaxID.TabIndex = 18;
			this.textBox_CashierTaxID.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox_CashierTaxID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_CashierTaxID.Location = new System.Drawing.Point(1, 14);
			this.textBox_CashierTaxID.MaxLength = 12;
			this.textBox_CashierTaxID.Name = "textBox_CashierTaxID";
			this.textBox_CashierTaxID.Size = new System.Drawing.Size(82, 20);
			this.textBox_CashierTaxID.TabIndex = 2;
			this.label_CashierTaxID.Dock = System.Windows.Forms.DockStyle.Top;
			this.label_CashierTaxID.Font = new System.Drawing.Font("Microsoft Sans Serif", 7f, System.Drawing.FontStyle.Italic);
			this.label_CashierTaxID.ForeColor = System.Drawing.Color.Blue;
			this.label_CashierTaxID.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_CashierTaxID.Location = new System.Drawing.Point(1, 1);
			this.label_CashierTaxID.Margin = new System.Windows.Forms.Padding(3);
			this.label_CashierTaxID.Name = "label_CashierTaxID";
			this.label_CashierTaxID.Size = new System.Drawing.Size(82, 13);
			this.label_CashierTaxID.TabIndex = 0;
			this.label_CashierTaxID.Text = "ИНН";
			this.panel_SetCashier.Controls.Add(this.button_SetCashier);
			this.panel_SetCashier.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel_SetCashier.Location = new System.Drawing.Point(75, 0);
			this.panel_SetCashier.Name = "panel_SetCashier";
			this.panel_SetCashier.Padding = new System.Windows.Forms.Padding(0, 3, 3, 3);
			this.panel_SetCashier.Size = new System.Drawing.Size(73, 38);
			this.panel_SetCashier.TabIndex = 16;
			this.button_SetCashier.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.button_SetCashier.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.button_SetCashier.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_SetCashier.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_SetCashier.Location = new System.Drawing.Point(0, 13);
			this.button_SetCashier.Name = "button_SetCashier";
			this.button_SetCashier.Size = new System.Drawing.Size(70, 22);
			this.button_SetCashier.TabIndex = 5;
			this.button_SetCashier.Text = "Задать";
			this.button_SetCashier.UseVisualStyleBackColor = true;
			this.button_SetCashier.Click += new System.EventHandler(Button_SetCashier_Click);
			this.panel_GetCashier.Controls.Add(this.button_GetCashier);
			this.panel_GetCashier.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel_GetCashier.Location = new System.Drawing.Point(0, 0);
			this.panel_GetCashier.Name = "panel_GetCashier";
			this.panel_GetCashier.Padding = new System.Windows.Forms.Padding(3, 3, 2, 3);
			this.panel_GetCashier.Size = new System.Drawing.Size(75, 38);
			this.panel_GetCashier.TabIndex = 16;
			this.button_GetCashier.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.button_GetCashier.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.button_GetCashier.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_GetCashier.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_GetCashier.Location = new System.Drawing.Point(3, 13);
			this.button_GetCashier.Name = "button_GetCashier";
			this.button_GetCashier.Size = new System.Drawing.Size(70, 22);
			this.button_GetCashier.TabIndex = 5;
			this.button_GetCashier.Text = "Проверить";
			this.button_GetCashier.UseVisualStyleBackColor = true;
			this.button_GetCashier.Click += new System.EventHandler(Button_GetCashier_Click);
			this.panel_DateTimeFrame.Controls.Add(this.groupBox_DateTime);
			this.panel_DateTimeFrame.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_DateTimeFrame.Location = new System.Drawing.Point(3, 111);
			this.panel_DateTimeFrame.Name = "panel_DateTimeFrame";
			this.panel_DateTimeFrame.Size = new System.Drawing.Size(618, 65);
			this.panel_DateTimeFrame.TabIndex = 18;
			this.groupBox_DateTime.BackColor = System.Drawing.Color.Transparent;
			this.groupBox_DateTime.Controls.Add(this.panel_DateTimeFW);
			this.groupBox_DateTime.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox_DateTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_DateTime.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_DateTime.Location = new System.Drawing.Point(0, 0);
			this.groupBox_DateTime.Name = "groupBox_DateTime";
			this.groupBox_DateTime.Size = new System.Drawing.Size(618, 55);
			this.groupBox_DateTime.TabIndex = 12;
			this.groupBox_DateTime.TabStop = false;
			this.groupBox_DateTime.Text = "Д а т а  -  В р е м я  -  В е р с и я";
			this.panel_DateTimeFW.BackColor = System.Drawing.Color.LightCyan;
			this.panel_DateTimeFW.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_DateTimeFW.Controls.Add(this.dateTimePicker_Current);
			this.panel_DateTimeFW.Controls.Add(this.panel_KKTSerial);
			this.panel_DateTimeFW.Controls.Add(this.label_VerKKT);
			this.panel_DateTimeFW.Controls.Add(this.button_VerKKT);
			this.panel_DateTimeFW.Controls.Add(this.button_GetDateTime);
			this.panel_DateTimeFW.Controls.Add(this.button_SetDateTime);
			this.panel_DateTimeFW.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel_DateTimeFW.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.panel_DateTimeFW.Location = new System.Drawing.Point(3, 17);
			this.panel_DateTimeFW.Name = "panel_DateTimeFW";
			this.panel_DateTimeFW.Size = new System.Drawing.Size(612, 35);
			this.panel_DateTimeFW.TabIndex = 0;
			this.dateTimePicker_Current.CustomFormat = "dd.MM.yyyy HH:mm:ss";
			this.dateTimePicker_Current.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dateTimePicker_Current.Location = new System.Drawing.Point(147, 7);
			this.dateTimePicker_Current.MinDate = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
			this.dateTimePicker_Current.Name = "dateTimePicker_Current";
			this.dateTimePicker_Current.ShowCheckBox = true;
			this.dateTimePicker_Current.Size = new System.Drawing.Size(159, 20);
			this.dateTimePicker_Current.TabIndex = 14;
			this.toolTip1.SetToolTip(this.dateTimePicker_Current, "Флажок: установить текущие дату и время ПК.\r\nСнимите флажок, чтобы установить заданные дату и время.");
			this.dateTimePicker_Current.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
			this.panel_KKTSerial.Controls.Add(this.numeric_KKTSerial);
			this.panel_KKTSerial.Controls.Add(this.label_SerialNo);
			this.panel_KKTSerial.Controls.Add(this.button_KKTSerialSet);
			this.panel_KKTSerial.Location = new System.Drawing.Point(418, 1);
			this.panel_KKTSerial.Name = "panel_KKTSerial";
			this.panel_KKTSerial.Padding = new System.Windows.Forms.Padding(2);
			this.panel_KKTSerial.Size = new System.Drawing.Size(191, 30);
			this.panel_KKTSerial.TabIndex = 0;
			this.numeric_KKTSerial.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.numeric_KKTSerial.ForeColor = System.Drawing.Color.Blue;
			this.numeric_KKTSerial.Location = new System.Drawing.Point(37, 6);
			this.numeric_KKTSerial.Maximum = new decimal(new int[4] { 1999999999, 0, 0, 0 });
			this.numeric_KKTSerial.Name = "numeric_KKTSerial";
			this.numeric_KKTSerial.ReadOnly = true;
			this.numeric_KKTSerial.Size = new System.Drawing.Size(90, 20);
			this.numeric_KKTSerial.TabIndex = 14;
			this.numeric_KKTSerial.Value = new decimal(new int[4] { 1234567890, 0, 0, 0 });
			this.label_SerialNo.AutoSize = true;
			this.label_SerialNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_SerialNo.ForeColor = System.Drawing.Color.Blue;
			this.label_SerialNo.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_SerialNo.Location = new System.Drawing.Point(2, 7);
			this.label_SerialNo.Margin = new System.Windows.Forms.Padding(3);
			this.label_SerialNo.Name = "label_SerialNo";
			this.label_SerialNo.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label_SerialNo.Size = new System.Drawing.Size(37, 13);
			this.label_SerialNo.TabIndex = 15;
			this.label_SerialNo.Text = "06500";
			this.label_SerialNo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.button_KKTSerialSet.Enabled = false;
			this.button_KKTSerialSet.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.button_KKTSerialSet.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_KKTSerialSet.Location = new System.Drawing.Point(128, 2);
			this.button_KKTSerialSet.Name = "button_KKTSerialSet";
			this.button_KKTSerialSet.Size = new System.Drawing.Size(60, 27);
			this.button_KKTSerialSet.TabIndex = 13;
			this.button_KKTSerialSet.Text = "Сер.№";
			this.button_KKTSerialSet.UseVisualStyleBackColor = true;
			this.button_KKTSerialSet.Visible = false;
			this.button_KKTSerialSet.Click += new System.EventHandler(Button_KKTSerialSet_Click);
			this.label_VerKKT.BackColor = System.Drawing.Color.Cyan;
			this.label_VerKKT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.label_VerKKT.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.label_VerKKT.ForeColor = System.Drawing.Color.Blue;
			this.label_VerKKT.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_VerKKT.Location = new System.Drawing.Point(362, 6);
			this.label_VerKKT.Margin = new System.Windows.Forms.Padding(3);
			this.label_VerKKT.Name = "label_VerKKT";
			this.label_VerKKT.Size = new System.Drawing.Size(54, 20);
			this.label_VerKKT.TabIndex = 11;
			this.label_VerKKT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.button_VerKKT.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.button_VerKKT.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_VerKKT.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_VerKKT.Location = new System.Drawing.Point(308, 3);
			this.button_VerKKT.Name = "button_VerKKT";
			this.button_VerKKT.Size = new System.Drawing.Size(52, 27);
			this.button_VerKKT.TabIndex = 0;
			this.button_VerKKT.Text = "Версия";
			this.button_VerKKT.UseVisualStyleBackColor = true;
			this.button_VerKKT.Click += new System.EventHandler(Button_VerKKT_Click);
			this.button_GetDateTime.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_GetDateTime.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_GetDateTime.Location = new System.Drawing.Point(3, 3);
			this.button_GetDateTime.Name = "button_GetDateTime";
			this.button_GetDateTime.Size = new System.Drawing.Size(70, 27);
			this.button_GetDateTime.TabIndex = 10;
			this.button_GetDateTime.Text = "Состояние";
			this.button_GetDateTime.UseVisualStyleBackColor = true;
			this.button_GetDateTime.Click += new System.EventHandler(Button_GetDateTime_Click);
			this.button_SetDateTime.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_SetDateTime.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_SetDateTime.Location = new System.Drawing.Point(75, 3);
			this.button_SetDateTime.Name = "button_SetDateTime";
			this.button_SetDateTime.Size = new System.Drawing.Size(70, 27);
			this.button_SetDateTime.TabIndex = 9;
			this.button_SetDateTime.Text = "Задать";
			this.button_SetDateTime.UseVisualStyleBackColor = true;
			this.button_SetDateTime.Click += new System.EventHandler(Button_SetDateTime_Click);
			this.panel_Connection.Controls.Add(this.groupBox_Connection);
			this.panel_Connection.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Connection.Location = new System.Drawing.Point(3, 3);
			this.panel_Connection.Name = "panel_Connection";
			this.panel_Connection.Padding = new System.Windows.Forms.Padding(1);
			this.panel_Connection.Size = new System.Drawing.Size(618, 108);
			this.panel_Connection.TabIndex = 17;
			this.groupBox_Connection.BackColor = System.Drawing.Color.Transparent;
			this.groupBox_Connection.Controls.Add(this.panel_RadioCOM);
			this.groupBox_Connection.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox_Connection.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_Connection.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_Connection.Location = new System.Drawing.Point(1, 1);
			this.groupBox_Connection.Name = "groupBox_Connection";
			this.groupBox_Connection.Size = new System.Drawing.Size(616, 100);
			this.groupBox_Connection.TabIndex = 7;
			this.groupBox_Connection.TabStop = false;
			this.groupBox_Connection.Text = "П о д к л ю ч е н и е   К К Т";
			this.panel_RadioCOM.BackColor = System.Drawing.Color.LightCyan;
			this.panel_RadioCOM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_RadioCOM.Controls.Add(this.comboBox_Language);
			this.panel_RadioCOM.Controls.Add(this.panel_COMRefresh);
			this.panel_RadioCOM.Controls.Add(this.panel_LAN);
			this.panel_RadioCOM.Controls.Add(this.panel_Service);
			this.panel_RadioCOM.Controls.Add(this.panel_RadioButtons);
			this.panel_RadioCOM.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel_RadioCOM.Location = new System.Drawing.Point(3, 17);
			this.panel_RadioCOM.Name = "panel_RadioCOM";
			this.panel_RadioCOM.Padding = new System.Windows.Forms.Padding(3);
			this.panel_RadioCOM.Size = new System.Drawing.Size(610, 80);
			this.panel_RadioCOM.TabIndex = 7;
			this.comboBox_Language.BackColor = System.Drawing.SystemColors.Window;
			this.comboBox_Language.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.comboBox_Language.ForeColor = System.Drawing.SystemColors.ControlText;
			this.comboBox_Language.Items.AddRange(new object[2] { "EN", "RU" });
			this.comboBox_Language.Location = new System.Drawing.Point(371, 29);
			this.comboBox_Language.Name = "comboBox_Language";
			this.comboBox_Language.Size = new System.Drawing.Size(40, 21);
			this.comboBox_Language.TabIndex = 15;
			this.comboBox_Language.Tag = "0";
			this.comboBox_Language.Text = "RU";
			this.comboBox_Language.Visible = false;
			this.comboBox_Language.SelectedIndexChanged += new System.EventHandler(comboBox_Language_SelectedIndexChanged);
			this.panel_COMRefresh.Controls.Add(this.button_RunTest);
			this.panel_COMRefresh.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel_COMRefresh.Location = new System.Drawing.Point(445, 27);
			this.panel_COMRefresh.Name = "panel_COMRefresh";
			this.panel_COMRefresh.Size = new System.Drawing.Size(160, 48);
			this.panel_COMRefresh.TabIndex = 5;
			this.button_RunTest.BackColor = System.Drawing.SystemColors.ControlLight;
			this.button_RunTest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button_RunTest.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.button_RunTest.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_RunTest.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_RunTest.Location = new System.Drawing.Point(44, 3);
			this.button_RunTest.Name = "button_RunTest";
			this.button_RunTest.Size = new System.Drawing.Size(116, 42);
			this.button_RunTest.TabIndex = 12;
			this.button_RunTest.Text = "ТЕСТ\r\nCOM+USB+LAN";
			this.toolTip1.SetToolTip(this.button_RunTest, "Проверка интерфейсов ККТ.\r\nНеобходимо подключение всех 3-х портов: COM, USB и LAN");
			this.button_RunTest.UseVisualStyleBackColor = false;
			this.button_RunTest.Visible = false;
			this.button_RunTest.Click += new System.EventHandler(Button_RunTest_Click);
			this.panel_LAN.Controls.Add(this.textBox_PortNo);
			this.panel_LAN.Controls.Add(this.label_Port);
			this.panel_LAN.Controls.Add(this.textBox_KKT_IP);
			this.panel_LAN.Controls.Add(this.label_IPAddress);
			this.panel_LAN.Controls.Add(this.Lan_Button);
			this.panel_LAN.Location = new System.Drawing.Point(3, 30);
			this.panel_LAN.Name = "panel_LAN";
			this.panel_LAN.Size = new System.Drawing.Size(362, 21);
			this.panel_LAN.TabIndex = 13;
			this.textBox_PortNo.Dock = System.Windows.Forms.DockStyle.Left;
			this.textBox_PortNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_PortNo.Location = new System.Drawing.Point(252, 0);
			this.textBox_PortNo.MaxLength = 5;
			this.textBox_PortNo.Name = "textBox_PortNo";
			this.textBox_PortNo.Size = new System.Drawing.Size(40, 20);
			this.textBox_PortNo.TabIndex = 6;
			this.textBox_PortNo.Text = "8200";
			this.textBox_PortNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.label_Port.Dock = System.Windows.Forms.DockStyle.Left;
			this.label_Port.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_Port.ForeColor = System.Drawing.SystemColors.ControlText;
			this.label_Port.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Port.Location = new System.Drawing.Point(217, 0);
			this.label_Port.Margin = new System.Windows.Forms.Padding(3);
			this.label_Port.Name = "label_Port";
			this.label_Port.Size = new System.Drawing.Size(35, 21);
			this.label_Port.TabIndex = 4;
			this.label_Port.Text = "Порт:";
			this.label_Port.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.textBox_KKT_IP.Dock = System.Windows.Forms.DockStyle.Left;
			this.textBox_KKT_IP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_KKT_IP.Location = new System.Drawing.Point(123, 0);
			this.textBox_KKT_IP.MaxLength = 15;
			this.textBox_KKT_IP.Name = "textBox_KKT_IP";
			this.textBox_KKT_IP.Size = new System.Drawing.Size(94, 20);
			this.textBox_KKT_IP.TabIndex = 3;
			this.textBox_KKT_IP.Text = "192.168.1.100";
			this.label_IPAddress.Dock = System.Windows.Forms.DockStyle.Left;
			this.label_IPAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_IPAddress.ForeColor = System.Drawing.SystemColors.ControlText;
			this.label_IPAddress.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_IPAddress.Location = new System.Drawing.Point(61, 0);
			this.label_IPAddress.Margin = new System.Windows.Forms.Padding(3);
			this.label_IPAddress.Name = "label_IPAddress";
			this.label_IPAddress.Size = new System.Drawing.Size(62, 21);
			this.label_IPAddress.TabIndex = 0;
			this.label_IPAddress.Text = "IP адрес:";
			this.label_IPAddress.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.Lan_Button.Dock = System.Windows.Forms.DockStyle.Left;
			this.Lan_Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.Lan_Button.ForeColor = System.Drawing.SystemColors.ControlText;
			this.Lan_Button.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.Lan_Button.Location = new System.Drawing.Point(0, 0);
			this.Lan_Button.Name = "Lan_Button";
			this.Lan_Button.Size = new System.Drawing.Size(61, 21);
			this.Lan_Button.TabIndex = 1;
			this.Lan_Button.Text = "LAN";
			this.Lan_Button.UseVisualStyleBackColor = true;
			this.Lan_Button.CheckedChanged += new System.EventHandler(Lan_Button_CheckedChanged);
			this.panel_Service.Controls.Add(this.numericUpDown_Service_ID);
			this.panel_Service.Controls.Add(this.label_Service_ID);
			this.panel_Service.Controls.Add(this.textBox_Service_Port);
			this.panel_Service.Controls.Add(this.label_Service_Port);
			this.panel_Service.Controls.Add(this.textBox_Service_IP);
			this.panel_Service.Controls.Add(this.label_Service_IP);
			this.panel_Service.Controls.Add(this.Ser_Button);
			this.panel_Service.Location = new System.Drawing.Point(3, 54);
			this.panel_Service.Name = "panel_Service";
			this.panel_Service.Size = new System.Drawing.Size(362, 21);
			this.panel_Service.TabIndex = 6;
			this.panel_Service.Visible = false;
			this.numericUpDown_Service_ID.Dock = System.Windows.Forms.DockStyle.Left;
			this.numericUpDown_Service_ID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.numericUpDown_Service_ID.Location = new System.Drawing.Point(313, 0);
			this.numericUpDown_Service_ID.Maximum = new decimal(new int[4] { 99, 0, 0, 0 });
			this.numericUpDown_Service_ID.Name = "numericUpDown_Service_ID";
			this.numericUpDown_Service_ID.Size = new System.Drawing.Size(40, 20);
			this.numericUpDown_Service_ID.TabIndex = 14;
			this.numericUpDown_Service_ID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.numericUpDown_Service_ID.ValueChanged += new System.EventHandler(Ser_Button_CheckedChanged);
			this.label_Service_ID.Dock = System.Windows.Forms.DockStyle.Left;
			this.label_Service_ID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_Service_ID.ForeColor = System.Drawing.SystemColors.ControlText;
			this.label_Service_ID.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Service_ID.Location = new System.Drawing.Point(292, 0);
			this.label_Service_ID.Margin = new System.Windows.Forms.Padding(3);
			this.label_Service_ID.Name = "label_Service_ID";
			this.label_Service_ID.Size = new System.Drawing.Size(21, 21);
			this.label_Service_ID.TabIndex = 12;
			this.label_Service_ID.Text = "ID:";
			this.label_Service_ID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.textBox_Service_Port.Dock = System.Windows.Forms.DockStyle.Left;
			this.textBox_Service_Port.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_Service_Port.Location = new System.Drawing.Point(252, 0);
			this.textBox_Service_Port.MaxLength = 5;
			this.textBox_Service_Port.Name = "textBox_Service_Port";
			this.textBox_Service_Port.Size = new System.Drawing.Size(40, 20);
			this.textBox_Service_Port.TabIndex = 11;
			this.textBox_Service_Port.Text = "8800";
			this.textBox_Service_Port.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.label_Service_Port.Dock = System.Windows.Forms.DockStyle.Left;
			this.label_Service_Port.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_Service_Port.ForeColor = System.Drawing.SystemColors.ControlText;
			this.label_Service_Port.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Service_Port.Location = new System.Drawing.Point(217, 0);
			this.label_Service_Port.Margin = new System.Windows.Forms.Padding(3);
			this.label_Service_Port.Name = "label_Service_Port";
			this.label_Service_Port.Size = new System.Drawing.Size(35, 21);
			this.label_Service_Port.TabIndex = 10;
			this.label_Service_Port.Text = "Порт:";
			this.label_Service_Port.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.textBox_Service_IP.Dock = System.Windows.Forms.DockStyle.Left;
			this.textBox_Service_IP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_Service_IP.Location = new System.Drawing.Point(123, 0);
			this.textBox_Service_IP.MaxLength = 15;
			this.textBox_Service_IP.Name = "textBox_Service_IP";
			this.textBox_Service_IP.Size = new System.Drawing.Size(94, 20);
			this.textBox_Service_IP.TabIndex = 9;
			this.textBox_Service_IP.Text = "127.0.0.1";
			this.label_Service_IP.Dock = System.Windows.Forms.DockStyle.Left;
			this.label_Service_IP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_Service_IP.ForeColor = System.Drawing.SystemColors.ControlText;
			this.label_Service_IP.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Service_IP.Location = new System.Drawing.Point(61, 0);
			this.label_Service_IP.Margin = new System.Windows.Forms.Padding(3);
			this.label_Service_IP.Name = "label_Service_IP";
			this.label_Service_IP.Size = new System.Drawing.Size(62, 21);
			this.label_Service_IP.TabIndex = 8;
			this.label_Service_IP.Text = "IP адрес:";
			this.label_Service_IP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.Ser_Button.Dock = System.Windows.Forms.DockStyle.Left;
			this.Ser_Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.Ser_Button.ForeColor = System.Drawing.SystemColors.ControlText;
			this.Ser_Button.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.Ser_Button.Location = new System.Drawing.Point(0, 0);
			this.Ser_Button.Name = "Ser_Button";
			this.Ser_Button.Size = new System.Drawing.Size(61, 21);
			this.Ser_Button.TabIndex = 7;
			this.Ser_Button.Text = "Service";
			this.Ser_Button.UseVisualStyleBackColor = true;
			this.Ser_Button.CheckedChanged += new System.EventHandler(Ser_Button_CheckedChanged);
			this.panel_RadioButtons.Controls.Add(this.panel_Baudrate);
			this.panel_RadioButtons.Controls.Add(this.button_COMScan);
			this.panel_RadioButtons.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_RadioButtons.Location = new System.Drawing.Point(3, 3);
			this.panel_RadioButtons.Name = "panel_RadioButtons";
			this.panel_RadioButtons.Size = new System.Drawing.Size(602, 24);
			this.panel_RadioButtons.TabIndex = 15;
			this.panel_Baudrate.Controls.Add(this.comboBox_COMBaudRate);
			this.panel_Baudrate.Controls.Add(this.label_COMBaudRate);
			this.panel_Baudrate.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel_Baudrate.Location = new System.Drawing.Point(451, 0);
			this.panel_Baudrate.Name = "panel_Baudrate";
			this.panel_Baudrate.Size = new System.Drawing.Size(111, 24);
			this.panel_Baudrate.TabIndex = 14;
			this.comboBox_COMBaudRate.Dock = System.Windows.Forms.DockStyle.Left;
			this.comboBox_COMBaudRate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.comboBox_COMBaudRate.FormattingEnabled = true;
			this.comboBox_COMBaudRate.Items.AddRange(new object[10] { "9600", "14400", "19200", "38400", "57600", "115200", "230400", "460800", "921600", "1382400" });
			this.comboBox_COMBaudRate.Location = new System.Drawing.Point(35, 0);
			this.comboBox_COMBaudRate.Name = "comboBox_COMBaudRate";
			this.comboBox_COMBaudRate.Size = new System.Drawing.Size(64, 21);
			this.comboBox_COMBaudRate.TabIndex = 3;
			this.comboBox_COMBaudRate.Text = "115200";
			this.comboBox_COMBaudRate.Visible = false;
			this.label_COMBaudRate.Dock = System.Windows.Forms.DockStyle.Left;
			this.label_COMBaudRate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_COMBaudRate.ForeColor = System.Drawing.SystemColors.ControlText;
			this.label_COMBaudRate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_COMBaudRate.Location = new System.Drawing.Point(0, 0);
			this.label_COMBaudRate.Margin = new System.Windows.Forms.Padding(3);
			this.label_COMBaudRate.Name = "label_COMBaudRate";
			this.label_COMBaudRate.Size = new System.Drawing.Size(35, 24);
			this.label_COMBaudRate.TabIndex = 0;
			this.label_COMBaudRate.Text = "Baud:";
			this.label_COMBaudRate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.label_COMBaudRate.Visible = false;
			this.button_COMScan.BackColor = System.Drawing.SystemColors.ControlLight;
			this.button_COMScan.Dock = System.Windows.Forms.DockStyle.Right;
			this.button_COMScan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button_COMScan.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.button_COMScan.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_COMScan.Image = (System.Drawing.Image)resources.GetObject("button_COMScan.Image");
			this.button_COMScan.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_COMScan.Location = new System.Drawing.Point(562, 0);
			this.button_COMScan.Name = "button_COMScan";
			this.button_COMScan.Size = new System.Drawing.Size(40, 24);
			this.button_COMScan.TabIndex = 15;
			this.toolTip1.SetToolTip(this.button_COMScan, "Поиск COM");
			this.button_COMScan.UseVisualStyleBackColor = false;
			this.button_COMScan.Click += new System.EventHandler(Initialize_COM_buttons);
			this.tabPage_Status.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.tabPage_Status.Controls.Add(this.groupBox_Status_OFD);
			this.tabPage_Status.Controls.Add(this.groupBox_Status_FN);
			this.tabPage_Status.Location = new System.Drawing.Point(154, 4);
			this.tabPage_Status.Name = "tabPage_Status";
			this.tabPage_Status.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage_Status.Size = new System.Drawing.Size(626, 424);
			this.tabPage_Status.TabIndex = 11;
			this.tabPage_Status.Text = "Статус";
			this.tabPage_Status.UseVisualStyleBackColor = true;
			this.groupBox_Status_OFD.BackColor = System.Drawing.Color.Transparent;
			this.groupBox_Status_OFD.Controls.Add(this.panel_Status_OFD);
			this.groupBox_Status_OFD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_Status_OFD.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_Status_OFD.Location = new System.Drawing.Point(315, 3);
			this.groupBox_Status_OFD.Name = "groupBox_Status_OFD";
			this.groupBox_Status_OFD.Size = new System.Drawing.Size(307, 421);
			this.groupBox_Status_OFD.TabIndex = 15;
			this.groupBox_Status_OFD.TabStop = false;
			this.groupBox_Status_OFD.Text = "О Ф Д  /  М а р к и р о в к а";
			this.panel_Status_OFD.BackColor = System.Drawing.Color.Transparent;
			this.panel_Status_OFD.Controls.Add(this.panel_Status_OFD3);
			this.panel_Status_OFD.Controls.Add(this.panel_DataMark);
			this.panel_Status_OFD.Controls.Add(this.panel_Status_OFD2);
			this.panel_Status_OFD.Controls.Add(this.panel_Status_OFD1);
			this.panel_Status_OFD.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel_Status_OFD.Location = new System.Drawing.Point(3, 17);
			this.panel_Status_OFD.Name = "panel_Status_OFD";
			this.panel_Status_OFD.Size = new System.Drawing.Size(301, 401);
			this.panel_Status_OFD.TabIndex = 15;
			this.panel_Status_OFD3.Controls.Add(this.dataGrid_Status_DM3);
			this.panel_Status_OFD3.Controls.Add(this.label_Status_DM3);
			this.panel_Status_OFD3.Controls.Add(this.label_Status_DM);
			this.panel_Status_OFD3.Controls.Add(this.dataGrid_Status_DM1);
			this.panel_Status_OFD3.Controls.Add(this.label_Status_DM2);
			this.panel_Status_OFD3.Controls.Add(this.dataGrid_Status_DM2);
			this.panel_Status_OFD3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel_Status_OFD3.Location = new System.Drawing.Point(0, 107);
			this.panel_Status_OFD3.Name = "panel_Status_OFD3";
			this.panel_Status_OFD3.Size = new System.Drawing.Size(301, 294);
			this.panel_Status_OFD3.TabIndex = 5;
			this.dataGrid_Status_DM3.AllowUserToAddRows = false;
			this.dataGrid_Status_DM3.AllowUserToDeleteRows = false;
			this.dataGrid_Status_DM3.AllowUserToResizeRows = false;
			dataGridViewCellStyle.BackColor = System.Drawing.Color.LightCyan;
			dataGridViewCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 204);
			this.dataGrid_Status_DM3.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle;
			this.dataGrid_Status_DM3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dataGrid_Status_DM3.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
			this.dataGrid_Status_DM3.ColumnHeadersHeight = 15;
			this.dataGrid_Status_DM3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this.dataGrid_Status_DM3.ColumnHeadersVisible = false;
			this.dataGrid_Status_DM3.Columns.AddRange(this.dataGridViewTextBoxColumn11);
			this.dataGrid_Status_DM3.Enabled = false;
			this.dataGrid_Status_DM3.GridColor = System.Drawing.SystemColors.WindowFrame;
			this.dataGrid_Status_DM3.Location = new System.Drawing.Point(152, 199);
			this.dataGrid_Status_DM3.MultiSelect = false;
			this.dataGrid_Status_DM3.Name = "dataGrid_Status_DM3";
			this.dataGrid_Status_DM3.RowHeadersVisible = false;
			this.dataGrid_Status_DM3.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 204);
			this.dataGrid_Status_DM3.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGrid_Status_DM3.RowTemplate.Height = 15;
			this.dataGrid_Status_DM3.RowTemplate.ReadOnly = true;
			this.dataGrid_Status_DM3.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.dataGrid_Status_DM3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
			this.dataGrid_Status_DM3.ShowCellToolTips = false;
			this.dataGrid_Status_DM3.ShowEditingIcon = false;
			this.dataGrid_Status_DM3.Size = new System.Drawing.Size(149, 63);
			this.dataGrid_Status_DM3.TabIndex = 4;
			this.dataGridViewTextBoxColumn11.HeaderText = "";
			this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
			this.dataGridViewTextBoxColumn11.Resizable = System.Windows.Forms.DataGridViewTriState.False;
			this.dataGridViewTextBoxColumn11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			this.label_Status_DM3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f);
			this.label_Status_DM3.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Status_DM3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Status_DM3.Location = new System.Drawing.Point(1, 199);
			this.label_Status_DM3.Margin = new System.Windows.Forms.Padding(3);
			this.label_Status_DM3.Name = "label_Status_DM3";
			this.label_Status_DM3.Size = new System.Drawing.Size(150, 63);
			this.label_Status_DM3.TabIndex = 3;
			this.label_Status_DM3.Text = "Агент обмена с ОФД\r\nСтатус ключей проверки\r\nПоддержка обновл. (D7)\r\nАдрес и порт ОКП";
			this.label_Status_DM3.TextAlign = System.Drawing.ContentAlignment.TopRight;
			this.label_Status_DM.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f);
			this.label_Status_DM.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Status_DM.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Status_DM.Location = new System.Drawing.Point(1, 1);
			this.label_Status_DM.Margin = new System.Windows.Forms.Padding(3);
			this.label_Status_DM.Name = "label_Status_DM";
			this.label_Status_DM.Size = new System.Drawing.Size(150, 108);
			this.label_Status_DM.TabIndex = 1;
			this.label_Status_DM.Text = "КМ: статус проверки\r\nСохранено результатов\r\nФлаги разрешения КМ\r\nФормирование уведом.\r\nК-во КМ в уведомлении\r\nОчередь уведомлений\r\n% заполнения буфера";
			this.label_Status_DM.TextAlign = System.Drawing.ContentAlignment.TopRight;
			this.dataGrid_Status_DM1.AllowUserToAddRows = false;
			this.dataGrid_Status_DM1.AllowUserToDeleteRows = false;
			this.dataGrid_Status_DM1.AllowUserToResizeRows = false;
			dataGridViewCellStyle2.BackColor = System.Drawing.Color.LightCyan;
			dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 204);
			this.dataGrid_Status_DM1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
			this.dataGrid_Status_DM1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dataGrid_Status_DM1.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
			this.dataGrid_Status_DM1.ColumnHeadersHeight = 15;
			this.dataGrid_Status_DM1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this.dataGrid_Status_DM1.ColumnHeadersVisible = false;
			this.dataGrid_Status_DM1.Columns.AddRange(this.dataGridViewTextBoxColumn4);
			this.dataGrid_Status_DM1.Enabled = false;
			this.dataGrid_Status_DM1.GridColor = System.Drawing.SystemColors.WindowFrame;
			this.dataGrid_Status_DM1.Location = new System.Drawing.Point(152, 1);
			this.dataGrid_Status_DM1.MultiSelect = false;
			this.dataGrid_Status_DM1.Name = "dataGrid_Status_DM1";
			this.dataGrid_Status_DM1.RowHeadersVisible = false;
			this.dataGrid_Status_DM1.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 204);
			this.dataGrid_Status_DM1.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGrid_Status_DM1.RowTemplate.Height = 15;
			this.dataGrid_Status_DM1.RowTemplate.ReadOnly = true;
			this.dataGrid_Status_DM1.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.dataGrid_Status_DM1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
			this.dataGrid_Status_DM1.ShowCellToolTips = false;
			this.dataGrid_Status_DM1.ShowEditingIcon = false;
			this.dataGrid_Status_DM1.Size = new System.Drawing.Size(149, 108);
			this.dataGrid_Status_DM1.TabIndex = 2;
			this.dataGridViewTextBoxColumn4.HeaderText = "";
			this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
			this.dataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.False;
			this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			this.label_Status_DM2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f);
			this.label_Status_DM2.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Status_DM2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Status_DM2.Location = new System.Drawing.Point(1, 115);
			this.label_Status_DM2.Margin = new System.Windows.Forms.Padding(3);
			this.label_Status_DM2.Name = "label_Status_DM2";
			this.label_Status_DM2.Size = new System.Drawing.Size(150, 78);
			this.label_Status_DM2.TabIndex = 1;
			this.label_Status_DM2.Text = "Статус передачи\r\nОчередь уведомлений\r\nТекущий № уведомления\r\nДата-время\r\n% заполнения памяти";
			this.label_Status_DM2.TextAlign = System.Drawing.ContentAlignment.TopRight;
			this.dataGrid_Status_DM2.AllowUserToAddRows = false;
			this.dataGrid_Status_DM2.AllowUserToDeleteRows = false;
			this.dataGrid_Status_DM2.AllowUserToResizeRows = false;
			dataGridViewCellStyle3.BackColor = System.Drawing.Color.LightCyan;
			dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 204);
			this.dataGrid_Status_DM2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
			this.dataGrid_Status_DM2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dataGrid_Status_DM2.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
			this.dataGrid_Status_DM2.ColumnHeadersHeight = 15;
			this.dataGrid_Status_DM2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this.dataGrid_Status_DM2.ColumnHeadersVisible = false;
			this.dataGrid_Status_DM2.Columns.AddRange(this.dataGridViewTextBoxColumn6);
			this.dataGrid_Status_DM2.Enabled = false;
			this.dataGrid_Status_DM2.GridColor = System.Drawing.SystemColors.WindowFrame;
			this.dataGrid_Status_DM2.Location = new System.Drawing.Point(152, 115);
			this.dataGrid_Status_DM2.MultiSelect = false;
			this.dataGrid_Status_DM2.Name = "dataGrid_Status_DM2";
			this.dataGrid_Status_DM2.RowHeadersVisible = false;
			this.dataGrid_Status_DM2.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 204);
			this.dataGrid_Status_DM2.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGrid_Status_DM2.RowTemplate.Height = 15;
			this.dataGrid_Status_DM2.RowTemplate.ReadOnly = true;
			this.dataGrid_Status_DM2.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.dataGrid_Status_DM2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
			this.dataGrid_Status_DM2.ShowCellToolTips = false;
			this.dataGrid_Status_DM2.ShowEditingIcon = false;
			this.dataGrid_Status_DM2.Size = new System.Drawing.Size(149, 78);
			this.dataGrid_Status_DM2.TabIndex = 2;
			this.dataGridViewTextBoxColumn6.HeaderText = "";
			this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
			this.dataGridViewTextBoxColumn6.Resizable = System.Windows.Forms.DataGridViewTriState.False;
			this.dataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			this.panel_DataMark.BackColor = System.Drawing.Color.LightCyan;
			this.panel_DataMark.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_DataMark.Controls.Add(this.button_Status_DM);
			this.panel_DataMark.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_DataMark.Location = new System.Drawing.Point(0, 81);
			this.panel_DataMark.Name = "panel_DataMark";
			this.panel_DataMark.Size = new System.Drawing.Size(301, 26);
			this.panel_DataMark.TabIndex = 3;
			this.button_Status_DM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.button_Status_DM.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_Status_DM.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_Status_DM.Location = new System.Drawing.Point(1, 1);
			this.button_Status_DM.Name = "button_Status_DM";
			this.button_Status_DM.Size = new System.Drawing.Size(149, 23);
			this.button_Status_DM.TabIndex = 0;
			this.button_Status_DM.Text = "Маркировка";
			this.button_Status_DM.UseVisualStyleBackColor = true;
			this.button_Status_DM.Click += new System.EventHandler(button_Status_DM_Click);
			this.panel_Status_OFD2.Controls.Add(this.label_Status_OFD);
			this.panel_Status_OFD2.Controls.Add(this.dataGrid_Status_OFD);
			this.panel_Status_OFD2.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Status_OFD2.Location = new System.Drawing.Point(0, 26);
			this.panel_Status_OFD2.Name = "panel_Status_OFD2";
			this.panel_Status_OFD2.Size = new System.Drawing.Size(301, 55);
			this.panel_Status_OFD2.TabIndex = 4;
			this.label_Status_OFD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f);
			this.label_Status_OFD.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Status_OFD.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Status_OFD.Location = new System.Drawing.Point(1, 1);
			this.label_Status_OFD.Margin = new System.Windows.Forms.Padding(3);
			this.label_Status_OFD.Name = "label_Status_OFD";
			this.label_Status_OFD.Size = new System.Drawing.Size(150, 48);
			this.label_Status_OFD.TabIndex = 1;
			this.label_Status_OFD.Text = "Непереданных док-тов\r\nНомер первого док-та\r\nДата первого док-та";
			this.label_Status_OFD.TextAlign = System.Drawing.ContentAlignment.TopRight;
			this.dataGrid_Status_OFD.AllowUserToAddRows = false;
			this.dataGrid_Status_OFD.AllowUserToDeleteRows = false;
			this.dataGrid_Status_OFD.AllowUserToResizeRows = false;
			dataGridViewCellStyle4.BackColor = System.Drawing.Color.LightCyan;
			dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 204);
			this.dataGrid_Status_OFD.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
			this.dataGrid_Status_OFD.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dataGrid_Status_OFD.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
			this.dataGrid_Status_OFD.ColumnHeadersHeight = 15;
			this.dataGrid_Status_OFD.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this.dataGrid_Status_OFD.ColumnHeadersVisible = false;
			this.dataGrid_Status_OFD.Columns.AddRange(this.dataGridViewTextBoxColumn8);
			this.dataGrid_Status_OFD.Enabled = false;
			this.dataGrid_Status_OFD.GridColor = System.Drawing.SystemColors.WindowFrame;
			this.dataGrid_Status_OFD.Location = new System.Drawing.Point(152, 1);
			this.dataGrid_Status_OFD.MultiSelect = false;
			this.dataGrid_Status_OFD.Name = "dataGrid_Status_OFD";
			this.dataGrid_Status_OFD.RowHeadersVisible = false;
			this.dataGrid_Status_OFD.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 204);
			this.dataGrid_Status_OFD.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGrid_Status_OFD.RowTemplate.Height = 15;
			this.dataGrid_Status_OFD.RowTemplate.ReadOnly = true;
			this.dataGrid_Status_OFD.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.dataGrid_Status_OFD.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
			this.dataGrid_Status_OFD.ShowCellToolTips = false;
			this.dataGrid_Status_OFD.ShowEditingIcon = false;
			this.dataGrid_Status_OFD.Size = new System.Drawing.Size(149, 48);
			this.dataGrid_Status_OFD.TabIndex = 2;
			this.dataGridViewTextBoxColumn8.HeaderText = "";
			this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
			this.dataGridViewTextBoxColumn8.Resizable = System.Windows.Forms.DataGridViewTriState.False;
			this.dataGridViewTextBoxColumn8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			this.panel_Status_OFD1.BackColor = System.Drawing.Color.LightCyan;
			this.panel_Status_OFD1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_Status_OFD1.Controls.Add(this.button_Status_OFD);
			this.panel_Status_OFD1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Status_OFD1.Location = new System.Drawing.Point(0, 0);
			this.panel_Status_OFD1.Name = "panel_Status_OFD1";
			this.panel_Status_OFD1.Size = new System.Drawing.Size(301, 26);
			this.panel_Status_OFD1.TabIndex = 3;
			this.button_Status_OFD.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.button_Status_OFD.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_Status_OFD.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_Status_OFD.Location = new System.Drawing.Point(1, 1);
			this.button_Status_OFD.Name = "button_Status_OFD";
			this.button_Status_OFD.Size = new System.Drawing.Size(149, 23);
			this.button_Status_OFD.TabIndex = 0;
			this.button_Status_OFD.Text = "Статус ОФД";
			this.button_Status_OFD.UseVisualStyleBackColor = true;
			this.button_Status_OFD.Click += new System.EventHandler(button_Status_OFD_Click);
			this.groupBox_Status_FN.BackColor = System.Drawing.Color.Transparent;
			this.groupBox_Status_FN.Controls.Add(this.panel_Status_FN);
			this.groupBox_Status_FN.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_Status_FN.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_Status_FN.Location = new System.Drawing.Point(3, 3);
			this.groupBox_Status_FN.Name = "groupBox_Status_FN";
			this.groupBox_Status_FN.Size = new System.Drawing.Size(307, 421);
			this.groupBox_Status_FN.TabIndex = 15;
			this.groupBox_Status_FN.TabStop = false;
			this.groupBox_Status_FN.Text = "Ф и с к а л ь н ы й   Н а к о п и т е л ь";
			this.panel_Status_FN.BackColor = System.Drawing.Color.Transparent;
			this.panel_Status_FN.Controls.Add(this.panel_Status_FN3);
			this.panel_Status_FN.Controls.Add(this.panel_Totals_FN);
			this.panel_Status_FN.Controls.Add(this.panel_Status_FN2);
			this.panel_Status_FN.Controls.Add(this.panel_Status_FN1);
			this.panel_Status_FN.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel_Status_FN.Location = new System.Drawing.Point(3, 17);
			this.panel_Status_FN.Name = "panel_Status_FN";
			this.panel_Status_FN.Size = new System.Drawing.Size(301, 401);
			this.panel_Status_FN.TabIndex = 15;
			this.panel_Status_FN3.Controls.Add(this.label_Totals_FN);
			this.panel_Status_FN3.Controls.Add(this.textBox_Accum_Total);
			this.panel_Status_FN3.Controls.Add(this.label_Acc_Total);
			this.panel_Status_FN3.Controls.Add(this.dataGrid_Totals_FN);
			this.panel_Status_FN3.Controls.Add(this.label_Tax_FN);
			this.panel_Status_FN3.Controls.Add(this.dataGrid_Tax_FN);
			this.panel_Status_FN3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel_Status_FN3.Location = new System.Drawing.Point(0, 164);
			this.panel_Status_FN3.Name = "panel_Status_FN3";
			this.panel_Status_FN3.Size = new System.Drawing.Size(301, 237);
			this.panel_Status_FN3.TabIndex = 7;
			this.label_Totals_FN.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f);
			this.label_Totals_FN.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Totals_FN.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Totals_FN.Location = new System.Drawing.Point(1, 1);
			this.label_Totals_FN.Margin = new System.Windows.Forms.Padding(3);
			this.label_Totals_FN.Name = "label_Totals_FN";
			this.label_Totals_FN.Size = new System.Drawing.Size(150, 108);
			this.label_Totals_FN.TabIndex = 1;
			this.label_Totals_FN.Text = "Всего чеков\r\nИтог общий\r\nСумма наличными\r\nСумма безналичными\r\nСумма авансом\r\nСумма кредита\r\nСумма иных оплат";
			this.label_Totals_FN.TextAlign = System.Drawing.ContentAlignment.TopRight;
			this.textBox_Accum_Total.BackColor = System.Drawing.SystemColors.InactiveCaption;
			this.textBox_Accum_Total.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.textBox_Accum_Total.ForeColor = System.Drawing.Color.Blue;
			this.textBox_Accum_Total.Location = new System.Drawing.Point(152, 210);
			this.textBox_Accum_Total.MaxLength = 12;
			this.textBox_Accum_Total.Name = "textBox_Accum_Total";
			this.textBox_Accum_Total.ReadOnly = true;
			this.textBox_Accum_Total.Size = new System.Drawing.Size(149, 20);
			this.textBox_Accum_Total.TabIndex = 5;
			this.textBox_Accum_Total.Text = "0,00";
			this.textBox_Accum_Total.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.label_Acc_Total.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f);
			this.label_Acc_Total.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Acc_Total.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Acc_Total.Location = new System.Drawing.Point(1, 210);
			this.label_Acc_Total.Name = "label_Acc_Total";
			this.label_Acc_Total.Size = new System.Drawing.Size(150, 20);
			this.label_Acc_Total.TabIndex = 1;
			this.label_Acc_Total.Text = "Накопленный итог";
			this.label_Acc_Total.TextAlign = System.Drawing.ContentAlignment.TopRight;
			this.dataGrid_Totals_FN.AllowUserToAddRows = false;
			dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle5.BackColor = System.Drawing.Color.LightCyan;
			dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 204);
			this.dataGrid_Totals_FN.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
			this.dataGrid_Totals_FN.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dataGrid_Totals_FN.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
			dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			this.dataGrid_Totals_FN.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
			this.dataGrid_Totals_FN.ColumnHeadersHeight = 15;
			this.dataGrid_Totals_FN.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this.dataGrid_Totals_FN.ColumnHeadersVisible = false;
			this.dataGrid_Totals_FN.Columns.AddRange(this.Column_Sales_FN, this.Column_Refund_FN);
			dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Blue;
			dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.dataGrid_Totals_FN.DefaultCellStyle = dataGridViewCellStyle7;
			this.dataGrid_Totals_FN.Enabled = false;
			this.dataGrid_Totals_FN.GridColor = System.Drawing.SystemColors.WindowFrame;
			this.dataGrid_Totals_FN.Location = new System.Drawing.Point(152, 1);
			this.dataGrid_Totals_FN.MultiSelect = false;
			this.dataGrid_Totals_FN.Name = "dataGrid_Totals_FN";
			dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			this.dataGrid_Totals_FN.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
			this.dataGrid_Totals_FN.RowHeadersVisible = false;
			dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 204);
			this.dataGrid_Totals_FN.RowsDefaultCellStyle = dataGridViewCellStyle9;
			this.dataGrid_Totals_FN.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.dataGrid_Totals_FN.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 204);
			this.dataGrid_Totals_FN.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGrid_Totals_FN.RowTemplate.Height = 15;
			this.dataGrid_Totals_FN.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.dataGrid_Totals_FN.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
			this.dataGrid_Totals_FN.ShowCellToolTips = false;
			this.dataGrid_Totals_FN.ShowEditingIcon = false;
			this.dataGrid_Totals_FN.Size = new System.Drawing.Size(149, 108);
			this.dataGrid_Totals_FN.TabIndex = 4;
			dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.Column_Sales_FN.DefaultCellStyle = dataGridViewCellStyle10;
			this.Column_Sales_FN.HeaderText = "";
			this.Column_Sales_FN.Name = "Column_Sales_FN";
			this.Column_Sales_FN.Resizable = System.Windows.Forms.DataGridViewTriState.False;
			this.Column_Sales_FN.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.Column_Refund_FN.DefaultCellStyle = dataGridViewCellStyle11;
			this.Column_Refund_FN.HeaderText = "";
			this.Column_Refund_FN.Name = "Column_Refund_FN";
			this.label_Tax_FN.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f);
			this.label_Tax_FN.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Tax_FN.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Tax_FN.Location = new System.Drawing.Point(1, 112);
			this.label_Tax_FN.Name = "label_Tax_FN";
			this.label_Tax_FN.Size = new System.Drawing.Size(150, 93);
			this.label_Tax_FN.TabIndex = 1;
			this.label_Tax_FN.Text = "Налог 20%\r\nНалог 10%\r\nНалог 20/120\r\nНалог 10/110\r\nНалог 0%\r\nБез налога";
			this.label_Tax_FN.TextAlign = System.Drawing.ContentAlignment.TopRight;
			this.dataGrid_Tax_FN.AllowUserToAddRows = false;
			this.dataGrid_Tax_FN.AllowUserToDeleteRows = false;
			this.dataGrid_Tax_FN.AllowUserToResizeRows = false;
			dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle12.BackColor = System.Drawing.Color.LightCyan;
			dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 204);
			this.dataGrid_Tax_FN.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle12;
			this.dataGrid_Tax_FN.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dataGrid_Tax_FN.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
			dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			this.dataGrid_Tax_FN.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
			this.dataGrid_Tax_FN.ColumnHeadersHeight = 15;
			this.dataGrid_Tax_FN.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this.dataGrid_Tax_FN.ColumnHeadersVisible = false;
			this.dataGrid_Tax_FN.Columns.AddRange(this.dataGridViewTextBoxColumn2, this.dataGridViewTextBoxColumn3);
			dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			dataGridViewCellStyle14.ForeColor = System.Drawing.Color.Blue;
			dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.dataGrid_Tax_FN.DefaultCellStyle = dataGridViewCellStyle14;
			this.dataGrid_Tax_FN.Enabled = false;
			this.dataGrid_Tax_FN.GridColor = System.Drawing.SystemColors.WindowFrame;
			this.dataGrid_Tax_FN.Location = new System.Drawing.Point(152, 112);
			this.dataGrid_Tax_FN.MultiSelect = false;
			this.dataGrid_Tax_FN.Name = "dataGrid_Tax_FN";
			dataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			this.dataGrid_Tax_FN.RowHeadersDefaultCellStyle = dataGridViewCellStyle15;
			this.dataGrid_Tax_FN.RowHeadersVisible = false;
			dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 204);
			this.dataGrid_Tax_FN.RowsDefaultCellStyle = dataGridViewCellStyle16;
			this.dataGrid_Tax_FN.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.dataGrid_Tax_FN.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 204);
			this.dataGrid_Tax_FN.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGrid_Tax_FN.RowTemplate.Height = 15;
			this.dataGrid_Tax_FN.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.dataGrid_Tax_FN.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
			this.dataGrid_Tax_FN.ShowCellToolTips = false;
			this.dataGrid_Tax_FN.ShowEditingIcon = false;
			this.dataGrid_Tax_FN.Size = new System.Drawing.Size(149, 93);
			this.dataGrid_Tax_FN.TabIndex = 4;
			dataGridViewCellStyle17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle17;
			this.dataGridViewTextBoxColumn2.HeaderText = "";
			this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
			this.dataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.False;
			this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			dataGridViewCellStyle18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle18;
			this.dataGridViewTextBoxColumn3.HeaderText = "";
			this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
			this.panel_Totals_FN.BackColor = System.Drawing.Color.LightCyan;
			this.panel_Totals_FN.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_Totals_FN.Controls.Add(this.button_Totals_FN);
			this.panel_Totals_FN.Controls.Add(this.label_Totals_Refund);
			this.panel_Totals_FN.Controls.Add(this.label_Totals_Sales);
			this.panel_Totals_FN.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Totals_FN.Location = new System.Drawing.Point(0, 138);
			this.panel_Totals_FN.Name = "panel_Totals_FN";
			this.panel_Totals_FN.Size = new System.Drawing.Size(301, 26);
			this.panel_Totals_FN.TabIndex = 3;
			this.button_Totals_FN.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.button_Totals_FN.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_Totals_FN.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_Totals_FN.Location = new System.Drawing.Point(1, 1);
			this.button_Totals_FN.Name = "button_Totals_FN";
			this.button_Totals_FN.Size = new System.Drawing.Size(149, 23);
			this.button_Totals_FN.TabIndex = 0;
			this.button_Totals_FN.Text = "Итоги";
			this.button_Totals_FN.UseVisualStyleBackColor = true;
			this.button_Totals_FN.Click += new System.EventHandler(button_Totals_FN_Click);
			this.label_Totals_Refund.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f);
			this.label_Totals_Refund.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Totals_Refund.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Totals_Refund.Location = new System.Drawing.Point(240, 8);
			this.label_Totals_Refund.Name = "label_Totals_Refund";
			this.label_Totals_Refund.Size = new System.Drawing.Size(56, 15);
			this.label_Totals_Refund.TabIndex = 1;
			this.label_Totals_Refund.Text = "Возврат";
			this.label_Totals_Refund.TextAlign = System.Drawing.ContentAlignment.BottomRight;
			this.label_Totals_Sales.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f);
			this.label_Totals_Sales.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Totals_Sales.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Totals_Sales.Location = new System.Drawing.Point(176, 8);
			this.label_Totals_Sales.Name = "label_Totals_Sales";
			this.label_Totals_Sales.Size = new System.Drawing.Size(50, 15);
			this.label_Totals_Sales.TabIndex = 1;
			this.label_Totals_Sales.Text = "Приход";
			this.label_Totals_Sales.TextAlign = System.Drawing.ContentAlignment.BottomRight;
			this.panel_Status_FN2.Controls.Add(this.label_Status_FN);
			this.panel_Status_FN2.Controls.Add(this.dataGrid_Status_FN);
			this.panel_Status_FN2.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Status_FN2.Location = new System.Drawing.Point(0, 26);
			this.panel_Status_FN2.Name = "panel_Status_FN2";
			this.panel_Status_FN2.Size = new System.Drawing.Size(301, 112);
			this.panel_Status_FN2.TabIndex = 6;
			this.label_Status_FN.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f);
			this.label_Status_FN.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Status_FN.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Status_FN.Location = new System.Drawing.Point(1, 1);
			this.label_Status_FN.Margin = new System.Windows.Forms.Padding(3);
			this.label_Status_FN.Name = "label_Status_FN";
			this.label_Status_FN.Size = new System.Drawing.Size(150, 108);
			this.label_Status_FN.TabIndex = 1;
			this.label_Status_FN.Text = "Заводской номер ФН\r\nСрок действия ФН\r\n№ рег. / осталось рег.\r\nЭтап применения ФН\r\nВерсия ФФД\r\nДата последнего ФД\r\n№ последнего ФД";
			this.label_Status_FN.TextAlign = System.Drawing.ContentAlignment.TopRight;
			this.dataGrid_Status_FN.AllowUserToAddRows = false;
			dataGridViewCellStyle19.BackColor = System.Drawing.Color.LightCyan;
			dataGridViewCellStyle19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 204);
			this.dataGrid_Status_FN.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle19;
			this.dataGrid_Status_FN.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dataGrid_Status_FN.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
			this.dataGrid_Status_FN.ColumnHeadersHeight = 15;
			this.dataGrid_Status_FN.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this.dataGrid_Status_FN.ColumnHeadersVisible = false;
			this.dataGrid_Status_FN.Columns.AddRange(this.dataGridViewTextBoxColumn1);
			this.dataGrid_Status_FN.Enabled = false;
			this.dataGrid_Status_FN.GridColor = System.Drawing.SystemColors.WindowFrame;
			this.dataGrid_Status_FN.Location = new System.Drawing.Point(152, 1);
			this.dataGrid_Status_FN.MultiSelect = false;
			this.dataGrid_Status_FN.Name = "dataGrid_Status_FN";
			this.dataGrid_Status_FN.RowHeadersVisible = false;
			this.dataGrid_Status_FN.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 204);
			this.dataGrid_Status_FN.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGrid_Status_FN.RowTemplate.Height = 15;
			this.dataGrid_Status_FN.RowTemplate.ReadOnly = true;
			this.dataGrid_Status_FN.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.dataGrid_Status_FN.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
			this.dataGrid_Status_FN.ShowCellToolTips = false;
			this.dataGrid_Status_FN.ShowEditingIcon = false;
			this.dataGrid_Status_FN.Size = new System.Drawing.Size(149, 108);
			this.dataGrid_Status_FN.TabIndex = 2;
			this.dataGridViewTextBoxColumn1.HeaderText = "";
			this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
			this.dataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
			this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			this.panel_Status_FN1.BackColor = System.Drawing.Color.LightCyan;
			this.panel_Status_FN1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_Status_FN1.Controls.Add(this.button_Status_FN);
			this.panel_Status_FN1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Status_FN1.Location = new System.Drawing.Point(0, 0);
			this.panel_Status_FN1.Name = "panel_Status_FN1";
			this.panel_Status_FN1.Size = new System.Drawing.Size(301, 26);
			this.panel_Status_FN1.TabIndex = 3;
			this.button_Status_FN.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.button_Status_FN.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_Status_FN.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_Status_FN.Location = new System.Drawing.Point(1, 1);
			this.button_Status_FN.Name = "button_Status_FN";
			this.button_Status_FN.Size = new System.Drawing.Size(149, 23);
			this.button_Status_FN.TabIndex = 0;
			this.button_Status_FN.Text = "Статус";
			this.button_Status_FN.UseVisualStyleBackColor = true;
			this.button_Status_FN.Click += new System.EventHandler(Button_Status_FN_Click);
			this.tabPage_Commands.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.tabPage_Commands.Controls.Add(this.panel_FWControlFrame);
			this.tabPage_Commands.Controls.Add(this.panel_FNControlFrame);
			this.tabPage_Commands.Controls.Add(this.panel_ManualCommandFrame);
			this.tabPage_Commands.Controls.Add(this.panel_AutoReceiptFrame);
			this.tabPage_Commands.Controls.Add(this.panel_ScriptFrame);
			this.tabPage_Commands.Location = new System.Drawing.Point(154, 4);
			this.tabPage_Commands.Name = "tabPage_Commands";
			this.tabPage_Commands.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage_Commands.Size = new System.Drawing.Size(626, 424);
			this.tabPage_Commands.TabIndex = 2;
			this.tabPage_Commands.Text = "Тест и обновление ПО";
			this.tabPage_Commands.UseVisualStyleBackColor = true;
			this.panel_FWControlFrame.Controls.Add(this.groupBox_FWControl);
			this.panel_FWControlFrame.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_FWControlFrame.Location = new System.Drawing.Point(3, 311);
			this.panel_FWControlFrame.Name = "panel_FWControlFrame";
			this.panel_FWControlFrame.Size = new System.Drawing.Size(618, 79);
			this.panel_FWControlFrame.TabIndex = 16;
			this.groupBox_FWControl.BackColor = System.Drawing.Color.Transparent;
			this.groupBox_FWControl.Controls.Add(this.panel_FWControl);
			this.groupBox_FWControl.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox_FWControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_FWControl.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_FWControl.Location = new System.Drawing.Point(0, 0);
			this.groupBox_FWControl.Name = "groupBox_FWControl";
			this.groupBox_FWControl.Size = new System.Drawing.Size(618, 72);
			this.groupBox_FWControl.TabIndex = 10;
			this.groupBox_FWControl.TabStop = false;
			this.groupBox_FWControl.Text = "П р о ш и в к а";
			this.panel_FWControl.BackColor = System.Drawing.Color.LightCyan;
			this.panel_FWControl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_FWControl.Controls.Add(this.textBox_FW_File);
			this.panel_FWControl.Controls.Add(this.button_FW_Download_Update);
			this.panel_FWControl.Controls.Add(this.checkBox_Setup_Reload);
			this.panel_FWControl.Controls.Add(this.button_FW_Upload);
			this.panel_FWControl.Controls.Add(this.checkBox_FW_Hex);
			this.panel_FWControl.Controls.Add(this.button_FW_Update);
			this.panel_FWControl.Controls.Add(this.checkBox_FW_CRC);
			this.panel_FWControl.Controls.Add(this.textBox_FW_CRC);
			this.panel_FWControl.Controls.Add(this.button_FW_Status);
			this.panel_FWControl.Controls.Add(this.button_FW_Download);
			this.panel_FWControl.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel_FWControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_FWControl.Location = new System.Drawing.Point(3, 16);
			this.panel_FWControl.Name = "panel_FWControl";
			this.panel_FWControl.Padding = new System.Windows.Forms.Padding(3);
			this.panel_FWControl.Size = new System.Drawing.Size(612, 53);
			this.panel_FWControl.TabIndex = 0;
			this.textBox_FW_File.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.textBox_FW_File.Location = new System.Drawing.Point(3, 28);
			this.textBox_FW_File.MaxLength = 999;
			this.textBox_FW_File.Name = "textBox_FW_File";
			this.textBox_FW_File.Size = new System.Drawing.Size(295, 20);
			this.textBox_FW_File.TabIndex = 23;
			this.toolTip1.SetToolTip(this.textBox_FW_File, "Файл прошивки");
			this.button_FW_Download_Update.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.button_FW_Download_Update.ForeColor = System.Drawing.Color.Brown;
			this.button_FW_Download_Update.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_FW_Download_Update.Location = new System.Drawing.Point(303, 3);
			this.button_FW_Download_Update.Name = "button_FW_Download_Update";
			this.button_FW_Download_Update.Size = new System.Drawing.Size(95, 23);
			this.button_FW_Download_Update.TabIndex = 22;
			this.button_FW_Download_Update.Text = "=> Обновить";
			this.button_FW_Download_Update.UseVisualStyleBackColor = true;
			this.button_FW_Download_Update.Click += new System.EventHandler(Button_FW_Download_Click);
			this.checkBox_Setup_Reload.Checked = true;
			this.checkBox_Setup_Reload.CheckState = System.Windows.Forms.CheckState.Checked;
			this.checkBox_Setup_Reload.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_Setup_Reload.ForeColor = System.Drawing.Color.Blue;
			this.checkBox_Setup_Reload.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_Setup_Reload.Location = new System.Drawing.Point(304, 30);
			this.checkBox_Setup_Reload.Name = "checkBox_Setup_Reload";
			this.checkBox_Setup_Reload.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.checkBox_Setup_Reload.Size = new System.Drawing.Size(83, 17);
			this.checkBox_Setup_Reload.TabIndex = 21;
			this.checkBox_Setup_Reload.Text = "Настройки";
			this.toolTip1.SetToolTip(this.checkBox_Setup_Reload, "Считать настройки ККТ и восстановить после обновления");
			this.checkBox_Setup_Reload.UseVisualStyleBackColor = true;
			this.button_FW_Upload.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.button_FW_Upload.ForeColor = System.Drawing.Color.Brown;
			this.button_FW_Upload.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_FW_Upload.Location = new System.Drawing.Point(511, 3);
			this.button_FW_Upload.Name = "button_FW_Upload";
			this.button_FW_Upload.Size = new System.Drawing.Size(95, 23);
			this.button_FW_Upload.TabIndex = 18;
			this.button_FW_Upload.Text = "Выгрузить";
			this.button_FW_Upload.UseVisualStyleBackColor = true;
			this.button_FW_Upload.Visible = false;
			this.button_FW_Upload.Click += new System.EventHandler(Button_FW_Upload_Click);
			this.checkBox_FW_Hex.Checked = true;
			this.checkBox_FW_Hex.CheckState = System.Windows.Forms.CheckState.Checked;
			this.checkBox_FW_Hex.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_FW_Hex.ForeColor = System.Drawing.Color.Blue;
			this.checkBox_FW_Hex.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_FW_Hex.Location = new System.Drawing.Point(512, 30);
			this.checkBox_FW_Hex.Name = "checkBox_FW_Hex";
			this.checkBox_FW_Hex.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.checkBox_FW_Hex.Size = new System.Drawing.Size(94, 17);
			this.checkBox_FW_Hex.TabIndex = 19;
			this.checkBox_FW_Hex.Text = "Формат HEX";
			this.toolTip1.SetToolTip(this.checkBox_FW_Hex, "HEX-формат данных для версий 2.0.35+");
			this.checkBox_FW_Hex.UseVisualStyleBackColor = true;
			this.checkBox_FW_Hex.Visible = false;
			this.button_FW_Update.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.button_FW_Update.ForeColor = System.Drawing.Color.Brown;
			this.button_FW_Update.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_FW_Update.Location = new System.Drawing.Point(203, 3);
			this.button_FW_Update.Name = "button_FW_Update";
			this.button_FW_Update.Size = new System.Drawing.Size(95, 23);
			this.button_FW_Update.TabIndex = 18;
			this.button_FW_Update.Text = "Установить";
			this.button_FW_Update.UseVisualStyleBackColor = true;
			this.button_FW_Update.Click += new System.EventHandler(Button_Do_Update_Click);
			this.checkBox_FW_CRC.Checked = true;
			this.checkBox_FW_CRC.CheckState = System.Windows.Forms.CheckState.Checked;
			this.checkBox_FW_CRC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_FW_CRC.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_FW_CRC.Location = new System.Drawing.Point(403, 30);
			this.checkBox_FW_CRC.Name = "checkBox_FW_CRC";
			this.checkBox_FW_CRC.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.checkBox_FW_CRC.Size = new System.Drawing.Size(100, 17);
			this.checkBox_FW_CRC.TabIndex = 19;
			this.checkBox_FW_CRC.Text = "Контроль CRC";
			this.toolTip1.SetToolTip(this.checkBox_FW_CRC, "Контроль CRC для версий 2.0.35+");
			this.checkBox_FW_CRC.UseVisualStyleBackColor = true;
			this.textBox_FW_CRC.BackColor = System.Drawing.Color.Cyan;
			this.textBox_FW_CRC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.textBox_FW_CRC.ForeColor = System.Drawing.Color.Blue;
			this.textBox_FW_CRC.Location = new System.Drawing.Point(403, 4);
			this.textBox_FW_CRC.MaxLength = 8;
			this.textBox_FW_CRC.Name = "textBox_FW_CRC";
			this.textBox_FW_CRC.Size = new System.Drawing.Size(95, 20);
			this.textBox_FW_CRC.TabIndex = 14;
			this.textBox_FW_CRC.Text = "D65848C0";
			this.textBox_FW_CRC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.textBox_FW_CRC.WordWrap = false;
			this.button_FW_Status.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.button_FW_Status.ForeColor = System.Drawing.Color.Brown;
			this.button_FW_Status.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_FW_Status.Location = new System.Drawing.Point(103, 3);
			this.button_FW_Status.Name = "button_FW_Status";
			this.button_FW_Status.Size = new System.Drawing.Size(95, 23);
			this.button_FW_Status.TabIndex = 0;
			this.button_FW_Status.Text = "Статус";
			this.button_FW_Status.UseVisualStyleBackColor = true;
			this.button_FW_Status.Click += new System.EventHandler(Button_FW_Status_Click);
			this.button_FW_Download.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.button_FW_Download.ForeColor = System.Drawing.Color.Brown;
			this.button_FW_Download.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_FW_Download.Location = new System.Drawing.Point(3, 3);
			this.button_FW_Download.Name = "button_FW_Download";
			this.button_FW_Download.Size = new System.Drawing.Size(95, 23);
			this.button_FW_Download.TabIndex = 17;
			this.button_FW_Download.Text = "Загрузить";
			this.button_FW_Download.UseVisualStyleBackColor = true;
			this.button_FW_Download.Click += new System.EventHandler(Button_FW_Download_Click);
			this.panel_FNControlFrame.Controls.Add(this.groupBox_FNControl);
			this.panel_FNControlFrame.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_FNControlFrame.Location = new System.Drawing.Point(3, 241);
			this.panel_FNControlFrame.Name = "panel_FNControlFrame";
			this.panel_FNControlFrame.Size = new System.Drawing.Size(618, 70);
			this.panel_FNControlFrame.TabIndex = 13;
			this.groupBox_FNControl.BackColor = System.Drawing.Color.Transparent;
			this.groupBox_FNControl.Controls.Add(this.panel_FNControl);
			this.groupBox_FNControl.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox_FNControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_FNControl.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_FNControl.Location = new System.Drawing.Point(0, 0);
			this.groupBox_FNControl.Name = "groupBox_FNControl";
			this.groupBox_FNControl.Size = new System.Drawing.Size(618, 50);
			this.groupBox_FNControl.TabIndex = 10;
			this.groupBox_FNControl.TabStop = false;
			this.groupBox_FNControl.Text = "М Г М   и   S P I - п а м я т ь";
			this.panel_FNControl.BackColor = System.Drawing.Color.LightCyan;
			this.panel_FNControl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_FNControl.Controls.Add(this.button_EraseSPI);
			this.panel_FNControl.Controls.Add(this.button_ResetMGM);
			this.panel_FNControl.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel_FNControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_FNControl.Location = new System.Drawing.Point(3, 16);
			this.panel_FNControl.Name = "panel_FNControl";
			this.panel_FNControl.Padding = new System.Windows.Forms.Padding(3);
			this.panel_FNControl.Size = new System.Drawing.Size(612, 31);
			this.panel_FNControl.TabIndex = 0;
			this.button_EraseSPI.Dock = System.Windows.Forms.DockStyle.Right;
			this.button_EraseSPI.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_EraseSPI.Location = new System.Drawing.Point(512, 3);
			this.button_EraseSPI.Name = "button_EraseSPI";
			this.button_EraseSPI.Size = new System.Drawing.Size(95, 23);
			this.button_EraseSPI.TabIndex = 17;
			this.button_EraseSPI.Text = "Очистка SPI";
			this.button_EraseSPI.UseVisualStyleBackColor = true;
			this.button_EraseSPI.Click += new System.EventHandler(Button_EraseSPI_Click);
			this.button_ResetMGM.Dock = System.Windows.Forms.DockStyle.Left;
			this.button_ResetMGM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.button_ResetMGM.ForeColor = System.Drawing.Color.Brown;
			this.button_ResetMGM.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_ResetMGM.Location = new System.Drawing.Point(3, 3);
			this.button_ResetMGM.Name = "button_ResetMGM";
			this.button_ResetMGM.Size = new System.Drawing.Size(95, 23);
			this.button_ResetMGM.TabIndex = 0;
			this.button_ResetMGM.Text = "Обнулить";
			this.button_ResetMGM.UseVisualStyleBackColor = true;
			this.button_ResetMGM.Click += new System.EventHandler(Button_ResetFN_Click);
			this.panel_ManualCommandFrame.Controls.Add(this.groupBox_ManualCommand);
			this.panel_ManualCommandFrame.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_ManualCommandFrame.Location = new System.Drawing.Point(3, 171);
			this.panel_ManualCommandFrame.Name = "panel_ManualCommandFrame";
			this.panel_ManualCommandFrame.Size = new System.Drawing.Size(618, 70);
			this.panel_ManualCommandFrame.TabIndex = 14;
			this.groupBox_ManualCommand.BackColor = System.Drawing.Color.Transparent;
			this.groupBox_ManualCommand.Controls.Add(this.panel_ManualCommand);
			this.groupBox_ManualCommand.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox_ManualCommand.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_ManualCommand.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_ManualCommand.Location = new System.Drawing.Point(0, 0);
			this.groupBox_ManualCommand.Name = "groupBox_ManualCommand";
			this.groupBox_ManualCommand.Size = new System.Drawing.Size(618, 50);
			this.groupBox_ManualCommand.TabIndex = 12;
			this.groupBox_ManualCommand.TabStop = false;
			this.groupBox_ManualCommand.Text = "К о м а н д а";
			this.panel_ManualCommand.BackColor = System.Drawing.Color.LightCyan;
			this.panel_ManualCommand.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_ManualCommand.Controls.Add(this.comboBox_Command);
			this.panel_ManualCommand.Controls.Add(this.button_ManualCommand);
			this.panel_ManualCommand.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel_ManualCommand.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_ManualCommand.Location = new System.Drawing.Point(3, 16);
			this.panel_ManualCommand.Name = "panel_ManualCommand";
			this.panel_ManualCommand.Padding = new System.Windows.Forms.Padding(3);
			this.panel_ManualCommand.Size = new System.Drawing.Size(612, 31);
			this.panel_ManualCommand.TabIndex = 0;
			this.comboBox_Command.BackColor = System.Drawing.SystemColors.Window;
			this.comboBox_Command.Dock = System.Windows.Forms.DockStyle.Fill;
			this.comboBox_Command.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.comboBox_Command.FormattingEnabled = true;
			this.comboBox_Command.Location = new System.Drawing.Point(98, 3);
			this.comboBox_Command.Name = "comboBox_Command";
			this.comboBox_Command.Size = new System.Drawing.Size(509, 21);
			this.comboBox_Command.TabIndex = 15;
			this.comboBox_Command.Text = "<PRINT>1d284102000002</PRINT>";
			this.toolTip1.SetToolTip(this.comboBox_Command, "Type command or select from dropdown list");
			this.comboBox_Command.KeyDown += new System.Windows.Forms.KeyEventHandler(comboBox_Command_KeyPressed);
			this.button_ManualCommand.Dock = System.Windows.Forms.DockStyle.Left;
			this.button_ManualCommand.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_ManualCommand.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_ManualCommand.Location = new System.Drawing.Point(3, 3);
			this.button_ManualCommand.Name = "button_ManualCommand";
			this.button_ManualCommand.Size = new System.Drawing.Size(95, 23);
			this.button_ManualCommand.TabIndex = 0;
			this.button_ManualCommand.Text = "Выполнить";
			this.button_ManualCommand.UseVisualStyleBackColor = true;
			this.button_ManualCommand.Click += new System.EventHandler(button_ManualCommand_Click);
			this.panel_AutoReceiptFrame.Controls.Add(this.groupBox_AutoReceipt);
			this.panel_AutoReceiptFrame.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_AutoReceiptFrame.Location = new System.Drawing.Point(3, 87);
			this.panel_AutoReceiptFrame.Name = "panel_AutoReceiptFrame";
			this.panel_AutoReceiptFrame.Size = new System.Drawing.Size(618, 84);
			this.panel_AutoReceiptFrame.TabIndex = 14;
			this.groupBox_AutoReceipt.Controls.Add(this.panel_AutoReceipt);
			this.groupBox_AutoReceipt.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox_AutoReceipt.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_AutoReceipt.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_AutoReceipt.Location = new System.Drawing.Point(0, 0);
			this.groupBox_AutoReceipt.Name = "groupBox_AutoReceipt";
			this.groupBox_AutoReceipt.Size = new System.Drawing.Size(618, 70);
			this.groupBox_AutoReceipt.TabIndex = 11;
			this.groupBox_AutoReceipt.TabStop = false;
			this.groupBox_AutoReceipt.Text = "Г е н е р а ц и я   ч е к о в";
			this.panel_AutoReceipt.BackColor = System.Drawing.Color.LightCyan;
			this.panel_AutoReceipt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_AutoReceipt.Controls.Add(this.panel_ItemName);
			this.panel_AutoReceipt.Controls.Add(this.panel_ProduceRcpt);
			this.panel_AutoReceipt.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel_AutoReceipt.ForeColor = System.Drawing.SystemColors.ControlText;
			this.panel_AutoReceipt.Location = new System.Drawing.Point(3, 16);
			this.panel_AutoReceipt.Name = "panel_AutoReceipt";
			this.panel_AutoReceipt.Padding = new System.Windows.Forms.Padding(3);
			this.panel_AutoReceipt.Size = new System.Drawing.Size(612, 51);
			this.panel_AutoReceipt.TabIndex = 5;
			this.panel_ItemName.Controls.Add(this.textBox_ItemTemplate);
			this.panel_ItemName.Controls.Add(this.label_AutoReceiptName);
			this.panel_ItemName.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel_ItemName.ForeColor = System.Drawing.SystemColors.ControlText;
			this.panel_ItemName.Location = new System.Drawing.Point(203, 3);
			this.panel_ItemName.Name = "panel_ItemName";
			this.panel_ItemName.Padding = new System.Windows.Forms.Padding(1);
			this.panel_ItemName.Size = new System.Drawing.Size(404, 43);
			this.panel_ItemName.TabIndex = 4;
			this.textBox_ItemTemplate.Dock = System.Windows.Forms.DockStyle.Top;
			this.textBox_ItemTemplate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.textBox_ItemTemplate.Location = new System.Drawing.Point(1, 15);
			this.textBox_ItemTemplate.MaxLength = 120;
			this.textBox_ItemTemplate.Multiline = true;
			this.textBox_ItemTemplate.Name = "textBox_ItemTemplate";
			this.textBox_ItemTemplate.Size = new System.Drawing.Size(402, 21);
			this.textBox_ItemTemplate.TabIndex = 1;
			this.textBox_ItemTemplate.Text = "Что-то очень нужное";
			this.label_AutoReceiptName.Dock = System.Windows.Forms.DockStyle.Top;
			this.label_AutoReceiptName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_AutoReceiptName.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_AutoReceiptName.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_AutoReceiptName.Location = new System.Drawing.Point(1, 1);
			this.label_AutoReceiptName.Margin = new System.Windows.Forms.Padding(3);
			this.label_AutoReceiptName.Name = "label_AutoReceiptName";
			this.label_AutoReceiptName.Size = new System.Drawing.Size(402, 14);
			this.label_AutoReceiptName.TabIndex = 1;
			this.label_AutoReceiptName.Text = "Шаблон наименования";
			this.label_AutoReceiptName.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.panel_ProduceRcpt.Controls.Add(this.button_AutoReceipt);
			this.panel_ProduceRcpt.Controls.Add(this.numericUpDown_AutoReceiptItemNo);
			this.panel_ProduceRcpt.Controls.Add(this.label_AutoReceiptItemNo);
			this.panel_ProduceRcpt.Controls.Add(this.label_AutoReceiptRepeat);
			this.panel_ProduceRcpt.Controls.Add(this.numericUpDown_AutoReceiptRepeat);
			this.panel_ProduceRcpt.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel_ProduceRcpt.Location = new System.Drawing.Point(3, 3);
			this.panel_ProduceRcpt.Name = "panel_ProduceRcpt";
			this.panel_ProduceRcpt.Padding = new System.Windows.Forms.Padding(1);
			this.panel_ProduceRcpt.Size = new System.Drawing.Size(200, 43);
			this.panel_ProduceRcpt.TabIndex = 1;
			this.button_AutoReceipt.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.button_AutoReceipt.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_AutoReceipt.Location = new System.Drawing.Point(3, 14);
			this.button_AutoReceipt.Name = "button_AutoReceipt";
			this.button_AutoReceipt.Size = new System.Drawing.Size(95, 23);
			this.button_AutoReceipt.TabIndex = 0;
			this.button_AutoReceipt.Text = "Запуск";
			this.button_AutoReceipt.UseVisualStyleBackColor = true;
			this.button_AutoReceipt.Click += new System.EventHandler(button_AutoReceipt_Click);
			this.numericUpDown_AutoReceiptItemNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f);
			this.numericUpDown_AutoReceiptItemNo.Increment = new decimal(new int[4] { 5, 0, 0, 0 });
			this.numericUpDown_AutoReceiptItemNo.Location = new System.Drawing.Point(145, 15);
			this.numericUpDown_AutoReceiptItemNo.Maximum = new decimal(new int[4] { 500, 0, 0, 0 });
			this.numericUpDown_AutoReceiptItemNo.MaximumSize = new System.Drawing.Size(60, 0);
			this.numericUpDown_AutoReceiptItemNo.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			this.numericUpDown_AutoReceiptItemNo.Name = "numericUpDown_AutoReceiptItemNo";
			this.numericUpDown_AutoReceiptItemNo.Size = new System.Drawing.Size(50, 21);
			this.numericUpDown_AutoReceiptItemNo.TabIndex = 0;
			this.numericUpDown_AutoReceiptItemNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.numericUpDown_AutoReceiptItemNo.Value = new decimal(new int[4] { 10, 0, 0, 0 });
			this.numericUpDown_AutoReceiptItemNo.ValueChanged += new System.EventHandler(numericUpDown_ItemLimit_ValueChanged);
			this.label_AutoReceiptItemNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_AutoReceiptItemNo.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_AutoReceiptItemNo.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_AutoReceiptItemNo.Location = new System.Drawing.Point(145, 1);
			this.label_AutoReceiptItemNo.Margin = new System.Windows.Forms.Padding(3);
			this.label_AutoReceiptItemNo.Name = "label_AutoReceiptItemNo";
			this.label_AutoReceiptItemNo.Size = new System.Drawing.Size(50, 12);
			this.label_AutoReceiptItemNo.TabIndex = 1;
			this.label_AutoReceiptItemNo.Text = "Товаров";
			this.label_AutoReceiptItemNo.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.label_AutoReceiptRepeat.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_AutoReceiptRepeat.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_AutoReceiptRepeat.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_AutoReceiptRepeat.Location = new System.Drawing.Point(101, 1);
			this.label_AutoReceiptRepeat.Margin = new System.Windows.Forms.Padding(3);
			this.label_AutoReceiptRepeat.Name = "label_AutoReceiptRepeat";
			this.label_AutoReceiptRepeat.Size = new System.Drawing.Size(42, 12);
			this.label_AutoReceiptRepeat.TabIndex = 1;
			this.label_AutoReceiptRepeat.Text = "Чеков";
			this.label_AutoReceiptRepeat.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.numericUpDown_AutoReceiptRepeat.Enabled = false;
			this.numericUpDown_AutoReceiptRepeat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f);
			this.numericUpDown_AutoReceiptRepeat.Location = new System.Drawing.Point(101, 15);
			this.numericUpDown_AutoReceiptRepeat.Maximum = new decimal(new int[4] { 10, 0, 0, 0 });
			this.numericUpDown_AutoReceiptRepeat.MaximumSize = new System.Drawing.Size(60, 0);
			this.numericUpDown_AutoReceiptRepeat.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			this.numericUpDown_AutoReceiptRepeat.Name = "numericUpDown_AutoReceiptRepeat";
			this.numericUpDown_AutoReceiptRepeat.Size = new System.Drawing.Size(42, 21);
			this.numericUpDown_AutoReceiptRepeat.TabIndex = 0;
			this.numericUpDown_AutoReceiptRepeat.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.numericUpDown_AutoReceiptRepeat.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			this.panel_ScriptFrame.Controls.Add(this.groupBox_Script);
			this.panel_ScriptFrame.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_ScriptFrame.Location = new System.Drawing.Point(3, 3);
			this.panel_ScriptFrame.Name = "panel_ScriptFrame";
			this.panel_ScriptFrame.Size = new System.Drawing.Size(618, 84);
			this.panel_ScriptFrame.TabIndex = 15;
			this.groupBox_Script.BackColor = System.Drawing.Color.Transparent;
			this.groupBox_Script.Controls.Add(this.panel_Script);
			this.groupBox_Script.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox_Script.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_Script.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_Script.Location = new System.Drawing.Point(0, 0);
			this.groupBox_Script.Name = "groupBox_Script";
			this.groupBox_Script.Size = new System.Drawing.Size(618, 70);
			this.groupBox_Script.TabIndex = 12;
			this.groupBox_Script.TabStop = false;
			this.groupBox_Script.Text = "Т е с т ы";
			this.panel_Script.BackColor = System.Drawing.Color.LightCyan;
			this.panel_Script.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_Script.Controls.Add(this.label_Script);
			this.panel_Script.Controls.Add(this.label_Drawer);
			this.panel_Script.Controls.Add(this.label_PaperCut);
			this.panel_Script.Controls.Add(this.label_Restart);
			this.panel_Script.Controls.Add(this.button_RestartFN);
			this.panel_Script.Controls.Add(this.button_ResetPrinter);
			this.panel_Script.Controls.Add(this.button_PaperCut);
			this.panel_Script.Controls.Add(this.button_Drawer_Status);
			this.panel_Script.Controls.Add(this.button_Drawer_Open);
			this.panel_Script.Controls.Add(this.button_Script);
			this.panel_Script.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel_Script.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_Script.ForeColor = System.Drawing.SystemColors.ControlText;
			this.panel_Script.Location = new System.Drawing.Point(3, 16);
			this.panel_Script.Name = "panel_Script";
			this.panel_Script.Padding = new System.Windows.Forms.Padding(3);
			this.panel_Script.Size = new System.Drawing.Size(612, 51);
			this.panel_Script.TabIndex = 1;
			this.label_Script.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_Script.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Script.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Script.Location = new System.Drawing.Point(3, 5);
			this.label_Script.Margin = new System.Windows.Forms.Padding(3);
			this.label_Script.Name = "label_Script";
			this.label_Script.Size = new System.Drawing.Size(95, 14);
			this.label_Script.TabIndex = 11;
			this.label_Script.Text = "Скрипт файл...";
			this.label_Script.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.label_Drawer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_Drawer.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Drawer.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Drawer.Location = new System.Drawing.Point(108, 5);
			this.label_Drawer.Margin = new System.Windows.Forms.Padding(3);
			this.label_Drawer.Name = "label_Drawer";
			this.label_Drawer.Size = new System.Drawing.Size(190, 14);
			this.label_Drawer.TabIndex = 10;
			this.label_Drawer.Text = "Д е н е ж н ы й   я щ и к";
			this.label_Drawer.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.label_PaperCut.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_PaperCut.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_PaperCut.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_PaperCut.Location = new System.Drawing.Point(310, 5);
			this.label_PaperCut.Margin = new System.Windows.Forms.Padding(3);
			this.label_PaperCut.Name = "label_PaperCut";
			this.label_PaperCut.Size = new System.Drawing.Size(95, 14);
			this.label_PaperCut.TabIndex = 9;
			this.label_PaperCut.Text = "Чековая лента";
			this.label_PaperCut.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.label_Restart.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_Restart.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Restart.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Restart.Location = new System.Drawing.Point(417, 5);
			this.label_Restart.Margin = new System.Windows.Forms.Padding(3);
			this.label_Restart.Name = "label_Restart";
			this.label_Restart.Size = new System.Drawing.Size(190, 14);
			this.label_Restart.TabIndex = 8;
			this.label_Restart.Text = "П е р е з а п у с т и т ь";
			this.label_Restart.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.button_RestartFN.Image = MitsuCube.Properties.Resources.restart;
			this.button_RestartFN.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_RestartFN.Location = new System.Drawing.Point(512, 20);
			this.button_RestartFN.Name = "button_RestartFN";
			this.button_RestartFN.Size = new System.Drawing.Size(95, 26);
			this.button_RestartFN.TabIndex = 7;
			this.button_RestartFN.Text = "ФН";
			this.button_RestartFN.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.button_RestartFN.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
			this.button_RestartFN.UseVisualStyleBackColor = true;
			this.button_RestartFN.Click += new System.EventHandler(Button_RestartFN_Click);
			this.button_ResetPrinter.BackColor = System.Drawing.Color.Transparent;
			this.button_ResetPrinter.Image = MitsuCube.Properties.Resources.restart;
			this.button_ResetPrinter.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.button_ResetPrinter.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_ResetPrinter.Location = new System.Drawing.Point(417, 20);
			this.button_ResetPrinter.Name = "button_ResetPrinter";
			this.button_ResetPrinter.Size = new System.Drawing.Size(95, 26);
			this.button_ResetPrinter.TabIndex = 6;
			this.button_ResetPrinter.Text = "Принтер";
			this.button_ResetPrinter.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.button_ResetPrinter.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
			this.button_ResetPrinter.UseVisualStyleBackColor = false;
			this.button_ResetPrinter.Click += new System.EventHandler(Button_ResetPrinter_Click);
			this.button_PaperCut.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_PaperCut.Location = new System.Drawing.Point(310, 20);
			this.button_PaperCut.Name = "button_PaperCut";
			this.button_PaperCut.Size = new System.Drawing.Size(95, 26);
			this.button_PaperCut.TabIndex = 1;
			this.button_PaperCut.Text = "Отрезать";
			this.button_PaperCut.UseVisualStyleBackColor = true;
			this.button_PaperCut.Click += new System.EventHandler(Button_PaperCut);
			this.button_Drawer_Status.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.button_Drawer_Status.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_Drawer_Status.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_Drawer_Status.Location = new System.Drawing.Point(203, 20);
			this.button_Drawer_Status.Name = "button_Drawer_Status";
			this.button_Drawer_Status.Size = new System.Drawing.Size(95, 26);
			this.button_Drawer_Status.TabIndex = 5;
			this.button_Drawer_Status.Text = "Состояние";
			this.button_Drawer_Status.UseVisualStyleBackColor = true;
			this.button_Drawer_Status.Click += new System.EventHandler(Button_Drawer_Open_Click);
			this.button_Drawer_Open.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.button_Drawer_Open.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_Drawer_Open.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_Drawer_Open.Location = new System.Drawing.Point(108, 20);
			this.button_Drawer_Open.Name = "button_Drawer_Open";
			this.button_Drawer_Open.Size = new System.Drawing.Size(95, 26);
			this.button_Drawer_Open.TabIndex = 5;
			this.button_Drawer_Open.Text = "Открыть";
			this.button_Drawer_Open.UseVisualStyleBackColor = true;
			this.button_Drawer_Open.Click += new System.EventHandler(Button_Drawer_Open_Click);
			this.button_Script.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_Script.Location = new System.Drawing.Point(3, 20);
			this.button_Script.Name = "button_Script";
			this.button_Script.Size = new System.Drawing.Size(95, 26);
			this.button_Script.TabIndex = 0;
			this.button_Script.Text = "Выполнить";
			this.button_Script.UseVisualStyleBackColor = true;
			this.button_Script.Click += new System.EventHandler(button_Script_Click);
			this.tabPage_Settings.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.tabPage_Settings.Controls.Add(this.panel_LAN_Buttons);
			this.tabPage_Settings.Controls.Add(this.panel_OKP_Settings);
			this.tabPage_Settings.Controls.Add(this.panel_OISM_Settings);
			this.tabPage_Settings.Controls.Add(this.panel_OFDSettings);
			this.tabPage_Settings.Controls.Add(this.panel_Setup);
			this.tabPage_Settings.Controls.Add(this.panel_LANSettings);
			this.tabPage_Settings.Location = new System.Drawing.Point(154, 4);
			this.tabPage_Settings.Name = "tabPage_Settings";
			this.tabPage_Settings.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage_Settings.Size = new System.Drawing.Size(626, 424);
			this.tabPage_Settings.TabIndex = 7;
			this.tabPage_Settings.Text = "Настройки";
			this.tabPage_Settings.UseVisualStyleBackColor = true;
			this.panel_LAN_Buttons.Controls.Add(this.button_LAN_Get);
			this.panel_LAN_Buttons.Controls.Add(this.button_LAN_Set);
			this.panel_LAN_Buttons.Location = new System.Drawing.Point(3, 378);
			this.panel_LAN_Buttons.Name = "panel_LAN_Buttons";
			this.panel_LAN_Buttons.Padding = new System.Windows.Forms.Padding(3);
			this.panel_LAN_Buttons.Size = new System.Drawing.Size(320, 35);
			this.panel_LAN_Buttons.TabIndex = 1;
			this.button_LAN_Get.Dock = System.Windows.Forms.DockStyle.Left;
			this.button_LAN_Get.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.button_LAN_Get.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_LAN_Get.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_LAN_Get.Location = new System.Drawing.Point(3, 3);
			this.button_LAN_Get.Name = "button_LAN_Get";
			this.button_LAN_Get.Size = new System.Drawing.Size(130, 29);
			this.button_LAN_Get.TabIndex = 1;
			this.button_LAN_Get.Text = "Считать";
			this.button_LAN_Get.UseVisualStyleBackColor = true;
			this.button_LAN_Get.Click += new System.EventHandler(button_GetLAN_Click);
			this.button_LAN_Set.Dock = System.Windows.Forms.DockStyle.Right;
			this.button_LAN_Set.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.button_LAN_Set.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_LAN_Set.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_LAN_Set.Location = new System.Drawing.Point(187, 3);
			this.button_LAN_Set.Name = "button_LAN_Set";
			this.button_LAN_Set.Size = new System.Drawing.Size(130, 29);
			this.button_LAN_Set.TabIndex = 0;
			this.button_LAN_Set.Text = "Установить";
			this.button_LAN_Set.UseVisualStyleBackColor = true;
			this.button_LAN_Set.Click += new System.EventHandler(button_SetLAN_Click);
			this.panel_OKP_Settings.Controls.Add(this.groupBox_OKPSettings);
			this.panel_OKP_Settings.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_OKP_Settings.Location = new System.Drawing.Point(3, 285);
			this.panel_OKP_Settings.Name = "panel_OKP_Settings";
			this.panel_OKP_Settings.Size = new System.Drawing.Size(320, 52);
			this.panel_OKP_Settings.TabIndex = 12;
			this.groupBox_OKPSettings.Controls.Add(this.label_OKP_IP);
			this.groupBox_OKPSettings.Controls.Add(this.label_OKP_Port);
			this.groupBox_OKPSettings.Controls.Add(this.dataGrid_OKP);
			this.groupBox_OKPSettings.Controls.Add(this.checkedListBox_OKP);
			this.groupBox_OKPSettings.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox_OKPSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_OKPSettings.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_OKPSettings.Location = new System.Drawing.Point(0, 0);
			this.groupBox_OKPSettings.Name = "groupBox_OKPSettings";
			this.groupBox_OKPSettings.Size = new System.Drawing.Size(320, 52);
			this.groupBox_OKPSettings.TabIndex = 9;
			this.groupBox_OKPSettings.TabStop = false;
			this.groupBox_OKPSettings.Text = "С О К   ( с е р в е р   О К П )";
			this.label_OKP_IP.AutoSize = true;
			this.label_OKP_IP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_OKP_IP.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_OKP_IP.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_OKP_IP.Location = new System.Drawing.Point(3, 15);
			this.label_OKP_IP.MinimumSize = new System.Drawing.Size(131, 0);
			this.label_OKP_IP.Name = "label_OKP_IP";
			this.label_OKP_IP.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label_OKP_IP.Size = new System.Drawing.Size(131, 13);
			this.label_OKP_IP.TabIndex = 19;
			this.label_OKP_IP.Text = "IP/URL адрес";
			this.label_OKP_IP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.label_OKP_Port.AutoSize = true;
			this.label_OKP_Port.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_OKP_Port.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_OKP_Port.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_OKP_Port.Location = new System.Drawing.Point(3, 30);
			this.label_OKP_Port.MinimumSize = new System.Drawing.Size(131, 0);
			this.label_OKP_Port.Name = "label_OKP_Port";
			this.label_OKP_Port.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label_OKP_Port.Size = new System.Drawing.Size(131, 13);
			this.label_OKP_Port.TabIndex = 20;
			this.label_OKP_Port.Text = "Порт";
			this.label_OKP_Port.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.dataGrid_OKP.AllowUserToAddRows = false;
			this.dataGrid_OKP.AllowUserToDeleteRows = false;
			this.dataGrid_OKP.AllowUserToResizeColumns = false;
			this.dataGrid_OKP.AllowUserToResizeRows = false;
			dataGridViewCellStyle20.BackColor = System.Drawing.Color.LightCyan;
			this.dataGrid_OKP.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle20;
			this.dataGrid_OKP.BackgroundColor = System.Drawing.Color.LightCyan;
			this.dataGrid_OKP.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.dataGrid_OKP.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
			this.dataGrid_OKP.ColumnHeadersHeight = 15;
			this.dataGrid_OKP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this.dataGrid_OKP.ColumnHeadersVisible = false;
			this.dataGrid_OKP.Columns.AddRange(this.dataGridViewTextBoxColumn10);
			this.dataGrid_OKP.GridColor = System.Drawing.SystemColors.ActiveBorder;
			this.dataGrid_OKP.Location = new System.Drawing.Point(152, 15);
			this.dataGrid_OKP.MultiSelect = false;
			this.dataGrid_OKP.Name = "dataGrid_OKP";
			this.dataGrid_OKP.RowHeadersVisible = false;
			this.dataGrid_OKP.RowHeadersWidth = 4;
			this.dataGrid_OKP.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
			this.dataGrid_OKP.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 204);
			this.dataGrid_OKP.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.ControlDark;
			this.dataGrid_OKP.RowTemplate.DividerHeight = 1;
			this.dataGrid_OKP.RowTemplate.Height = 15;
			this.dataGrid_OKP.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
			this.dataGrid_OKP.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.dataGrid_OKP.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
			this.dataGrid_OKP.ShowCellToolTips = false;
			this.dataGrid_OKP.ShowEditingIcon = false;
			this.dataGrid_OKP.Size = new System.Drawing.Size(160, 32);
			this.dataGrid_OKP.TabIndex = 5;
			this.dataGrid_OKP.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(CellBeginEdit_ListBoxCheck);
			this.dataGridViewTextBoxColumn10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
			this.dataGridViewTextBoxColumn10.DividerWidth = 1;
			this.dataGridViewTextBoxColumn10.HeaderText = "Value";
			this.dataGridViewTextBoxColumn10.MaxInputLength = 256;
			this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
			this.dataGridViewTextBoxColumn10.Resizable = System.Windows.Forms.DataGridViewTriState.False;
			this.dataGridViewTextBoxColumn10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			this.dataGridViewTextBoxColumn10.Width = 150;
			this.checkedListBox_OKP.BackColor = System.Drawing.SystemColors.Window;
			this.checkedListBox_OKP.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.checkedListBox_OKP.CheckOnClick = true;
			this.checkedListBox_OKP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkedListBox_OKP.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkedListBox_OKP.FormattingEnabled = true;
			this.checkedListBox_OKP.Items.AddRange(new object[2] { "1", "2" });
			this.checkedListBox_OKP.Location = new System.Drawing.Point(136, 15);
			this.checkedListBox_OKP.Name = "checkedListBox_OKP";
			this.checkedListBox_OKP.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.checkedListBox_OKP.Size = new System.Drawing.Size(14, 30);
			this.checkedListBox_OKP.TabIndex = 3;
			this.panel_OISM_Settings.Controls.Add(this.groupBox_OISMSettings);
			this.panel_OISM_Settings.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_OISM_Settings.Location = new System.Drawing.Point(3, 233);
			this.panel_OISM_Settings.Name = "panel_OISM_Settings";
			this.panel_OISM_Settings.Size = new System.Drawing.Size(320, 52);
			this.panel_OISM_Settings.TabIndex = 11;
			this.groupBox_OISMSettings.Controls.Add(this.label_OISM_IP);
			this.groupBox_OISMSettings.Controls.Add(this.label_OISM_Port);
			this.groupBox_OISMSettings.Controls.Add(this.dataGrid_OISM);
			this.groupBox_OISMSettings.Controls.Add(this.checkedListBox_OISM);
			this.groupBox_OISMSettings.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox_OISMSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_OISMSettings.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_OISMSettings.Location = new System.Drawing.Point(0, 0);
			this.groupBox_OISMSettings.Name = "groupBox_OISMSettings";
			this.groupBox_OISMSettings.Size = new System.Drawing.Size(320, 52);
			this.groupBox_OISMSettings.TabIndex = 9;
			this.groupBox_OISMSettings.TabStop = false;
			this.groupBox_OISMSettings.Text = "О И С М";
			this.label_OISM_IP.AutoSize = true;
			this.label_OISM_IP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_OISM_IP.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_OISM_IP.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_OISM_IP.Location = new System.Drawing.Point(3, 15);
			this.label_OISM_IP.MinimumSize = new System.Drawing.Size(131, 0);
			this.label_OISM_IP.Name = "label_OISM_IP";
			this.label_OISM_IP.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label_OISM_IP.Size = new System.Drawing.Size(131, 13);
			this.label_OISM_IP.TabIndex = 17;
			this.label_OISM_IP.Text = "IP/URL адрес";
			this.label_OISM_IP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.label_OISM_Port.AutoSize = true;
			this.label_OISM_Port.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_OISM_Port.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_OISM_Port.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_OISM_Port.Location = new System.Drawing.Point(3, 30);
			this.label_OISM_Port.MinimumSize = new System.Drawing.Size(131, 0);
			this.label_OISM_Port.Name = "label_OISM_Port";
			this.label_OISM_Port.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label_OISM_Port.Size = new System.Drawing.Size(131, 13);
			this.label_OISM_Port.TabIndex = 18;
			this.label_OISM_Port.Text = "Порт";
			this.label_OISM_Port.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.dataGrid_OISM.AllowUserToAddRows = false;
			this.dataGrid_OISM.AllowUserToDeleteRows = false;
			this.dataGrid_OISM.AllowUserToResizeColumns = false;
			this.dataGrid_OISM.AllowUserToResizeRows = false;
			dataGridViewCellStyle21.BackColor = System.Drawing.Color.LightCyan;
			this.dataGrid_OISM.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle21;
			this.dataGrid_OISM.BackgroundColor = System.Drawing.Color.LightCyan;
			this.dataGrid_OISM.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.dataGrid_OISM.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
			this.dataGrid_OISM.ColumnHeadersHeight = 15;
			this.dataGrid_OISM.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this.dataGrid_OISM.ColumnHeadersVisible = false;
			this.dataGrid_OISM.Columns.AddRange(this.dataGridViewTextBoxColumn7);
			this.dataGrid_OISM.GridColor = System.Drawing.SystemColors.ActiveBorder;
			this.dataGrid_OISM.Location = new System.Drawing.Point(152, 15);
			this.dataGrid_OISM.MultiSelect = false;
			this.dataGrid_OISM.Name = "dataGrid_OISM";
			this.dataGrid_OISM.RowHeadersVisible = false;
			this.dataGrid_OISM.RowHeadersWidth = 4;
			this.dataGrid_OISM.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
			this.dataGrid_OISM.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 204);
			this.dataGrid_OISM.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.ControlDark;
			this.dataGrid_OISM.RowTemplate.DividerHeight = 1;
			this.dataGrid_OISM.RowTemplate.Height = 15;
			this.dataGrid_OISM.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
			this.dataGrid_OISM.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.dataGrid_OISM.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
			this.dataGrid_OISM.ShowCellToolTips = false;
			this.dataGrid_OISM.ShowEditingIcon = false;
			this.dataGrid_OISM.Size = new System.Drawing.Size(160, 32);
			this.dataGrid_OISM.TabIndex = 5;
			this.dataGrid_OISM.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(CellBeginEdit_ListBoxCheck);
			this.dataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
			this.dataGridViewTextBoxColumn7.DividerWidth = 1;
			this.dataGridViewTextBoxColumn7.HeaderText = "Value";
			this.dataGridViewTextBoxColumn7.MaxInputLength = 256;
			this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
			this.dataGridViewTextBoxColumn7.Resizable = System.Windows.Forms.DataGridViewTriState.False;
			this.dataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			this.dataGridViewTextBoxColumn7.Width = 150;
			this.checkedListBox_OISM.BackColor = System.Drawing.SystemColors.Window;
			this.checkedListBox_OISM.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.checkedListBox_OISM.CheckOnClick = true;
			this.checkedListBox_OISM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkedListBox_OISM.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkedListBox_OISM.FormattingEnabled = true;
			this.checkedListBox_OISM.Items.AddRange(new object[2] { "1", "2" });
			this.checkedListBox_OISM.Location = new System.Drawing.Point(136, 15);
			this.checkedListBox_OISM.Name = "checkedListBox_OISM";
			this.checkedListBox_OISM.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.checkedListBox_OISM.Size = new System.Drawing.Size(14, 30);
			this.checkedListBox_OISM.TabIndex = 3;
			this.panel_OFDSettings.Controls.Add(this.groupBox_OFDSettings);
			this.panel_OFDSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_OFDSettings.Location = new System.Drawing.Point(3, 115);
			this.panel_OFDSettings.Name = "panel_OFDSettings";
			this.panel_OFDSettings.Size = new System.Drawing.Size(320, 118);
			this.panel_OFDSettings.TabIndex = 10;
			this.groupBox_OFDSettings.Controls.Add(this.panel_Setup_OFDClient);
			this.groupBox_OFDSettings.Controls.Add(this.checkBox_OFD_Client);
			this.groupBox_OFDSettings.Controls.Add(this.label_OFD_IP);
			this.groupBox_OFDSettings.Controls.Add(this.label_OFD_Port);
			this.groupBox_OFDSettings.Controls.Add(this.label_OFD_TimerOFD);
			this.groupBox_OFDSettings.Controls.Add(this.label_TimerFN);
			this.groupBox_OFDSettings.Controls.Add(this.label_OFD_Client);
			this.groupBox_OFDSettings.Controls.Add(this.dataGrid_OFD);
			this.groupBox_OFDSettings.Controls.Add(this.checkedListBox_OFD);
			this.groupBox_OFDSettings.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox_OFDSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_OFDSettings.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_OFDSettings.Location = new System.Drawing.Point(0, 0);
			this.groupBox_OFDSettings.Name = "groupBox_OFDSettings";
			this.groupBox_OFDSettings.Size = new System.Drawing.Size(320, 118);
			this.groupBox_OFDSettings.TabIndex = 9;
			this.groupBox_OFDSettings.TabStop = false;
			this.groupBox_OFDSettings.Text = "О Ф Д";
			this.panel_Setup_OFDClient.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_Setup_OFDClient.Controls.Add(this.radio_Setup_OFDClient_Internal);
			this.panel_Setup_OFDClient.Controls.Add(this.radio_Setup_OFDClient_External);
			this.panel_Setup_OFDClient.Location = new System.Drawing.Point(152, 78);
			this.panel_Setup_OFDClient.Name = "panel_Setup_OFDClient";
			this.panel_Setup_OFDClient.Size = new System.Drawing.Size(160, 36);
			this.panel_Setup_OFDClient.TabIndex = 17;
			this.radio_Setup_OFDClient_Internal.AutoSize = true;
			this.radio_Setup_OFDClient_Internal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.radio_Setup_OFDClient_Internal.ForeColor = System.Drawing.Color.Blue;
			this.radio_Setup_OFDClient_Internal.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radio_Setup_OFDClient_Internal.Location = new System.Drawing.Point(4, 17);
			this.radio_Setup_OFDClient_Internal.Name = "radio_Setup_OFDClient_Internal";
			this.radio_Setup_OFDClient_Internal.Size = new System.Drawing.Size(143, 17);
			this.radio_Setup_OFDClient_Internal.TabIndex = 12;
			this.radio_Setup_OFDClient_Internal.Text = "Встроенный (ККТ/LAN)";
			this.radio_Setup_OFDClient_Internal.UseVisualStyleBackColor = true;
			this.radio_Setup_OFDClient_Internal.CheckedChanged += new System.EventHandler(radio_Setup_OFDClient_External_CheckedChanged);
			this.radio_Setup_OFDClient_External.AutoSize = true;
			this.radio_Setup_OFDClient_External.Checked = true;
			this.radio_Setup_OFDClient_External.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.radio_Setup_OFDClient_External.ForeColor = System.Drawing.Color.Blue;
			this.radio_Setup_OFDClient_External.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radio_Setup_OFDClient_External.Location = new System.Drawing.Point(4, 0);
			this.radio_Setup_OFDClient_External.Name = "radio_Setup_OFDClient_External";
			this.radio_Setup_OFDClient_External.Size = new System.Drawing.Size(133, 17);
			this.radio_Setup_OFDClient_External.TabIndex = 11;
			this.radio_Setup_OFDClient_External.TabStop = true;
			this.radio_Setup_OFDClient_External.Text = "Внешний (через POS)";
			this.radio_Setup_OFDClient_External.UseVisualStyleBackColor = true;
			this.radio_Setup_OFDClient_External.CheckedChanged += new System.EventHandler(radio_Setup_OFDClient_External_CheckedChanged);
			this.checkBox_OFD_Client.AutoSize = true;
			this.checkBox_OFD_Client.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_OFD_Client.Location = new System.Drawing.Point(136, 90);
			this.checkBox_OFD_Client.Name = "checkBox_OFD_Client";
			this.checkBox_OFD_Client.Size = new System.Drawing.Size(15, 14);
			this.checkBox_OFD_Client.TabIndex = 16;
			this.checkBox_OFD_Client.UseVisualStyleBackColor = true;
			this.label_OFD_IP.AutoSize = true;
			this.label_OFD_IP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_OFD_IP.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_OFD_IP.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_OFD_IP.Location = new System.Drawing.Point(3, 15);
			this.label_OFD_IP.MinimumSize = new System.Drawing.Size(131, 0);
			this.label_OFD_IP.Name = "label_OFD_IP";
			this.label_OFD_IP.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label_OFD_IP.Size = new System.Drawing.Size(131, 13);
			this.label_OFD_IP.TabIndex = 11;
			this.label_OFD_IP.Text = "IP/URL адрес";
			this.label_OFD_IP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.label_OFD_Port.AutoSize = true;
			this.label_OFD_Port.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_OFD_Port.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_OFD_Port.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_OFD_Port.Location = new System.Drawing.Point(3, 30);
			this.label_OFD_Port.MinimumSize = new System.Drawing.Size(131, 0);
			this.label_OFD_Port.Name = "label_OFD_Port";
			this.label_OFD_Port.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label_OFD_Port.Size = new System.Drawing.Size(131, 13);
			this.label_OFD_Port.TabIndex = 12;
			this.label_OFD_Port.Text = "Порт";
			this.label_OFD_Port.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.label_OFD_TimerOFD.AutoSize = true;
			this.label_OFD_TimerOFD.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_OFD_TimerOFD.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_OFD_TimerOFD.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_OFD_TimerOFD.Location = new System.Drawing.Point(3, 45);
			this.label_OFD_TimerOFD.MinimumSize = new System.Drawing.Size(131, 0);
			this.label_OFD_TimerOFD.Name = "label_OFD_TimerOFD";
			this.label_OFD_TimerOFD.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label_OFD_TimerOFD.Size = new System.Drawing.Size(131, 13);
			this.label_OFD_TimerOFD.TabIndex = 13;
			this.label_OFD_TimerOFD.Text = "Интервал ОФД (сек)";
			this.label_OFD_TimerOFD.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.label_TimerFN.AutoSize = true;
			this.label_TimerFN.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_TimerFN.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_TimerFN.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_TimerFN.Location = new System.Drawing.Point(3, 60);
			this.label_TimerFN.MinimumSize = new System.Drawing.Size(131, 0);
			this.label_TimerFN.Name = "label_TimerFN";
			this.label_TimerFN.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label_TimerFN.Size = new System.Drawing.Size(131, 13);
			this.label_TimerFN.TabIndex = 14;
			this.label_TimerFN.Text = "Интервал ФН (сек)";
			this.label_TimerFN.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.label_OFD_Client.AutoSize = true;
			this.label_OFD_Client.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_OFD_Client.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_OFD_Client.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_OFD_Client.Location = new System.Drawing.Point(3, 90);
			this.label_OFD_Client.MinimumSize = new System.Drawing.Size(131, 0);
			this.label_OFD_Client.Name = "label_OFD_Client";
			this.label_OFD_Client.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label_OFD_Client.Size = new System.Drawing.Size(131, 13);
			this.label_OFD_Client.TabIndex = 15;
			this.label_OFD_Client.Text = "Клиент обмена с ОФД";
			this.label_OFD_Client.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.dataGrid_OFD.AllowUserToAddRows = false;
			this.dataGrid_OFD.AllowUserToDeleteRows = false;
			this.dataGrid_OFD.AllowUserToResizeColumns = false;
			this.dataGrid_OFD.AllowUserToResizeRows = false;
			dataGridViewCellStyle22.BackColor = System.Drawing.Color.LightCyan;
			this.dataGrid_OFD.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle22;
			this.dataGrid_OFD.BackgroundColor = System.Drawing.Color.LightCyan;
			this.dataGrid_OFD.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.dataGrid_OFD.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
			this.dataGrid_OFD.ColumnHeadersHeight = 15;
			this.dataGrid_OFD.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this.dataGrid_OFD.ColumnHeadersVisible = false;
			this.dataGrid_OFD.Columns.AddRange(this.dataGridViewTextBoxColumn9);
			this.dataGrid_OFD.GridColor = System.Drawing.SystemColors.ActiveBorder;
			this.dataGrid_OFD.Location = new System.Drawing.Point(152, 15);
			this.dataGrid_OFD.MultiSelect = false;
			this.dataGrid_OFD.Name = "dataGrid_OFD";
			this.dataGrid_OFD.RowHeadersVisible = false;
			this.dataGrid_OFD.RowHeadersWidth = 4;
			this.dataGrid_OFD.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
			this.dataGrid_OFD.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 204);
			this.dataGrid_OFD.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.ControlDark;
			this.dataGrid_OFD.RowTemplate.DividerHeight = 1;
			this.dataGrid_OFD.RowTemplate.Height = 15;
			this.dataGrid_OFD.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
			this.dataGrid_OFD.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.dataGrid_OFD.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
			this.dataGrid_OFD.ShowCellToolTips = false;
			this.dataGrid_OFD.ShowEditingIcon = false;
			this.dataGrid_OFD.Size = new System.Drawing.Size(160, 62);
			this.dataGrid_OFD.TabIndex = 5;
			this.dataGrid_OFD.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(CellBeginEdit_ListBoxCheck);
			this.dataGridViewTextBoxColumn9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
			this.dataGridViewTextBoxColumn9.DividerWidth = 1;
			this.dataGridViewTextBoxColumn9.HeaderText = "Value";
			this.dataGridViewTextBoxColumn9.MaxInputLength = 256;
			this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
			this.dataGridViewTextBoxColumn9.Resizable = System.Windows.Forms.DataGridViewTriState.False;
			this.dataGridViewTextBoxColumn9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			this.dataGridViewTextBoxColumn9.Width = 150;
			this.checkedListBox_OFD.BackColor = System.Drawing.SystemColors.Window;
			this.checkedListBox_OFD.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.checkedListBox_OFD.CheckOnClick = true;
			this.checkedListBox_OFD.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkedListBox_OFD.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkedListBox_OFD.FormattingEnabled = true;
			this.checkedListBox_OFD.Items.AddRange(new object[4] { "IP/URL адрес ОФД", "Порт ОФД", "Период опроса ОФД", "Период опроса ФН" });
			this.checkedListBox_OFD.Location = new System.Drawing.Point(136, 15);
			this.checkedListBox_OFD.Name = "checkedListBox_OFD";
			this.checkedListBox_OFD.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.checkedListBox_OFD.Size = new System.Drawing.Size(14, 60);
			this.checkedListBox_OFD.TabIndex = 3;
			this.panel_Setup.Controls.Add(this.groupBox_Setup);
			this.panel_Setup.Location = new System.Drawing.Point(326, 3);
			this.panel_Setup.Name = "panel_Setup";
			this.panel_Setup.Size = new System.Drawing.Size(292, 413);
			this.panel_Setup.TabIndex = 2;
			this.groupBox_Setup.Controls.Add(this.panel_Setup_PrstTime);
			this.groupBox_Setup.Controls.Add(this.panel_Setup_Prst);
			this.groupBox_Setup.Controls.Add(this.panel_Setup_DrawerFall);
			this.groupBox_Setup.Controls.Add(this.panel_Setup_DrawerPulse);
			this.groupBox_Setup.Controls.Add(this.panel_Setup_DrawerPin);
			this.groupBox_Setup.Controls.Add(this.panel_Setup_ItemCnt);
			this.groupBox_Setup.Controls.Add(this.panel_Setup_DrawerOpen);
			this.groupBox_Setup.Controls.Add(this.panel_Setup_AutoTest);
			this.groupBox_Setup.Controls.Add(this.panel_Setup_Beeper);
			this.groupBox_Setup.Controls.Add(this.panel_Setup_PaperCut);
			this.groupBox_Setup.Controls.Add(this.panel_Setup_QRText);
			this.groupBox_Setup.Controls.Add(this.panel_Setup_FontType);
			this.groupBox_Setup.Controls.Add(this.panel_Setup_PaperWidth);
			this.groupBox_Setup.Controls.Add(this.panel_Setup_LineType);
			this.groupBox_Setup.Controls.Add(this.panel_Setup_Rounding);
			this.groupBox_Setup.Controls.Add(this.panel_Setup_QRAlign);
			this.groupBox_Setup.Controls.Add(this.panel_PrinterModel);
			this.groupBox_Setup.Controls.Add(this.panel_Setup_Buttons);
			this.groupBox_Setup.Controls.Add(this.panel_Setup_PrBaudrate);
			this.groupBox_Setup.Controls.Add(this.panel_Setup_COMBaudrate);
			this.groupBox_Setup.Controls.Add(this.panel_Setup_SelectAll);
			this.groupBox_Setup.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox_Setup.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_Setup.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_Setup.Location = new System.Drawing.Point(0, 0);
			this.groupBox_Setup.Name = "groupBox_Setup";
			this.groupBox_Setup.Size = new System.Drawing.Size(292, 413);
			this.groupBox_Setup.TabIndex = 10;
			this.groupBox_Setup.TabStop = false;
			this.groupBox_Setup.Text = "У с т р о й с т в а   и   ф о р м а т   ч е к а";
			this.panel_Setup_PrstTime.BackColor = System.Drawing.Color.LightCyan;
			this.panel_Setup_PrstTime.Controls.Add(this.numeric_Setup_PrstTime);
			this.panel_Setup_PrstTime.Controls.Add(this.checkBox_Setup_PrstTime);
			this.panel_Setup_PrstTime.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Setup_PrstTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_Setup_PrstTime.Location = new System.Drawing.Point(3, 352);
			this.panel_Setup_PrstTime.Name = "panel_Setup_PrstTime";
			this.panel_Setup_PrstTime.Size = new System.Drawing.Size(286, 20);
			this.panel_Setup_PrstTime.TabIndex = 22;
			this.panel_Setup_PrstTime.Visible = false;
			this.numeric_Setup_PrstTime.BackColor = System.Drawing.Color.LightCyan;
			this.numeric_Setup_PrstTime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.numeric_Setup_PrstTime.Dock = System.Windows.Forms.DockStyle.Fill;
			this.numeric_Setup_PrstTime.Location = new System.Drawing.Point(140, 0);
			this.numeric_Setup_PrstTime.Maximum = new decimal(new int[4] { 255, 0, 0, 0 });
			this.numeric_Setup_PrstTime.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			this.numeric_Setup_PrstTime.Name = "numeric_Setup_PrstTime";
			this.numeric_Setup_PrstTime.Size = new System.Drawing.Size(146, 20);
			this.numeric_Setup_PrstTime.TabIndex = 7;
			this.toolTip1.SetToolTip(this.numeric_Setup_PrstTime, "Время ожидания презентера в секундах");
			this.numeric_Setup_PrstTime.Value = new decimal(new int[4] { 4, 0, 0, 0 });
			this.checkBox_Setup_PrstTime.BackColor = System.Drawing.Color.LightCyan;
			this.checkBox_Setup_PrstTime.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_PrstTime.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkBox_Setup_PrstTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_Setup_PrstTime.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_Setup_PrstTime.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_Setup_PrstTime.Location = new System.Drawing.Point(0, 0);
			this.checkBox_Setup_PrstTime.Name = "checkBox_Setup_PrstTime";
			this.checkBox_Setup_PrstTime.Size = new System.Drawing.Size(140, 20);
			this.checkBox_Setup_PrstTime.TabIndex = 6;
			this.checkBox_Setup_PrstTime.Text = "Таймаут презентера";
			this.checkBox_Setup_PrstTime.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_PrstTime.UseVisualStyleBackColor = false;
			this.panel_Setup_Prst.BackColor = System.Drawing.Color.LightCyan;
			this.panel_Setup_Prst.Controls.Add(this.checkBox_Setup_Prst);
			this.panel_Setup_Prst.Controls.Add(this.panel_Setup_PrstValue);
			this.panel_Setup_Prst.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Setup_Prst.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_Setup_Prst.Location = new System.Drawing.Point(3, 334);
			this.panel_Setup_Prst.Name = "panel_Setup_Prst";
			this.panel_Setup_Prst.Size = new System.Drawing.Size(286, 18);
			this.panel_Setup_Prst.TabIndex = 21;
			this.panel_Setup_Prst.Visible = false;
			this.checkBox_Setup_Prst.BackColor = System.Drawing.SystemColors.Window;
			this.checkBox_Setup_Prst.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_Prst.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkBox_Setup_Prst.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_Setup_Prst.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_Setup_Prst.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_Setup_Prst.Location = new System.Drawing.Point(0, 0);
			this.checkBox_Setup_Prst.Name = "checkBox_Setup_Prst";
			this.checkBox_Setup_Prst.Size = new System.Drawing.Size(140, 18);
			this.checkBox_Setup_Prst.TabIndex = 6;
			this.checkBox_Setup_Prst.Text = "Презентер/Ретракт";
			this.checkBox_Setup_Prst.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_Prst.UseVisualStyleBackColor = false;
			this.panel_Setup_PrstValue.BackColor = System.Drawing.Color.LightCyan;
			this.panel_Setup_PrstValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_Setup_PrstValue.Controls.Add(this.comboBox_Setup_Prst);
			this.panel_Setup_PrstValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_Setup_PrstValue.Location = new System.Drawing.Point(140, 0);
			this.panel_Setup_PrstValue.Name = "panel_Setup_PrstValue";
			this.panel_Setup_PrstValue.Size = new System.Drawing.Size(146, 19);
			this.panel_Setup_PrstValue.TabIndex = 25;
			this.comboBox_Setup_Prst.BackColor = System.Drawing.SystemColors.Window;
			this.comboBox_Setup_Prst.Dock = System.Windows.Forms.DockStyle.Fill;
			this.comboBox_Setup_Prst.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox_Setup_Prst.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.comboBox_Setup_Prst.FormattingEnabled = true;
			this.comboBox_Setup_Prst.Items.AddRange(new object[4] { "Не используется", "Ретракция", "Выброс", "Презентер" });
			this.comboBox_Setup_Prst.Location = new System.Drawing.Point(0, 0);
			this.comboBox_Setup_Prst.Name = "comboBox_Setup_Prst";
			this.comboBox_Setup_Prst.Size = new System.Drawing.Size(144, 21);
			this.comboBox_Setup_Prst.TabIndex = 7;
			this.comboBox_Setup_Prst.SelectedIndexChanged += new System.EventHandler(comboBox_Setup_Prst1_SelectedIndexChanged);
			this.panel_Setup_DrawerFall.BackColor = System.Drawing.Color.LightCyan;
			this.panel_Setup_DrawerFall.Controls.Add(this.numericUpDown_Setup_DrawerFall);
			this.panel_Setup_DrawerFall.Controls.Add(this.checkBox_Setup_DrawerFall);
			this.panel_Setup_DrawerFall.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Setup_DrawerFall.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_Setup_DrawerFall.Location = new System.Drawing.Point(3, 315);
			this.panel_Setup_DrawerFall.Name = "panel_Setup_DrawerFall";
			this.panel_Setup_DrawerFall.Size = new System.Drawing.Size(286, 19);
			this.panel_Setup_DrawerFall.TabIndex = 25;
			this.numericUpDown_Setup_DrawerFall.BackColor = System.Drawing.Color.LightCyan;
			this.numericUpDown_Setup_DrawerFall.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.numericUpDown_Setup_DrawerFall.Dock = System.Windows.Forms.DockStyle.Fill;
			this.numericUpDown_Setup_DrawerFall.Increment = new decimal(new int[4] { 10, 0, 0, 0 });
			this.numericUpDown_Setup_DrawerFall.Location = new System.Drawing.Point(140, 0);
			this.numericUpDown_Setup_DrawerFall.Maximum = new decimal(new int[4] { 1000, 0, 0, 0 });
			this.numericUpDown_Setup_DrawerFall.Name = "numericUpDown_Setup_DrawerFall";
			this.numericUpDown_Setup_DrawerFall.Size = new System.Drawing.Size(146, 20);
			this.numericUpDown_Setup_DrawerFall.TabIndex = 7;
			this.toolTip1.SetToolTip(this.numericUpDown_Setup_DrawerFall, "Длительность спада импульса денежного ящика (мс)");
			this.numericUpDown_Setup_DrawerFall.ValueChanged += new System.EventHandler(numericUpDown_Setup_DrawerFall_ValueChanged);
			this.checkBox_Setup_DrawerFall.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_DrawerFall.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkBox_Setup_DrawerFall.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_Setup_DrawerFall.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_Setup_DrawerFall.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_Setup_DrawerFall.Location = new System.Drawing.Point(0, 0);
			this.checkBox_Setup_DrawerFall.Name = "checkBox_Setup_DrawerFall";
			this.checkBox_Setup_DrawerFall.Size = new System.Drawing.Size(140, 19);
			this.checkBox_Setup_DrawerFall.TabIndex = 6;
			this.checkBox_Setup_DrawerFall.Text = "Спад импульса Д/Я";
			this.checkBox_Setup_DrawerFall.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.toolTip1.SetToolTip(this.checkBox_Setup_DrawerFall, "Денежный ящик");
			this.checkBox_Setup_DrawerFall.UseVisualStyleBackColor = true;
			this.panel_Setup_DrawerPulse.BackColor = System.Drawing.Color.Transparent;
			this.panel_Setup_DrawerPulse.Controls.Add(this.numericUpDown_Setup_DrawerPulse);
			this.panel_Setup_DrawerPulse.Controls.Add(this.checkBox_Setup_DrawerPulse);
			this.panel_Setup_DrawerPulse.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Setup_DrawerPulse.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_Setup_DrawerPulse.Location = new System.Drawing.Point(3, 296);
			this.panel_Setup_DrawerPulse.Name = "panel_Setup_DrawerPulse";
			this.panel_Setup_DrawerPulse.Size = new System.Drawing.Size(286, 19);
			this.panel_Setup_DrawerPulse.TabIndex = 24;
			this.numericUpDown_Setup_DrawerPulse.BackColor = System.Drawing.SystemColors.Window;
			this.numericUpDown_Setup_DrawerPulse.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.numericUpDown_Setup_DrawerPulse.Dock = System.Windows.Forms.DockStyle.Fill;
			this.numericUpDown_Setup_DrawerPulse.Increment = new decimal(new int[4] { 10, 0, 0, 0 });
			this.numericUpDown_Setup_DrawerPulse.Location = new System.Drawing.Point(140, 0);
			this.numericUpDown_Setup_DrawerPulse.Maximum = new decimal(new int[4] { 1000, 0, 0, 0 });
			this.numericUpDown_Setup_DrawerPulse.Name = "numericUpDown_Setup_DrawerPulse";
			this.numericUpDown_Setup_DrawerPulse.Size = new System.Drawing.Size(146, 20);
			this.numericUpDown_Setup_DrawerPulse.TabIndex = 7;
			this.toolTip1.SetToolTip(this.numericUpDown_Setup_DrawerPulse, "Длительность фронта импульса денежного ящика (мс)");
			this.numericUpDown_Setup_DrawerPulse.ValueChanged += new System.EventHandler(numericUpDown_Setup_DrawerPulse_ValueChanged);
			this.checkBox_Setup_DrawerPulse.BackColor = System.Drawing.SystemColors.Window;
			this.checkBox_Setup_DrawerPulse.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_DrawerPulse.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkBox_Setup_DrawerPulse.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_Setup_DrawerPulse.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_Setup_DrawerPulse.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_Setup_DrawerPulse.Location = new System.Drawing.Point(0, 0);
			this.checkBox_Setup_DrawerPulse.Name = "checkBox_Setup_DrawerPulse";
			this.checkBox_Setup_DrawerPulse.Size = new System.Drawing.Size(140, 19);
			this.checkBox_Setup_DrawerPulse.TabIndex = 6;
			this.checkBox_Setup_DrawerPulse.Text = "Фронт импульса Д/Я";
			this.checkBox_Setup_DrawerPulse.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.toolTip1.SetToolTip(this.checkBox_Setup_DrawerPulse, "Денежный ящик");
			this.checkBox_Setup_DrawerPulse.UseVisualStyleBackColor = false;
			this.panel_Setup_DrawerPin.BackColor = System.Drawing.Color.LightCyan;
			this.panel_Setup_DrawerPin.Controls.Add(this.numericUpDown_Setup_DrawerPin);
			this.panel_Setup_DrawerPin.Controls.Add(this.checkBox_Setup_DrawerPin);
			this.panel_Setup_DrawerPin.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Setup_DrawerPin.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_Setup_DrawerPin.Location = new System.Drawing.Point(3, 277);
			this.panel_Setup_DrawerPin.Name = "panel_Setup_DrawerPin";
			this.panel_Setup_DrawerPin.Size = new System.Drawing.Size(286, 19);
			this.panel_Setup_DrawerPin.TabIndex = 23;
			this.numericUpDown_Setup_DrawerPin.BackColor = System.Drawing.Color.LightCyan;
			this.numericUpDown_Setup_DrawerPin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.numericUpDown_Setup_DrawerPin.Dock = System.Windows.Forms.DockStyle.Fill;
			this.numericUpDown_Setup_DrawerPin.Location = new System.Drawing.Point(140, 0);
			this.numericUpDown_Setup_DrawerPin.Maximum = new decimal(new int[4] { 9, 0, 0, 0 });
			this.numericUpDown_Setup_DrawerPin.Name = "numericUpDown_Setup_DrawerPin";
			this.numericUpDown_Setup_DrawerPin.Size = new System.Drawing.Size(146, 20);
			this.numericUpDown_Setup_DrawerPin.TabIndex = 7;
			this.toolTip1.SetToolTip(this.numericUpDown_Setup_DrawerPin, "Номер контакта разъема денежного ящика");
			this.numericUpDown_Setup_DrawerPin.ValueChanged += new System.EventHandler(numericUpDown_Setup_DrawerPin_ValueChanged);
			this.checkBox_Setup_DrawerPin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_DrawerPin.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkBox_Setup_DrawerPin.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_Setup_DrawerPin.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_Setup_DrawerPin.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_Setup_DrawerPin.Location = new System.Drawing.Point(0, 0);
			this.checkBox_Setup_DrawerPin.Name = "checkBox_Setup_DrawerPin";
			this.checkBox_Setup_DrawerPin.Size = new System.Drawing.Size(140, 19);
			this.checkBox_Setup_DrawerPin.TabIndex = 6;
			this.checkBox_Setup_DrawerPin.Text = "Номер контакта Д/Я";
			this.checkBox_Setup_DrawerPin.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.toolTip1.SetToolTip(this.checkBox_Setup_DrawerPin, "Денежный ящик");
			this.checkBox_Setup_DrawerPin.UseVisualStyleBackColor = true;
			this.panel_Setup_ItemCnt.BackColor = System.Drawing.Color.Transparent;
			this.panel_Setup_ItemCnt.Controls.Add(this.panel_ItemCntYesNo);
			this.panel_Setup_ItemCnt.Controls.Add(this.checkBox_Setup_ItemCnt);
			this.panel_Setup_ItemCnt.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Setup_ItemCnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_Setup_ItemCnt.Location = new System.Drawing.Point(3, 260);
			this.panel_Setup_ItemCnt.Name = "panel_Setup_ItemCnt";
			this.panel_Setup_ItemCnt.Size = new System.Drawing.Size(286, 17);
			this.panel_Setup_ItemCnt.TabIndex = 20;
			this.panel_ItemCntYesNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_ItemCntYesNo.Controls.Add(this.radio_Setup_ItemCnt_Yes);
			this.panel_ItemCntYesNo.Controls.Add(this.radio_Setup_ItemCnt_No);
			this.panel_ItemCntYesNo.Location = new System.Drawing.Point(140, 0);
			this.panel_ItemCntYesNo.Name = "panel_ItemCntYesNo";
			this.panel_ItemCntYesNo.Size = new System.Drawing.Size(146, 18);
			this.panel_ItemCntYesNo.TabIndex = 8;
			this.radio_Setup_ItemCnt_Yes.AutoSize = true;
			this.radio_Setup_ItemCnt_Yes.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radio_Setup_ItemCnt_Yes.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radio_Setup_ItemCnt_Yes.Location = new System.Drawing.Point(4, 0);
			this.radio_Setup_ItemCnt_Yes.Name = "radio_Setup_ItemCnt_Yes";
			this.radio_Setup_ItemCnt_Yes.Size = new System.Drawing.Size(40, 17);
			this.radio_Setup_ItemCnt_Yes.TabIndex = 7;
			this.radio_Setup_ItemCnt_Yes.TabStop = true;
			this.radio_Setup_ItemCnt_Yes.Text = "Да";
			this.radio_Setup_ItemCnt_Yes.UseVisualStyleBackColor = true;
			this.radio_Setup_ItemCnt_Yes.CheckedChanged += new System.EventHandler(radio_Setup_ItemCnt_Yes_CheckedChanged);
			this.radio_Setup_ItemCnt_No.AutoSize = true;
			this.radio_Setup_ItemCnt_No.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radio_Setup_ItemCnt_No.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radio_Setup_ItemCnt_No.Location = new System.Drawing.Point(74, 0);
			this.radio_Setup_ItemCnt_No.Name = "radio_Setup_ItemCnt_No";
			this.radio_Setup_ItemCnt_No.Size = new System.Drawing.Size(44, 17);
			this.radio_Setup_ItemCnt_No.TabIndex = 8;
			this.radio_Setup_ItemCnt_No.TabStop = true;
			this.radio_Setup_ItemCnt_No.Text = "Нет";
			this.radio_Setup_ItemCnt_No.UseVisualStyleBackColor = true;
			this.radio_Setup_ItemCnt_No.CheckedChanged += new System.EventHandler(radio_Setup_ItemCnt_Yes_CheckedChanged);
			this.checkBox_Setup_ItemCnt.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_ItemCnt.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkBox_Setup_ItemCnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_Setup_ItemCnt.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_Setup_ItemCnt.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_Setup_ItemCnt.Location = new System.Drawing.Point(0, 0);
			this.checkBox_Setup_ItemCnt.Name = "checkBox_Setup_ItemCnt";
			this.checkBox_Setup_ItemCnt.Size = new System.Drawing.Size(140, 17);
			this.checkBox_Setup_ItemCnt.TabIndex = 6;
			this.checkBox_Setup_ItemCnt.Text = "К-во покупок в чеке";
			this.checkBox_Setup_ItemCnt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_ItemCnt.UseVisualStyleBackColor = true;
			this.panel_Setup_DrawerOpen.BackColor = System.Drawing.Color.LightCyan;
			this.panel_Setup_DrawerOpen.Controls.Add(this.panel_Setup_DrawerOpen_Y_N);
			this.panel_Setup_DrawerOpen.Controls.Add(this.checkBox_Setup_Cash);
			this.panel_Setup_DrawerOpen.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Setup_DrawerOpen.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_Setup_DrawerOpen.Location = new System.Drawing.Point(3, 243);
			this.panel_Setup_DrawerOpen.Name = "panel_Setup_DrawerOpen";
			this.panel_Setup_DrawerOpen.Size = new System.Drawing.Size(286, 17);
			this.panel_Setup_DrawerOpen.TabIndex = 16;
			this.panel_Setup_DrawerOpen_Y_N.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_Setup_DrawerOpen_Y_N.Controls.Add(this.checkBox_Drawer_Beznal);
			this.panel_Setup_DrawerOpen_Y_N.Controls.Add(this.checkBox_Drawer_Nal);
			this.panel_Setup_DrawerOpen_Y_N.Location = new System.Drawing.Point(140, 0);
			this.panel_Setup_DrawerOpen_Y_N.Name = "panel_Setup_DrawerOpen_Y_N";
			this.panel_Setup_DrawerOpen_Y_N.Size = new System.Drawing.Size(146, 18);
			this.panel_Setup_DrawerOpen_Y_N.TabIndex = 8;
			this.checkBox_Drawer_Beznal.AutoSize = true;
			this.checkBox_Drawer_Beznal.ForeColor = System.Drawing.SystemColors.ControlText;
			this.checkBox_Drawer_Beznal.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_Drawer_Beznal.Location = new System.Drawing.Point(74, 0);
			this.checkBox_Drawer_Beznal.Name = "checkBox_Drawer_Beznal";
			this.checkBox_Drawer_Beznal.Size = new System.Drawing.Size(63, 17);
			this.checkBox_Drawer_Beznal.TabIndex = 9;
			this.checkBox_Drawer_Beznal.Text = "Безнал";
			this.checkBox_Drawer_Beznal.UseVisualStyleBackColor = true;
			this.checkBox_Drawer_Beznal.CheckedChanged += new System.EventHandler(checkBox_Drawer_CheckedChanged);
			this.checkBox_Drawer_Nal.AutoSize = true;
			this.checkBox_Drawer_Nal.ForeColor = System.Drawing.SystemColors.ControlText;
			this.checkBox_Drawer_Nal.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_Drawer_Nal.Location = new System.Drawing.Point(4, 0);
			this.checkBox_Drawer_Nal.Name = "checkBox_Drawer_Nal";
			this.checkBox_Drawer_Nal.Size = new System.Drawing.Size(46, 17);
			this.checkBox_Drawer_Nal.TabIndex = 9;
			this.checkBox_Drawer_Nal.Text = "Нал";
			this.checkBox_Drawer_Nal.UseVisualStyleBackColor = true;
			this.checkBox_Drawer_Nal.CheckedChanged += new System.EventHandler(checkBox_Drawer_CheckedChanged);
			this.checkBox_Setup_Cash.BackColor = System.Drawing.Color.Transparent;
			this.checkBox_Setup_Cash.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_Cash.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkBox_Setup_Cash.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_Setup_Cash.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_Setup_Cash.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_Setup_Cash.Location = new System.Drawing.Point(0, 0);
			this.checkBox_Setup_Cash.Name = "checkBox_Setup_Cash";
			this.checkBox_Setup_Cash.Size = new System.Drawing.Size(140, 17);
			this.checkBox_Setup_Cash.TabIndex = 6;
			this.checkBox_Setup_Cash.Text = "Открыть ящик";
			this.checkBox_Setup_Cash.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_Cash.UseVisualStyleBackColor = true;
			this.panel_Setup_AutoTest.BackColor = System.Drawing.Color.Transparent;
			this.panel_Setup_AutoTest.Controls.Add(this.panel_Setup_AutoTest_Y_N);
			this.panel_Setup_AutoTest.Controls.Add(this.checkBox_Setup_AutoTest);
			this.panel_Setup_AutoTest.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Setup_AutoTest.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_Setup_AutoTest.Location = new System.Drawing.Point(3, 226);
			this.panel_Setup_AutoTest.Name = "panel_Setup_AutoTest";
			this.panel_Setup_AutoTest.Size = new System.Drawing.Size(286, 17);
			this.panel_Setup_AutoTest.TabIndex = 12;
			this.panel_Setup_AutoTest_Y_N.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_Setup_AutoTest_Y_N.Controls.Add(this.radio_Setup_AutoTest_Yes);
			this.panel_Setup_AutoTest_Y_N.Controls.Add(this.radio_Setup_AutoTest_No);
			this.panel_Setup_AutoTest_Y_N.Location = new System.Drawing.Point(140, 0);
			this.panel_Setup_AutoTest_Y_N.Name = "panel_Setup_AutoTest_Y_N";
			this.panel_Setup_AutoTest_Y_N.Size = new System.Drawing.Size(146, 18);
			this.panel_Setup_AutoTest_Y_N.TabIndex = 8;
			this.radio_Setup_AutoTest_Yes.AutoSize = true;
			this.radio_Setup_AutoTest_Yes.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radio_Setup_AutoTest_Yes.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radio_Setup_AutoTest_Yes.Location = new System.Drawing.Point(4, 0);
			this.radio_Setup_AutoTest_Yes.Name = "radio_Setup_AutoTest_Yes";
			this.radio_Setup_AutoTest_Yes.Size = new System.Drawing.Size(40, 17);
			this.radio_Setup_AutoTest_Yes.TabIndex = 7;
			this.radio_Setup_AutoTest_Yes.TabStop = true;
			this.radio_Setup_AutoTest_Yes.Text = "Да";
			this.radio_Setup_AutoTest_Yes.UseVisualStyleBackColor = true;
			this.radio_Setup_AutoTest_Yes.CheckedChanged += new System.EventHandler(radio_Setup_AutoTest_Yes_CheckedChanged);
			this.radio_Setup_AutoTest_No.AutoSize = true;
			this.radio_Setup_AutoTest_No.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radio_Setup_AutoTest_No.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radio_Setup_AutoTest_No.Location = new System.Drawing.Point(74, 0);
			this.radio_Setup_AutoTest_No.Name = "radio_Setup_AutoTest_No";
			this.radio_Setup_AutoTest_No.Size = new System.Drawing.Size(44, 17);
			this.radio_Setup_AutoTest_No.TabIndex = 8;
			this.radio_Setup_AutoTest_No.TabStop = true;
			this.radio_Setup_AutoTest_No.Text = "Нет";
			this.radio_Setup_AutoTest_No.UseVisualStyleBackColor = true;
			this.radio_Setup_AutoTest_No.CheckedChanged += new System.EventHandler(radio_Setup_AutoTest_Yes_CheckedChanged);
			this.checkBox_Setup_AutoTest.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_AutoTest.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkBox_Setup_AutoTest.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_Setup_AutoTest.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_Setup_AutoTest.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_Setup_AutoTest.Location = new System.Drawing.Point(0, 0);
			this.checkBox_Setup_AutoTest.Name = "checkBox_Setup_AutoTest";
			this.checkBox_Setup_AutoTest.Size = new System.Drawing.Size(140, 17);
			this.checkBox_Setup_AutoTest.TabIndex = 6;
			this.checkBox_Setup_AutoTest.Text = "Печать авто-теста";
			this.checkBox_Setup_AutoTest.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_AutoTest.UseVisualStyleBackColor = true;
			this.panel_Setup_Beeper.BackColor = System.Drawing.Color.LightCyan;
			this.panel_Setup_Beeper.Controls.Add(this.panel_Setup_Beeper_Y_N);
			this.panel_Setup_Beeper.Controls.Add(this.checkBox_Setup_Beeper);
			this.panel_Setup_Beeper.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Setup_Beeper.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_Setup_Beeper.Location = new System.Drawing.Point(3, 209);
			this.panel_Setup_Beeper.Name = "panel_Setup_Beeper";
			this.panel_Setup_Beeper.Size = new System.Drawing.Size(286, 17);
			this.panel_Setup_Beeper.TabIndex = 17;
			this.panel_Setup_Beeper_Y_N.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_Setup_Beeper_Y_N.Controls.Add(this.radio_Setup_Beeper_Yes);
			this.panel_Setup_Beeper_Y_N.Controls.Add(this.radio_Setup_Beeper_No);
			this.panel_Setup_Beeper_Y_N.Location = new System.Drawing.Point(140, 0);
			this.panel_Setup_Beeper_Y_N.Name = "panel_Setup_Beeper_Y_N";
			this.panel_Setup_Beeper_Y_N.Size = new System.Drawing.Size(146, 18);
			this.panel_Setup_Beeper_Y_N.TabIndex = 8;
			this.radio_Setup_Beeper_Yes.AutoSize = true;
			this.radio_Setup_Beeper_Yes.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radio_Setup_Beeper_Yes.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radio_Setup_Beeper_Yes.Location = new System.Drawing.Point(4, 0);
			this.radio_Setup_Beeper_Yes.Name = "radio_Setup_Beeper_Yes";
			this.radio_Setup_Beeper_Yes.Size = new System.Drawing.Size(40, 17);
			this.radio_Setup_Beeper_Yes.TabIndex = 7;
			this.radio_Setup_Beeper_Yes.TabStop = true;
			this.radio_Setup_Beeper_Yes.Text = "Да";
			this.radio_Setup_Beeper_Yes.UseVisualStyleBackColor = true;
			this.radio_Setup_Beeper_Yes.CheckedChanged += new System.EventHandler(radio_Setup_Beeper_Yes_CheckedChanged);
			this.radio_Setup_Beeper_No.AutoSize = true;
			this.radio_Setup_Beeper_No.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radio_Setup_Beeper_No.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radio_Setup_Beeper_No.Location = new System.Drawing.Point(74, 0);
			this.radio_Setup_Beeper_No.Name = "radio_Setup_Beeper_No";
			this.radio_Setup_Beeper_No.Size = new System.Drawing.Size(44, 17);
			this.radio_Setup_Beeper_No.TabIndex = 8;
			this.radio_Setup_Beeper_No.TabStop = true;
			this.radio_Setup_Beeper_No.Text = "Нет";
			this.radio_Setup_Beeper_No.UseVisualStyleBackColor = true;
			this.radio_Setup_Beeper_No.CheckedChanged += new System.EventHandler(radio_Setup_Beeper_Yes_CheckedChanged);
			this.checkBox_Setup_Beeper.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_Beeper.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkBox_Setup_Beeper.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_Setup_Beeper.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_Setup_Beeper.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_Setup_Beeper.Location = new System.Drawing.Point(0, 0);
			this.checkBox_Setup_Beeper.Name = "checkBox_Setup_Beeper";
			this.checkBox_Setup_Beeper.Size = new System.Drawing.Size(140, 17);
			this.checkBox_Setup_Beeper.TabIndex = 6;
			this.checkBox_Setup_Beeper.Text = "Сигнал конца бумаги";
			this.checkBox_Setup_Beeper.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_Beeper.UseVisualStyleBackColor = true;
			this.panel_Setup_PaperCut.BackColor = System.Drawing.Color.Transparent;
			this.panel_Setup_PaperCut.Controls.Add(this.panel_Setup_PaperCut_Y_N);
			this.panel_Setup_PaperCut.Controls.Add(this.checkBox_Setup_PaperCut);
			this.panel_Setup_PaperCut.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Setup_PaperCut.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_Setup_PaperCut.Location = new System.Drawing.Point(3, 192);
			this.panel_Setup_PaperCut.Name = "panel_Setup_PaperCut";
			this.panel_Setup_PaperCut.Size = new System.Drawing.Size(286, 17);
			this.panel_Setup_PaperCut.TabIndex = 11;
			this.panel_Setup_PaperCut_Y_N.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_Setup_PaperCut_Y_N.Controls.Add(this.radio_Setup_PaperCut_Yes);
			this.panel_Setup_PaperCut_Y_N.Controls.Add(this.radio_Setup_PaperCut_No);
			this.panel_Setup_PaperCut_Y_N.Location = new System.Drawing.Point(140, 0);
			this.panel_Setup_PaperCut_Y_N.Name = "panel_Setup_PaperCut_Y_N";
			this.panel_Setup_PaperCut_Y_N.Size = new System.Drawing.Size(146, 18);
			this.panel_Setup_PaperCut_Y_N.TabIndex = 8;
			this.radio_Setup_PaperCut_Yes.AutoSize = true;
			this.radio_Setup_PaperCut_Yes.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radio_Setup_PaperCut_Yes.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radio_Setup_PaperCut_Yes.Location = new System.Drawing.Point(4, 0);
			this.radio_Setup_PaperCut_Yes.Name = "radio_Setup_PaperCut_Yes";
			this.radio_Setup_PaperCut_Yes.Size = new System.Drawing.Size(40, 17);
			this.radio_Setup_PaperCut_Yes.TabIndex = 7;
			this.radio_Setup_PaperCut_Yes.TabStop = true;
			this.radio_Setup_PaperCut_Yes.Text = "Да";
			this.radio_Setup_PaperCut_Yes.UseVisualStyleBackColor = true;
			this.radio_Setup_PaperCut_Yes.CheckedChanged += new System.EventHandler(radio_Setup_PaperCut_Yes_CheckedChanged);
			this.radio_Setup_PaperCut_No.AutoSize = true;
			this.radio_Setup_PaperCut_No.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radio_Setup_PaperCut_No.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radio_Setup_PaperCut_No.Location = new System.Drawing.Point(74, 0);
			this.radio_Setup_PaperCut_No.Name = "radio_Setup_PaperCut_No";
			this.radio_Setup_PaperCut_No.Size = new System.Drawing.Size(44, 17);
			this.radio_Setup_PaperCut_No.TabIndex = 8;
			this.radio_Setup_PaperCut_No.TabStop = true;
			this.radio_Setup_PaperCut_No.Text = "Нет";
			this.radio_Setup_PaperCut_No.UseVisualStyleBackColor = true;
			this.checkBox_Setup_PaperCut.BackColor = System.Drawing.Color.Transparent;
			this.checkBox_Setup_PaperCut.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_PaperCut.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkBox_Setup_PaperCut.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_Setup_PaperCut.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_Setup_PaperCut.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_Setup_PaperCut.Location = new System.Drawing.Point(0, 0);
			this.checkBox_Setup_PaperCut.Name = "checkBox_Setup_PaperCut";
			this.checkBox_Setup_PaperCut.Size = new System.Drawing.Size(140, 17);
			this.checkBox_Setup_PaperCut.TabIndex = 6;
			this.checkBox_Setup_PaperCut.Text = "Отрезка чека";
			this.checkBox_Setup_PaperCut.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_PaperCut.UseVisualStyleBackColor = true;
			this.panel_Setup_QRText.BackColor = System.Drawing.Color.LightCyan;
			this.panel_Setup_QRText.Controls.Add(this.panel_Setup_QRText_Y_N);
			this.panel_Setup_QRText.Controls.Add(this.checkBox_Setup_QRText);
			this.panel_Setup_QRText.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Setup_QRText.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_Setup_QRText.Location = new System.Drawing.Point(3, 175);
			this.panel_Setup_QRText.Name = "panel_Setup_QRText";
			this.panel_Setup_QRText.Size = new System.Drawing.Size(286, 17);
			this.panel_Setup_QRText.TabIndex = 19;
			this.panel_Setup_QRText_Y_N.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_Setup_QRText_Y_N.Controls.Add(this.radio_Setup_QRText_Yes);
			this.panel_Setup_QRText_Y_N.Controls.Add(this.radio_Setup_QRText_No);
			this.panel_Setup_QRText_Y_N.Location = new System.Drawing.Point(140, 0);
			this.panel_Setup_QRText_Y_N.Name = "panel_Setup_QRText_Y_N";
			this.panel_Setup_QRText_Y_N.Size = new System.Drawing.Size(146, 18);
			this.panel_Setup_QRText_Y_N.TabIndex = 8;
			this.radio_Setup_QRText_Yes.AutoSize = true;
			this.radio_Setup_QRText_Yes.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radio_Setup_QRText_Yes.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radio_Setup_QRText_Yes.Location = new System.Drawing.Point(4, 0);
			this.radio_Setup_QRText_Yes.Name = "radio_Setup_QRText_Yes";
			this.radio_Setup_QRText_Yes.Size = new System.Drawing.Size(40, 17);
			this.radio_Setup_QRText_Yes.TabIndex = 7;
			this.radio_Setup_QRText_Yes.TabStop = true;
			this.radio_Setup_QRText_Yes.Text = "Да";
			this.radio_Setup_QRText_Yes.UseVisualStyleBackColor = true;
			this.radio_Setup_QRText_Yes.CheckedChanged += new System.EventHandler(radio_Setup_QRText_Yes_CheckedChanged);
			this.radio_Setup_QRText_No.AutoSize = true;
			this.radio_Setup_QRText_No.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radio_Setup_QRText_No.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radio_Setup_QRText_No.Location = new System.Drawing.Point(74, 0);
			this.radio_Setup_QRText_No.Name = "radio_Setup_QRText_No";
			this.radio_Setup_QRText_No.Size = new System.Drawing.Size(44, 17);
			this.radio_Setup_QRText_No.TabIndex = 8;
			this.radio_Setup_QRText_No.TabStop = true;
			this.radio_Setup_QRText_No.Text = "Нет";
			this.radio_Setup_QRText_No.UseVisualStyleBackColor = true;
			this.radio_Setup_QRText_No.CheckedChanged += new System.EventHandler(radio_Setup_QRText_Yes_CheckedChanged);
			this.checkBox_Setup_QRText.BackColor = System.Drawing.Color.Transparent;
			this.checkBox_Setup_QRText.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_QRText.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkBox_Setup_QRText.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_Setup_QRText.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_Setup_QRText.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_Setup_QRText.Location = new System.Drawing.Point(0, 0);
			this.checkBox_Setup_QRText.Name = "checkBox_Setup_QRText";
			this.checkBox_Setup_QRText.Size = new System.Drawing.Size(140, 17);
			this.checkBox_Setup_QRText.TabIndex = 6;
			this.checkBox_Setup_QRText.Text = "Текст рядом с QR";
			this.checkBox_Setup_QRText.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_QRText.UseVisualStyleBackColor = false;
			this.panel_Setup_FontType.BackColor = System.Drawing.Color.Transparent;
			this.panel_Setup_FontType.Controls.Add(this.panel_Setup_A_B);
			this.panel_Setup_FontType.Controls.Add(this.checkBox_Setup_FontType);
			this.panel_Setup_FontType.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Setup_FontType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_Setup_FontType.Location = new System.Drawing.Point(3, 158);
			this.panel_Setup_FontType.Name = "panel_Setup_FontType";
			this.panel_Setup_FontType.Size = new System.Drawing.Size(286, 17);
			this.panel_Setup_FontType.TabIndex = 7;
			this.panel_Setup_A_B.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_Setup_A_B.Controls.Add(this.radio_Setup_FontB);
			this.panel_Setup_A_B.Controls.Add(this.radio_Setup_FontA);
			this.panel_Setup_A_B.Location = new System.Drawing.Point(140, 0);
			this.panel_Setup_A_B.Name = "panel_Setup_A_B";
			this.panel_Setup_A_B.Size = new System.Drawing.Size(146, 18);
			this.panel_Setup_A_B.TabIndex = 8;
			this.radio_Setup_FontB.AutoSize = true;
			this.radio_Setup_FontB.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radio_Setup_FontB.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radio_Setup_FontB.Location = new System.Drawing.Point(74, 0);
			this.radio_Setup_FontB.Name = "radio_Setup_FontB";
			this.radio_Setup_FontB.Size = new System.Drawing.Size(32, 17);
			this.radio_Setup_FontB.TabIndex = 12;
			this.radio_Setup_FontB.TabStop = true;
			this.radio_Setup_FontB.Text = "B";
			this.radio_Setup_FontB.UseVisualStyleBackColor = true;
			this.radio_Setup_FontA.AutoSize = true;
			this.radio_Setup_FontA.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radio_Setup_FontA.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radio_Setup_FontA.Location = new System.Drawing.Point(4, 0);
			this.radio_Setup_FontA.Name = "radio_Setup_FontA";
			this.radio_Setup_FontA.Size = new System.Drawing.Size(32, 17);
			this.radio_Setup_FontA.TabIndex = 11;
			this.radio_Setup_FontA.TabStop = true;
			this.radio_Setup_FontA.Text = "A";
			this.radio_Setup_FontA.UseVisualStyleBackColor = true;
			this.radio_Setup_FontA.CheckedChanged += new System.EventHandler(radio_Setup_FontA_CheckedChanged);
			this.checkBox_Setup_FontType.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_FontType.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkBox_Setup_FontType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_Setup_FontType.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_Setup_FontType.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_Setup_FontType.Location = new System.Drawing.Point(0, 0);
			this.checkBox_Setup_FontType.Name = "checkBox_Setup_FontType";
			this.checkBox_Setup_FontType.Size = new System.Drawing.Size(140, 17);
			this.checkBox_Setup_FontType.TabIndex = 6;
			this.checkBox_Setup_FontType.Text = "Шрифт";
			this.checkBox_Setup_FontType.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_FontType.UseVisualStyleBackColor = true;
			this.panel_Setup_PaperWidth.BackColor = System.Drawing.Color.LightCyan;
			this.panel_Setup_PaperWidth.Controls.Add(this.panel_Setup_80_57);
			this.panel_Setup_PaperWidth.Controls.Add(this.checkBox_Setup_PaperWidth);
			this.panel_Setup_PaperWidth.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Setup_PaperWidth.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_Setup_PaperWidth.Location = new System.Drawing.Point(3, 141);
			this.panel_Setup_PaperWidth.Name = "panel_Setup_PaperWidth";
			this.panel_Setup_PaperWidth.Size = new System.Drawing.Size(286, 17);
			this.panel_Setup_PaperWidth.TabIndex = 8;
			this.panel_Setup_80_57.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_Setup_80_57.Controls.Add(this.radio_Setup_Paper57mm);
			this.panel_Setup_80_57.Controls.Add(this.radio_Setup_Paper80mm);
			this.panel_Setup_80_57.Location = new System.Drawing.Point(140, 0);
			this.panel_Setup_80_57.Name = "panel_Setup_80_57";
			this.panel_Setup_80_57.Size = new System.Drawing.Size(146, 18);
			this.panel_Setup_80_57.TabIndex = 7;
			this.radio_Setup_Paper57mm.AutoSize = true;
			this.radio_Setup_Paper57mm.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radio_Setup_Paper57mm.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radio_Setup_Paper57mm.Location = new System.Drawing.Point(74, 0);
			this.radio_Setup_Paper57mm.Name = "radio_Setup_Paper57mm";
			this.radio_Setup_Paper57mm.Size = new System.Drawing.Size(56, 17);
			this.radio_Setup_Paper57mm.TabIndex = 10;
			this.radio_Setup_Paper57mm.TabStop = true;
			this.radio_Setup_Paper57mm.Text = "57 мм";
			this.radio_Setup_Paper57mm.UseVisualStyleBackColor = true;
			this.radio_Setup_Paper80mm.AutoSize = true;
			this.radio_Setup_Paper80mm.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radio_Setup_Paper80mm.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radio_Setup_Paper80mm.Location = new System.Drawing.Point(4, 0);
			this.radio_Setup_Paper80mm.Name = "radio_Setup_Paper80mm";
			this.radio_Setup_Paper80mm.Size = new System.Drawing.Size(56, 17);
			this.radio_Setup_Paper80mm.TabIndex = 9;
			this.radio_Setup_Paper80mm.TabStop = true;
			this.radio_Setup_Paper80mm.Text = "80 мм";
			this.radio_Setup_Paper80mm.UseVisualStyleBackColor = true;
			this.radio_Setup_Paper80mm.CheckedChanged += new System.EventHandler(radio_Setup_Paper80mm_CheckedChanged);
			this.checkBox_Setup_PaperWidth.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_PaperWidth.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkBox_Setup_PaperWidth.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_Setup_PaperWidth.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_Setup_PaperWidth.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_Setup_PaperWidth.Location = new System.Drawing.Point(0, 0);
			this.checkBox_Setup_PaperWidth.Name = "checkBox_Setup_PaperWidth";
			this.checkBox_Setup_PaperWidth.Size = new System.Drawing.Size(140, 17);
			this.checkBox_Setup_PaperWidth.TabIndex = 6;
			this.checkBox_Setup_PaperWidth.Text = "Ширина";
			this.checkBox_Setup_PaperWidth.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_PaperWidth.UseVisualStyleBackColor = true;
			this.panel_Setup_LineType.BackColor = System.Drawing.Color.Transparent;
			this.panel_Setup_LineType.Controls.Add(this.panel_Setup_LineTypeValue);
			this.panel_Setup_LineType.Controls.Add(this.checkBox_Setup_LineType);
			this.panel_Setup_LineType.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Setup_LineType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_Setup_LineType.Location = new System.Drawing.Point(3, 123);
			this.panel_Setup_LineType.Name = "panel_Setup_LineType";
			this.panel_Setup_LineType.Size = new System.Drawing.Size(286, 18);
			this.panel_Setup_LineType.TabIndex = 10;
			this.panel_Setup_LineTypeValue.BackColor = System.Drawing.SystemColors.Window;
			this.panel_Setup_LineTypeValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_Setup_LineTypeValue.Controls.Add(this.comboBox_Setup_LineType);
			this.panel_Setup_LineTypeValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_Setup_LineTypeValue.Location = new System.Drawing.Point(140, 0);
			this.panel_Setup_LineTypeValue.Name = "panel_Setup_LineTypeValue";
			this.panel_Setup_LineTypeValue.Size = new System.Drawing.Size(146, 19);
			this.panel_Setup_LineTypeValue.TabIndex = 25;
			this.comboBox_Setup_LineType.BackColor = System.Drawing.SystemColors.Window;
			this.comboBox_Setup_LineType.Dock = System.Windows.Forms.DockStyle.Fill;
			this.comboBox_Setup_LineType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox_Setup_LineType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.comboBox_Setup_LineType.FormattingEnabled = true;
			this.comboBox_Setup_LineType.Items.AddRange(new object[3] { "None", "Symbols", "Graphics" });
			this.comboBox_Setup_LineType.Location = new System.Drawing.Point(0, 0);
			this.comboBox_Setup_LineType.Name = "comboBox_Setup_LineType";
			this.comboBox_Setup_LineType.Size = new System.Drawing.Size(144, 21);
			this.comboBox_Setup_LineType.TabIndex = 3;
			this.comboBox_Setup_LineType.SelectedIndexChanged += new System.EventHandler(comboBox_Setup_LineType_SelectedIndexChanged);
			this.checkBox_Setup_LineType.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_LineType.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkBox_Setup_LineType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_Setup_LineType.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_Setup_LineType.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_Setup_LineType.Location = new System.Drawing.Point(0, 0);
			this.checkBox_Setup_LineType.Name = "checkBox_Setup_LineType";
			this.checkBox_Setup_LineType.Size = new System.Drawing.Size(140, 18);
			this.checkBox_Setup_LineType.TabIndex = 6;
			this.checkBox_Setup_LineType.Text = "Разделитель";
			this.checkBox_Setup_LineType.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_LineType.UseVisualStyleBackColor = true;
			this.panel_Setup_Rounding.BackColor = System.Drawing.Color.LightCyan;
			this.panel_Setup_Rounding.Controls.Add(this.checkBox_Setup_Rounding);
			this.panel_Setup_Rounding.Controls.Add(this.panel_Setup_RoundingValue);
			this.panel_Setup_Rounding.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Setup_Rounding.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_Setup_Rounding.Location = new System.Drawing.Point(3, 105);
			this.panel_Setup_Rounding.Name = "panel_Setup_Rounding";
			this.panel_Setup_Rounding.Size = new System.Drawing.Size(286, 18);
			this.panel_Setup_Rounding.TabIndex = 9;
			this.checkBox_Setup_Rounding.BackColor = System.Drawing.Color.Transparent;
			this.checkBox_Setup_Rounding.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_Rounding.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkBox_Setup_Rounding.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_Setup_Rounding.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_Setup_Rounding.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_Setup_Rounding.Location = new System.Drawing.Point(0, 0);
			this.checkBox_Setup_Rounding.Name = "checkBox_Setup_Rounding";
			this.checkBox_Setup_Rounding.Size = new System.Drawing.Size(140, 18);
			this.checkBox_Setup_Rounding.TabIndex = 6;
			this.checkBox_Setup_Rounding.Text = "Округление итога";
			this.checkBox_Setup_Rounding.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_Rounding.UseVisualStyleBackColor = false;
			this.panel_Setup_RoundingValue.BackColor = System.Drawing.Color.LightCyan;
			this.panel_Setup_RoundingValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_Setup_RoundingValue.Controls.Add(this.comboBox_Setup_Rounding);
			this.panel_Setup_RoundingValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_Setup_RoundingValue.Location = new System.Drawing.Point(140, 0);
			this.panel_Setup_RoundingValue.Name = "panel_Setup_RoundingValue";
			this.panel_Setup_RoundingValue.Size = new System.Drawing.Size(146, 19);
			this.panel_Setup_RoundingValue.TabIndex = 25;
			this.comboBox_Setup_Rounding.BackColor = System.Drawing.Color.LightCyan;
			this.comboBox_Setup_Rounding.Dock = System.Windows.Forms.DockStyle.Fill;
			this.comboBox_Setup_Rounding.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox_Setup_Rounding.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.comboBox_Setup_Rounding.FormattingEnabled = true;
			this.comboBox_Setup_Rounding.Items.AddRange(new object[4] { "0.00", "0.10", "0.50", "1.00" });
			this.comboBox_Setup_Rounding.Location = new System.Drawing.Point(0, 0);
			this.comboBox_Setup_Rounding.Name = "comboBox_Setup_Rounding";
			this.comboBox_Setup_Rounding.Size = new System.Drawing.Size(144, 21);
			this.comboBox_Setup_Rounding.TabIndex = 3;
			this.comboBox_Setup_Rounding.SelectedIndexChanged += new System.EventHandler(comboBox_Setup_Rounding_SelectedIndexChanged);
			this.panel_Setup_QRAlign.BackColor = System.Drawing.Color.Transparent;
			this.panel_Setup_QRAlign.Controls.Add(this.panel_Setup_QRAlignValue);
			this.panel_Setup_QRAlign.Controls.Add(this.checkBox_Setup_QRAlign);
			this.panel_Setup_QRAlign.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Setup_QRAlign.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_Setup_QRAlign.Location = new System.Drawing.Point(3, 87);
			this.panel_Setup_QRAlign.Name = "panel_Setup_QRAlign";
			this.panel_Setup_QRAlign.Size = new System.Drawing.Size(286, 18);
			this.panel_Setup_QRAlign.TabIndex = 12;
			this.panel_Setup_QRAlignValue.BackColor = System.Drawing.SystemColors.Window;
			this.panel_Setup_QRAlignValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_Setup_QRAlignValue.Controls.Add(this.comboBox_Setup_QRAlign);
			this.panel_Setup_QRAlignValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_Setup_QRAlignValue.Location = new System.Drawing.Point(140, 0);
			this.panel_Setup_QRAlignValue.Name = "panel_Setup_QRAlignValue";
			this.panel_Setup_QRAlignValue.Size = new System.Drawing.Size(146, 19);
			this.panel_Setup_QRAlignValue.TabIndex = 25;
			this.comboBox_Setup_QRAlign.BackColor = System.Drawing.SystemColors.Window;
			this.comboBox_Setup_QRAlign.Dock = System.Windows.Forms.DockStyle.Fill;
			this.comboBox_Setup_QRAlign.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox_Setup_QRAlign.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.comboBox_Setup_QRAlign.FormattingEnabled = true;
			this.comboBox_Setup_QRAlign.Items.AddRange(new object[3] { "Слева", "По центру", "Справа" });
			this.comboBox_Setup_QRAlign.Location = new System.Drawing.Point(0, 0);
			this.comboBox_Setup_QRAlign.MaxDropDownItems = 3;
			this.comboBox_Setup_QRAlign.Name = "comboBox_Setup_QRAlign";
			this.comboBox_Setup_QRAlign.Size = new System.Drawing.Size(144, 21);
			this.comboBox_Setup_QRAlign.TabIndex = 4;
			this.comboBox_Setup_QRAlign.SelectedIndexChanged += new System.EventHandler(comboBox_Setup_QRAlign_SelectedIndexChanged);
			this.checkBox_Setup_QRAlign.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_QRAlign.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkBox_Setup_QRAlign.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_Setup_QRAlign.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_Setup_QRAlign.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_Setup_QRAlign.Location = new System.Drawing.Point(0, 0);
			this.checkBox_Setup_QRAlign.Name = "checkBox_Setup_QRAlign";
			this.checkBox_Setup_QRAlign.Size = new System.Drawing.Size(140, 18);
			this.checkBox_Setup_QRAlign.TabIndex = 6;
			this.checkBox_Setup_QRAlign.Text = "Положение QR кода";
			this.checkBox_Setup_QRAlign.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_QRAlign.UseVisualStyleBackColor = true;
			this.panel_PrinterModel.BackColor = System.Drawing.Color.LightCyan;
			this.panel_PrinterModel.Controls.Add(this.checkBox_Setup_PrinterModel);
			this.panel_PrinterModel.Controls.Add(this.panel_PrinterModelValue);
			this.panel_PrinterModel.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_PrinterModel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_PrinterModel.Location = new System.Drawing.Point(3, 69);
			this.panel_PrinterModel.Name = "panel_PrinterModel";
			this.panel_PrinterModel.Size = new System.Drawing.Size(286, 18);
			this.panel_PrinterModel.TabIndex = 6;
			this.checkBox_Setup_PrinterModel.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_PrinterModel.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkBox_Setup_PrinterModel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_Setup_PrinterModel.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_Setup_PrinterModel.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_Setup_PrinterModel.Location = new System.Drawing.Point(0, 0);
			this.checkBox_Setup_PrinterModel.Name = "checkBox_Setup_PrinterModel";
			this.checkBox_Setup_PrinterModel.Size = new System.Drawing.Size(140, 18);
			this.checkBox_Setup_PrinterModel.TabIndex = 6;
			this.checkBox_Setup_PrinterModel.Text = "Модель принтера";
			this.checkBox_Setup_PrinterModel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_PrinterModel.UseVisualStyleBackColor = true;
			this.panel_PrinterModelValue.BackColor = System.Drawing.Color.LightCyan;
			this.panel_PrinterModelValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_PrinterModelValue.Controls.Add(this.comboBox_Setup_PrinterModel);
			this.panel_PrinterModelValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_PrinterModelValue.Location = new System.Drawing.Point(140, 0);
			this.panel_PrinterModelValue.Name = "panel_PrinterModelValue";
			this.panel_PrinterModelValue.Size = new System.Drawing.Size(146, 19);
			this.panel_PrinterModelValue.TabIndex = 25;
			this.comboBox_Setup_PrinterModel.BackColor = System.Drawing.Color.LightCyan;
			this.comboBox_Setup_PrinterModel.Dock = System.Windows.Forms.DockStyle.Fill;
			this.comboBox_Setup_PrinterModel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox_Setup_PrinterModel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.comboBox_Setup_PrinterModel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.comboBox_Setup_PrinterModel.FormattingEnabled = true;
			this.comboBox_Setup_PrinterModel.Location = new System.Drawing.Point(0, 0);
			this.comboBox_Setup_PrinterModel.Margin = new System.Windows.Forms.Padding(0);
			this.comboBox_Setup_PrinterModel.Name = "comboBox_Setup_PrinterModel";
			this.comboBox_Setup_PrinterModel.Size = new System.Drawing.Size(144, 21);
			this.comboBox_Setup_PrinterModel.TabIndex = 14;
			this.comboBox_Setup_PrinterModel.SelectedIndexChanged += new System.EventHandler(comboBox_Setup_PrinterModel_SelectedIndexChanged);
			this.panel_Setup_Buttons.Controls.Add(this.button_Setup_Set);
			this.panel_Setup_Buttons.Controls.Add(this.button_Setup_Get);
			this.panel_Setup_Buttons.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel_Setup_Buttons.Location = new System.Drawing.Point(3, 375);
			this.panel_Setup_Buttons.Name = "panel_Setup_Buttons";
			this.panel_Setup_Buttons.Padding = new System.Windows.Forms.Padding(3);
			this.panel_Setup_Buttons.Size = new System.Drawing.Size(286, 35);
			this.panel_Setup_Buttons.TabIndex = 1;
			this.button_Setup_Set.Dock = System.Windows.Forms.DockStyle.Right;
			this.button_Setup_Set.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.button_Setup_Set.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_Setup_Set.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_Setup_Set.Location = new System.Drawing.Point(153, 3);
			this.button_Setup_Set.Name = "button_Setup_Set";
			this.button_Setup_Set.Size = new System.Drawing.Size(130, 29);
			this.button_Setup_Set.TabIndex = 0;
			this.button_Setup_Set.Text = "Установить";
			this.button_Setup_Set.UseVisualStyleBackColor = true;
			this.button_Setup_Set.Click += new System.EventHandler(button_Setup_Set_Click);
			this.button_Setup_Get.Dock = System.Windows.Forms.DockStyle.Left;
			this.button_Setup_Get.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.button_Setup_Get.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_Setup_Get.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_Setup_Get.Location = new System.Drawing.Point(3, 3);
			this.button_Setup_Get.Name = "button_Setup_Get";
			this.button_Setup_Get.Size = new System.Drawing.Size(130, 29);
			this.button_Setup_Get.TabIndex = 1;
			this.button_Setup_Get.Text = "Считать";
			this.button_Setup_Get.UseVisualStyleBackColor = true;
			this.button_Setup_Get.Click += new System.EventHandler(button_Setup_Get_Click);
			this.panel_Setup_PrBaudrate.BackColor = System.Drawing.Color.Transparent;
			this.panel_Setup_PrBaudrate.Controls.Add(this.panel_Setup_PrBaudrateValue);
			this.panel_Setup_PrBaudrate.Controls.Add(this.checkBox_Setup_PrBaudrate);
			this.panel_Setup_PrBaudrate.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Setup_PrBaudrate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_Setup_PrBaudrate.Location = new System.Drawing.Point(3, 51);
			this.panel_Setup_PrBaudrate.Name = "panel_Setup_PrBaudrate";
			this.panel_Setup_PrBaudrate.Size = new System.Drawing.Size(286, 18);
			this.panel_Setup_PrBaudrate.TabIndex = 15;
			this.panel_Setup_PrBaudrateValue.BackColor = System.Drawing.SystemColors.Window;
			this.panel_Setup_PrBaudrateValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_Setup_PrBaudrateValue.Controls.Add(this.comboBox_Setup_PrBaudrate);
			this.panel_Setup_PrBaudrateValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_Setup_PrBaudrateValue.Location = new System.Drawing.Point(140, 0);
			this.panel_Setup_PrBaudrateValue.Name = "panel_Setup_PrBaudrateValue";
			this.panel_Setup_PrBaudrateValue.Size = new System.Drawing.Size(146, 19);
			this.panel_Setup_PrBaudrateValue.TabIndex = 24;
			this.comboBox_Setup_PrBaudrate.BackColor = System.Drawing.SystemColors.Window;
			this.comboBox_Setup_PrBaudrate.Dock = System.Windows.Forms.DockStyle.Fill;
			this.comboBox_Setup_PrBaudrate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox_Setup_PrBaudrate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.comboBox_Setup_PrBaudrate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.comboBox_Setup_PrBaudrate.FormattingEnabled = true;
			this.comboBox_Setup_PrBaudrate.Items.AddRange(new object[6] { "115200", "57600", "38400", "19200", "14400", "9600" });
			this.comboBox_Setup_PrBaudrate.Location = new System.Drawing.Point(0, 0);
			this.comboBox_Setup_PrBaudrate.Margin = new System.Windows.Forms.Padding(0);
			this.comboBox_Setup_PrBaudrate.Name = "comboBox_Setup_PrBaudrate";
			this.comboBox_Setup_PrBaudrate.Size = new System.Drawing.Size(144, 21);
			this.comboBox_Setup_PrBaudrate.TabIndex = 14;
			this.comboBox_Setup_PrBaudrate.SelectedValueChanged += new System.EventHandler(comboBox_Setup_PRNBaudrate_SelectedIndexChanged);
			this.checkBox_Setup_PrBaudrate.BackColor = System.Drawing.Color.Transparent;
			this.checkBox_Setup_PrBaudrate.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_PrBaudrate.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkBox_Setup_PrBaudrate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_Setup_PrBaudrate.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_Setup_PrBaudrate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_Setup_PrBaudrate.Location = new System.Drawing.Point(0, 0);
			this.checkBox_Setup_PrBaudrate.Name = "checkBox_Setup_PrBaudrate";
			this.checkBox_Setup_PrBaudrate.Size = new System.Drawing.Size(140, 18);
			this.checkBox_Setup_PrBaudrate.TabIndex = 6;
			this.checkBox_Setup_PrBaudrate.Text = "Скорость принтера";
			this.checkBox_Setup_PrBaudrate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_PrBaudrate.UseVisualStyleBackColor = false;
			this.panel_Setup_COMBaudrate.BackColor = System.Drawing.Color.LightCyan;
			this.panel_Setup_COMBaudrate.Controls.Add(this.panel_Setup_COMBaudrateValue);
			this.panel_Setup_COMBaudrate.Controls.Add(this.checkBox_Setup_COMBaudrate);
			this.panel_Setup_COMBaudrate.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Setup_COMBaudrate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_Setup_COMBaudrate.Location = new System.Drawing.Point(3, 33);
			this.panel_Setup_COMBaudrate.Name = "panel_Setup_COMBaudrate";
			this.panel_Setup_COMBaudrate.Size = new System.Drawing.Size(286, 18);
			this.panel_Setup_COMBaudrate.TabIndex = 5;
			this.panel_Setup_COMBaudrateValue.BackColor = System.Drawing.Color.LightCyan;
			this.panel_Setup_COMBaudrateValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_Setup_COMBaudrateValue.Controls.Add(this.comboBox_Setup_COMBaudrate);
			this.panel_Setup_COMBaudrateValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_Setup_COMBaudrateValue.Location = new System.Drawing.Point(140, 0);
			this.panel_Setup_COMBaudrateValue.Name = "panel_Setup_COMBaudrateValue";
			this.panel_Setup_COMBaudrateValue.Size = new System.Drawing.Size(146, 19);
			this.panel_Setup_COMBaudrateValue.TabIndex = 23;
			this.comboBox_Setup_COMBaudrate.BackColor = System.Drawing.Color.LightCyan;
			this.comboBox_Setup_COMBaudrate.Dock = System.Windows.Forms.DockStyle.Fill;
			this.comboBox_Setup_COMBaudrate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox_Setup_COMBaudrate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.comboBox_Setup_COMBaudrate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.comboBox_Setup_COMBaudrate.FormattingEnabled = true;
			this.comboBox_Setup_COMBaudrate.IntegralHeight = false;
			this.comboBox_Setup_COMBaudrate.Items.AddRange(new object[6] { "115200", "57600", "38400", "19200", "14400", "9600" });
			this.comboBox_Setup_COMBaudrate.Location = new System.Drawing.Point(0, 0);
			this.comboBox_Setup_COMBaudrate.Margin = new System.Windows.Forms.Padding(0);
			this.comboBox_Setup_COMBaudrate.Name = "comboBox_Setup_COMBaudrate";
			this.comboBox_Setup_COMBaudrate.Size = new System.Drawing.Size(144, 21);
			this.comboBox_Setup_COMBaudrate.TabIndex = 14;
			this.comboBox_Setup_COMBaudrate.SelectedValueChanged += new System.EventHandler(comboBox_Setup_COMBaudrate_SelectedIndexChanged);
			this.checkBox_Setup_COMBaudrate.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_Setup_COMBaudrate.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkBox_Setup_COMBaudrate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_Setup_COMBaudrate.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_Setup_COMBaudrate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_Setup_COMBaudrate.Location = new System.Drawing.Point(0, 0);
			this.checkBox_Setup_COMBaudrate.Name = "checkBox_Setup_COMBaudrate";
			this.checkBox_Setup_COMBaudrate.Size = new System.Drawing.Size(140, 18);
			this.checkBox_Setup_COMBaudrate.TabIndex = 6;
			this.checkBox_Setup_COMBaudrate.Text = "Скорость COM порта";
			this.checkBox_Setup_COMBaudrate.TextAlign = System.Drawing.ContentAlignment.TopRight;
			this.checkBox_Setup_COMBaudrate.UseVisualStyleBackColor = true;
			this.panel_Setup_SelectAll.BackColor = System.Drawing.Color.Transparent;
			this.panel_Setup_SelectAll.Controls.Add(this.checkBox_Setup_SelectAll);
			this.panel_Setup_SelectAll.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Setup_SelectAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_Setup_SelectAll.Location = new System.Drawing.Point(3, 16);
			this.panel_Setup_SelectAll.Name = "panel_Setup_SelectAll";
			this.panel_Setup_SelectAll.Size = new System.Drawing.Size(286, 17);
			this.panel_Setup_SelectAll.TabIndex = 2;
			this.checkBox_Setup_SelectAll.BackColor = System.Drawing.Color.Transparent;
			this.checkBox_Setup_SelectAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_Setup_SelectAll.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_Setup_SelectAll.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_Setup_SelectAll.Location = new System.Drawing.Point(126, 0);
			this.checkBox_Setup_SelectAll.Name = "checkBox_Setup_SelectAll";
			this.checkBox_Setup_SelectAll.Size = new System.Drawing.Size(140, 17);
			this.checkBox_Setup_SelectAll.TabIndex = 6;
			this.checkBox_Setup_SelectAll.Text = "Выбрать все";
			this.checkBox_Setup_SelectAll.UseVisualStyleBackColor = false;
			this.checkBox_Setup_SelectAll.CheckedChanged += new System.EventHandler(checkBox_Setup_SelectAll_CheckedChanged);
			this.panel_LANSettings.Controls.Add(this.groupBox_LANSettings);
			this.panel_LANSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_LANSettings.Location = new System.Drawing.Point(3, 3);
			this.panel_LANSettings.Name = "panel_LANSettings";
			this.panel_LANSettings.Size = new System.Drawing.Size(320, 112);
			this.panel_LANSettings.TabIndex = 0;
			this.groupBox_LANSettings.Controls.Add(this.checkBox_LAN_SelectAll);
			this.groupBox_LANSettings.Controls.Add(this.label_LAN_Gateway);
			this.groupBox_LANSettings.Controls.Add(this.label_LAN_DNS);
			this.groupBox_LANSettings.Controls.Add(this.label_LAN_Port);
			this.groupBox_LANSettings.Controls.Add(this.label_LAN_Mask);
			this.groupBox_LANSettings.Controls.Add(this.checkedListBox_LAN);
			this.groupBox_LANSettings.Controls.Add(this.label_LAN_IP);
			this.groupBox_LANSettings.Controls.Add(this.dataGrid_LAN);
			this.groupBox_LANSettings.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox_LANSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_LANSettings.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_LANSettings.Location = new System.Drawing.Point(0, 0);
			this.groupBox_LANSettings.Name = "groupBox_LANSettings";
			this.groupBox_LANSettings.Size = new System.Drawing.Size(320, 112);
			this.groupBox_LANSettings.TabIndex = 9;
			this.groupBox_LANSettings.TabStop = false;
			this.groupBox_LANSettings.Text = "L A N";
			this.checkBox_LAN_SelectAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_LAN_SelectAll.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_LAN_SelectAll.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_LAN_SelectAll.Location = new System.Drawing.Point(136, 14);
			this.checkBox_LAN_SelectAll.Name = "checkBox_LAN_SelectAll";
			this.checkBox_LAN_SelectAll.Size = new System.Drawing.Size(147, 17);
			this.checkBox_LAN_SelectAll.TabIndex = 6;
			this.checkBox_LAN_SelectAll.Text = "Выбрать все";
			this.checkBox_LAN_SelectAll.UseVisualStyleBackColor = true;
			this.checkBox_LAN_SelectAll.CheckedChanged += new System.EventHandler(checkBox_LAN_SelectAll_CheckedChanged);
			this.label_LAN_Gateway.AutoSize = true;
			this.label_LAN_Gateway.BackColor = System.Drawing.Color.Transparent;
			this.label_LAN_Gateway.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_LAN_Gateway.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_LAN_Gateway.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_LAN_Gateway.Location = new System.Drawing.Point(3, 90);
			this.label_LAN_Gateway.MinimumSize = new System.Drawing.Size(131, 0);
			this.label_LAN_Gateway.Name = "label_LAN_Gateway";
			this.label_LAN_Gateway.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label_LAN_Gateway.Size = new System.Drawing.Size(131, 13);
			this.label_LAN_Gateway.TabIndex = 10;
			this.label_LAN_Gateway.Text = "Шлюз";
			this.label_LAN_Gateway.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.label_LAN_DNS.AutoSize = true;
			this.label_LAN_DNS.BackColor = System.Drawing.Color.LightCyan;
			this.label_LAN_DNS.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_LAN_DNS.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_LAN_DNS.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_LAN_DNS.Location = new System.Drawing.Point(3, 75);
			this.label_LAN_DNS.MinimumSize = new System.Drawing.Size(131, 0);
			this.label_LAN_DNS.Name = "label_LAN_DNS";
			this.label_LAN_DNS.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label_LAN_DNS.Size = new System.Drawing.Size(131, 13);
			this.label_LAN_DNS.TabIndex = 9;
			this.label_LAN_DNS.Text = "DNS";
			this.label_LAN_DNS.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.label_LAN_Port.AutoSize = true;
			this.label_LAN_Port.BackColor = System.Drawing.Color.Transparent;
			this.label_LAN_Port.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_LAN_Port.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_LAN_Port.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_LAN_Port.Location = new System.Drawing.Point(3, 60);
			this.label_LAN_Port.MinimumSize = new System.Drawing.Size(131, 0);
			this.label_LAN_Port.Name = "label_LAN_Port";
			this.label_LAN_Port.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label_LAN_Port.Size = new System.Drawing.Size(131, 13);
			this.label_LAN_Port.TabIndex = 8;
			this.label_LAN_Port.Text = "Порт";
			this.label_LAN_Port.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.label_LAN_Mask.AutoSize = true;
			this.label_LAN_Mask.BackColor = System.Drawing.Color.LightCyan;
			this.label_LAN_Mask.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_LAN_Mask.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_LAN_Mask.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_LAN_Mask.Location = new System.Drawing.Point(3, 45);
			this.label_LAN_Mask.MinimumSize = new System.Drawing.Size(131, 0);
			this.label_LAN_Mask.Name = "label_LAN_Mask";
			this.label_LAN_Mask.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label_LAN_Mask.Size = new System.Drawing.Size(131, 13);
			this.label_LAN_Mask.TabIndex = 7;
			this.label_LAN_Mask.Text = "Маска подсети";
			this.label_LAN_Mask.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkedListBox_LAN.BackColor = System.Drawing.SystemColors.Window;
			this.checkedListBox_LAN.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.checkedListBox_LAN.CheckOnClick = true;
			this.checkedListBox_LAN.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkedListBox_LAN.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkedListBox_LAN.FormattingEnabled = true;
			this.checkedListBox_LAN.Items.AddRange(new object[5] { "LAN: IP адрес ККТ", "Маска подсети", "Порт", "DNS-сервер", "Шлюз" });
			this.checkedListBox_LAN.Location = new System.Drawing.Point(136, 30);
			this.checkedListBox_LAN.Name = "checkedListBox_LAN";
			this.checkedListBox_LAN.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.checkedListBox_LAN.Size = new System.Drawing.Size(14, 75);
			this.checkedListBox_LAN.TabIndex = 3;
			this.label_LAN_IP.AutoSize = true;
			this.label_LAN_IP.BackColor = System.Drawing.Color.Transparent;
			this.label_LAN_IP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_LAN_IP.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_LAN_IP.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_LAN_IP.Location = new System.Drawing.Point(3, 30);
			this.label_LAN_IP.MinimumSize = new System.Drawing.Size(131, 0);
			this.label_LAN_IP.Name = "label_LAN_IP";
			this.label_LAN_IP.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label_LAN_IP.Size = new System.Drawing.Size(131, 13);
			this.label_LAN_IP.TabIndex = 5;
			this.label_LAN_IP.Text = "IP адрес";
			this.label_LAN_IP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.dataGrid_LAN.AllowUserToAddRows = false;
			this.dataGrid_LAN.AllowUserToDeleteRows = false;
			this.dataGrid_LAN.AllowUserToResizeColumns = false;
			this.dataGrid_LAN.AllowUserToResizeRows = false;
			dataGridViewCellStyle23.BackColor = System.Drawing.Color.LightCyan;
			this.dataGrid_LAN.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle23;
			this.dataGrid_LAN.BackgroundColor = System.Drawing.Color.LightCyan;
			this.dataGrid_LAN.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.dataGrid_LAN.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
			this.dataGrid_LAN.ColumnHeadersHeight = 15;
			this.dataGrid_LAN.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this.dataGrid_LAN.ColumnHeadersVisible = false;
			this.dataGrid_LAN.Columns.AddRange(this.dataGridViewTextBoxColumn_LAN);
			this.dataGrid_LAN.GridColor = System.Drawing.SystemColors.ActiveBorder;
			this.dataGrid_LAN.Location = new System.Drawing.Point(152, 30);
			this.dataGrid_LAN.MultiSelect = false;
			this.dataGrid_LAN.Name = "dataGrid_LAN";
			this.dataGrid_LAN.RowHeadersVisible = false;
			this.dataGrid_LAN.RowHeadersWidth = 4;
			this.dataGrid_LAN.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
			this.dataGrid_LAN.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 204);
			this.dataGrid_LAN.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.ControlDark;
			this.dataGrid_LAN.RowTemplate.DividerHeight = 1;
			this.dataGrid_LAN.RowTemplate.Height = 15;
			this.dataGrid_LAN.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
			this.dataGrid_LAN.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.dataGrid_LAN.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
			this.dataGrid_LAN.ShowCellToolTips = false;
			this.dataGrid_LAN.ShowEditingIcon = false;
			this.dataGrid_LAN.Size = new System.Drawing.Size(160, 77);
			this.dataGrid_LAN.TabIndex = 5;
			this.dataGrid_LAN.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(CellBeginEdit_ListBoxCheck);
			this.dataGridViewTextBoxColumn_LAN.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
			this.dataGridViewTextBoxColumn_LAN.DividerWidth = 1;
			this.dataGridViewTextBoxColumn_LAN.HeaderText = "Value";
			this.dataGridViewTextBoxColumn_LAN.MaxInputLength = 256;
			this.dataGridViewTextBoxColumn_LAN.Name = "dataGridViewTextBoxColumn_LAN";
			this.dataGridViewTextBoxColumn_LAN.Resizable = System.Windows.Forms.DataGridViewTriState.False;
			this.dataGridViewTextBoxColumn_LAN.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			this.dataGridViewTextBoxColumn_LAN.Width = 150;
			this.tabPage_Header.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.tabPage_Header.Controls.Add(this.panel_LogoPic);
			this.tabPage_Header.Controls.Add(this.groupBox_Header);
			this.tabPage_Header.Location = new System.Drawing.Point(154, 4);
			this.tabPage_Header.Name = "tabPage_Header";
			this.tabPage_Header.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage_Header.Size = new System.Drawing.Size(626, 424);
			this.tabPage_Header.TabIndex = 10;
			this.tabPage_Header.Text = "Клише и подвал";
			this.tabPage_Header.UseVisualStyleBackColor = true;
			this.panel_LogoPic.Controls.Add(this.groupBox_Picture);
			this.panel_LogoPic.Controls.Add(this.groupBox_Logo);
			this.panel_LogoPic.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_LogoPic.Location = new System.Drawing.Point(3, 241);
			this.panel_LogoPic.Name = "panel_LogoPic";
			this.panel_LogoPic.Padding = new System.Windows.Forms.Padding(3);
			this.panel_LogoPic.Size = new System.Drawing.Size(618, 149);
			this.panel_LogoPic.TabIndex = 18;
			this.groupBox_Picture.Controls.Add(this.pictureBox_Picture);
			this.groupBox_Picture.Controls.Add(this.panel_Picture);
			this.groupBox_Picture.Dock = System.Windows.Forms.DockStyle.Left;
			this.groupBox_Picture.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_Picture.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_Picture.Location = new System.Drawing.Point(309, 3);
			this.groupBox_Picture.Name = "groupBox_Picture";
			this.groupBox_Picture.Size = new System.Drawing.Size(306, 143);
			this.groupBox_Picture.TabIndex = 17;
			this.groupBox_Picture.TabStop = false;
			this.groupBox_Picture.Text = "Р и с у н о к";
			this.toolTip1.SetToolTip(this.groupBox_Picture, "Картинки 1-22 в чеке");
			this.pictureBox_Picture.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pictureBox_Picture.Dock = System.Windows.Forms.DockStyle.Fill;
			this.pictureBox_Picture.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.pictureBox_Picture.InitialImage = null;
			this.pictureBox_Picture.Location = new System.Drawing.Point(3, 45);
			this.pictureBox_Picture.Name = "pictureBox_Picture";
			this.pictureBox_Picture.Size = new System.Drawing.Size(300, 95);
			this.pictureBox_Picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pictureBox_Picture.TabIndex = 17;
			this.pictureBox_Picture.TabStop = false;
			this.toolTip1.SetToolTip(this.pictureBox_Picture, "Картинка перевернутая, инверсия цвета");
			this.panel_Picture.Controls.Add(this.button_PictureErase);
			this.panel_Picture.Controls.Add(this.button_PictureShow);
			this.panel_Picture.Controls.Add(this.button_Picture);
			this.panel_Picture.Controls.Add(this.numericUpDown_Picture);
			this.panel_Picture.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Picture.Location = new System.Drawing.Point(3, 16);
			this.panel_Picture.Name = "panel_Picture";
			this.panel_Picture.Padding = new System.Windows.Forms.Padding(3);
			this.panel_Picture.Size = new System.Drawing.Size(300, 29);
			this.panel_Picture.TabIndex = 16;
			this.button_PictureErase.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.button_PictureErase.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_PictureErase.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_PictureErase.Location = new System.Drawing.Point(214, 3);
			this.button_PictureErase.Name = "button_PictureErase";
			this.button_PictureErase.Size = new System.Drawing.Size(83, 23);
			this.button_PictureErase.TabIndex = 20;
			this.button_PictureErase.Text = "Удалить";
			this.button_PictureErase.UseVisualStyleBackColor = true;
			this.button_PictureErase.Click += new System.EventHandler(Button_LogoErase_Click);
			this.button_PictureShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.button_PictureShow.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_PictureShow.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_PictureShow.Location = new System.Drawing.Point(46, 3);
			this.button_PictureShow.Name = "button_PictureShow";
			this.button_PictureShow.Size = new System.Drawing.Size(83, 23);
			this.button_PictureShow.TabIndex = 3;
			this.button_PictureShow.Text = "Файл";
			this.button_PictureShow.UseVisualStyleBackColor = true;
			this.button_PictureShow.Click += new System.EventHandler(Button_LogoShow_Click);
			this.button_Picture.Enabled = false;
			this.button_Picture.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.button_Picture.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_Picture.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_Picture.Location = new System.Drawing.Point(130, 3);
			this.button_Picture.Name = "button_Picture";
			this.button_Picture.Size = new System.Drawing.Size(83, 23);
			this.button_Picture.TabIndex = 1;
			this.button_Picture.Text = "Установить";
			this.button_Picture.UseVisualStyleBackColor = true;
			this.button_Picture.Click += new System.EventHandler(Button_Logo_Download_Click);
			this.numericUpDown_Picture.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f, System.Drawing.FontStyle.Bold);
			this.numericUpDown_Picture.Location = new System.Drawing.Point(4, 4);
			this.numericUpDown_Picture.Maximum = new decimal(new int[4] { 22, 0, 0, 0 });
			this.numericUpDown_Picture.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			this.numericUpDown_Picture.Name = "numericUpDown_Picture";
			this.numericUpDown_Picture.Size = new System.Drawing.Size(40, 21);
			this.numericUpDown_Picture.TabIndex = 2;
			this.numericUpDown_Picture.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.numericUpDown_Picture.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			this.groupBox_Logo.Controls.Add(this.pictureBox_Logo);
			this.groupBox_Logo.Controls.Add(this.panel_Logo);
			this.groupBox_Logo.Dock = System.Windows.Forms.DockStyle.Left;
			this.groupBox_Logo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_Logo.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_Logo.Location = new System.Drawing.Point(3, 3);
			this.groupBox_Logo.Name = "groupBox_Logo";
			this.groupBox_Logo.Size = new System.Drawing.Size(306, 143);
			this.groupBox_Logo.TabIndex = 16;
			this.groupBox_Logo.TabStop = false;
			this.groupBox_Logo.Text = "Л о г о т и п";
			this.toolTip1.SetToolTip(this.groupBox_Logo, "Картинка - логотип чека");
			this.pictureBox_Logo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pictureBox_Logo.Dock = System.Windows.Forms.DockStyle.Fill;
			this.pictureBox_Logo.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.pictureBox_Logo.Location = new System.Drawing.Point(3, 45);
			this.pictureBox_Logo.Name = "pictureBox_Logo";
			this.pictureBox_Logo.Size = new System.Drawing.Size(300, 95);
			this.pictureBox_Logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pictureBox_Logo.TabIndex = 17;
			this.pictureBox_Logo.TabStop = false;
			this.toolTip1.SetToolTip(this.pictureBox_Logo, "Картинка перевернутая, инверсия цвета");
			this.panel_Logo.Controls.Add(this.button_LogoErase);
			this.panel_Logo.Controls.Add(this.button_LogoShow);
			this.panel_Logo.Controls.Add(this.textBox_Logo);
			this.panel_Logo.Controls.Add(this.button_Logo);
			this.panel_Logo.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Logo.Location = new System.Drawing.Point(3, 16);
			this.panel_Logo.Name = "panel_Logo";
			this.panel_Logo.Padding = new System.Windows.Forms.Padding(3);
			this.panel_Logo.Size = new System.Drawing.Size(300, 29);
			this.panel_Logo.TabIndex = 16;
			this.button_LogoErase.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.button_LogoErase.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_LogoErase.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_LogoErase.Location = new System.Drawing.Point(214, 3);
			this.button_LogoErase.Name = "button_LogoErase";
			this.button_LogoErase.Size = new System.Drawing.Size(83, 23);
			this.button_LogoErase.TabIndex = 19;
			this.button_LogoErase.Text = "Удалить";
			this.button_LogoErase.UseVisualStyleBackColor = true;
			this.button_LogoErase.Click += new System.EventHandler(Button_LogoErase_Click);
			this.button_LogoShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.button_LogoShow.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_LogoShow.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_LogoShow.Location = new System.Drawing.Point(46, 3);
			this.button_LogoShow.Name = "button_LogoShow";
			this.button_LogoShow.Size = new System.Drawing.Size(83, 23);
			this.button_LogoShow.TabIndex = 1;
			this.button_LogoShow.Text = "Файл";
			this.button_LogoShow.UseVisualStyleBackColor = true;
			this.button_LogoShow.Click += new System.EventHandler(Button_LogoShow_Click);
			this.textBox_Logo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f, System.Drawing.FontStyle.Bold);
			this.textBox_Logo.Location = new System.Drawing.Point(4, 4);
			this.textBox_Logo.Name = "textBox_Logo";
			this.textBox_Logo.ReadOnly = true;
			this.textBox_Logo.Size = new System.Drawing.Size(40, 21);
			this.textBox_Logo.TabIndex = 18;
			this.textBox_Logo.Text = "0";
			this.textBox_Logo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.button_Logo.Enabled = false;
			this.button_Logo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.button_Logo.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_Logo.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_Logo.Location = new System.Drawing.Point(130, 3);
			this.button_Logo.Name = "button_Logo";
			this.button_Logo.Size = new System.Drawing.Size(83, 23);
			this.button_Logo.TabIndex = 1;
			this.button_Logo.Text = "Установить";
			this.button_Logo.UseVisualStyleBackColor = true;
			this.button_Logo.Click += new System.EventHandler(Button_Logo_Download_Click);
			this.groupBox_Header.Controls.Add(this.panel_Header);
			this.groupBox_Header.Controls.Add(this.panel_HeaderSel);
			this.groupBox_Header.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox_Header.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_Header.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_Header.Location = new System.Drawing.Point(3, 3);
			this.groupBox_Header.Name = "groupBox_Header";
			this.groupBox_Header.Padding = new System.Windows.Forms.Padding(1);
			this.groupBox_Header.Size = new System.Drawing.Size(618, 238);
			this.groupBox_Header.TabIndex = 15;
			this.groupBox_Header.TabStop = false;
			this.groupBox_Header.Text = "К л и ш е   /   П о д в а л";
			this.toolTip1.SetToolTip(this.groupBox_Header, "Данные регистрации");
			this.panel_Header.Controls.Add(this.panel_HeaderSet);
			this.panel_Header.Controls.Add(this.panel_HeaderList);
			this.panel_Header.Controls.Add(this.panel_HeaderCheckList);
			this.panel_Header.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel_Header.Location = new System.Drawing.Point(1, 40);
			this.panel_Header.Name = "panel_Header";
			this.panel_Header.Size = new System.Drawing.Size(616, 197);
			this.panel_Header.TabIndex = 5;
			this.panel_HeaderSet.BackColor = System.Drawing.Color.LightCyan;
			this.panel_HeaderSet.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_HeaderSet.Controls.Add(this.groupBox_HeaderAlign);
			this.panel_HeaderSet.Controls.Add(this.groupBox_HeaderUnderline);
			this.panel_HeaderSet.Controls.Add(this.groupBox_HeaderFont);
			this.panel_HeaderSet.Controls.Add(this.groupBox_CharHeight);
			this.panel_HeaderSet.Controls.Add(this.groupBox_CharWidth);
			this.panel_HeaderSet.Controls.Add(this.groupBox_HeaderInverse);
			this.panel_HeaderSet.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel_HeaderSet.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.panel_HeaderSet.Location = new System.Drawing.Point(70, 153);
			this.panel_HeaderSet.Name = "panel_HeaderSet";
			this.panel_HeaderSet.Size = new System.Drawing.Size(546, 44);
			this.panel_HeaderSet.TabIndex = 16;
			this.groupBox_HeaderAlign.Controls.Add(this.comboBox_HeaderAlign);
			this.groupBox_HeaderAlign.Dock = System.Windows.Forms.DockStyle.Left;
			this.groupBox_HeaderAlign.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.groupBox_HeaderAlign.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.groupBox_HeaderAlign.Location = new System.Drawing.Point(430, 0);
			this.groupBox_HeaderAlign.Name = "groupBox_HeaderAlign";
			this.groupBox_HeaderAlign.Size = new System.Drawing.Size(82, 42);
			this.groupBox_HeaderAlign.TabIndex = 21;
			this.groupBox_HeaderAlign.TabStop = false;
			this.groupBox_HeaderAlign.Text = "Положение";
			this.comboBox_HeaderAlign.Dock = System.Windows.Forms.DockStyle.Top;
			this.comboBox_HeaderAlign.DropDownHeight = 44;
			this.comboBox_HeaderAlign.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox_HeaderAlign.DropDownWidth = 40;
			this.comboBox_HeaderAlign.IntegralHeight = false;
			this.comboBox_HeaderAlign.Items.AddRange(new object[3] { "Слева", "По центру", "Справа" });
			this.comboBox_HeaderAlign.Location = new System.Drawing.Point(3, 16);
			this.comboBox_HeaderAlign.MaxDropDownItems = 3;
			this.comboBox_HeaderAlign.Name = "comboBox_HeaderAlign";
			this.comboBox_HeaderAlign.Size = new System.Drawing.Size(76, 21);
			this.comboBox_HeaderAlign.TabIndex = 9;
			this.toolTip1.SetToolTip(this.comboBox_HeaderAlign, "Text line alignment");
			this.comboBox_HeaderAlign.SelectedIndexChanged += new System.EventHandler(comboBox_HeaderAlign_SelectedIndexChanged);
			this.groupBox_HeaderUnderline.Controls.Add(this.comboBox_HeaderUnderline);
			this.groupBox_HeaderUnderline.Dock = System.Windows.Forms.DockStyle.Left;
			this.groupBox_HeaderUnderline.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.groupBox_HeaderUnderline.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.groupBox_HeaderUnderline.Location = new System.Drawing.Point(328, 0);
			this.groupBox_HeaderUnderline.Name = "groupBox_HeaderUnderline";
			this.groupBox_HeaderUnderline.Size = new System.Drawing.Size(102, 42);
			this.groupBox_HeaderUnderline.TabIndex = 20;
			this.groupBox_HeaderUnderline.TabStop = false;
			this.groupBox_HeaderUnderline.Text = "Подчеркивание";
			this.comboBox_HeaderUnderline.Dock = System.Windows.Forms.DockStyle.Top;
			this.comboBox_HeaderUnderline.DropDownHeight = 44;
			this.comboBox_HeaderUnderline.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox_HeaderUnderline.DropDownWidth = 40;
			this.comboBox_HeaderUnderline.IntegralHeight = false;
			this.comboBox_HeaderUnderline.Items.AddRange(new object[3] { "Нет", "Только текст", "Вся строка" });
			this.comboBox_HeaderUnderline.Location = new System.Drawing.Point(3, 16);
			this.comboBox_HeaderUnderline.MaxDropDownItems = 3;
			this.comboBox_HeaderUnderline.Name = "comboBox_HeaderUnderline";
			this.comboBox_HeaderUnderline.Size = new System.Drawing.Size(96, 21);
			this.comboBox_HeaderUnderline.TabIndex = 14;
			this.toolTip1.SetToolTip(this.comboBox_HeaderUnderline, "Underline");
			this.comboBox_HeaderUnderline.SelectedIndexChanged += new System.EventHandler(comboBox_HeaderUnderline_SelectedIndexChanged);
			this.groupBox_HeaderFont.Controls.Add(this.comboBox_HeaderFont);
			this.groupBox_HeaderFont.Dock = System.Windows.Forms.DockStyle.Left;
			this.groupBox_HeaderFont.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.groupBox_HeaderFont.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.groupBox_HeaderFont.Location = new System.Drawing.Point(246, 0);
			this.groupBox_HeaderFont.Name = "groupBox_HeaderFont";
			this.groupBox_HeaderFont.Size = new System.Drawing.Size(82, 42);
			this.groupBox_HeaderFont.TabIndex = 19;
			this.groupBox_HeaderFont.TabStop = false;
			this.groupBox_HeaderFont.Text = "Шрифт";
			this.comboBox_HeaderFont.Dock = System.Windows.Forms.DockStyle.Top;
			this.comboBox_HeaderFont.DropDownHeight = 44;
			this.comboBox_HeaderFont.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox_HeaderFont.DropDownWidth = 40;
			this.comboBox_HeaderFont.IntegralHeight = false;
			this.comboBox_HeaderFont.Items.AddRange(new object[3] { "Установленный", "Нормальный", "Мелкий" });
			this.comboBox_HeaderFont.Location = new System.Drawing.Point(3, 16);
			this.comboBox_HeaderFont.MaxDropDownItems = 3;
			this.comboBox_HeaderFont.Name = "comboBox_HeaderFont";
			this.comboBox_HeaderFont.Size = new System.Drawing.Size(76, 21);
			this.comboBox_HeaderFont.TabIndex = 13;
			this.toolTip1.SetToolTip(this.comboBox_HeaderFont, "Font");
			this.comboBox_HeaderFont.SelectedIndexChanged += new System.EventHandler(comboBox_HeaderFont_SelectedIndexChanged);
			this.groupBox_CharHeight.Controls.Add(this.numericUpDown_CharHeight);
			this.groupBox_CharHeight.Dock = System.Windows.Forms.DockStyle.Left;
			this.groupBox_CharHeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.groupBox_CharHeight.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.groupBox_CharHeight.Location = new System.Drawing.Point(164, 0);
			this.groupBox_CharHeight.Name = "groupBox_CharHeight";
			this.groupBox_CharHeight.Size = new System.Drawing.Size(82, 42);
			this.groupBox_CharHeight.TabIndex = 18;
			this.groupBox_CharHeight.TabStop = false;
			this.groupBox_CharHeight.Text = "Высота";
			this.numericUpDown_CharHeight.Dock = System.Windows.Forms.DockStyle.Top;
			this.numericUpDown_CharHeight.Location = new System.Drawing.Point(3, 16);
			this.numericUpDown_CharHeight.Maximum = new decimal(new int[4] { 8, 0, 0, 0 });
			this.numericUpDown_CharHeight.Name = "numericUpDown_CharHeight";
			this.numericUpDown_CharHeight.Size = new System.Drawing.Size(76, 20);
			this.numericUpDown_CharHeight.TabIndex = 12;
			this.numericUpDown_CharHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.toolTip1.SetToolTip(this.numericUpDown_CharHeight, "Character height: 0..8");
			this.numericUpDown_CharHeight.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			this.numericUpDown_CharHeight.ValueChanged += new System.EventHandler(numericUpDown_CharHeight_ValueChanged);
			this.groupBox_CharWidth.Controls.Add(this.numericUpDown_CharWidth);
			this.groupBox_CharWidth.Dock = System.Windows.Forms.DockStyle.Left;
			this.groupBox_CharWidth.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.groupBox_CharWidth.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.groupBox_CharWidth.Location = new System.Drawing.Point(82, 0);
			this.groupBox_CharWidth.Name = "groupBox_CharWidth";
			this.groupBox_CharWidth.Size = new System.Drawing.Size(82, 42);
			this.groupBox_CharWidth.TabIndex = 17;
			this.groupBox_CharWidth.TabStop = false;
			this.groupBox_CharWidth.Text = "Ширина";
			this.numericUpDown_CharWidth.Dock = System.Windows.Forms.DockStyle.Top;
			this.numericUpDown_CharWidth.Location = new System.Drawing.Point(3, 16);
			this.numericUpDown_CharWidth.Maximum = new decimal(new int[4] { 8, 0, 0, 0 });
			this.numericUpDown_CharWidth.Name = "numericUpDown_CharWidth";
			this.numericUpDown_CharWidth.Size = new System.Drawing.Size(76, 20);
			this.numericUpDown_CharWidth.TabIndex = 11;
			this.numericUpDown_CharWidth.Tag = "Width";
			this.numericUpDown_CharWidth.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.toolTip1.SetToolTip(this.numericUpDown_CharWidth, "Character width: 0..8");
			this.numericUpDown_CharWidth.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			this.numericUpDown_CharWidth.ValueChanged += new System.EventHandler(numericUpDown_CharWidth_ValueChanged);
			this.groupBox_HeaderInverse.Controls.Add(this.checkBox_HeaderInverse);
			this.groupBox_HeaderInverse.Dock = System.Windows.Forms.DockStyle.Left;
			this.groupBox_HeaderInverse.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.groupBox_HeaderInverse.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.groupBox_HeaderInverse.Location = new System.Drawing.Point(0, 0);
			this.groupBox_HeaderInverse.Name = "groupBox_HeaderInverse";
			this.groupBox_HeaderInverse.Size = new System.Drawing.Size(82, 42);
			this.groupBox_HeaderInverse.TabIndex = 16;
			this.groupBox_HeaderInverse.TabStop = false;
			this.groupBox_HeaderInverse.Text = "Ч/Б";
			this.checkBox_HeaderInverse.AutoSize = true;
			this.checkBox_HeaderInverse.Dock = System.Windows.Forms.DockStyle.Top;
			this.checkBox_HeaderInverse.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_HeaderInverse.ForeColor = System.Drawing.SystemColors.ControlText;
			this.checkBox_HeaderInverse.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_HeaderInverse.Location = new System.Drawing.Point(3, 16);
			this.checkBox_HeaderInverse.Name = "checkBox_HeaderInverse";
			this.checkBox_HeaderInverse.Size = new System.Drawing.Size(76, 17);
			this.checkBox_HeaderInverse.TabIndex = 15;
			this.checkBox_HeaderInverse.Text = "Инверсия";
			this.checkBox_HeaderInverse.UseVisualStyleBackColor = true;
			this.checkBox_HeaderInverse.CheckedChanged += new System.EventHandler(checkBox_HeaderInverse_CheckedChanged);
			this.panel_HeaderList.Controls.Add(this.dataGrid_Header2);
			this.panel_HeaderList.Controls.Add(this.dataGrid_Header1);
			this.panel_HeaderList.Controls.Add(this.dataGrid_Header4);
			this.panel_HeaderList.Controls.Add(this.dataGrid_Header3);
			this.panel_HeaderList.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_HeaderList.Location = new System.Drawing.Point(70, 0);
			this.panel_HeaderList.Name = "panel_HeaderList";
			this.panel_HeaderList.Size = new System.Drawing.Size(546, 153);
			this.panel_HeaderList.TabIndex = 17;
			this.dataGrid_Header2.AllowUserToAddRows = false;
			this.dataGrid_Header2.AllowUserToDeleteRows = false;
			this.dataGrid_Header2.AllowUserToResizeColumns = false;
			this.dataGrid_Header2.AllowUserToResizeRows = false;
			dataGridViewCellStyle24.BackColor = System.Drawing.Color.LightCyan;
			this.dataGrid_Header2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle24;
			this.dataGrid_Header2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dataGrid_Header2.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
			this.dataGrid_Header2.ColumnHeadersHeight = 15;
			this.dataGrid_Header2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this.dataGrid_Header2.ColumnHeadersVisible = false;
			this.dataGrid_Header2.Columns.AddRange(this.dataGridViewTextBoxColumn_Header2);
			this.dataGrid_Header2.Dock = System.Windows.Forms.DockStyle.Top;
			this.dataGrid_Header2.GridColor = System.Drawing.SystemColors.WindowFrame;
			this.dataGrid_Header2.Location = new System.Drawing.Point(0, 0);
			this.dataGrid_Header2.MultiSelect = false;
			this.dataGrid_Header2.Name = "dataGrid_Header2";
			this.dataGrid_Header2.RowHeadersVisible = false;
			this.dataGrid_Header2.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 204);
			this.dataGrid_Header2.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGrid_Header2.RowTemplate.Height = 15;
			this.dataGrid_Header2.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.dataGrid_Header2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
			this.dataGrid_Header2.ShowCellToolTips = false;
			this.dataGrid_Header2.ShowEditingIcon = false;
			this.dataGrid_Header2.Size = new System.Drawing.Size(546, 153);
			this.dataGrid_Header2.TabIndex = 5;
			this.dataGrid_Header2.Visible = false;
			this.dataGrid_Header2.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(dataGrid_Header_CellContentClick);
			this.dataGridViewTextBoxColumn_Header2.HeaderText = "Column_Header2";
			this.dataGridViewTextBoxColumn_Header2.MaxInputLength = 2000;
			this.dataGridViewTextBoxColumn_Header2.Name = "dataGridViewTextBoxColumn_Header2";
			this.dataGrid_Header1.AllowUserToAddRows = false;
			this.dataGrid_Header1.AllowUserToDeleteRows = false;
			this.dataGrid_Header1.AllowUserToResizeColumns = false;
			this.dataGrid_Header1.AllowUserToResizeRows = false;
			dataGridViewCellStyle25.BackColor = System.Drawing.Color.LightCyan;
			this.dataGrid_Header1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle25;
			this.dataGrid_Header1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dataGrid_Header1.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
			this.dataGrid_Header1.ColumnHeadersHeight = 15;
			this.dataGrid_Header1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this.dataGrid_Header1.ColumnHeadersVisible = false;
			this.dataGrid_Header1.Columns.AddRange(this.dataGridViewTextBoxColumn_Header);
			this.dataGrid_Header1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dataGrid_Header1.GridColor = System.Drawing.SystemColors.WindowFrame;
			this.dataGrid_Header1.Location = new System.Drawing.Point(0, 0);
			this.dataGrid_Header1.MultiSelect = false;
			this.dataGrid_Header1.Name = "dataGrid_Header1";
			this.dataGrid_Header1.RowHeadersVisible = false;
			this.dataGrid_Header1.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 204);
			this.dataGrid_Header1.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGrid_Header1.RowTemplate.Height = 15;
			this.dataGrid_Header1.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.dataGrid_Header1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
			this.dataGrid_Header1.ShowCellToolTips = false;
			this.dataGrid_Header1.ShowEditingIcon = false;
			this.dataGrid_Header1.Size = new System.Drawing.Size(546, 153);
			this.dataGrid_Header1.TabIndex = 0;
			this.dataGrid_Header1.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(dataGrid_Header_CellContentClick);
			this.dataGridViewTextBoxColumn_Header.HeaderText = "Column_Header";
			this.dataGridViewTextBoxColumn_Header.MaxInputLength = 2000;
			this.dataGridViewTextBoxColumn_Header.Name = "dataGridViewTextBoxColumn_Header";
			this.dataGrid_Header4.AllowUserToAddRows = false;
			this.dataGrid_Header4.AllowUserToDeleteRows = false;
			this.dataGrid_Header4.AllowUserToResizeColumns = false;
			this.dataGrid_Header4.AllowUserToResizeRows = false;
			dataGridViewCellStyle26.BackColor = System.Drawing.Color.LightCyan;
			this.dataGrid_Header4.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle26;
			this.dataGrid_Header4.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dataGrid_Header4.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
			this.dataGrid_Header4.ColumnHeadersHeight = 15;
			this.dataGrid_Header4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this.dataGrid_Header4.ColumnHeadersVisible = false;
			this.dataGrid_Header4.Columns.AddRange(this.dataGridViewTextBoxColumn_Header4);
			this.dataGrid_Header4.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dataGrid_Header4.GridColor = System.Drawing.SystemColors.WindowFrame;
			this.dataGrid_Header4.Location = new System.Drawing.Point(0, 0);
			this.dataGrid_Header4.MultiSelect = false;
			this.dataGrid_Header4.Name = "dataGrid_Header4";
			this.dataGrid_Header4.RowHeadersVisible = false;
			this.dataGrid_Header4.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 204);
			this.dataGrid_Header4.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGrid_Header4.RowTemplate.Height = 15;
			this.dataGrid_Header4.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.dataGrid_Header4.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
			this.dataGrid_Header4.ShowCellToolTips = false;
			this.dataGrid_Header4.ShowEditingIcon = false;
			this.dataGrid_Header4.Size = new System.Drawing.Size(546, 153);
			this.dataGrid_Header4.TabIndex = 7;
			this.dataGrid_Header4.Visible = false;
			this.dataGrid_Header4.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(dataGrid_Header_CellContentClick);
			this.dataGridViewTextBoxColumn_Header4.HeaderText = "Column_Header4";
			this.dataGridViewTextBoxColumn_Header4.MaxInputLength = 2000;
			this.dataGridViewTextBoxColumn_Header4.Name = "dataGridViewTextBoxColumn_Header4";
			this.dataGrid_Header3.AllowUserToAddRows = false;
			this.dataGrid_Header3.AllowUserToDeleteRows = false;
			this.dataGrid_Header3.AllowUserToResizeColumns = false;
			this.dataGrid_Header3.AllowUserToResizeRows = false;
			dataGridViewCellStyle27.BackColor = System.Drawing.Color.LightCyan;
			this.dataGrid_Header3.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle27;
			this.dataGrid_Header3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dataGrid_Header3.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
			this.dataGrid_Header3.ColumnHeadersHeight = 15;
			this.dataGrid_Header3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this.dataGrid_Header3.ColumnHeadersVisible = false;
			this.dataGrid_Header3.Columns.AddRange(this.dataGridViewTextBoxColumn_Header3);
			this.dataGrid_Header3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dataGrid_Header3.GridColor = System.Drawing.SystemColors.WindowFrame;
			this.dataGrid_Header3.Location = new System.Drawing.Point(0, 0);
			this.dataGrid_Header3.MultiSelect = false;
			this.dataGrid_Header3.Name = "dataGrid_Header3";
			this.dataGrid_Header3.RowHeadersVisible = false;
			this.dataGrid_Header3.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 204);
			this.dataGrid_Header3.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGrid_Header3.RowTemplate.Height = 15;
			this.dataGrid_Header3.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.dataGrid_Header3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
			this.dataGrid_Header3.ShowCellToolTips = false;
			this.dataGrid_Header3.ShowEditingIcon = false;
			this.dataGrid_Header3.Size = new System.Drawing.Size(546, 153);
			this.dataGrid_Header3.TabIndex = 6;
			this.dataGrid_Header3.Visible = false;
			this.dataGrid_Header3.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(dataGrid_Header_CellContentClick);
			this.dataGridViewTextBoxColumn_Header3.HeaderText = "Column_Header3";
			this.dataGridViewTextBoxColumn_Header3.MaxInputLength = 2000;
			this.dataGridViewTextBoxColumn_Header3.Name = "dataGridViewTextBoxColumn_Header3";
			this.panel_HeaderCheckList.BackColor = System.Drawing.Color.Transparent;
			this.panel_HeaderCheckList.Controls.Add(this.label_Header_Lines);
			this.panel_HeaderCheckList.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel_HeaderCheckList.Location = new System.Drawing.Point(0, 0);
			this.panel_HeaderCheckList.Name = "panel_HeaderCheckList";
			this.panel_HeaderCheckList.Size = new System.Drawing.Size(70, 197);
			this.panel_HeaderCheckList.TabIndex = 18;
			this.label_Header_Lines.AutoSize = true;
			this.label_Header_Lines.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f);
			this.label_Header_Lines.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Header_Lines.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Header_Lines.Location = new System.Drawing.Point(6, 0);
			this.label_Header_Lines.Name = "label_Header_Lines";
			this.label_Header_Lines.Size = new System.Drawing.Size(51, 150);
			this.label_Header_Lines.TabIndex = 8;
			this.label_Header_Lines.Text = "Line 1:\r\nLine 2:\r\nLine 3:\r\nLine 4:\r\nLine 5:\r\nLine 6:\r\nLine 7:\r\nLine 8:\r\nLine 9:\r\nLine 10:";
			this.label_Header_Lines.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.panel_HeaderSel.BackColor = System.Drawing.Color.LightCyan;
			this.panel_HeaderSel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_HeaderSel.Controls.Add(this.button_HeaderDel);
			this.panel_HeaderSel.Controls.Add(this.button_HeaderSet);
			this.panel_HeaderSel.Controls.Add(this.label_Header);
			this.panel_HeaderSel.Controls.Add(this.button_HeaderGet);
			this.panel_HeaderSel.Controls.Add(this.checkBox_HeaderKeep);
			this.panel_HeaderSel.Controls.Add(this.radioButton_Header4);
			this.panel_HeaderSel.Controls.Add(this.radioButton_Header3);
			this.panel_HeaderSel.Controls.Add(this.radioButton_Header2);
			this.panel_HeaderSel.Controls.Add(this.radioButton_Header1);
			this.panel_HeaderSel.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_HeaderSel.Location = new System.Drawing.Point(1, 14);
			this.panel_HeaderSel.Name = "panel_HeaderSel";
			this.panel_HeaderSel.Padding = new System.Windows.Forms.Padding(1);
			this.panel_HeaderSel.Size = new System.Drawing.Size(616, 26);
			this.panel_HeaderSel.TabIndex = 6;
			this.button_HeaderDel.Dock = System.Windows.Forms.DockStyle.Left;
			this.button_HeaderDel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.button_HeaderDel.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_HeaderDel.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_HeaderDel.Location = new System.Drawing.Point(505, 1);
			this.button_HeaderDel.Name = "button_HeaderDel";
			this.button_HeaderDel.Size = new System.Drawing.Size(85, 22);
			this.button_HeaderDel.TabIndex = 10;
			this.button_HeaderDel.Text = "Удалить";
			this.button_HeaderDel.UseVisualStyleBackColor = true;
			this.button_HeaderDel.Click += new System.EventHandler(button_HeaderDel_Click);
			this.button_HeaderSet.Dock = System.Windows.Forms.DockStyle.Left;
			this.button_HeaderSet.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.button_HeaderSet.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_HeaderSet.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_HeaderSet.Location = new System.Drawing.Point(420, 1);
			this.button_HeaderSet.Name = "button_HeaderSet";
			this.button_HeaderSet.Size = new System.Drawing.Size(85, 22);
			this.button_HeaderSet.TabIndex = 0;
			this.button_HeaderSet.Text = "Установить";
			this.button_HeaderSet.UseVisualStyleBackColor = true;
			this.button_HeaderSet.Click += new System.EventHandler(button_HeaderSet_Click);
			this.label_Header.BackColor = System.Drawing.Color.Brown;
			this.label_Header.Dock = System.Windows.Forms.DockStyle.Right;
			this.label_Header.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold);
			this.label_Header.ForeColor = System.Drawing.SystemColors.ControlLightLight;
			this.label_Header.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Header.Location = new System.Drawing.Point(595, 1);
			this.label_Header.Name = "label_Header";
			this.label_Header.Size = new System.Drawing.Size(18, 22);
			this.label_Header.TabIndex = 9;
			this.label_Header.Text = "?";
			this.label_Header.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.toolTip1.SetToolTip(this.label_Header, resources.GetString("label_Header.ToolTip"));
			this.button_HeaderGet.Dock = System.Windows.Forms.DockStyle.Left;
			this.button_HeaderGet.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.button_HeaderGet.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_HeaderGet.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_HeaderGet.Location = new System.Drawing.Point(335, 1);
			this.button_HeaderGet.Name = "button_HeaderGet";
			this.button_HeaderGet.Size = new System.Drawing.Size(85, 22);
			this.button_HeaderGet.TabIndex = 1;
			this.button_HeaderGet.Text = "Считать";
			this.button_HeaderGet.UseVisualStyleBackColor = true;
			this.button_HeaderGet.Click += new System.EventHandler(button_HeaderGet_Click);
			this.checkBox_HeaderKeep.AutoSize = true;
			this.checkBox_HeaderKeep.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkBox_HeaderKeep.Enabled = false;
			this.checkBox_HeaderKeep.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_HeaderKeep.ForeColor = System.Drawing.SystemColors.ControlText;
			this.checkBox_HeaderKeep.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_HeaderKeep.Location = new System.Drawing.Point(282, 1);
			this.checkBox_HeaderKeep.Name = "checkBox_HeaderKeep";
			this.checkBox_HeaderKeep.Size = new System.Drawing.Size(53, 22);
			this.checkBox_HeaderKeep.TabIndex = 7;
			this.checkBox_HeaderKeep.Text = "Сохр.";
			this.checkBox_HeaderKeep.UseVisualStyleBackColor = true;
			this.checkBox_HeaderKeep.Visible = false;
			this.radioButton_Header4.AutoSize = true;
			this.radioButton_Header4.Dock = System.Windows.Forms.DockStyle.Left;
			this.radioButton_Header4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.radioButton_Header4.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radioButton_Header4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radioButton_Header4.Location = new System.Drawing.Point(210, 1);
			this.radioButton_Header4.Name = "radioButton_Header4";
			this.radioButton_Header4.Size = new System.Drawing.Size(72, 22);
			this.radioButton_Header4.TabIndex = 8;
			this.radioButton_Header4.Text = "Подвал 2";
			this.radioButton_Header4.UseVisualStyleBackColor = true;
			this.radioButton_Header4.CheckedChanged += new System.EventHandler(radioButton_Header_CheckedChanged);
			this.radioButton_Header3.AutoSize = true;
			this.radioButton_Header3.Dock = System.Windows.Forms.DockStyle.Left;
			this.radioButton_Header3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.radioButton_Header3.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radioButton_Header3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radioButton_Header3.Location = new System.Drawing.Point(138, 1);
			this.radioButton_Header3.Name = "radioButton_Header3";
			this.radioButton_Header3.Size = new System.Drawing.Size(72, 22);
			this.radioButton_Header3.TabIndex = 8;
			this.radioButton_Header3.Text = "Подвал 1";
			this.radioButton_Header3.UseVisualStyleBackColor = true;
			this.radioButton_Header3.CheckedChanged += new System.EventHandler(radioButton_Header_CheckedChanged);
			this.radioButton_Header2.AutoSize = true;
			this.radioButton_Header2.Dock = System.Windows.Forms.DockStyle.Left;
			this.radioButton_Header2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.radioButton_Header2.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radioButton_Header2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radioButton_Header2.Location = new System.Drawing.Point(71, 1);
			this.radioButton_Header2.Name = "radioButton_Header2";
			this.radioButton_Header2.Size = new System.Drawing.Size(67, 22);
			this.radioButton_Header2.TabIndex = 8;
			this.radioButton_Header2.Text = "Клише 2";
			this.radioButton_Header2.UseVisualStyleBackColor = true;
			this.radioButton_Header2.CheckedChanged += new System.EventHandler(radioButton_Header_CheckedChanged);
			this.radioButton_Header1.AutoSize = true;
			this.radioButton_Header1.Checked = true;
			this.radioButton_Header1.Dock = System.Windows.Forms.DockStyle.Left;
			this.radioButton_Header1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.radioButton_Header1.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radioButton_Header1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radioButton_Header1.Location = new System.Drawing.Point(1, 1);
			this.radioButton_Header1.Name = "radioButton_Header1";
			this.radioButton_Header1.Padding = new System.Windows.Forms.Padding(3, 0, 0, 0);
			this.radioButton_Header1.Size = new System.Drawing.Size(70, 22);
			this.radioButton_Header1.TabIndex = 8;
			this.radioButton_Header1.TabStop = true;
			this.radioButton_Header1.Text = "Клише 1";
			this.radioButton_Header1.UseVisualStyleBackColor = true;
			this.radioButton_Header1.CheckedChanged += new System.EventHandler(radioButton_Header_CheckedChanged);
			this.tabPage_Registration.AutoScroll = true;
			this.tabPage_Registration.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.tabPage_Registration.Controls.Add(this.checkBox_ReReg);
			this.tabPage_Registration.Controls.Add(this.checkBox_Reg_FFD12);
			this.tabPage_Registration.Controls.Add(this.panel_RegNo);
			this.tabPage_Registration.Controls.Add(this.panel_Reg3);
			this.tabPage_Registration.Controls.Add(this.panel_Reg1);
			this.tabPage_Registration.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold);
			this.tabPage_Registration.Location = new System.Drawing.Point(154, 4);
			this.tabPage_Registration.Name = "tabPage_Registration";
			this.tabPage_Registration.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage_Registration.Size = new System.Drawing.Size(626, 424);
			this.tabPage_Registration.TabIndex = 5;
			this.tabPage_Registration.Text = "Регистрация";
			this.tabPage_Registration.UseVisualStyleBackColor = true;
			this.checkBox_ReReg.AutoSize = true;
			this.checkBox_ReReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_ReReg.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_ReReg.Location = new System.Drawing.Point(421, 34);
			this.checkBox_ReReg.Margin = new System.Windows.Forms.Padding(10, 3, 3, 3);
			this.checkBox_ReReg.Name = "checkBox_ReReg";
			this.checkBox_ReReg.Size = new System.Drawing.Size(116, 17);
			this.checkBox_ReReg.TabIndex = 1;
			this.checkBox_ReReg.Text = "Перерегистрация";
			this.checkBox_ReReg.UseVisualStyleBackColor = true;
			this.checkBox_ReReg.CheckedChanged += new System.EventHandler(CheckBox_ReReg_CheckedChanged);
			this.checkBox_Reg_FFD12.AutoSize = true;
			this.checkBox_Reg_FFD12.Checked = true;
			this.checkBox_Reg_FFD12.CheckState = System.Windows.Forms.CheckState.Checked;
			this.checkBox_Reg_FFD12.Enabled = false;
			this.checkBox_Reg_FFD12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.checkBox_Reg_FFD12.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_Reg_FFD12.Location = new System.Drawing.Point(545, 34);
			this.checkBox_Reg_FFD12.Name = "checkBox_Reg_FFD12";
			this.checkBox_Reg_FFD12.Size = new System.Drawing.Size(75, 17);
			this.checkBox_Reg_FFD12.TabIndex = 23;
			this.checkBox_Reg_FFD12.Text = "ФФД 1.2";
			this.checkBox_Reg_FFD12.UseVisualStyleBackColor = true;
			this.panel_RegNo.Controls.Add(this.button_Verify);
			this.panel_RegNo.Controls.Add(this.button_Calculate);
			this.panel_RegNo.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_RegNo.Location = new System.Drawing.Point(419, 3);
			this.panel_RegNo.Name = "panel_RegNo";
			this.panel_RegNo.Size = new System.Drawing.Size(202, 28);
			this.panel_RegNo.TabIndex = 7;
			this.button_Verify.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.button_Verify.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_Verify.Location = new System.Drawing.Point(76, 5);
			this.button_Verify.Name = "button_Verify";
			this.button_Verify.Size = new System.Drawing.Size(70, 21);
			this.button_Verify.TabIndex = 0;
			this.button_Verify.Text = "Проверить";
			this.button_Verify.UseVisualStyleBackColor = true;
			this.button_Verify.Click += new System.EventHandler(verifyToolStripMenuItem_Click);
			this.button_Calculate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.button_Calculate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_Calculate.Location = new System.Drawing.Point(5, 5);
			this.button_Calculate.Name = "button_Calculate";
			this.button_Calculate.Size = new System.Drawing.Size(70, 21);
			this.button_Calculate.TabIndex = 0;
			this.button_Calculate.Text = "Вычислить";
			this.button_Calculate.UseVisualStyleBackColor = true;
			this.button_Calculate.Click += new System.EventHandler(сalculateToolStripMenuItem_Click);
			this.panel_Reg3.Controls.Add(this.groupBox_Reason11);
			this.panel_Reg3.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel_Reg3.Location = new System.Drawing.Point(419, 54);
			this.panel_Reg3.Name = "panel_Reg3";
			this.panel_Reg3.Size = new System.Drawing.Size(202, 365);
			this.panel_Reg3.TabIndex = 20;
			this.groupBox_Reason11.Controls.Add(this.checkedListBox_Reason11);
			this.groupBox_Reason11.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox_Reason11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_Reason11.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_Reason11.Location = new System.Drawing.Point(0, 0);
			this.groupBox_Reason11.Name = "groupBox_Reason11";
			this.groupBox_Reason11.Padding = new System.Windows.Forms.Padding(1);
			this.groupBox_Reason11.Size = new System.Drawing.Size(202, 365);
			this.groupBox_Reason11.TabIndex = 7;
			this.groupBox_Reason11.TabStop = false;
			this.groupBox_Reason11.Text = "Причины перерегистрации";
			this.checkedListBox_Reason11.BackColor = System.Drawing.SystemColors.Window;
			this.checkedListBox_Reason11.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.checkedListBox_Reason11.CheckOnClick = true;
			this.checkedListBox_Reason11.Dock = System.Windows.Forms.DockStyle.Fill;
			this.checkedListBox_Reason11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkedListBox_Reason11.ForeColor = System.Drawing.SystemColors.ControlText;
			this.checkedListBox_Reason11.FormattingEnabled = true;
			this.checkedListBox_Reason11.Items.AddRange(new object[20]
			{
				"1.Замена ФН", "2.Замена ОФД", "3.Изм.наименования пользователя", "4.Изм.адреса и/или места расчетов", "5.Откл. автономного режима", "6.Вкл. автономного режима", "7.Изменение версии модели ККТ", "8.Изменение СНО", "9.Изменение номера автомата", "10.Откл. автоматического режима",
				"11.Вкл. автоматического режима", "12.Вкл. режима БСО", "13.Откл. режима БСО", "14.Откл. расчетов в Интернет", "15.Вкл. расчетов в Интернет", "18.Откл. азартных игр", "19.Вкл. азартных игр", "20.Откл. лотерей", "21.Вкл. лотерей", "32.Иные причины"
			});
			this.checkedListBox_Reason11.Location = new System.Drawing.Point(1, 14);
			this.checkedListBox_Reason11.Name = "checkedListBox_Reason11";
			this.checkedListBox_Reason11.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.checkedListBox_Reason11.Size = new System.Drawing.Size(200, 350);
			this.checkedListBox_Reason11.TabIndex = 9;
			this.panel_Reg1.Controls.Add(this.panel_RegBottom);
			this.panel_Reg1.Controls.Add(this.panel_Reg2);
			this.panel_Reg1.Controls.Add(this.groupBox_RegData);
			this.panel_Reg1.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel_Reg1.Location = new System.Drawing.Point(3, 3);
			this.panel_Reg1.Name = "panel_Reg1";
			this.panel_Reg1.Size = new System.Drawing.Size(416, 416);
			this.panel_Reg1.TabIndex = 19;
			this.panel_RegBottom.Controls.Add(this.textBox_RegDateTime);
			this.panel_RegBottom.Controls.Add(this.button_Reg);
			this.panel_RegBottom.Controls.Add(this.label_RegNo);
			this.panel_RegBottom.Controls.Add(this.numericUpDown_ReRegNumber);
			this.panel_RegBottom.Controls.Add(this.button_GetRegData);
			this.panel_RegBottom.Controls.Add(this.button_PrintReRegTicket);
			this.panel_RegBottom.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_RegBottom.Location = new System.Drawing.Point(0, 354);
			this.panel_RegBottom.Name = "panel_RegBottom";
			this.panel_RegBottom.Padding = new System.Windows.Forms.Padding(3);
			this.panel_RegBottom.Size = new System.Drawing.Size(416, 51);
			this.panel_RegBottom.TabIndex = 12;
			this.textBox_RegDateTime.BackColor = System.Drawing.SystemColors.InactiveCaption;
			this.textBox_RegDateTime.ForeColor = System.Drawing.Color.Blue;
			this.textBox_RegDateTime.Location = new System.Drawing.Point(182, 28);
			this.textBox_RegDateTime.Name = "textBox_RegDateTime";
			this.textBox_RegDateTime.ReadOnly = true;
			this.textBox_RegDateTime.Size = new System.Drawing.Size(146, 20);
			this.textBox_RegDateTime.TabIndex = 1;
			this.textBox_RegDateTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.button_Reg.AutoSize = true;
			this.button_Reg.Dock = System.Windows.Forms.DockStyle.Left;
			this.button_Reg.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold);
			this.button_Reg.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_Reg.Location = new System.Drawing.Point(83, 3);
			this.button_Reg.Name = "button_Reg";
			this.button_Reg.Size = new System.Drawing.Size(93, 45);
			this.button_Reg.TabIndex = 0;
			this.button_Reg.Text = "Регистрация";
			this.button_Reg.UseVisualStyleBackColor = true;
			this.button_Reg.Click += new System.EventHandler(Button_Reg_Click);
			this.label_RegNo.AutoSize = true;
			this.label_RegNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_RegNo.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_RegNo.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_RegNo.Location = new System.Drawing.Point(243, 6);
			this.label_RegNo.Margin = new System.Windows.Forms.Padding(0);
			this.label_RegNo.Name = "label_RegNo";
			this.label_RegNo.Size = new System.Drawing.Size(42, 13);
			this.label_RegNo.TabIndex = 2;
			this.label_RegNo.Text = "Рег. №";
			this.label_RegNo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.numericUpDown_ReRegNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.numericUpDown_ReRegNumber.Location = new System.Drawing.Point(288, 4);
			this.numericUpDown_ReRegNumber.Maximum = new decimal(new int[4] { 99, 0, 0, 0 });
			this.numericUpDown_ReRegNumber.Name = "numericUpDown_ReRegNumber";
			this.numericUpDown_ReRegNumber.Size = new System.Drawing.Size(40, 20);
			this.numericUpDown_ReRegNumber.TabIndex = 0;
			this.numericUpDown_ReRegNumber.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			this.button_GetRegData.Dock = System.Windows.Forms.DockStyle.Left;
			this.button_GetRegData.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold);
			this.button_GetRegData.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_GetRegData.Location = new System.Drawing.Point(3, 3);
			this.button_GetRegData.Name = "button_GetRegData";
			this.button_GetRegData.Size = new System.Drawing.Size(80, 45);
			this.button_GetRegData.TabIndex = 0;
			this.button_GetRegData.Text = "Считать";
			this.button_GetRegData.UseVisualStyleBackColor = true;
			this.button_GetRegData.Click += new System.EventHandler(Button_GetRegData_Click);
			this.button_PrintReRegTicket.Dock = System.Windows.Forms.DockStyle.Right;
			this.button_PrintReRegTicket.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.button_PrintReRegTicket.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_PrintReRegTicket.Location = new System.Drawing.Point(333, 3);
			this.button_PrintReRegTicket.Name = "button_PrintReRegTicket";
			this.button_PrintReRegTicket.Size = new System.Drawing.Size(80, 45);
			this.button_PrintReRegTicket.TabIndex = 0;
			this.button_PrintReRegTicket.Text = "По номеру";
			this.button_PrintReRegTicket.UseVisualStyleBackColor = true;
			this.button_PrintReRegTicket.Click += new System.EventHandler(Button_PrintReRegTicket_Click);
			this.panel_Reg2.Controls.Add(this.groupBox_OpMode);
			this.panel_Reg2.Controls.Add(this.groupBox_Taxes);
			this.panel_Reg2.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Reg2.Location = new System.Drawing.Point(0, 210);
			this.panel_Reg2.Name = "panel_Reg2";
			this.panel_Reg2.Size = new System.Drawing.Size(416, 144);
			this.panel_Reg2.TabIndex = 18;
			this.groupBox_OpMode.Controls.Add(this.checkedListBox_ModeB);
			this.groupBox_OpMode.Controls.Add(this.checkedListBox_ModeA);
			this.groupBox_OpMode.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox_OpMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_OpMode.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_OpMode.Location = new System.Drawing.Point(135, 0);
			this.groupBox_OpMode.Name = "groupBox_OpMode";
			this.groupBox_OpMode.Size = new System.Drawing.Size(281, 144);
			this.groupBox_OpMode.TabIndex = 15;
			this.groupBox_OpMode.TabStop = false;
			this.groupBox_OpMode.Text = "Р е ж и м ы";
			this.checkedListBox_ModeB.BackColor = System.Drawing.SystemColors.Window;
			this.checkedListBox_ModeB.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.checkedListBox_ModeB.CheckOnClick = true;
			this.checkedListBox_ModeB.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkedListBox_ModeB.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkedListBox_ModeB.ForeColor = System.Drawing.SystemColors.ControlText;
			this.checkedListBox_ModeB.FormattingEnabled = true;
			this.checkedListBox_ModeB.Items.AddRange(new object[8] { "Подакцизные товары\t@T1207", "Азартные игры\t\t@T1193", "Лотереи\t\t\t@T1126", "В автомате\t\t@T1221", "Маркировка\t\t@MARK", "Ломбард\t\t\t@PAWN", "Страхование\t\t@INS", "Торг.автомат\t\t@VEND" });
			this.checkedListBox_ModeB.Location = new System.Drawing.Point(123, 16);
			this.checkedListBox_ModeB.Name = "checkedListBox_ModeB";
			this.checkedListBox_ModeB.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.checkedListBox_ModeB.Size = new System.Drawing.Size(129, 125);
			this.checkedListBox_ModeB.TabIndex = 4;
			this.checkedListBox_ModeB.Tag = "";
			this.checkedListBox_ModeA.BackColor = System.Drawing.SystemColors.Window;
			this.checkedListBox_ModeA.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.checkedListBox_ModeA.CheckOnClick = true;
			this.checkedListBox_ModeA.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkedListBox_ModeA.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkedListBox_ModeA.ForeColor = System.Drawing.SystemColors.ControlText;
			this.checkedListBox_ModeA.FormattingEnabled = true;
			this.checkedListBox_ModeA.Items.AddRange(new object[8] { "Шифрование     \t\t@T1056", "Автономный \t\t@T1002", "Автоматич. \t\t@T1001", "Сфера услуг \t\t@T1109", "Режим БСО \t\t@T1110", "ККТ в Интернет \t\t@T1108", "Общепит\t\t\t@DINE", "Оптовая торговля\t\t@OPT" });
			this.checkedListBox_ModeA.Location = new System.Drawing.Point(3, 16);
			this.checkedListBox_ModeA.Name = "checkedListBox_ModeA";
			this.checkedListBox_ModeA.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.checkedListBox_ModeA.Size = new System.Drawing.Size(120, 125);
			this.checkedListBox_ModeA.TabIndex = 4;
			this.checkedListBox_ModeA.Tag = "";
			this.groupBox_Taxes.Controls.Add(this.checkedListBox_Taxes);
			this.groupBox_Taxes.Dock = System.Windows.Forms.DockStyle.Left;
			this.groupBox_Taxes.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_Taxes.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_Taxes.Location = new System.Drawing.Point(0, 0);
			this.groupBox_Taxes.Name = "groupBox_Taxes";
			this.groupBox_Taxes.Size = new System.Drawing.Size(135, 144);
			this.groupBox_Taxes.TabIndex = 15;
			this.groupBox_Taxes.TabStop = false;
			this.groupBox_Taxes.Text = "Н а л о г и";
			this.checkedListBox_Taxes.BackColor = System.Drawing.SystemColors.Window;
			this.checkedListBox_Taxes.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.checkedListBox_Taxes.CheckOnClick = true;
			this.checkedListBox_Taxes.Dock = System.Windows.Forms.DockStyle.Fill;
			this.checkedListBox_Taxes.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkedListBox_Taxes.ForeColor = System.Drawing.SystemColors.ControlText;
			this.checkedListBox_Taxes.Items.AddRange(new object[6] { "0.ОСН", "1.УСН доход", "2.УСН доход-расход", "3.(ЕНВД)", "4.ЕСХН", "5.Патент" });
			this.checkedListBox_Taxes.Location = new System.Drawing.Point(3, 16);
			this.checkedListBox_Taxes.Name = "checkedListBox_Taxes";
			this.checkedListBox_Taxes.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.checkedListBox_Taxes.Size = new System.Drawing.Size(129, 125);
			this.checkedListBox_Taxes.TabIndex = 4;
			this.toolTip1.SetToolTip(this.checkedListBox_Taxes, "General VAT\r\nSimplified on income\r\nSimplified on (income-expenses)\r\nFixed \r\nAgricultural\r\nPatent");
			this.groupBox_RegData.Controls.Add(this.checkBox_RegNum);
			this.groupBox_RegData.Controls.Add(this.label_FNS);
			this.groupBox_RegData.Controls.Add(this.label_Calculate);
			this.groupBox_RegData.Controls.Add(this.dataGrid_RegData);
			this.groupBox_RegData.Controls.Add(this.label_RegData);
			this.groupBox_RegData.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox_RegData.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_RegData.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_RegData.Location = new System.Drawing.Point(0, 0);
			this.groupBox_RegData.Name = "groupBox_RegData";
			this.groupBox_RegData.Padding = new System.Windows.Forms.Padding(0);
			this.groupBox_RegData.Size = new System.Drawing.Size(416, 210);
			this.groupBox_RegData.TabIndex = 14;
			this.groupBox_RegData.TabStop = false;
			this.groupBox_RegData.Text = "Р е г и с т р а ц и о н н ы е   д а н н ы е";
			this.toolTip1.SetToolTip(this.groupBox_RegData, "Данные регистрации");
			this.checkBox_RegNum.AutoSize = true;
			this.checkBox_RegNum.BackColor = System.Drawing.Color.Transparent;
			this.checkBox_RegNum.Enabled = false;
			this.checkBox_RegNum.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.checkBox_RegNum.ForeColor = System.Drawing.SystemColors.ControlText;
			this.checkBox_RegNum.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_RegNum.Location = new System.Drawing.Point(360, 14);
			this.checkBox_RegNum.Name = "checkBox_RegNum";
			this.checkBox_RegNum.Size = new System.Drawing.Size(12, 11);
			this.checkBox_RegNum.TabIndex = 20;
			this.toolTip1.SetToolTip(this.checkBox_RegNum, "At ReReg: Include Registration Number");
			this.checkBox_RegNum.UseVisualStyleBackColor = false;
			this.label_FNS.BackColor = System.Drawing.Color.Brown;
			this.label_FNS.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold);
			this.label_FNS.ForeColor = System.Drawing.SystemColors.ControlLightLight;
			this.label_FNS.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_FNS.Location = new System.Drawing.Point(354, 135);
			this.label_FNS.Name = "label_FNS";
			this.label_FNS.Size = new System.Drawing.Size(63, 13);
			this.label_FNS.TabIndex = 6;
			this.label_FNS.Text = "<- задать";
			this.label_FNS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.toolTip1.SetToolTip(this.label_FNS, "www.nalog.gov.ru");
			this.label_FNS.Click += new System.EventHandler(label_FNS_Click);
			this.label_Calculate.AutoSize = true;
			this.label_Calculate.BackColor = System.Drawing.Color.Brown;
			this.label_Calculate.ContextMenuStrip = this.contextMenuStrip_Reg;
			this.label_Calculate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold);
			this.label_Calculate.ForeColor = System.Drawing.SystemColors.ControlLightLight;
			this.label_Calculate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Calculate.Location = new System.Drawing.Point(376, 15);
			this.label_Calculate.Name = "label_Calculate";
			this.label_Calculate.Size = new System.Drawing.Size(75, 13);
			this.label_Calculate.TabIndex = 6;
			this.label_Calculate.Text = "Вычислить.";
			this.label_Calculate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.toolTip1.SetToolTip(this.label_Calculate, "Рассчитать/Проверить");
			this.contextMenuStrip_Reg.Items.AddRange(new System.Windows.Forms.ToolStripItem[2] { this.сalculateToolStripMenuItem, this.verifyToolStripMenuItem });
			this.contextMenuStrip_Reg.Name = "contextMenuStrip2";
			this.contextMenuStrip_Reg.Size = new System.Drawing.Size(136, 48);
			this.сalculateToolStripMenuItem.Name = "сalculateToolStripMenuItem";
			this.сalculateToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
			this.сalculateToolStripMenuItem.Text = "Вычислить";
			this.сalculateToolStripMenuItem.Click += new System.EventHandler(сalculateToolStripMenuItem_Click);
			this.verifyToolStripMenuItem.Name = "verifyToolStripMenuItem";
			this.verifyToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
			this.verifyToolStripMenuItem.Text = "Проверить";
			this.verifyToolStripMenuItem.Click += new System.EventHandler(verifyToolStripMenuItem_Click);
			this.dataGrid_RegData.AllowUserToAddRows = false;
			this.dataGrid_RegData.AllowUserToDeleteRows = false;
			this.dataGrid_RegData.AllowUserToResizeRows = false;
			dataGridViewCellStyle28.BackColor = System.Drawing.Color.LightCyan;
			this.dataGrid_RegData.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle28;
			this.dataGrid_RegData.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
			dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle29.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle29.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			dataGridViewCellStyle29.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle29.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle29.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			this.dataGrid_RegData.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle29;
			this.dataGrid_RegData.ColumnHeadersHeight = 15;
			this.dataGrid_RegData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this.dataGrid_RegData.ColumnHeadersVisible = false;
			this.dataGrid_RegData.Columns.AddRange(this.Column_RegData);
			this.dataGrid_RegData.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dataGrid_RegData.GridColor = System.Drawing.SystemColors.WindowFrame;
			this.dataGrid_RegData.Location = new System.Drawing.Point(130, 13);
			this.dataGrid_RegData.MultiSelect = false;
			this.dataGrid_RegData.Name = "dataGrid_RegData";
			dataGridViewCellStyle30.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle30.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			dataGridViewCellStyle30.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle30.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle30.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			this.dataGrid_RegData.RowHeadersDefaultCellStyle = dataGridViewCellStyle30;
			this.dataGrid_RegData.RowHeadersVisible = false;
			this.dataGrid_RegData.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 204);
			this.dataGrid_RegData.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.ControlDark;
			this.dataGrid_RegData.RowTemplate.Height = 15;
			this.dataGrid_RegData.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
			this.dataGrid_RegData.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.dataGrid_RegData.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
			this.dataGrid_RegData.ShowCellToolTips = false;
			this.dataGrid_RegData.Size = new System.Drawing.Size(286, 197);
			this.dataGrid_RegData.TabIndex = 0;
			this.dataGrid_RegData.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(dataGrid_CellBeginEdit);
			this.Column_RegData.HeaderText = "Column_RegData";
			this.Column_RegData.Name = "Column_RegData";
			this.Column_RegData.Resizable = System.Windows.Forms.DataGridViewTriState.False;
			this.Column_RegData.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			this.Column_RegData.Width = 283;
			this.label_RegData.Dock = System.Windows.Forms.DockStyle.Left;
			this.label_RegData.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f);
			this.label_RegData.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_RegData.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_RegData.Location = new System.Drawing.Point(0, 13);
			this.label_RegData.Name = "label_RegData";
			this.label_RegData.Size = new System.Drawing.Size(130, 197);
			this.label_RegData.TabIndex = 0;
			this.label_RegData.Text = resources.GetString("label_RegData.Text");
			this.label_RegData.TextAlign = System.Drawing.ContentAlignment.TopRight;
			this.tabPage_Transaction.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.tabPage_Transaction.Controls.Add(this.panel_beznal);
			this.tabPage_Transaction.Controls.Add(this.panel_AddItem);
			this.tabPage_Transaction.Controls.Add(this.panel_TicketClose);
			this.tabPage_Transaction.Controls.Add(this.panel_Ticket_Total);
			this.tabPage_Transaction.Controls.Add(this.panel_TicketOpen);
			this.tabPage_Transaction.Controls.Add(this.groupBox_OCh);
			this.tabPage_Transaction.Controls.Add(this.panel_TicketPay);
			this.tabPage_Transaction.Controls.Add(this.panel_Ticket_Type_and_Tax);
			this.tabPage_Transaction.Location = new System.Drawing.Point(154, 4);
			this.tabPage_Transaction.Name = "tabPage_Transaction";
			this.tabPage_Transaction.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
			this.tabPage_Transaction.Size = new System.Drawing.Size(626, 424);
			this.tabPage_Transaction.TabIndex = 4;
			this.tabPage_Transaction.Text = "Чек";
			this.tabPage_Transaction.UseVisualStyleBackColor = true;
			this.panel_beznal.BackColor = System.Drawing.Color.LightCyan;
			this.panel_beznal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_beznal.Controls.Add(this.checkedListBox_beznal);
			this.panel_beznal.Controls.Add(this.dataGrid_beznal);
			this.panel_beznal.Location = new System.Drawing.Point(164, 272);
			this.panel_beznal.Name = "panel_beznal";
			this.panel_beznal.Size = new System.Drawing.Size(118, 85);
			this.panel_beznal.TabIndex = 16;
			this.panel_beznal.Visible = false;
			this.checkedListBox_beznal.BackColor = System.Drawing.Color.LightCyan;
			this.checkedListBox_beznal.CheckOnClick = true;
			this.checkedListBox_beznal.FormattingEnabled = true;
			this.checkedListBox_beznal.Items.AddRange(new object[5] { "1", "2", "3", "4", "5" });
			this.checkedListBox_beznal.Location = new System.Drawing.Point(2, 2);
			this.checkedListBox_beznal.Name = "checkedListBox_beznal";
			this.checkedListBox_beznal.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.checkedListBox_beznal.Size = new System.Drawing.Size(32, 79);
			this.checkedListBox_beznal.TabIndex = 4;
			this.dataGrid_beznal.AllowUserToAddRows = false;
			this.dataGrid_beznal.AllowUserToDeleteRows = false;
			this.dataGrid_beznal.AllowUserToResizeColumns = false;
			this.dataGrid_beznal.AllowUserToResizeRows = false;
			dataGridViewCellStyle31.BackColor = System.Drawing.Color.LightCyan;
			this.dataGrid_beznal.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle31;
			this.dataGrid_beznal.BackgroundColor = System.Drawing.Color.LightCyan;
			this.dataGrid_beznal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.dataGrid_beznal.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
			dataGridViewCellStyle32.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.dataGrid_beznal.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle32;
			this.dataGrid_beznal.ColumnHeadersHeight = 15;
			this.dataGrid_beznal.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this.dataGrid_beznal.ColumnHeadersVisible = false;
			this.dataGrid_beznal.Columns.AddRange(this.dataGridViewTextBoxColumn5);
			dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle33.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle33.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			dataGridViewCellStyle33.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle33.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle33.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle33.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.dataGrid_beznal.DefaultCellStyle = dataGridViewCellStyle33;
			this.dataGrid_beznal.GridColor = System.Drawing.SystemColors.ActiveBorder;
			this.dataGrid_beznal.Location = new System.Drawing.Point(34, 2);
			this.dataGrid_beznal.MultiSelect = false;
			this.dataGrid_beznal.Name = "dataGrid_beznal";
			dataGridViewCellStyle34.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.dataGrid_beznal.RowHeadersDefaultCellStyle = dataGridViewCellStyle34;
			this.dataGrid_beznal.RowHeadersVisible = false;
			this.dataGrid_beznal.RowHeadersWidth = 4;
			this.dataGrid_beznal.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
			this.dataGrid_beznal.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 204);
			this.dataGrid_beznal.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGrid_beznal.RowTemplate.DividerHeight = 1;
			this.dataGrid_beznal.RowTemplate.Height = 15;
			this.dataGrid_beznal.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
			this.dataGrid_beznal.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.dataGrid_beznal.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
			this.dataGrid_beznal.ShowCellToolTips = false;
			this.dataGrid_beznal.ShowEditingIcon = false;
			this.dataGrid_beznal.Size = new System.Drawing.Size(80, 79);
			this.dataGrid_beznal.TabIndex = 6;
			this.dataGrid_beznal.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(DataGrid_beznal_CellContentClick);
			this.dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
			this.dataGridViewTextBoxColumn5.DividerWidth = 1;
			this.dataGridViewTextBoxColumn5.HeaderText = "Value";
			this.dataGridViewTextBoxColumn5.MaxInputLength = 256;
			this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
			this.dataGridViewTextBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.False;
			this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			this.dataGridViewTextBoxColumn5.Width = 150;
			this.panel_AddItem.Controls.Add(this.groupBox_AddItem);
			this.panel_AddItem.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_AddItem.Location = new System.Drawing.Point(3, 127);
			this.panel_AddItem.Name = "panel_AddItem";
			this.panel_AddItem.Padding = new System.Windows.Forms.Padding(0, 0, 0, 3);
			this.panel_AddItem.Size = new System.Drawing.Size(618, 160);
			this.panel_AddItem.TabIndex = 4;
			this.groupBox_AddItem.Controls.Add(this.panel_Ticket_Item);
			this.groupBox_AddItem.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox_AddItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_AddItem.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_AddItem.Location = new System.Drawing.Point(0, 0);
			this.groupBox_AddItem.Name = "groupBox_AddItem";
			this.groupBox_AddItem.Size = new System.Drawing.Size(618, 157);
			this.groupBox_AddItem.TabIndex = 0;
			this.groupBox_AddItem.TabStop = false;
			this.groupBox_AddItem.Text = "П р е д м е т ы   р а с ч е т а";
			this.panel_Ticket_Item.BackColor = System.Drawing.Color.LightCyan;
			this.panel_Ticket_Item.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_Ticket_Item.Controls.Add(this.groupBox_Mark);
			this.panel_Ticket_Item.Controls.Add(this.panel_Ticket_Option4);
			this.panel_Ticket_Item.Controls.Add(this.panel_Ticket_Option41);
			this.panel_Ticket_Item.Controls.Add(this.panel_Ticket_Option3);
			this.panel_Ticket_Item.Controls.Add(this.panel_Ticket_Option31);
			this.panel_Ticket_Item.Controls.Add(this.panel_Ticket_Option2);
			this.panel_Ticket_Item.Controls.Add(this.panel_Ticket_Option21);
			this.panel_Ticket_Item.Controls.Add(this.panel_Ticket_Option1);
			this.panel_Ticket_Item.Controls.Add(this.panel_Ticket_ItemAddTest);
			this.panel_Ticket_Item.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel_Ticket_Item.Location = new System.Drawing.Point(3, 16);
			this.panel_Ticket_Item.Name = "panel_Ticket_Item";
			this.panel_Ticket_Item.Padding = new System.Windows.Forms.Padding(3);
			this.panel_Ticket_Item.Size = new System.Drawing.Size(612, 138);
			this.panel_Ticket_Item.TabIndex = 9;
			this.groupBox_Mark.BackColor = System.Drawing.Color.LightBlue;
			this.groupBox_Mark.Controls.Add(this.panel_Mark_Data);
			this.groupBox_Mark.Controls.Add(this.panel_Mark_Header);
			this.groupBox_Mark.Controls.Add(this.panel_ItemMark);
			this.groupBox_Mark.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox_Mark.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_Mark.Location = new System.Drawing.Point(73, 151);
			this.groupBox_Mark.Name = "groupBox_Mark";
			this.groupBox_Mark.Size = new System.Drawing.Size(534, 79);
			this.groupBox_Mark.TabIndex = 32;
			this.groupBox_Mark.TabStop = false;
			this.groupBox_Mark.Text = "М а р к и р о в к а";
			this.panel_Mark_Data.Controls.Add(this.textBox_ItemCode);
			this.panel_Mark_Data.Controls.Add(this.textBox_ItemID);
			this.panel_Mark_Data.Controls.Add(this.comboBox_ItemStatus);
			this.panel_Mark_Data.Controls.Add(this.comboBox_TypeOfCode);
			this.panel_Mark_Data.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Mark_Data.Location = new System.Drawing.Point(3, 49);
			this.panel_Mark_Data.Name = "panel_Mark_Data";
			this.panel_Mark_Data.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
			this.panel_Mark_Data.Size = new System.Drawing.Size(528, 21);
			this.panel_Mark_Data.TabIndex = 32;
			this.textBox_ItemCode.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox_ItemCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_ItemCode.ForeColor = System.Drawing.SystemColors.WindowText;
			this.textBox_ItemCode.Location = new System.Drawing.Point(398, 0);
			this.textBox_ItemCode.MaxLength = 64;
			this.textBox_ItemCode.Name = "textBox_ItemCode";
			this.textBox_ItemCode.Size = new System.Drawing.Size(127, 20);
			this.textBox_ItemCode.TabIndex = 26;
			this.textBox_ItemID.Dock = System.Windows.Forms.DockStyle.Left;
			this.textBox_ItemID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_ItemID.ForeColor = System.Drawing.SystemColors.WindowText;
			this.textBox_ItemID.Location = new System.Drawing.Point(258, 0);
			this.textBox_ItemID.MaxLength = 64;
			this.textBox_ItemID.MinimumSize = new System.Drawing.Size(4, 21);
			this.textBox_ItemID.Name = "textBox_ItemID";
			this.textBox_ItemID.Size = new System.Drawing.Size(140, 20);
			this.textBox_ItemID.TabIndex = 2;
			this.comboBox_ItemStatus.Dock = System.Windows.Forms.DockStyle.Left;
			this.comboBox_ItemStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox_ItemStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.comboBox_ItemStatus.FormattingEnabled = true;
			this.comboBox_ItemStatus.Items.AddRange(new object[6] { "0. <<<Не указан>>>", "1. Штучный товар, реализован", "2. Мерный товар, в стадии реализации", "3. Штучный товар, возвращен", "4. Часть товара, возвращена", "255. Статус товара не изменился" });
			this.comboBox_ItemStatus.Location = new System.Drawing.Point(78, 0);
			this.comboBox_ItemStatus.Name = "comboBox_ItemStatus";
			this.comboBox_ItemStatus.Size = new System.Drawing.Size(180, 21);
			this.comboBox_ItemStatus.TabIndex = 25;
			this.comboBox_TypeOfCode.Dock = System.Windows.Forms.DockStyle.Left;
			this.comboBox_TypeOfCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox_TypeOfCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.comboBox_TypeOfCode.FormattingEnabled = true;
			this.comboBox_TypeOfCode.Items.AddRange(new object[16]
			{
				"Неизв.", "EAN-8", "EAN-13", "ITF-14", "GS1.0", "GS1.М", "КМК", "МИ", "ЕГАИС-2.0", "ЕГАИС-3.0",
				"Ф.1", "Ф.2", "Ф.3", "Ф.4", "Ф.5", "Ф.6"
			});
			this.comboBox_TypeOfCode.Location = new System.Drawing.Point(3, 0);
			this.comboBox_TypeOfCode.Name = "comboBox_TypeOfCode";
			this.comboBox_TypeOfCode.Size = new System.Drawing.Size(75, 21);
			this.comboBox_TypeOfCode.TabIndex = 22;
			this.panel_Mark_Header.Controls.Add(this.label_ItemCode);
			this.panel_Mark_Header.Controls.Add(this.label_ItemID);
			this.panel_Mark_Header.Controls.Add(this.label_ItemStatus);
			this.panel_Mark_Header.Controls.Add(this.label_TypeOfCode);
			this.panel_Mark_Header.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Mark_Header.Location = new System.Drawing.Point(3, 37);
			this.panel_Mark_Header.Name = "panel_Mark_Header";
			this.panel_Mark_Header.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
			this.panel_Mark_Header.Size = new System.Drawing.Size(528, 12);
			this.panel_Mark_Header.TabIndex = 31;
			this.label_ItemCode.Dock = System.Windows.Forms.DockStyle.Left;
			this.label_ItemCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_ItemCode.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_ItemCode.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_ItemCode.Location = new System.Drawing.Point(383, 0);
			this.label_ItemCode.Margin = new System.Windows.Forms.Padding(3);
			this.label_ItemCode.Name = "label_ItemCode";
			this.label_ItemCode.Size = new System.Drawing.Size(140, 12);
			this.label_ItemCode.TabIndex = 15;
			this.label_ItemCode.Text = "Код товара";
			this.label_ItemCode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label_ItemID.Dock = System.Windows.Forms.DockStyle.Left;
			this.label_ItemID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_ItemID.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_ItemID.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_ItemID.Location = new System.Drawing.Point(243, 0);
			this.label_ItemID.Margin = new System.Windows.Forms.Padding(3);
			this.label_ItemID.Name = "label_ItemID";
			this.label_ItemID.Size = new System.Drawing.Size(140, 12);
			this.label_ItemID.TabIndex = 13;
			this.label_ItemID.Text = "Идентификатор товара";
			this.label_ItemID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label_ItemStatus.Dock = System.Windows.Forms.DockStyle.Left;
			this.label_ItemStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_ItemStatus.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_ItemStatus.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_ItemStatus.Location = new System.Drawing.Point(63, 0);
			this.label_ItemStatus.Margin = new System.Windows.Forms.Padding(3);
			this.label_ItemStatus.Name = "label_ItemStatus";
			this.label_ItemStatus.Size = new System.Drawing.Size(180, 12);
			this.label_ItemStatus.TabIndex = 13;
			this.label_ItemStatus.Text = "Планируемый статус товара";
			this.label_ItemStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label_TypeOfCode.Dock = System.Windows.Forms.DockStyle.Left;
			this.label_TypeOfCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_TypeOfCode.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_TypeOfCode.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_TypeOfCode.Location = new System.Drawing.Point(3, 0);
			this.label_TypeOfCode.Margin = new System.Windows.Forms.Padding(3);
			this.label_TypeOfCode.Name = "label_TypeOfCode";
			this.label_TypeOfCode.Size = new System.Drawing.Size(60, 12);
			this.label_TypeOfCode.TabIndex = 14;
			this.label_TypeOfCode.Text = "Тип КМ";
			this.label_TypeOfCode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.panel_ItemMark.Controls.Add(this.comboBox_Mark);
			this.panel_ItemMark.Controls.Add(this.checkBox_ItemMark);
			this.panel_ItemMark.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_ItemMark.Location = new System.Drawing.Point(3, 16);
			this.panel_ItemMark.Name = "panel_ItemMark";
			this.panel_ItemMark.Size = new System.Drawing.Size(528, 21);
			this.panel_ItemMark.TabIndex = 33;
			this.comboBox_Mark.Dock = System.Windows.Forms.DockStyle.Fill;
			this.comboBox_Mark.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.comboBox_Mark.ForeColor = System.Drawing.SystemColors.InactiveCaption;
			this.comboBox_Mark.FormattingEnabled = true;
			this.comboBox_Mark.Location = new System.Drawing.Point(15, 0);
			this.comboBox_Mark.Name = "comboBox_Mark";
			this.comboBox_Mark.Size = new System.Drawing.Size(513, 21);
			this.comboBox_Mark.TabIndex = 6;
			this.comboBox_Mark.TextChanged += new System.EventHandler(comboBox_Mark_TextChanged);
			this.comboBox_Mark.Click += new System.EventHandler(comboBox_Mark_TextClick);
			this.checkBox_ItemMark.AutoSize = true;
			this.checkBox_ItemMark.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkBox_ItemMark.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_ItemMark.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_ItemMark.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_ItemMark.Location = new System.Drawing.Point(0, 0);
			this.checkBox_ItemMark.Name = "checkBox_ItemMark";
			this.checkBox_ItemMark.Size = new System.Drawing.Size(15, 21);
			this.checkBox_ItemMark.TabIndex = 33;
			this.checkBox_ItemMark.UseVisualStyleBackColor = true;
			this.checkBox_ItemMark.CheckedChanged += new System.EventHandler(checkBox_ItemMark_CheckedChanged);
			this.panel_Ticket_Option4.Controls.Add(this.textBox_ItemDR);
			this.panel_Ticket_Option4.Controls.Add(this.dateTimePicker_FoivDate);
			this.panel_Ticket_Option4.Controls.Add(this.textBox_Ticket_FoivNo);
			this.panel_Ticket_Option4.Controls.Add(this.textBox_Ticket_Foiv);
			this.panel_Ticket_Option4.Controls.Add(this.textBox_Ticket_FoivID);
			this.panel_Ticket_Option4.Controls.Add(this.checkBox_Foiv);
			this.panel_Ticket_Option4.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Ticket_Option4.Location = new System.Drawing.Point(73, 123);
			this.panel_Ticket_Option4.Name = "panel_Ticket_Option4";
			this.panel_Ticket_Option4.Padding = new System.Windows.Forms.Padding(3, 0, 3, 5);
			this.panel_Ticket_Option4.Size = new System.Drawing.Size(534, 28);
			this.panel_Ticket_Option4.TabIndex = 27;
			this.textBox_ItemDR.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_ItemDR.Location = new System.Drawing.Point(371, 0);
			this.textBox_ItemDR.MaxLength = 64;
			this.textBox_ItemDR.Name = "textBox_ItemDR";
			this.textBox_ItemDR.Size = new System.Drawing.Size(160, 20);
			this.textBox_ItemDR.TabIndex = 19;
			this.dateTimePicker_FoivDate.Checked = false;
			this.dateTimePicker_FoivDate.CustomFormat = "dd.MM.yyyy HH:mm";
			this.dateTimePicker_FoivDate.Dock = System.Windows.Forms.DockStyle.Left;
			this.dateTimePicker_FoivDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.dateTimePicker_FoivDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			this.dateTimePicker_FoivDate.ImeMode = System.Windows.Forms.ImeMode.Off;
			this.dateTimePicker_FoivDate.Location = new System.Drawing.Point(256, 0);
			this.dateTimePicker_FoivDate.MaxDate = new System.DateTime(2099, 12, 31, 0, 0, 0, 0);
			this.dateTimePicker_FoivDate.MinDate = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
			this.dateTimePicker_FoivDate.Name = "dateTimePicker_FoivDate";
			this.dateTimePicker_FoivDate.ShowCheckBox = true;
			this.dateTimePicker_FoivDate.Size = new System.Drawing.Size(100, 20);
			this.dateTimePicker_FoivDate.TabIndex = 18;
			this.dateTimePicker_FoivDate.Value = new System.DateTime(2023, 3, 13, 23, 26, 21, 0);
			this.dateTimePicker_FoivDate.ValueChanged += new System.EventHandler(dateTimePicker_FoivDate_ValueChanged);
			this.textBox_Ticket_FoivNo.Dock = System.Windows.Forms.DockStyle.Left;
			this.textBox_Ticket_FoivNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_Ticket_FoivNo.ForeColor = System.Drawing.SystemColors.GrayText;
			this.textBox_Ticket_FoivNo.Location = new System.Drawing.Point(206, 0);
			this.textBox_Ticket_FoivNo.MaxLength = 128;
			this.textBox_Ticket_FoivNo.Name = "textBox_Ticket_FoivNo";
			this.textBox_Ticket_FoivNo.Size = new System.Drawing.Size(50, 20);
			this.textBox_Ticket_FoivNo.TabIndex = 12;
			this.textBox_Ticket_FoivNo.Text = "123";
			this.textBox_Ticket_FoivNo.Click += new System.EventHandler(textBox_TextChanged);
			this.textBox_Ticket_Foiv.Dock = System.Windows.Forms.DockStyle.Left;
			this.textBox_Ticket_Foiv.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_Ticket_Foiv.ForeColor = System.Drawing.SystemColors.GrayText;
			this.textBox_Ticket_Foiv.Location = new System.Drawing.Point(66, 0);
			this.textBox_Ticket_Foiv.MaxLength = 128;
			this.textBox_Ticket_Foiv.Name = "textBox_Ticket_Foiv";
			this.textBox_Ticket_Foiv.Size = new System.Drawing.Size(140, 20);
			this.textBox_Ticket_Foiv.TabIndex = 11;
			this.textBox_Ticket_Foiv.Text = "Ид1=Знач1&Ид2=Знач2";
			this.textBox_Ticket_Foiv.Click += new System.EventHandler(textBox_TextChanged);
			this.textBox_Ticket_FoivID.Dock = System.Windows.Forms.DockStyle.Left;
			this.textBox_Ticket_FoivID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_Ticket_FoivID.ForeColor = System.Drawing.SystemColors.GrayText;
			this.textBox_Ticket_FoivID.Location = new System.Drawing.Point(18, 0);
			this.textBox_Ticket_FoivID.MaxLength = 128;
			this.textBox_Ticket_FoivID.Name = "textBox_Ticket_FoivID";
			this.textBox_Ticket_FoivID.Size = new System.Drawing.Size(48, 20);
			this.textBox_Ticket_FoivID.TabIndex = 1;
			this.textBox_Ticket_FoivID.Text = "001";
			this.textBox_Ticket_FoivID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.textBox_Ticket_FoivID.Click += new System.EventHandler(textBox_TextChanged);
			this.checkBox_Foiv.AutoSize = true;
			this.checkBox_Foiv.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkBox_Foiv.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_Foiv.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_Foiv.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_Foiv.Location = new System.Drawing.Point(3, 0);
			this.checkBox_Foiv.Name = "checkBox_Foiv";
			this.checkBox_Foiv.Size = new System.Drawing.Size(15, 23);
			this.checkBox_Foiv.TabIndex = 34;
			this.checkBox_Foiv.UseVisualStyleBackColor = true;
			this.checkBox_Foiv.CheckedChanged += new System.EventHandler(checkBox_Foiv_CheckedChanged);
			this.panel_Ticket_Option41.Controls.Add(this.label_ItemDR);
			this.panel_Ticket_Option41.Controls.Add(this.label_FoivDate);
			this.panel_Ticket_Option41.Controls.Add(this.label11);
			this.panel_Ticket_Option41.Controls.Add(this.label12);
			this.panel_Ticket_Option41.Controls.Add(this.label13);
			this.panel_Ticket_Option41.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Ticket_Option41.Location = new System.Drawing.Point(73, 111);
			this.panel_Ticket_Option41.Name = "panel_Ticket_Option41";
			this.panel_Ticket_Option41.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
			this.panel_Ticket_Option41.Size = new System.Drawing.Size(534, 12);
			this.panel_Ticket_Option41.TabIndex = 29;
			this.label_ItemDR.Dock = System.Windows.Forms.DockStyle.Left;
			this.label_ItemDR.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_ItemDR.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_ItemDR.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_ItemDR.Location = new System.Drawing.Point(371, 0);
			this.label_ItemDR.Margin = new System.Windows.Forms.Padding(3);
			this.label_ItemDR.Name = "label_ItemDR";
			this.label_ItemDR.Size = new System.Drawing.Size(160, 12);
			this.label_ItemDR.TabIndex = 16;
			this.label_ItemDR.Text = "Дополнительный реквизит";
			this.label_ItemDR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label_FoivDate.Dock = System.Windows.Forms.DockStyle.Left;
			this.label_FoivDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_FoivDate.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_FoivDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_FoivDate.Location = new System.Drawing.Point(256, 0);
			this.label_FoivDate.Margin = new System.Windows.Forms.Padding(3);
			this.label_FoivDate.Name = "label_FoivDate";
			this.label_FoivDate.Size = new System.Drawing.Size(115, 12);
			this.label_FoivDate.TabIndex = 13;
			this.label_FoivDate.Text = "Дата док.осн.";
			this.label_FoivDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.label11.Dock = System.Windows.Forms.DockStyle.Left;
			this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label11.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label11.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label11.Location = new System.Drawing.Point(206, 0);
			this.label11.Margin = new System.Windows.Forms.Padding(3);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(50, 12);
			this.label11.TabIndex = 13;
			this.label11.Text = "Док.№";
			this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.label12.Dock = System.Windows.Forms.DockStyle.Left;
			this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label12.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label12.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label12.Location = new System.Drawing.Point(66, 0);
			this.label12.Margin = new System.Windows.Forms.Padding(3);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(140, 12);
			this.label12.TabIndex = 13;
			this.label12.Text = "Значение отр. реквизита";
			this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.label13.Dock = System.Windows.Forms.DockStyle.Left;
			this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label13.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label13.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label13.Location = new System.Drawing.Point(3, 0);
			this.label13.Margin = new System.Windows.Forms.Padding(3);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(63, 12);
			this.label13.TabIndex = 14;
			this.label13.Text = "ФОИВ";
			this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.panel_Ticket_Option3.BackColor = System.Drawing.Color.LightBlue;
			this.panel_Ticket_Option3.Controls.Add(this.textBox_ItemCountry);
			this.panel_Ticket_Option3.Controls.Add(this.textBox_ItemCustomNo);
			this.panel_Ticket_Option3.Controls.Add(this.comboBox_PaymentType);
			this.panel_Ticket_Option3.Controls.Add(this.numericUpDown_PricePerPiece);
			this.panel_Ticket_Option3.Controls.Add(this.numeric_QtyDenom);
			this.panel_Ticket_Option3.Controls.Add(this.numeric_QtyNom);
			this.panel_Ticket_Option3.Controls.Add(this.checkBox_Fraction);
			this.panel_Ticket_Option3.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Ticket_Option3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.panel_Ticket_Option3.Location = new System.Drawing.Point(73, 83);
			this.panel_Ticket_Option3.Name = "panel_Ticket_Option3";
			this.panel_Ticket_Option3.Padding = new System.Windows.Forms.Padding(3, 0, 3, 5);
			this.panel_Ticket_Option3.Size = new System.Drawing.Size(534, 28);
			this.panel_Ticket_Option3.TabIndex = 24;
			this.textBox_ItemCountry.Location = new System.Drawing.Point(262, 0);
			this.textBox_ItemCountry.MaxLength = 3;
			this.textBox_ItemCountry.Name = "textBox_ItemCountry";
			this.textBox_ItemCountry.Size = new System.Drawing.Size(40, 20);
			this.textBox_ItemCountry.TabIndex = 2;
			this.textBox_ItemCountry.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.textBox_ItemCustomNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_ItemCustomNo.Location = new System.Drawing.Point(310, 0);
			this.textBox_ItemCustomNo.MaxLength = 32;
			this.textBox_ItemCustomNo.Name = "textBox_ItemCustomNo";
			this.textBox_ItemCustomNo.Size = new System.Drawing.Size(95, 20);
			this.textBox_ItemCustomNo.TabIndex = 2;
			this.comboBox_PaymentType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox_PaymentType.DropDownWidth = 170;
			this.comboBox_PaymentType.FormattingEnabled = true;
			this.comboBox_PaymentType.Items.AddRange(new object[8] { "-по умолчанию-", "1.Предоплата 100%", "2.Предоплата", "3.Аванс", "4.Полный расчет", "5.Частичный расчет и кредит", "6.Передача в кредит", "7.Оплата кредита" });
			this.comboBox_PaymentType.Location = new System.Drawing.Point(413, 0);
			this.comboBox_PaymentType.Name = "comboBox_PaymentType";
			this.comboBox_PaymentType.Size = new System.Drawing.Size(118, 21);
			this.comboBox_PaymentType.TabIndex = 16;
			this.numericUpDown_PricePerPiece.DecimalPlaces = 2;
			this.numericUpDown_PricePerPiece.Location = new System.Drawing.Point(175, 0);
			this.numericUpDown_PricePerPiece.Maximum = new decimal(new int[4] { -1, 255, 0, 131072 });
			this.numericUpDown_PricePerPiece.Name = "numericUpDown_PricePerPiece";
			this.numericUpDown_PricePerPiece.Size = new System.Drawing.Size(79, 20);
			this.numericUpDown_PricePerPiece.TabIndex = 5;
			this.numericUpDown_PricePerPiece.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.numericUpDown_PricePerPiece.ThousandsSeparator = true;
			this.numeric_QtyDenom.Dock = System.Windows.Forms.DockStyle.Left;
			this.numeric_QtyDenom.Location = new System.Drawing.Point(93, 0);
			this.numeric_QtyDenom.Maximum = new decimal(new int[4] { 1000000, 0, 0, 0 });
			this.numeric_QtyDenom.Minimum = new decimal(new int[4] { 1000000, 0, 0, -2147483648 });
			this.numeric_QtyDenom.Name = "numeric_QtyDenom";
			this.numeric_QtyDenom.Size = new System.Drawing.Size(75, 20);
			this.numeric_QtyDenom.TabIndex = 5;
			this.numeric_QtyDenom.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.numeric_QtyDenom.ThousandsSeparator = true;
			this.numeric_QtyDenom.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			this.numeric_QtyNom.Dock = System.Windows.Forms.DockStyle.Left;
			this.numeric_QtyNom.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.numeric_QtyNom.Location = new System.Drawing.Point(18, 0);
			this.numeric_QtyNom.Maximum = new decimal(new int[4] { 1000000, 0, 0, 0 });
			this.numeric_QtyNom.Minimum = new decimal(new int[4] { 1000000, 0, 0, -2147483648 });
			this.numeric_QtyNom.Name = "numeric_QtyNom";
			this.numeric_QtyNom.Size = new System.Drawing.Size(75, 20);
			this.numeric_QtyNom.TabIndex = 5;
			this.numeric_QtyNom.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.numeric_QtyNom.ThousandsSeparator = true;
			this.numeric_QtyNom.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			this.checkBox_Fraction.AutoSize = true;
			this.checkBox_Fraction.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkBox_Fraction.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_Fraction.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_Fraction.Location = new System.Drawing.Point(3, 0);
			this.checkBox_Fraction.Name = "checkBox_Fraction";
			this.checkBox_Fraction.Size = new System.Drawing.Size(15, 23);
			this.checkBox_Fraction.TabIndex = 15;
			this.checkBox_Fraction.UseVisualStyleBackColor = true;
			this.panel_Ticket_Option31.BackColor = System.Drawing.Color.LightBlue;
			this.panel_Ticket_Option31.Controls.Add(this.label_ItemCountry);
			this.panel_Ticket_Option31.Controls.Add(this.label_ItemCustomNo);
			this.panel_Ticket_Option31.Controls.Add(this.label_PaymentType);
			this.panel_Ticket_Option31.Controls.Add(this.label_PricePerPiece);
			this.panel_Ticket_Option31.Controls.Add(this.label_Qty_Nom_Denom);
			this.panel_Ticket_Option31.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Ticket_Option31.Location = new System.Drawing.Point(73, 71);
			this.panel_Ticket_Option31.Name = "panel_Ticket_Option31";
			this.panel_Ticket_Option31.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
			this.panel_Ticket_Option31.Size = new System.Drawing.Size(534, 12);
			this.panel_Ticket_Option31.TabIndex = 23;
			this.label_ItemCountry.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_ItemCountry.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_ItemCountry.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_ItemCountry.Location = new System.Drawing.Point(260, 0);
			this.label_ItemCountry.Margin = new System.Windows.Forms.Padding(3);
			this.label_ItemCountry.Name = "label_ItemCountry";
			this.label_ItemCountry.Size = new System.Drawing.Size(44, 12);
			this.label_ItemCountry.TabIndex = 13;
			this.label_ItemCountry.Text = "Страна";
			this.label_ItemCountry.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label_ItemCustomNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_ItemCustomNo.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_ItemCustomNo.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_ItemCustomNo.Location = new System.Drawing.Point(306, 0);
			this.label_ItemCustomNo.Margin = new System.Windows.Forms.Padding(3);
			this.label_ItemCustomNo.Name = "label_ItemCustomNo";
			this.label_ItemCustomNo.Size = new System.Drawing.Size(105, 12);
			this.label_ItemCustomNo.TabIndex = 13;
			this.label_ItemCustomNo.Text = "Тамож.декларация";
			this.label_ItemCustomNo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label_PaymentType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_PaymentType.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_PaymentType.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_PaymentType.Location = new System.Drawing.Point(411, 0);
			this.label_PaymentType.Margin = new System.Windows.Forms.Padding(3);
			this.label_PaymentType.Name = "label_PaymentType";
			this.label_PaymentType.Size = new System.Drawing.Size(120, 12);
			this.label_PaymentType.TabIndex = 13;
			this.label_PaymentType.Text = "Способ расчета";
			this.label_PaymentType.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label_PricePerPiece.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_PricePerPiece.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_PricePerPiece.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_PricePerPiece.Location = new System.Drawing.Point(180, 0);
			this.label_PricePerPiece.Margin = new System.Windows.Forms.Padding(3);
			this.label_PricePerPiece.Name = "label_PricePerPiece";
			this.label_PricePerPiece.Size = new System.Drawing.Size(72, 12);
			this.label_PricePerPiece.TabIndex = 13;
			this.label_PricePerPiece.Text = "Цена за ед.";
			this.label_PricePerPiece.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label_Qty_Nom_Denom.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_Qty_Nom_Denom.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Qty_Nom_Denom.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Qty_Nom_Denom.Location = new System.Drawing.Point(0, 0);
			this.label_Qty_Nom_Denom.Margin = new System.Windows.Forms.Padding(3);
			this.label_Qty_Nom_Denom.Name = "label_Qty_Nom_Denom";
			this.label_Qty_Nom_Denom.Size = new System.Drawing.Size(176, 13);
			this.label_Qty_Nom_Denom.TabIndex = 14;
			this.label_Qty_Nom_Denom.Text = "Дроб:Числитель/Знаменатель";
			this.label_Qty_Nom_Denom.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.panel_Ticket_Option2.Controls.Add(this.numeric_ItemAmount);
			this.panel_Ticket_Option2.Controls.Add(this.comboBox_ItemNDS);
			this.panel_Ticket_Option2.Controls.Add(this.numeric_ItemExcise);
			this.panel_Ticket_Option2.Controls.Add(this.numeric_ItemPrice);
			this.panel_Ticket_Option2.Controls.Add(this.comboBox_ItemType);
			this.panel_Ticket_Option2.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Ticket_Option2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.panel_Ticket_Option2.Location = new System.Drawing.Point(73, 43);
			this.panel_Ticket_Option2.Name = "panel_Ticket_Option2";
			this.panel_Ticket_Option2.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
			this.panel_Ticket_Option2.Size = new System.Drawing.Size(534, 28);
			this.panel_Ticket_Option2.TabIndex = 20;
			this.numeric_ItemAmount.DecimalPlaces = 2;
			this.numeric_ItemAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.numeric_ItemAmount.Location = new System.Drawing.Point(111, 0);
			this.numeric_ItemAmount.Maximum = new decimal(new int[4] { -1, 255, 0, 131072 });
			this.numeric_ItemAmount.Name = "numeric_ItemAmount";
			this.numeric_ItemAmount.Size = new System.Drawing.Size(104, 20);
			this.numeric_ItemAmount.TabIndex = 6;
			this.numeric_ItemAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.numeric_ItemAmount.ThousandsSeparator = true;
			this.comboBox_ItemNDS.Items.AddRange(new object[6] { "20%", "10%", "20/120", "10/110", "0%", "б/н" });
			this.comboBox_ItemNDS.Location = new System.Drawing.Point(326, 0);
			this.comboBox_ItemNDS.MaxDropDownItems = 6;
			this.comboBox_ItemNDS.Name = "comboBox_ItemNDS";
			this.comboBox_ItemNDS.Size = new System.Drawing.Size(60, 21);
			this.comboBox_ItemNDS.TabIndex = 5;
			this.comboBox_ItemNDS.Text = "20%";
			this.numeric_ItemExcise.DecimalPlaces = 2;
			this.numeric_ItemExcise.Location = new System.Drawing.Point(219, 0);
			this.numeric_ItemExcise.Maximum = new decimal(new int[4] { -1, 255, 0, 131072 });
			this.numeric_ItemExcise.Name = "numeric_ItemExcise";
			this.numeric_ItemExcise.Size = new System.Drawing.Size(104, 20);
			this.numeric_ItemExcise.TabIndex = 5;
			this.numeric_ItemExcise.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.numeric_ItemExcise.ThousandsSeparator = true;
			this.numeric_ItemPrice.DecimalPlaces = 2;
			this.numeric_ItemPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.numeric_ItemPrice.Location = new System.Drawing.Point(0, 0);
			this.numeric_ItemPrice.Maximum = new decimal(new int[4] { -1, 255, 0, 131072 });
			this.numeric_ItemPrice.Name = "numeric_ItemPrice";
			this.numeric_ItemPrice.Size = new System.Drawing.Size(104, 20);
			this.numeric_ItemPrice.TabIndex = 5;
			this.numeric_ItemPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.numeric_ItemPrice.ThousandsSeparator = true;
			this.numeric_ItemPrice.Value = new decimal(new int[4] { 10, 0, 0, 0 });
			this.numeric_ItemPrice.ValueChanged += new System.EventHandler(Numeric_ItemPrice_ValueChanged);
			this.comboBox_ItemType.DropDownHeight = 500;
			this.comboBox_ItemType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox_ItemType.DropDownWidth = 180;
			this.comboBox_ItemType.FormattingEnabled = true;
			this.comboBox_ItemType.IntegralHeight = false;
			this.comboBox_ItemType.Items.AddRange(new object[32]
			{
				"0. по умолчанию", "1. Товар", "2. Подакцизный товар", "3. Работа", "4. Услуга", "5. Ставка азартной игры", "6. Выигрыш азартной игры", "7. Лотерейный билет", "8. Выигрыш лотереи", "9. Предоставление РИД",
				"10.Платеж", "11.Агентское вознаграждение", "12.Выплата", "13.Иной предмет расчета", "14.Имущественное право", "15.Внереализационный доход", "16.Иные платежи и взносы", "17.Торговый сбор", "18.Курортный сбор", "19.Залог",
				"20.Расход", "21.Взносы на ОПС ИП", "22.Взносы на ОПС", "23.Взносы на ОМС ИП", "24.Взносы на ОМС", "25.Взносы на ОСС", "26.Платеж казино", "27.Выдача ДС", "30.АТНМ-акцизный товар без КМ", "31.АТМ-акцизный товар с КМ",
				"32.ТНМ-товар без КМ", "33.ТМ-товар с КМ"
			});
			this.comboBox_ItemType.Location = new System.Drawing.Point(413, 0);
			this.comboBox_ItemType.MaxDropDownItems = 32;
			this.comboBox_ItemType.Name = "comboBox_ItemType";
			this.comboBox_ItemType.Size = new System.Drawing.Size(118, 21);
			this.comboBox_ItemType.TabIndex = 5;
			this.panel_Ticket_Option21.Controls.Add(this.label_ItemNDS);
			this.panel_Ticket_Option21.Controls.Add(this.label_ItemExcise);
			this.panel_Ticket_Option21.Controls.Add(this.label_ItemAmount);
			this.panel_Ticket_Option21.Controls.Add(this.label_ItemPrice);
			this.panel_Ticket_Option21.Controls.Add(this.label_ItemType);
			this.panel_Ticket_Option21.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Ticket_Option21.Location = new System.Drawing.Point(73, 31);
			this.panel_Ticket_Option21.Name = "panel_Ticket_Option21";
			this.panel_Ticket_Option21.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
			this.panel_Ticket_Option21.Size = new System.Drawing.Size(534, 12);
			this.panel_Ticket_Option21.TabIndex = 19;
			this.label_ItemNDS.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_ItemNDS.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_ItemNDS.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_ItemNDS.Location = new System.Drawing.Point(326, 0);
			this.label_ItemNDS.Margin = new System.Windows.Forms.Padding(3);
			this.label_ItemNDS.Name = "label_ItemNDS";
			this.label_ItemNDS.Size = new System.Drawing.Size(60, 13);
			this.label_ItemNDS.TabIndex = 13;
			this.label_ItemNDS.Text = "НДС";
			this.label_ItemNDS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label_ItemExcise.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_ItemExcise.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_ItemExcise.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_ItemExcise.Location = new System.Drawing.Point(219, 0);
			this.label_ItemExcise.Margin = new System.Windows.Forms.Padding(3);
			this.label_ItemExcise.Name = "label_ItemExcise";
			this.label_ItemExcise.Size = new System.Drawing.Size(104, 12);
			this.label_ItemExcise.TabIndex = 13;
			this.label_ItemExcise.Text = "Акциз";
			this.label_ItemExcise.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label_ItemAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_ItemAmount.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_ItemAmount.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_ItemAmount.Location = new System.Drawing.Point(110, 0);
			this.label_ItemAmount.Margin = new System.Windows.Forms.Padding(3);
			this.label_ItemAmount.Name = "label_ItemAmount";
			this.label_ItemAmount.Size = new System.Drawing.Size(104, 12);
			this.label_ItemAmount.TabIndex = 13;
			this.label_ItemAmount.Text = "Сумма";
			this.label_ItemAmount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label_ItemPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_ItemPrice.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_ItemPrice.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_ItemPrice.Location = new System.Drawing.Point(3, 0);
			this.label_ItemPrice.Margin = new System.Windows.Forms.Padding(3);
			this.label_ItemPrice.Name = "label_ItemPrice";
			this.label_ItemPrice.Size = new System.Drawing.Size(104, 12);
			this.label_ItemPrice.TabIndex = 13;
			this.label_ItemPrice.Text = "Цена";
			this.label_ItemPrice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label_ItemType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_ItemType.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_ItemType.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_ItemType.Location = new System.Drawing.Point(412, 0);
			this.label_ItemType.Margin = new System.Windows.Forms.Padding(3);
			this.label_ItemType.Name = "label_ItemType";
			this.label_ItemType.Size = new System.Drawing.Size(120, 12);
			this.label_ItemType.TabIndex = 13;
			this.label_ItemType.Text = "Признак предмета";
			this.label_ItemType.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.panel_Ticket_Option1.BackColor = System.Drawing.Color.LightBlue;
			this.panel_Ticket_Option1.Controls.Add(this.comboBox_ItemMeasure);
			this.panel_Ticket_Option1.Controls.Add(this.numeric_ItemQty);
			this.panel_Ticket_Option1.Controls.Add(this.textBox_ItemName);
			this.panel_Ticket_Option1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Ticket_Option1.Location = new System.Drawing.Point(73, 3);
			this.panel_Ticket_Option1.Name = "panel_Ticket_Option1";
			this.panel_Ticket_Option1.Padding = new System.Windows.Forms.Padding(3);
			this.panel_Ticket_Option1.Size = new System.Drawing.Size(534, 28);
			this.panel_Ticket_Option1.TabIndex = 18;
			this.comboBox_ItemMeasure.Dock = System.Windows.Forms.DockStyle.Left;
			this.comboBox_ItemMeasure.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.comboBox_ItemMeasure.Items.AddRange(new object[24]
			{
				"0. шт", "10. гр", "11. кг", "12. т", "20. см", "21. дм", "22. м", "30. см2", "31. дм2", "32. м2",
				"40. мл", "41. л", "42. м3", "50. квч", "51. гкал", "70. сут", "71. час", "72. мин", "73. сек", "80. Кб",
				"81. Мб", "82. Гб", "83. Тб", "255.xxx"
			});
			this.comboBox_ItemMeasure.Location = new System.Drawing.Point(466, 3);
			this.comboBox_ItemMeasure.MaxDropDownItems = 24;
			this.comboBox_ItemMeasure.Name = "comboBox_ItemMeasure";
			this.comboBox_ItemMeasure.Size = new System.Drawing.Size(65, 21);
			this.comboBox_ItemMeasure.TabIndex = 16;
			this.toolTip1.SetToolTip(this.comboBox_ItemMeasure, "Мера количества");
			this.numeric_ItemQty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.numeric_ItemQty.DecimalPlaces = 6;
			this.numeric_ItemQty.Dock = System.Windows.Forms.DockStyle.Left;
			this.numeric_ItemQty.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.numeric_ItemQty.Location = new System.Drawing.Point(378, 3);
			this.numeric_ItemQty.Maximum = new decimal(new int[4] { -1, 255, 0, 131072 });
			this.numeric_ItemQty.Name = "numeric_ItemQty";
			this.numeric_ItemQty.Size = new System.Drawing.Size(88, 20);
			this.numeric_ItemQty.TabIndex = 5;
			this.numeric_ItemQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.numeric_ItemQty.ThousandsSeparator = true;
			this.numeric_ItemQty.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			this.numeric_ItemQty.ValueChanged += new System.EventHandler(Numeric_ItemPrice_ValueChanged);
			this.textBox_ItemName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.textBox_ItemName.Dock = System.Windows.Forms.DockStyle.Left;
			this.textBox_ItemName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_ItemName.Location = new System.Drawing.Point(3, 3);
			this.textBox_ItemName.MaxLength = 256;
			this.textBox_ItemName.Name = "textBox_ItemName";
			this.textBox_ItemName.Size = new System.Drawing.Size(375, 20);
			this.textBox_ItemName.TabIndex = 5;
			this.textBox_ItemName.Text = "Конфеты \"Красная Шапочка\"";
			this.panel_Ticket_ItemAddTest.BackColor = System.Drawing.Color.LightCyan;
			this.panel_Ticket_ItemAddTest.Controls.Add(this.checkBox_Agent);
			this.panel_Ticket_ItemAddTest.Controls.Add(this.checkBox_PreCheck);
			this.panel_Ticket_ItemAddTest.Controls.Add(this.button_MarkClear);
			this.panel_Ticket_ItemAddTest.Controls.Add(this.checkBox_ShowResult);
			this.panel_Ticket_ItemAddTest.Controls.Add(this.checkBox_Autonom);
			this.panel_Ticket_ItemAddTest.Controls.Add(this.button_MarkReset);
			this.panel_Ticket_ItemAddTest.Controls.Add(this.button_MarkResult);
			this.panel_Ticket_ItemAddTest.Controls.Add(this.button_MarkVerify);
			this.panel_Ticket_ItemAddTest.Controls.Add(this.button_ItemAgent);
			this.panel_Ticket_ItemAddTest.Controls.Add(this.button_AddItem);
			this.panel_Ticket_ItemAddTest.Controls.Add(this.checkBox_ItemOptions);
			this.panel_Ticket_ItemAddTest.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel_Ticket_ItemAddTest.Location = new System.Drawing.Point(3, 3);
			this.panel_Ticket_ItemAddTest.Name = "panel_Ticket_ItemAddTest";
			this.panel_Ticket_ItemAddTest.Size = new System.Drawing.Size(70, 130);
			this.panel_Ticket_ItemAddTest.TabIndex = 17;
			this.checkBox_Agent.BackColor = System.Drawing.Color.Transparent;
			this.checkBox_Agent.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Italic);
			this.checkBox_Agent.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_Agent.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_Agent.Location = new System.Drawing.Point(55, 55);
			this.checkBox_Agent.Name = "checkBox_Agent";
			this.checkBox_Agent.Size = new System.Drawing.Size(13, 13);
			this.checkBox_Agent.TabIndex = 34;
			this.checkBox_Agent.UseVisualStyleBackColor = false;
			this.checkBox_PreCheck.BackColor = System.Drawing.Color.Transparent;
			this.checkBox_PreCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Italic);
			this.checkBox_PreCheck.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_PreCheck.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_PreCheck.Location = new System.Drawing.Point(55, 141);
			this.checkBox_PreCheck.Name = "checkBox_PreCheck";
			this.checkBox_PreCheck.Size = new System.Drawing.Size(13, 13);
			this.checkBox_PreCheck.TabIndex = 33;
			this.checkBox_PreCheck.UseVisualStyleBackColor = false;
			this.checkBox_PreCheck.CheckedChanged += new System.EventHandler(checkBox_PreCheck_CheckedChanged);
			this.button_MarkClear.BackColor = System.Drawing.Color.Transparent;
			this.button_MarkClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.button_MarkClear.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_MarkClear.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_MarkClear.Location = new System.Drawing.Point(0, 205);
			this.button_MarkClear.Name = "button_MarkClear";
			this.button_MarkClear.Size = new System.Drawing.Size(70, 22);
			this.button_MarkClear.TabIndex = 32;
			this.button_MarkClear.Text = "Очистить";
			this.button_MarkClear.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.button_MarkClear.UseVisualStyleBackColor = false;
			this.button_MarkClear.Click += new System.EventHandler(button_ClearAll_Click);
			this.checkBox_ShowResult.BackColor = System.Drawing.Color.Transparent;
			this.checkBox_ShowResult.Checked = true;
			this.checkBox_ShowResult.CheckState = System.Windows.Forms.CheckState.Checked;
			this.checkBox_ShowResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.checkBox_ShowResult.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_ShowResult.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_ShowResult.Location = new System.Drawing.Point(55, 163);
			this.checkBox_ShowResult.Name = "checkBox_ShowResult";
			this.checkBox_ShowResult.Size = new System.Drawing.Size(13, 13);
			this.checkBox_ShowResult.TabIndex = 31;
			this.checkBox_ShowResult.UseVisualStyleBackColor = false;
			this.checkBox_Autonom.AutoSize = true;
			this.checkBox_Autonom.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_Autonom.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_Autonom.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_Autonom.Location = new System.Drawing.Point(0, 97);
			this.checkBox_Autonom.Name = "checkBox_Autonom";
			this.checkBox_Autonom.Size = new System.Drawing.Size(73, 17);
			this.checkBox_Autonom.TabIndex = 1;
			this.checkBox_Autonom.Text = "Автоном.";
			this.checkBox_Autonom.UseVisualStyleBackColor = true;
			this.button_MarkReset.BackColor = System.Drawing.Color.Transparent;
			this.button_MarkReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.button_MarkReset.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_MarkReset.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_MarkReset.Location = new System.Drawing.Point(0, 183);
			this.button_MarkReset.Name = "button_MarkReset";
			this.button_MarkReset.Size = new System.Drawing.Size(70, 22);
			this.button_MarkReset.TabIndex = 32;
			this.button_MarkReset.Text = "Отменить";
			this.button_MarkReset.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.button_MarkReset.UseVisualStyleBackColor = false;
			this.button_MarkReset.Click += new System.EventHandler(button_ClearLast_Click);
			this.button_MarkResult.BackColor = System.Drawing.Color.Transparent;
			this.button_MarkResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.button_MarkResult.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_MarkResult.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_MarkResult.Location = new System.Drawing.Point(0, 161);
			this.button_MarkResult.Name = "button_MarkResult";
			this.button_MarkResult.Size = new System.Drawing.Size(70, 22);
			this.button_MarkResult.TabIndex = 30;
			this.button_MarkResult.Text = "Результат";
			this.button_MarkResult.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.button_MarkResult.UseVisualStyleBackColor = false;
			this.button_MarkResult.Click += new System.EventHandler(button_MarkResult_Click);
			this.button_MarkVerify.BackColor = System.Drawing.Color.Transparent;
			this.button_MarkVerify.Enabled = false;
			this.button_MarkVerify.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.button_MarkVerify.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_MarkVerify.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_MarkVerify.Location = new System.Drawing.Point(0, 139);
			this.button_MarkVerify.Name = "button_MarkVerify";
			this.button_MarkVerify.Size = new System.Drawing.Size(70, 22);
			this.button_MarkVerify.TabIndex = 30;
			this.button_MarkVerify.Text = "Тест ФН";
			this.button_MarkVerify.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.button_MarkVerify.UseVisualStyleBackColor = false;
			this.button_MarkVerify.Click += new System.EventHandler(Button_MarkVerify_Click);
			this.button_ItemAgent.BackColor = System.Drawing.Color.Transparent;
			this.button_ItemAgent.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold);
			this.button_ItemAgent.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_ItemAgent.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_ItemAgent.Location = new System.Drawing.Point(0, 53);
			this.button_ItemAgent.Name = "button_ItemAgent";
			this.button_ItemAgent.Size = new System.Drawing.Size(70, 22);
			this.button_ItemAgent.TabIndex = 29;
			this.button_ItemAgent.Text = "Агент";
			this.button_ItemAgent.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.button_ItemAgent.UseVisualStyleBackColor = false;
			this.button_ItemAgent.Click += new System.EventHandler(Button_ItemAgent_Click);
			this.button_AddItem.BackColor = System.Drawing.Color.Transparent;
			this.button_AddItem.Dock = System.Windows.Forms.DockStyle.Top;
			this.button_AddItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold);
			this.button_AddItem.ForeColor = System.Drawing.Color.Brown;
			this.button_AddItem.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_AddItem.Location = new System.Drawing.Point(0, 0);
			this.button_AddItem.Name = "button_AddItem";
			this.button_AddItem.Size = new System.Drawing.Size(70, 50);
			this.button_AddItem.TabIndex = 1;
			this.button_AddItem.TabStop = false;
			this.button_AddItem.Text = "ТОВАР\r\n(предмет\r\nрасчета)";
			this.button_AddItem.UseVisualStyleBackColor = false;
			this.button_AddItem.Click += new System.EventHandler(Button_AddItem_Click);
			this.checkBox_ItemOptions.AutoSize = true;
			this.checkBox_ItemOptions.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.checkBox_ItemOptions.ForeColor = System.Drawing.Color.Blue;
			this.checkBox_ItemOptions.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_ItemOptions.Location = new System.Drawing.Point(0, 77);
			this.checkBox_ItemOptions.Name = "checkBox_ItemOptions";
			this.checkBox_ItemOptions.Size = new System.Drawing.Size(68, 17);
			this.checkBox_ItemOptions.TabIndex = 15;
			this.checkBox_ItemOptions.Text = "Марка!..";
			this.checkBox_ItemOptions.UseVisualStyleBackColor = true;
			this.checkBox_ItemOptions.CheckedChanged += new System.EventHandler(CheckBox_ItemOptions_CheckedChanged);
			this.panel_TicketClose.BackColor = System.Drawing.Color.LightCyan;
			this.panel_TicketClose.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_TicketClose.Controls.Add(this.checkBox_ItemCount);
			this.panel_TicketClose.Controls.Add(this.checkBox_ItemSpace);
			this.panel_TicketClose.Controls.Add(this.checkBox_ItemSeparator);
			this.panel_TicketClose.Controls.Add(this.button_DocCancel1);
			this.panel_TicketClose.Controls.Add(this.button_RunSales);
			this.panel_TicketClose.Controls.Add(this.button_FCh);
			this.panel_TicketClose.Controls.Add(this.button_CCh);
			this.panel_TicketClose.Location = new System.Drawing.Point(6, 387);
			this.panel_TicketClose.Name = "panel_TicketClose";
			this.panel_TicketClose.Padding = new System.Windows.Forms.Padding(1);
			this.panel_TicketClose.Size = new System.Drawing.Size(612, 30);
			this.panel_TicketClose.TabIndex = 0;
			this.checkBox_ItemCount.AutoSize = true;
			this.checkBox_ItemCount.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_ItemCount.Checked = true;
			this.checkBox_ItemCount.CheckState = System.Windows.Forms.CheckState.Checked;
			this.checkBox_ItemCount.Dock = System.Windows.Forms.DockStyle.Right;
			this.checkBox_ItemCount.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_ItemCount.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_ItemCount.Location = new System.Drawing.Point(314, 1);
			this.checkBox_ItemCount.Name = "checkBox_ItemCount";
			this.checkBox_ItemCount.Size = new System.Drawing.Size(104, 26);
			this.checkBox_ItemCount.TabIndex = 19;
			this.checkBox_ItemCount.Text = "Кол-во товаров";
			this.toolTip1.SetToolTip(this.checkBox_ItemCount, "Печатать количество предметов расчета в чеке");
			this.checkBox_ItemCount.UseVisualStyleBackColor = true;
			this.checkBox_ItemSpace.AutoSize = true;
			this.checkBox_ItemSpace.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_ItemSpace.Dock = System.Windows.Forms.DockStyle.Right;
			this.checkBox_ItemSpace.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_ItemSpace.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_ItemSpace.Location = new System.Drawing.Point(418, 1);
			this.checkBox_ItemSpace.Name = "checkBox_ItemSpace";
			this.checkBox_ItemSpace.Size = new System.Drawing.Size(134, 26);
			this.checkBox_ItemSpace.TabIndex = 18;
			this.checkBox_ItemSpace.Text = "Разделитель: пробел";
			this.toolTip1.SetToolTip(this.checkBox_ItemSpace, "Разделитель позиций в чеке");
			this.checkBox_ItemSpace.UseVisualStyleBackColor = true;
			this.checkBox_ItemSeparator.AutoSize = true;
			this.checkBox_ItemSeparator.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_ItemSeparator.Checked = true;
			this.checkBox_ItemSeparator.CheckState = System.Windows.Forms.CheckState.Checked;
			this.checkBox_ItemSeparator.Dock = System.Windows.Forms.DockStyle.Right;
			this.checkBox_ItemSeparator.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_ItemSeparator.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_ItemSeparator.Location = new System.Drawing.Point(552, 1);
			this.checkBox_ItemSeparator.Name = "checkBox_ItemSeparator";
			this.checkBox_ItemSeparator.Size = new System.Drawing.Size(57, 26);
			this.checkBox_ItemSeparator.TabIndex = 17;
			this.checkBox_ItemSeparator.Text = " черта";
			this.toolTip1.SetToolTip(this.checkBox_ItemSeparator, "Разделитель позиций в чеке");
			this.checkBox_ItemSeparator.UseVisualStyleBackColor = true;
			this.button_DocCancel1.Dock = System.Windows.Forms.DockStyle.Left;
			this.button_DocCancel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.button_DocCancel1.ForeColor = System.Drawing.Color.Brown;
			this.button_DocCancel1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_DocCancel1.Location = new System.Drawing.Point(236, 1);
			this.button_DocCancel1.Name = "button_DocCancel1";
			this.button_DocCancel1.Size = new System.Drawing.Size(70, 26);
			this.button_DocCancel1.TabIndex = 7;
			this.button_DocCancel1.Text = "Отмена";
			this.toolTip1.SetToolTip(this.button_DocCancel1, "Отменить текущий документ (если открыт)");
			this.button_DocCancel1.UseVisualStyleBackColor = true;
			this.button_DocCancel1.Click += new System.EventHandler(Button_DocCancel_Click);
			this.button_RunSales.AutoSize = true;
			this.button_RunSales.Dock = System.Windows.Forms.DockStyle.Left;
			this.button_RunSales.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold);
			this.button_RunSales.ForeColor = System.Drawing.Color.Brown;
			this.button_RunSales.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_RunSales.Location = new System.Drawing.Point(143, 1);
			this.button_RunSales.Name = "button_RunSales";
			this.button_RunSales.Size = new System.Drawing.Size(93, 26);
			this.button_RunSales.TabIndex = 6;
			this.button_RunSales.Text = "В один клик!";
			this.button_RunSales.UseVisualStyleBackColor = true;
			this.button_RunSales.Click += new System.EventHandler(Button_RunSales_Click);
			this.button_FCh.Dock = System.Windows.Forms.DockStyle.Left;
			this.button_FCh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold);
			this.button_FCh.ForeColor = System.Drawing.Color.Brown;
			this.button_FCh.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_FCh.Location = new System.Drawing.Point(72, 1);
			this.button_FCh.Name = "button_FCh";
			this.button_FCh.Size = new System.Drawing.Size(71, 26);
			this.button_FCh.TabIndex = 4;
			this.button_FCh.Text = "Печать";
			this.toolTip1.SetToolTip(this.button_FCh, "Печать чека");
			this.button_FCh.UseVisualStyleBackColor = true;
			this.button_FCh.Visible = false;
			this.button_FCh.Click += new System.EventHandler(Button_FCh_Click);
			this.button_CCh.Dock = System.Windows.Forms.DockStyle.Left;
			this.button_CCh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold);
			this.button_CCh.ForeColor = System.Drawing.Color.Brown;
			this.button_CCh.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_CCh.Location = new System.Drawing.Point(1, 1);
			this.button_CCh.Name = "button_CCh";
			this.button_CCh.Size = new System.Drawing.Size(71, 26);
			this.button_CCh.TabIndex = 4;
			this.button_CCh.Text = "Закрыть";
			this.toolTip1.SetToolTip(this.button_CCh, "Нажать 1 раз для закрытия, 2 раза для печати чека");
			this.button_CCh.UseVisualStyleBackColor = true;
			this.button_CCh.Click += new System.EventHandler(Button_CCh_Click);
			this.panel_Ticket_Total.BackColor = System.Drawing.Color.LightCyan;
			this.panel_Ticket_Total.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_Ticket_Total.Controls.Add(this.label_Discount);
			this.panel_Ticket_Total.Controls.Add(this.numeric_Discount);
			this.panel_Ticket_Total.Controls.Add(this.textBox_Round_Check);
			this.panel_Ticket_Total.Controls.Add(this.label_Round_Check);
			this.panel_Ticket_Total.Controls.Add(this.textBox_Total_Check);
			this.panel_Ticket_Total.Controls.Add(this.label_Check_Total);
			this.panel_Ticket_Total.Controls.Add(this.textBox_ItemCnt_Check);
			this.panel_Ticket_Total.Controls.Add(this.label_Check_Items);
			this.panel_Ticket_Total.Controls.Add(this.button_Total);
			this.panel_Ticket_Total.Location = new System.Drawing.Point(6, 303);
			this.panel_Ticket_Total.Name = "panel_Ticket_Total";
			this.panel_Ticket_Total.Padding = new System.Windows.Forms.Padding(1);
			this.panel_Ticket_Total.Size = new System.Drawing.Size(612, 30);
			this.panel_Ticket_Total.TabIndex = 13;
			this.label_Discount.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Discount.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Discount.Location = new System.Drawing.Point(462, 0);
			this.label_Discount.Margin = new System.Windows.Forms.Padding(3);
			this.label_Discount.Name = "label_Discount";
			this.label_Discount.Size = new System.Drawing.Size(69, 26);
			this.label_Discount.TabIndex = 6;
			this.label_Discount.Text = "Округлить\r\n(скидка)";
			this.label_Discount.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.numeric_Discount.DecimalPlaces = 2;
			this.numeric_Discount.Increment = new decimal(new int[4] { 1, 0, 0, 131072 });
			this.numeric_Discount.Location = new System.Drawing.Point(531, 4);
			this.numeric_Discount.Maximum = new decimal(new int[4] { 99, 0, 0, 131072 });
			this.numeric_Discount.Name = "numeric_Discount";
			this.numeric_Discount.Size = new System.Drawing.Size(75, 20);
			this.numeric_Discount.TabIndex = 5;
			this.numeric_Discount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.numeric_Discount.ThousandsSeparator = true;
			this.textBox_Round_Check.BackColor = System.Drawing.Color.Cyan;
			this.textBox_Round_Check.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.textBox_Round_Check.ForeColor = System.Drawing.Color.Blue;
			this.textBox_Round_Check.Location = new System.Drawing.Point(355, 4);
			this.textBox_Round_Check.MaxLength = 12;
			this.textBox_Round_Check.Name = "textBox_Round_Check";
			this.textBox_Round_Check.ReadOnly = true;
			this.textBox_Round_Check.Size = new System.Drawing.Size(75, 20);
			this.textBox_Round_Check.TabIndex = 3;
			this.textBox_Round_Check.Text = "0,00";
			this.textBox_Round_Check.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.label_Round_Check.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Round_Check.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Round_Check.Location = new System.Drawing.Point(300, 0);
			this.label_Round_Check.Margin = new System.Windows.Forms.Padding(3);
			this.label_Round_Check.Name = "label_Round_Check";
			this.label_Round_Check.Size = new System.Drawing.Size(55, 26);
			this.label_Round_Check.TabIndex = 2;
			this.label_Round_Check.Text = "Округл.\r\nитог";
			this.label_Round_Check.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.textBox_Total_Check.BackColor = System.Drawing.Color.Cyan;
			this.textBox_Total_Check.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.textBox_Total_Check.ForeColor = System.Drawing.Color.Blue;
			this.textBox_Total_Check.Location = new System.Drawing.Point(225, 4);
			this.textBox_Total_Check.MaxLength = 12;
			this.textBox_Total_Check.Name = "textBox_Total_Check";
			this.textBox_Total_Check.ReadOnly = true;
			this.textBox_Total_Check.Size = new System.Drawing.Size(75, 20);
			this.textBox_Total_Check.TabIndex = 1;
			this.textBox_Total_Check.Text = "0,00";
			this.textBox_Total_Check.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.label_Check_Total.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Check_Total.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Check_Total.Location = new System.Drawing.Point(175, 0);
			this.label_Check_Total.Margin = new System.Windows.Forms.Padding(3);
			this.label_Check_Total.Name = "label_Check_Total";
			this.label_Check_Total.Size = new System.Drawing.Size(50, 26);
			this.label_Check_Total.TabIndex = 1;
			this.label_Check_Total.Text = "Сумма:";
			this.label_Check_Total.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.textBox_ItemCnt_Check.BackColor = System.Drawing.Color.Cyan;
			this.textBox_ItemCnt_Check.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.textBox_ItemCnt_Check.ForeColor = System.Drawing.Color.Blue;
			this.textBox_ItemCnt_Check.Location = new System.Drawing.Point(142, 4);
			this.textBox_ItemCnt_Check.MaxLength = 128;
			this.textBox_ItemCnt_Check.Name = "textBox_ItemCnt_Check";
			this.textBox_ItemCnt_Check.ReadOnly = true;
			this.textBox_ItemCnt_Check.Size = new System.Drawing.Size(33, 20);
			this.textBox_ItemCnt_Check.TabIndex = 0;
			this.textBox_ItemCnt_Check.Text = "0";
			this.textBox_ItemCnt_Check.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.label_Check_Items.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Check_Items.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Check_Items.Location = new System.Drawing.Point(71, 0);
			this.label_Check_Items.Margin = new System.Windows.Forms.Padding(3);
			this.label_Check_Items.Name = "label_Check_Items";
			this.label_Check_Items.Size = new System.Drawing.Size(70, 26);
			this.label_Check_Items.TabIndex = 0;
			this.label_Check_Items.Text = "Количество\r\nпредметов:";
			this.label_Check_Items.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.button_Total.Dock = System.Windows.Forms.DockStyle.Left;
			this.button_Total.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold);
			this.button_Total.ForeColor = System.Drawing.Color.Brown;
			this.button_Total.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_Total.Location = new System.Drawing.Point(1, 1);
			this.button_Total.Name = "button_Total";
			this.button_Total.Size = new System.Drawing.Size(70, 26);
			this.button_Total.TabIndex = 1;
			this.button_Total.Text = "ИТОГО";
			this.button_Total.UseVisualStyleBackColor = true;
			this.button_Total.Click += new System.EventHandler(Button_Total_Click);
			this.panel_TicketOpen.Controls.Add(this.groupBox_TicketOpen);
			this.panel_TicketOpen.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_TicketOpen.Location = new System.Drawing.Point(3, 68);
			this.panel_TicketOpen.Name = "panel_TicketOpen";
			this.panel_TicketOpen.Padding = new System.Windows.Forms.Padding(0, 0, 0, 4);
			this.panel_TicketOpen.Size = new System.Drawing.Size(618, 59);
			this.panel_TicketOpen.TabIndex = 3;
			this.groupBox_TicketOpen.Controls.Add(this.panel_Ticket_Open);
			this.groupBox_TicketOpen.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox_TicketOpen.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_TicketOpen.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_TicketOpen.Location = new System.Drawing.Point(0, 0);
			this.groupBox_TicketOpen.Name = "groupBox_TicketOpen";
			this.groupBox_TicketOpen.Size = new System.Drawing.Size(618, 55);
			this.groupBox_TicketOpen.TabIndex = 2;
			this.groupBox_TicketOpen.TabStop = false;
			this.groupBox_TicketOpen.Text = "О т к р ы т ь   ч е к";
			this.panel_Ticket_Open.BackColor = System.Drawing.Color.LightCyan;
			this.panel_Ticket_Open.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_Ticket_Open.Controls.Add(this.button_Text);
			this.panel_Ticket_Open.Controls.Add(this.button_CheckOptions);
			this.panel_Ticket_Open.Controls.Add(this.button_CheckCustomer);
			this.panel_Ticket_Open.Controls.Add(this.checkBox_Ticket_User);
			this.panel_Ticket_Open.Controls.Add(this.button_CheckCorr);
			this.panel_Ticket_Open.Controls.Add(this.button_CheckOpen);
			this.panel_Ticket_Open.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel_Ticket_Open.Location = new System.Drawing.Point(3, 16);
			this.panel_Ticket_Open.Name = "panel_Ticket_Open";
			this.panel_Ticket_Open.Padding = new System.Windows.Forms.Padding(3, 6, 3, 6);
			this.panel_Ticket_Open.Size = new System.Drawing.Size(612, 36);
			this.panel_Ticket_Open.TabIndex = 6;
			this.button_Text.AutoSize = true;
			this.button_Text.Dock = System.Windows.Forms.DockStyle.Left;
			this.button_Text.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold);
			this.button_Text.ForeColor = System.Drawing.Color.Brown;
			this.button_Text.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_Text.Location = new System.Drawing.Point(489, 6);
			this.button_Text.Name = "button_Text";
			this.button_Text.Size = new System.Drawing.Size(117, 22);
			this.button_Text.TabIndex = 8;
			this.button_Text.Text = "Текст и графика";
			this.button_Text.UseVisualStyleBackColor = true;
			this.button_Text.Click += new System.EventHandler(Button_Text_Click);
			this.button_CheckOptions.AutoSize = true;
			this.button_CheckOptions.Dock = System.Windows.Forms.DockStyle.Left;
			this.button_CheckOptions.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold);
			this.button_CheckOptions.ForeColor = System.Drawing.Color.Brown;
			this.button_CheckOptions.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_CheckOptions.Location = new System.Drawing.Point(373, 6);
			this.button_CheckOptions.Name = "button_CheckOptions";
			this.button_CheckOptions.Size = new System.Drawing.Size(116, 22);
			this.button_CheckOptions.TabIndex = 7;
			this.button_CheckOptions.Text = "Реквизиты чека";
			this.button_CheckOptions.UseVisualStyleBackColor = true;
			this.button_CheckOptions.Click += new System.EventHandler(Button_CheckOptions_Click);
			this.button_CheckCustomer.AutoSize = true;
			this.button_CheckCustomer.Dock = System.Windows.Forms.DockStyle.Left;
			this.button_CheckCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold);
			this.button_CheckCustomer.ForeColor = System.Drawing.Color.Brown;
			this.button_CheckCustomer.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_CheckCustomer.Location = new System.Drawing.Point(285, 6);
			this.button_CheckCustomer.Name = "button_CheckCustomer";
			this.button_CheckCustomer.Size = new System.Drawing.Size(88, 22);
			this.button_CheckCustomer.TabIndex = 5;
			this.button_CheckCustomer.Text = "Покупатель";
			this.button_CheckCustomer.UseVisualStyleBackColor = true;
			this.button_CheckCustomer.Click += new System.EventHandler(Button_CheckCustomer_Click);
			this.checkBox_Ticket_User.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkBox_Ticket_User.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f, System.Drawing.FontStyle.Italic);
			this.checkBox_Ticket_User.ForeColor = System.Drawing.Color.Blue;
			this.checkBox_Ticket_User.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_Ticket_User.Location = new System.Drawing.Point(169, 6);
			this.checkBox_Ticket_User.Name = "checkBox_Ticket_User";
			this.checkBox_Ticket_User.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
			this.checkBox_Ticket_User.Size = new System.Drawing.Size(116, 22);
			this.checkBox_Ticket_User.TabIndex = 5;
			this.checkBox_Ticket_User.Text = "Пользователь";
			this.checkBox_Ticket_User.UseVisualStyleBackColor = true;
			this.button_CheckCorr.Dock = System.Windows.Forms.DockStyle.Left;
			this.button_CheckCorr.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold);
			this.button_CheckCorr.ForeColor = System.Drawing.Color.Brown;
			this.button_CheckCorr.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_CheckCorr.Location = new System.Drawing.Point(73, 6);
			this.button_CheckCorr.Name = "button_CheckCorr";
			this.button_CheckCorr.Size = new System.Drawing.Size(96, 22);
			this.button_CheckCorr.TabIndex = 1;
			this.button_CheckCorr.Text = "КОРРЕКЦИЯ";
			this.button_CheckCorr.UseVisualStyleBackColor = true;
			this.button_CheckCorr.Click += new System.EventHandler(Button_CheckCorr_Click);
			this.button_CheckOpen.BackColor = System.Drawing.Color.Transparent;
			this.button_CheckOpen.Dock = System.Windows.Forms.DockStyle.Left;
			this.button_CheckOpen.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold);
			this.button_CheckOpen.ForeColor = System.Drawing.Color.Brown;
			this.button_CheckOpen.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_CheckOpen.Location = new System.Drawing.Point(3, 6);
			this.button_CheckOpen.Name = "button_CheckOpen";
			this.button_CheckOpen.Size = new System.Drawing.Size(70, 22);
			this.button_CheckOpen.TabIndex = 4;
			this.button_CheckOpen.Text = "ЧЕК";
			this.button_CheckOpen.UseVisualStyleBackColor = false;
			this.button_CheckOpen.Click += new System.EventHandler(Button_CheckOpen_Click);
			this.groupBox_OCh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.groupBox_OCh.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_OCh.Location = new System.Drawing.Point(158, 487);
			this.groupBox_OCh.Name = "groupBox_OCh";
			this.groupBox_OCh.Padding = new System.Windows.Forms.Padding(1);
			this.groupBox_OCh.Size = new System.Drawing.Size(238, 46);
			this.groupBox_OCh.TabIndex = 12;
			this.groupBox_OCh.TabStop = false;
			this.groupBox_OCh.Text = "Собрать чек";
			this.groupBox_OCh.Visible = false;
			this.panel_TicketPay.BackColor = System.Drawing.Color.LightCyan;
			this.panel_TicketPay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_TicketPay.Controls.Add(this.label_Beznal_Type);
			this.panel_TicketPay.Controls.Add(this.label_Beznal);
			this.panel_TicketPay.Controls.Add(this.checkBox_Pay_Cash);
			this.panel_TicketPay.Controls.Add(this.textBox_CardNumber);
			this.panel_TicketPay.Controls.Add(this.comboBox_Beznal);
			this.panel_TicketPay.Controls.Add(this.label_Pay_Prov);
			this.panel_TicketPay.Controls.Add(this.label_Pay_Credit);
			this.panel_TicketPay.Controls.Add(this.label_Pay_Prepaid);
			this.panel_TicketPay.Controls.Add(this.label_Pay_Card);
			this.panel_TicketPay.Controls.Add(this.nUpDown_VpCheck);
			this.panel_TicketPay.Controls.Add(this.nUpDown_CrCheck);
			this.panel_TicketPay.Controls.Add(this.nUpDown_AvCheck);
			this.panel_TicketPay.Controls.Add(this.nUpDown_ElCheck);
			this.panel_TicketPay.Controls.Add(this.nUpDown_NalCheck);
			this.panel_TicketPay.Controls.Add(this.button_Payment);
			this.panel_TicketPay.Location = new System.Drawing.Point(6, 338);
			this.panel_TicketPay.Name = "panel_TicketPay";
			this.panel_TicketPay.Padding = new System.Windows.Forms.Padding(1);
			this.panel_TicketPay.Size = new System.Drawing.Size(612, 44);
			this.panel_TicketPay.TabIndex = 14;
			this.label_Beznal_Type.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_Beznal_Type.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Beznal_Type.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Beznal_Type.Location = new System.Drawing.Point(236, 3);
			this.label_Beznal_Type.Margin = new System.Windows.Forms.Padding(3);
			this.label_Beznal_Type.Name = "label_Beznal_Type";
			this.label_Beznal_Type.Size = new System.Drawing.Size(70, 15);
			this.label_Beznal_Type.TabIndex = 18;
			this.label_Beznal_Type.Text = "Тип";
			this.label_Beznal_Type.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.label_Beznal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_Beznal.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Beznal.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Beznal.Location = new System.Drawing.Point(159, 3);
			this.label_Beznal.Margin = new System.Windows.Forms.Padding(3);
			this.label_Beznal.Name = "label_Beznal";
			this.label_Beznal.Size = new System.Drawing.Size(75, 15);
			this.label_Beznal.TabIndex = 17;
			this.label_Beznal.Text = "Безнал.";
			this.label_Beznal.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.checkBox_Pay_Cash.Checked = true;
			this.checkBox_Pay_Cash.CheckState = System.Windows.Forms.CheckState.Checked;
			this.checkBox_Pay_Cash.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_Pay_Cash.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_Pay_Cash.Location = new System.Drawing.Point(72, 3);
			this.checkBox_Pay_Cash.Name = "checkBox_Pay_Cash";
			this.checkBox_Pay_Cash.Size = new System.Drawing.Size(85, 15);
			this.checkBox_Pay_Cash.TabIndex = 5;
			this.checkBox_Pay_Cash.Text = "Наличными";
			this.checkBox_Pay_Cash.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.toolTip1.SetToolTip(this.checkBox_Pay_Cash, "Включить в оплату, даже если 0");
			this.checkBox_Pay_Cash.UseVisualStyleBackColor = true;
			this.textBox_CardNumber.Location = new System.Drawing.Point(308, 20);
			this.textBox_CardNumber.Name = "textBox_CardNumber";
			this.textBox_CardNumber.Size = new System.Drawing.Size(67, 20);
			this.textBox_CardNumber.TabIndex = 3;
			this.comboBox_Beznal.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox_Beznal.DropDownWidth = 90;
			this.comboBox_Beznal.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.comboBox_Beznal.FormattingEnabled = true;
			this.comboBox_Beznal.Items.AddRange(new object[8] { "Безнал.", "Безнал-1", "Безнал-2", "Безнал-3", "Безнал-4", "Безнал-5", "Задать 1-5", "СБП" });
			this.comboBox_Beznal.Location = new System.Drawing.Point(236, 20);
			this.comboBox_Beznal.Name = "comboBox_Beznal";
			this.comboBox_Beznal.Size = new System.Drawing.Size(70, 21);
			this.comboBox_Beznal.TabIndex = 14;
			this.toolTip1.SetToolTip(this.comboBox_Beznal, "Тип оплаты безналичными");
			this.comboBox_Beznal.SelectedIndexChanged += new System.EventHandler(ComboBox_Beznal_SelectedIndexChanged);
			this.label_Pay_Prov.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Pay_Prov.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Pay_Prov.Location = new System.Drawing.Point(531, 3);
			this.label_Pay_Prov.Margin = new System.Windows.Forms.Padding(3);
			this.label_Pay_Prov.Name = "label_Pay_Prov";
			this.label_Pay_Prov.Size = new System.Drawing.Size(75, 15);
			this.label_Pay_Prov.TabIndex = 14;
			this.label_Pay_Prov.Text = "Другое";
			this.label_Pay_Prov.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.toolTip1.SetToolTip(this.label_Pay_Prov, "Bottle return");
			this.label_Pay_Credit.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Pay_Credit.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Pay_Credit.Location = new System.Drawing.Point(454, 3);
			this.label_Pay_Credit.Margin = new System.Windows.Forms.Padding(3);
			this.label_Pay_Credit.Name = "label_Pay_Credit";
			this.label_Pay_Credit.Size = new System.Drawing.Size(75, 15);
			this.label_Pay_Credit.TabIndex = 14;
			this.label_Pay_Credit.Text = "Кредит";
			this.label_Pay_Credit.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.label_Pay_Prepaid.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Pay_Prepaid.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Pay_Prepaid.Location = new System.Drawing.Point(377, 3);
			this.label_Pay_Prepaid.Margin = new System.Windows.Forms.Padding(3);
			this.label_Pay_Prepaid.Name = "label_Pay_Prepaid";
			this.label_Pay_Prepaid.Size = new System.Drawing.Size(75, 15);
			this.label_Pay_Prepaid.TabIndex = 15;
			this.label_Pay_Prepaid.Text = "Аванс";
			this.label_Pay_Prepaid.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.label_Pay_Card.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_Pay_Card.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Pay_Card.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Pay_Card.Location = new System.Drawing.Point(300, 3);
			this.label_Pay_Card.Margin = new System.Windows.Forms.Padding(3);
			this.label_Pay_Card.Name = "label_Pay_Card";
			this.label_Pay_Card.Size = new System.Drawing.Size(75, 15);
			this.label_Pay_Card.TabIndex = 16;
			this.label_Pay_Card.Text = "№ карты";
			this.label_Pay_Card.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.nUpDown_VpCheck.DecimalPlaces = 2;
			this.nUpDown_VpCheck.Increment = new decimal(new int[4] { 10, 0, 0, 0 });
			this.nUpDown_VpCheck.Location = new System.Drawing.Point(531, 20);
			this.nUpDown_VpCheck.Maximum = new decimal(new int[4] { -1, 255, 0, 131072 });
			this.nUpDown_VpCheck.Name = "nUpDown_VpCheck";
			this.nUpDown_VpCheck.Size = new System.Drawing.Size(75, 20);
			this.nUpDown_VpCheck.TabIndex = 4;
			this.nUpDown_VpCheck.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.nUpDown_VpCheck.ThousandsSeparator = true;
			this.nUpDown_CrCheck.DecimalPlaces = 2;
			this.nUpDown_CrCheck.Increment = new decimal(new int[4] { 10, 0, 0, 0 });
			this.nUpDown_CrCheck.Location = new System.Drawing.Point(454, 20);
			this.nUpDown_CrCheck.Maximum = new decimal(new int[4] { -1, 255, 0, 131072 });
			this.nUpDown_CrCheck.Name = "nUpDown_CrCheck";
			this.nUpDown_CrCheck.Size = new System.Drawing.Size(75, 20);
			this.nUpDown_CrCheck.TabIndex = 3;
			this.nUpDown_CrCheck.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.nUpDown_CrCheck.ThousandsSeparator = true;
			this.nUpDown_AvCheck.DecimalPlaces = 2;
			this.nUpDown_AvCheck.Increment = new decimal(new int[4] { 10, 0, 0, 0 });
			this.nUpDown_AvCheck.Location = new System.Drawing.Point(377, 20);
			this.nUpDown_AvCheck.Maximum = new decimal(new int[4] { -1, 255, 0, 131072 });
			this.nUpDown_AvCheck.Name = "nUpDown_AvCheck";
			this.nUpDown_AvCheck.Size = new System.Drawing.Size(75, 20);
			this.nUpDown_AvCheck.TabIndex = 2;
			this.nUpDown_AvCheck.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.nUpDown_AvCheck.ThousandsSeparator = true;
			this.nUpDown_ElCheck.DecimalPlaces = 2;
			this.nUpDown_ElCheck.Increment = new decimal(new int[4] { 10, 0, 0, 0 });
			this.nUpDown_ElCheck.Location = new System.Drawing.Point(159, 20);
			this.nUpDown_ElCheck.Maximum = new decimal(new int[4] { -1, 255, 0, 131072 });
			this.nUpDown_ElCheck.Name = "nUpDown_ElCheck";
			this.nUpDown_ElCheck.Size = new System.Drawing.Size(75, 20);
			this.nUpDown_ElCheck.TabIndex = 1;
			this.nUpDown_ElCheck.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.nUpDown_ElCheck.ThousandsSeparator = true;
			this.nUpDown_NalCheck.DecimalPlaces = 2;
			this.nUpDown_NalCheck.Increment = new decimal(new int[4] { 10, 0, 0, 0 });
			this.nUpDown_NalCheck.Location = new System.Drawing.Point(72, 20);
			this.nUpDown_NalCheck.Maximum = new decimal(new int[4] { -1, 255, 0, 131072 });
			this.nUpDown_NalCheck.Name = "nUpDown_NalCheck";
			this.nUpDown_NalCheck.Size = new System.Drawing.Size(85, 20);
			this.nUpDown_NalCheck.TabIndex = 0;
			this.nUpDown_NalCheck.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.nUpDown_NalCheck.ThousandsSeparator = true;
			this.nUpDown_NalCheck.Value = new decimal(new int[4] { 100, 0, 0, 0 });
			this.nUpDown_NalCheck.ValueChanged += new System.EventHandler(Numeric_NalCheck_ValueChanged);
			this.button_Payment.Dock = System.Windows.Forms.DockStyle.Left;
			this.button_Payment.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold);
			this.button_Payment.ForeColor = System.Drawing.Color.Brown;
			this.button_Payment.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_Payment.Location = new System.Drawing.Point(1, 1);
			this.button_Payment.Name = "button_Payment";
			this.button_Payment.Size = new System.Drawing.Size(70, 40);
			this.button_Payment.TabIndex = 1;
			this.button_Payment.Text = "ОПЛАТА";
			this.button_Payment.UseVisualStyleBackColor = true;
			this.button_Payment.Click += new System.EventHandler(Button_Payment_Click);
			this.panel_Ticket_Type_and_Tax.Controls.Add(this.groupBox_TransactionTax);
			this.panel_Ticket_Type_and_Tax.Controls.Add(this.groupBox_TransactionType);
			this.panel_Ticket_Type_and_Tax.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Ticket_Type_and_Tax.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_Ticket_Type_and_Tax.Location = new System.Drawing.Point(3, 0);
			this.panel_Ticket_Type_and_Tax.Name = "panel_Ticket_Type_and_Tax";
			this.panel_Ticket_Type_and_Tax.Padding = new System.Windows.Forms.Padding(0, 0, 0, 6);
			this.panel_Ticket_Type_and_Tax.Size = new System.Drawing.Size(618, 68);
			this.panel_Ticket_Type_and_Tax.TabIndex = 0;
			this.groupBox_TransactionTax.Controls.Add(this.panel_Ticket_Tax);
			this.groupBox_TransactionTax.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox_TransactionTax.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_TransactionTax.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_TransactionTax.Location = new System.Drawing.Point(266, 0);
			this.groupBox_TransactionTax.Name = "groupBox_TransactionTax";
			this.groupBox_TransactionTax.Size = new System.Drawing.Size(352, 62);
			this.groupBox_TransactionTax.TabIndex = 1;
			this.groupBox_TransactionTax.TabStop = false;
			this.groupBox_TransactionTax.Text = "Система налогообложения";
			this.panel_Ticket_Tax.BackColor = System.Drawing.Color.LightCyan;
			this.panel_Ticket_Tax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_Ticket_Tax.Controls.Add(this.radioButton_Tax0);
			this.panel_Ticket_Tax.Controls.Add(this.radioButton_Tax1);
			this.panel_Ticket_Tax.Controls.Add(this.radioButton_Tax4);
			this.panel_Ticket_Tax.Controls.Add(this.radioButton_Tax3);
			this.panel_Ticket_Tax.Controls.Add(this.radioButton_Tax2);
			this.panel_Ticket_Tax.Controls.Add(this.radioButton_Tax5);
			this.panel_Ticket_Tax.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel_Ticket_Tax.ForeColor = System.Drawing.SystemColors.ControlText;
			this.panel_Ticket_Tax.Location = new System.Drawing.Point(3, 17);
			this.panel_Ticket_Tax.Name = "panel_Ticket_Tax";
			this.panel_Ticket_Tax.Padding = new System.Windows.Forms.Padding(3);
			this.panel_Ticket_Tax.Size = new System.Drawing.Size(346, 42);
			this.panel_Ticket_Tax.TabIndex = 1;
			this.radioButton_Tax0.Checked = true;
			this.radioButton_Tax0.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.radioButton_Tax0.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radioButton_Tax0.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radioButton_Tax0.Location = new System.Drawing.Point(3, 3);
			this.radioButton_Tax0.Name = "radioButton_Tax0";
			this.radioButton_Tax0.Size = new System.Drawing.Size(72, 17);
			this.radioButton_Tax0.TabIndex = 0;
			this.radioButton_Tax0.TabStop = true;
			this.radioButton_Tax0.Text = "ОСН";
			this.radioButton_Tax0.UseVisualStyleBackColor = true;
			this.radioButton_Tax1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.radioButton_Tax1.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radioButton_Tax1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radioButton_Tax1.Location = new System.Drawing.Point(76, 3);
			this.radioButton_Tax1.Name = "radioButton_Tax1";
			this.radioButton_Tax1.Size = new System.Drawing.Size(110, 17);
			this.radioButton_Tax1.TabIndex = 0;
			this.radioButton_Tax1.Text = "УСН (доход)";
			this.radioButton_Tax1.UseVisualStyleBackColor = true;
			this.radioButton_Tax4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.radioButton_Tax4.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radioButton_Tax4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radioButton_Tax4.Location = new System.Drawing.Point(76, 20);
			this.radioButton_Tax4.Name = "radioButton_Tax4";
			this.radioButton_Tax4.Size = new System.Drawing.Size(110, 17);
			this.radioButton_Tax4.TabIndex = 0;
			this.radioButton_Tax4.Text = "ЕСХН";
			this.radioButton_Tax4.UseVisualStyleBackColor = true;
			this.radioButton_Tax3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.radioButton_Tax3.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radioButton_Tax3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radioButton_Tax3.Location = new System.Drawing.Point(3, 20);
			this.radioButton_Tax3.Name = "radioButton_Tax3";
			this.radioButton_Tax3.Size = new System.Drawing.Size(72, 17);
			this.radioButton_Tax3.TabIndex = 0;
			this.radioButton_Tax3.Text = "ЕНВД";
			this.radioButton_Tax3.UseVisualStyleBackColor = true;
			this.radioButton_Tax2.AutoSize = true;
			this.radioButton_Tax2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.radioButton_Tax2.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radioButton_Tax2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radioButton_Tax2.Location = new System.Drawing.Point(190, 3);
			this.radioButton_Tax2.Name = "radioButton_Tax2";
			this.radioButton_Tax2.Size = new System.Drawing.Size(124, 17);
			this.radioButton_Tax2.TabIndex = 0;
			this.radioButton_Tax2.Text = "УСН (доход-расход)";
			this.radioButton_Tax2.UseVisualStyleBackColor = true;
			this.radioButton_Tax5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.radioButton_Tax5.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radioButton_Tax5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radioButton_Tax5.Location = new System.Drawing.Point(190, 20);
			this.radioButton_Tax5.Name = "radioButton_Tax5";
			this.radioButton_Tax5.Size = new System.Drawing.Size(142, 17);
			this.radioButton_Tax5.TabIndex = 0;
			this.radioButton_Tax5.Text = "Патент";
			this.radioButton_Tax5.UseVisualStyleBackColor = true;
			this.groupBox_TransactionType.Controls.Add(this.panel_Ticket_Type);
			this.groupBox_TransactionType.Dock = System.Windows.Forms.DockStyle.Left;
			this.groupBox_TransactionType.Font = new System.Drawing.Font("Microsoft Sans Serif", 9f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_TransactionType.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_TransactionType.Location = new System.Drawing.Point(0, 0);
			this.groupBox_TransactionType.Name = "groupBox_TransactionType";
			this.groupBox_TransactionType.Size = new System.Drawing.Size(266, 62);
			this.groupBox_TransactionType.TabIndex = 0;
			this.groupBox_TransactionType.TabStop = false;
			this.groupBox_TransactionType.Text = "Тип операции";
			this.panel_Ticket_Type.BackColor = System.Drawing.Color.LightCyan;
			this.panel_Ticket_Type.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_Ticket_Type.Controls.Add(this.radioButton_Type1);
			this.panel_Ticket_Type.Controls.Add(this.radioButton_Type2);
			this.panel_Ticket_Type.Controls.Add(this.radioButton_Type3);
			this.panel_Ticket_Type.Controls.Add(this.radioButton_Type4);
			this.panel_Ticket_Type.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel_Ticket_Type.ForeColor = System.Drawing.SystemColors.ControlText;
			this.panel_Ticket_Type.Location = new System.Drawing.Point(3, 17);
			this.panel_Ticket_Type.Name = "panel_Ticket_Type";
			this.panel_Ticket_Type.Padding = new System.Windows.Forms.Padding(3);
			this.panel_Ticket_Type.Size = new System.Drawing.Size(260, 42);
			this.panel_Ticket_Type.TabIndex = 1;
			this.radioButton_Type1.AutoSize = true;
			this.radioButton_Type1.Checked = true;
			this.radioButton_Type1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.radioButton_Type1.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radioButton_Type1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radioButton_Type1.Location = new System.Drawing.Point(3, 3);
			this.radioButton_Type1.Name = "radioButton_Type1";
			this.radioButton_Type1.Size = new System.Drawing.Size(62, 17);
			this.radioButton_Type1.TabIndex = 0;
			this.radioButton_Type1.TabStop = true;
			this.radioButton_Type1.Text = "Приход";
			this.radioButton_Type1.UseVisualStyleBackColor = true;
			this.radioButton_Type2.AutoSize = true;
			this.radioButton_Type2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.radioButton_Type2.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radioButton_Type2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radioButton_Type2.Location = new System.Drawing.Point(122, 3);
			this.radioButton_Type2.Name = "radioButton_Type2";
			this.radioButton_Type2.Size = new System.Drawing.Size(111, 17);
			this.radioButton_Type2.TabIndex = 0;
			this.radioButton_Type2.Text = "Возврат прихода";
			this.radioButton_Type2.UseVisualStyleBackColor = true;
			this.radioButton_Type3.AutoSize = true;
			this.radioButton_Type3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.radioButton_Type3.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radioButton_Type3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radioButton_Type3.Location = new System.Drawing.Point(3, 20);
			this.radioButton_Type3.Name = "radioButton_Type3";
			this.radioButton_Type3.Size = new System.Drawing.Size(61, 17);
			this.radioButton_Type3.TabIndex = 0;
			this.radioButton_Type3.Text = "Расход";
			this.radioButton_Type3.UseVisualStyleBackColor = true;
			this.radioButton_Type4.AutoSize = true;
			this.radioButton_Type4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.radioButton_Type4.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radioButton_Type4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radioButton_Type4.Location = new System.Drawing.Point(122, 20);
			this.radioButton_Type4.Name = "radioButton_Type4";
			this.radioButton_Type4.Size = new System.Drawing.Size(111, 17);
			this.radioButton_Type4.TabIndex = 0;
			this.radioButton_Type4.Text = "Возврат расхода";
			this.radioButton_Type4.UseVisualStyleBackColor = true;
			this.tabPage_NonFiscal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.tabPage_NonFiscal.Controls.Add(this.groupBox_TextLines);
			this.tabPage_NonFiscal.Location = new System.Drawing.Point(154, 4);
			this.tabPage_NonFiscal.Name = "tabPage_NonFiscal";
			this.tabPage_NonFiscal.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage_NonFiscal.Size = new System.Drawing.Size(626, 424);
			this.tabPage_NonFiscal.TabIndex = 8;
			this.tabPage_NonFiscal.Text = "Нефискальный документ";
			this.tabPage_NonFiscal.UseVisualStyleBackColor = true;
			this.groupBox_TextLines.BackColor = System.Drawing.Color.Transparent;
			this.groupBox_TextLines.Controls.Add(this.panel_TextFormat);
			this.groupBox_TextLines.Controls.Add(this.panel_TextEntries);
			this.groupBox_TextLines.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_TextLines.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_TextLines.Location = new System.Drawing.Point(3, 3);
			this.groupBox_TextLines.Name = "groupBox_TextLines";
			this.groupBox_TextLines.Padding = new System.Windows.Forms.Padding(1);
			this.groupBox_TextLines.Size = new System.Drawing.Size(604, 363);
			this.groupBox_TextLines.TabIndex = 18;
			this.groupBox_TextLines.TabStop = false;
			this.groupBox_TextLines.Text = "Т е к с т о в ы е   с т р о к и";
			this.toolTip1.SetToolTip(this.groupBox_TextLines, "Данные регистрации");
			this.panel_TextFormat.BackColor = System.Drawing.Color.LightCyan;
			this.panel_TextFormat.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_TextFormat.Controls.Add(this.comboBox_txt_LineType);
			this.panel_TextFormat.Controls.Add(this.label_LineType);
			this.panel_TextFormat.Controls.Add(this.label_txt_PictureNo);
			this.panel_TextFormat.Controls.Add(this.label_txt_Pic_Align);
			this.panel_TextFormat.Controls.Add(this.numeric_txt_PictureNo);
			this.panel_TextFormat.Controls.Add(this.label_txt_BarcodeHeight);
			this.panel_TextFormat.Controls.Add(this.label_txt_BarcodeType);
			this.panel_TextFormat.Controls.Add(this.label_txt_BarcodeWidth);
			this.panel_TextFormat.Controls.Add(this.numeric_txt_BarcodeHeight);
			this.panel_TextFormat.Controls.Add(this.numeric_txt_BarcodeWidth);
			this.panel_TextFormat.Controls.Add(this.comboBox_txt_BarcodeType);
			this.panel_TextFormat.Controls.Add(this.textBox_txt_QR);
			this.panel_TextFormat.Controls.Add(this.textBox_txt_QRText);
			this.panel_TextFormat.Controls.Add(this.checkBox_txt_QRText);
			this.panel_TextFormat.Controls.Add(this.label_txt_QR_DotSize);
			this.panel_TextFormat.Controls.Add(this.label_txt_QR_Level);
			this.panel_TextFormat.Controls.Add(this.numeric_txt_QR_DotSize);
			this.panel_TextFormat.Controls.Add(this.numeric_txt_QR_Level);
			this.panel_TextFormat.Controls.Add(this.panel_txt_Pic_Align);
			this.panel_TextFormat.Controls.Add(this.panel_txt_QR_Align);
			this.panel_TextFormat.Controls.Add(this.checkBox_txt_QR);
			this.panel_TextFormat.Controls.Add(this.checkBox_txt_Line);
			this.panel_TextFormat.Controls.Add(this.checkBox_txt_Image);
			this.panel_TextFormat.Controls.Add(this.checkBox_txt_Barcode);
			this.panel_TextFormat.Controls.Add(this.button_CreateTXTDoc);
			this.panel_TextFormat.Controls.Add(this.checkBox_IncludeHeader);
			this.panel_TextFormat.Controls.Add(this.textBox_txt_Barcode);
			this.panel_TextFormat.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel_TextFormat.Location = new System.Drawing.Point(1, 170);
			this.panel_TextFormat.Name = "panel_TextFormat";
			this.panel_TextFormat.Padding = new System.Windows.Forms.Padding(3);
			this.panel_TextFormat.Size = new System.Drawing.Size(602, 192);
			this.panel_TextFormat.TabIndex = 16;
			this.comboBox_txt_LineType.DropDownHeight = 44;
			this.comboBox_txt_LineType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox_txt_LineType.DropDownWidth = 40;
			this.comboBox_txt_LineType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.comboBox_txt_LineType.IntegralHeight = false;
			this.comboBox_txt_LineType.Items.AddRange(new object[3] { "Одинарная", "Двойная", "Жирная" });
			this.comboBox_txt_LineType.Location = new System.Drawing.Point(416, 114);
			this.comboBox_txt_LineType.MaxDropDownItems = 3;
			this.comboBox_txt_LineType.Name = "comboBox_txt_LineType";
			this.comboBox_txt_LineType.Size = new System.Drawing.Size(83, 21);
			this.comboBox_txt_LineType.TabIndex = 40;
			this.label_LineType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_LineType.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_LineType.Location = new System.Drawing.Point(416, 101);
			this.label_LineType.Name = "label_LineType";
			this.label_LineType.Size = new System.Drawing.Size(83, 13);
			this.label_LineType.TabIndex = 41;
			this.label_LineType.Text = "Тип линии";
			this.label_LineType.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.label_txt_PictureNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_txt_PictureNo.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_txt_PictureNo.Location = new System.Drawing.Point(82, 101);
			this.label_txt_PictureNo.Name = "label_txt_PictureNo";
			this.label_txt_PictureNo.Size = new System.Drawing.Size(71, 13);
			this.label_txt_PictureNo.TabIndex = 39;
			this.label_txt_PictureNo.Text = "Номер (1-22)";
			this.label_txt_PictureNo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.label_txt_Pic_Align.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_txt_Pic_Align.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_txt_Pic_Align.Location = new System.Drawing.Point(159, 101);
			this.label_txt_Pic_Align.Name = "label_txt_Pic_Align";
			this.label_txt_Pic_Align.Size = new System.Drawing.Size(75, 13);
			this.label_txt_Pic_Align.TabIndex = 38;
			this.label_txt_Pic_Align.Text = "Положение";
			this.label_txt_Pic_Align.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.numeric_txt_PictureNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.numeric_txt_PictureNo.Location = new System.Drawing.Point(85, 114);
			this.numeric_txt_PictureNo.Maximum = new decimal(new int[4] { 22, 0, 0, 0 });
			this.numeric_txt_PictureNo.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			this.numeric_txt_PictureNo.Name = "numeric_txt_PictureNo";
			this.numeric_txt_PictureNo.Size = new System.Drawing.Size(50, 20);
			this.numeric_txt_PictureNo.TabIndex = 37;
			this.numeric_txt_PictureNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.numeric_txt_PictureNo.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			this.label_txt_BarcodeHeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_txt_BarcodeHeight.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_txt_BarcodeHeight.Location = new System.Drawing.Point(546, 61);
			this.label_txt_BarcodeHeight.Name = "label_txt_BarcodeHeight";
			this.label_txt_BarcodeHeight.Size = new System.Drawing.Size(54, 13);
			this.label_txt_BarcodeHeight.TabIndex = 34;
			this.label_txt_BarcodeHeight.Text = "Высота";
			this.label_txt_BarcodeHeight.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label_txt_BarcodeType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_txt_BarcodeType.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_txt_BarcodeType.Location = new System.Drawing.Point(413, 61);
			this.label_txt_BarcodeType.Name = "label_txt_BarcodeType";
			this.label_txt_BarcodeType.Size = new System.Drawing.Size(56, 13);
			this.label_txt_BarcodeType.TabIndex = 35;
			this.label_txt_BarcodeType.Text = "Тип";
			this.label_txt_BarcodeType.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.label_txt_BarcodeWidth.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_txt_BarcodeWidth.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_txt_BarcodeWidth.Location = new System.Drawing.Point(489, 61);
			this.label_txt_BarcodeWidth.Name = "label_txt_BarcodeWidth";
			this.label_txt_BarcodeWidth.Size = new System.Drawing.Size(56, 13);
			this.label_txt_BarcodeWidth.TabIndex = 36;
			this.label_txt_BarcodeWidth.Text = "Толщина";
			this.label_txt_BarcodeWidth.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.numeric_txt_BarcodeHeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.numeric_txt_BarcodeHeight.Increment = new decimal(new int[4] { 10, 0, 0, 0 });
			this.numeric_txt_BarcodeHeight.Location = new System.Drawing.Point(552, 75);
			this.numeric_txt_BarcodeHeight.Maximum = new decimal(new int[4] { 200, 0, 0, 0 });
			this.numeric_txt_BarcodeHeight.Minimum = new decimal(new int[4] { 10, 0, 0, 0 });
			this.numeric_txt_BarcodeHeight.Name = "numeric_txt_BarcodeHeight";
			this.numeric_txt_BarcodeHeight.Size = new System.Drawing.Size(45, 20);
			this.numeric_txt_BarcodeHeight.TabIndex = 31;
			this.numeric_txt_BarcodeHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.numeric_txt_BarcodeHeight.Value = new decimal(new int[4] { 50, 0, 0, 0 });
			this.numeric_txt_BarcodeWidth.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.numeric_txt_BarcodeWidth.Location = new System.Drawing.Point(500, 75);
			this.numeric_txt_BarcodeWidth.Maximum = new decimal(new int[4] { 4, 0, 0, 0 });
			this.numeric_txt_BarcodeWidth.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			this.numeric_txt_BarcodeWidth.Name = "numeric_txt_BarcodeWidth";
			this.numeric_txt_BarcodeWidth.Size = new System.Drawing.Size(45, 20);
			this.numeric_txt_BarcodeWidth.TabIndex = 32;
			this.numeric_txt_BarcodeWidth.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.numeric_txt_BarcodeWidth.Value = new decimal(new int[4] { 2, 0, 0, 0 });
			this.comboBox_txt_BarcodeType.DropDownHeight = 168;
			this.comboBox_txt_BarcodeType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox_txt_BarcodeType.DropDownWidth = 40;
			this.comboBox_txt_BarcodeType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.comboBox_txt_BarcodeType.IntegralHeight = false;
			this.comboBox_txt_BarcodeType.Items.AddRange(new object[9] { "UPC-A", "UPC-E", "EAN-13", "EAN-8", "Code39", "ITF", "Codabar", "Code93", "Code128" });
			this.comboBox_txt_BarcodeType.Location = new System.Drawing.Point(416, 75);
			this.comboBox_txt_BarcodeType.MaxDropDownItems = 9;
			this.comboBox_txt_BarcodeType.Name = "comboBox_txt_BarcodeType";
			this.comboBox_txt_BarcodeType.Size = new System.Drawing.Size(80, 21);
			this.comboBox_txt_BarcodeType.TabIndex = 33;
			this.textBox_txt_QR.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_txt_QR.Location = new System.Drawing.Point(85, 15);
			this.textBox_txt_QR.MaxLength = 256;
			this.textBox_txt_QR.Name = "textBox_txt_QR";
			this.textBox_txt_QR.Size = new System.Drawing.Size(411, 20);
			this.textBox_txt_QR.TabIndex = 2;
			this.textBox_txt_QR.Text = "http://check.egais.ru?id=14a0058f-8a0d-4b29-8b06-68a33f3985ee&amp;dt=1809181734&amp;cn=020000434502";
			this.textBox_txt_QRText.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_txt_QRText.Location = new System.Drawing.Point(85, 38);
			this.textBox_txt_QRText.MaxLength = 256;
			this.textBox_txt_QRText.Name = "textBox_txt_QRText";
			this.textBox_txt_QRText.Size = new System.Drawing.Size(411, 20);
			this.textBox_txt_QRText.TabIndex = 27;
			this.textBox_txt_QRText.Text = "Подари нам шанс стать еще лучше!\\x0AОставь свой отзыв о посещении KFC на сайте KFCFEEDBACKRUS.com (на страницу можно попасть, отсканировав QR-код)";
			this.checkBox_txt_QRText.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_txt_QRText.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.checkBox_txt_QRText.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_txt_QRText.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_txt_QRText.Location = new System.Drawing.Point(6, 40);
			this.checkBox_txt_QRText.Name = "checkBox_txt_QRText";
			this.checkBox_txt_QRText.Size = new System.Drawing.Size(75, 17);
			this.checkBox_txt_QRText.TabIndex = 28;
			this.checkBox_txt_QRText.Text = "Текст";
			this.checkBox_txt_QRText.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_txt_QRText.UseVisualStyleBackColor = true;
			this.label_txt_QR_DotSize.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_txt_QR_DotSize.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_txt_QR_DotSize.Location = new System.Drawing.Point(552, 0);
			this.label_txt_QR_DotSize.Name = "label_txt_QR_DotSize";
			this.label_txt_QR_DotSize.Size = new System.Drawing.Size(46, 13);
			this.label_txt_QR_DotSize.TabIndex = 25;
			this.label_txt_QR_DotSize.Text = "Размер";
			this.label_txt_QR_DotSize.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label_txt_QR_Level.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_txt_QR_Level.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_txt_QR_Level.Location = new System.Drawing.Point(498, 0);
			this.label_txt_QR_Level.Name = "label_txt_QR_Level";
			this.label_txt_QR_Level.Size = new System.Drawing.Size(52, 13);
			this.label_txt_QR_Level.TabIndex = 26;
			this.label_txt_QR_Level.Text = "Уровень";
			this.label_txt_QR_Level.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.numeric_txt_QR_DotSize.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.numeric_txt_QR_DotSize.Location = new System.Drawing.Point(552, 15);
			this.numeric_txt_QR_DotSize.Maximum = new decimal(new int[4] { 4, 0, 0, 0 });
			this.numeric_txt_QR_DotSize.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			this.numeric_txt_QR_DotSize.Name = "numeric_txt_QR_DotSize";
			this.numeric_txt_QR_DotSize.Size = new System.Drawing.Size(46, 20);
			this.numeric_txt_QR_DotSize.TabIndex = 24;
			this.numeric_txt_QR_DotSize.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.numeric_txt_QR_DotSize.Value = new decimal(new int[4] { 4, 0, 0, 0 });
			this.numeric_txt_QR_Level.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.numeric_txt_QR_Level.Location = new System.Drawing.Point(502, 15);
			this.numeric_txt_QR_Level.Maximum = new decimal(new int[4] { 4, 0, 0, 0 });
			this.numeric_txt_QR_Level.Name = "numeric_txt_QR_Level";
			this.numeric_txt_QR_Level.Size = new System.Drawing.Size(45, 20);
			this.numeric_txt_QR_Level.TabIndex = 23;
			this.numeric_txt_QR_Level.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.numeric_txt_QR_Level.Value = new decimal(new int[4] { 2, 0, 0, 0 });
			this.panel_txt_Pic_Align.Controls.Add(this.radio_txt_Pic_Right);
			this.panel_txt_Pic_Align.Controls.Add(this.radio_txt_Pic_Center);
			this.panel_txt_Pic_Align.Controls.Add(this.radio_txt_Pic_Left);
			this.panel_txt_Pic_Align.Location = new System.Drawing.Point(150, 114);
			this.panel_txt_Pic_Align.Name = "panel_txt_Pic_Align";
			this.panel_txt_Pic_Align.Size = new System.Drawing.Size(99, 20);
			this.panel_txt_Pic_Align.TabIndex = 19;
			this.radio_txt_Pic_Right.AutoSize = true;
			this.radio_txt_Pic_Right.Dock = System.Windows.Forms.DockStyle.Left;
			this.radio_txt_Pic_Right.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.radio_txt_Pic_Right.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radio_txt_Pic_Right.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radio_txt_Pic_Right.Location = new System.Drawing.Point(65, 0);
			this.radio_txt_Pic_Right.Name = "radio_txt_Pic_Right";
			this.radio_txt_Pic_Right.Size = new System.Drawing.Size(34, 20);
			this.radio_txt_Pic_Right.TabIndex = 12;
			this.radio_txt_Pic_Right.Text = "R";
			this.radio_txt_Pic_Right.UseVisualStyleBackColor = true;
			this.radio_txt_Pic_Center.AutoSize = true;
			this.radio_txt_Pic_Center.Dock = System.Windows.Forms.DockStyle.Left;
			this.radio_txt_Pic_Center.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.radio_txt_Pic_Center.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radio_txt_Pic_Center.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radio_txt_Pic_Center.Location = new System.Drawing.Point(32, 0);
			this.radio_txt_Pic_Center.Name = "radio_txt_Pic_Center";
			this.radio_txt_Pic_Center.Size = new System.Drawing.Size(33, 20);
			this.radio_txt_Pic_Center.TabIndex = 13;
			this.radio_txt_Pic_Center.Text = "C";
			this.radio_txt_Pic_Center.UseVisualStyleBackColor = true;
			this.radio_txt_Pic_Left.AutoSize = true;
			this.radio_txt_Pic_Left.Checked = true;
			this.radio_txt_Pic_Left.Dock = System.Windows.Forms.DockStyle.Left;
			this.radio_txt_Pic_Left.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.radio_txt_Pic_Left.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radio_txt_Pic_Left.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radio_txt_Pic_Left.Location = new System.Drawing.Point(0, 0);
			this.radio_txt_Pic_Left.Name = "radio_txt_Pic_Left";
			this.radio_txt_Pic_Left.Size = new System.Drawing.Size(32, 20);
			this.radio_txt_Pic_Left.TabIndex = 11;
			this.radio_txt_Pic_Left.TabStop = true;
			this.radio_txt_Pic_Left.Text = "L";
			this.radio_txt_Pic_Left.UseVisualStyleBackColor = true;
			this.panel_txt_QR_Align.Controls.Add(this.radio_txt_QR_Right);
			this.panel_txt_QR_Align.Controls.Add(this.radio_txt_QR_Center);
			this.panel_txt_QR_Align.Controls.Add(this.radio_txt_QR_Left);
			this.panel_txt_QR_Align.Location = new System.Drawing.Point(502, 37);
			this.panel_txt_QR_Align.Name = "panel_txt_QR_Align";
			this.panel_txt_QR_Align.Size = new System.Drawing.Size(99, 20);
			this.panel_txt_QR_Align.TabIndex = 18;
			this.radio_txt_QR_Right.AutoSize = true;
			this.radio_txt_QR_Right.Dock = System.Windows.Forms.DockStyle.Left;
			this.radio_txt_QR_Right.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.radio_txt_QR_Right.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radio_txt_QR_Right.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radio_txt_QR_Right.Location = new System.Drawing.Point(65, 0);
			this.radio_txt_QR_Right.Name = "radio_txt_QR_Right";
			this.radio_txt_QR_Right.Size = new System.Drawing.Size(34, 20);
			this.radio_txt_QR_Right.TabIndex = 12;
			this.radio_txt_QR_Right.Text = "R";
			this.radio_txt_QR_Right.UseVisualStyleBackColor = true;
			this.radio_txt_QR_Center.AutoSize = true;
			this.radio_txt_QR_Center.Dock = System.Windows.Forms.DockStyle.Left;
			this.radio_txt_QR_Center.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.radio_txt_QR_Center.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radio_txt_QR_Center.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radio_txt_QR_Center.Location = new System.Drawing.Point(32, 0);
			this.radio_txt_QR_Center.Name = "radio_txt_QR_Center";
			this.radio_txt_QR_Center.Size = new System.Drawing.Size(33, 20);
			this.radio_txt_QR_Center.TabIndex = 13;
			this.radio_txt_QR_Center.Text = "C";
			this.radio_txt_QR_Center.UseVisualStyleBackColor = true;
			this.radio_txt_QR_Left.AutoSize = true;
			this.radio_txt_QR_Left.Checked = true;
			this.radio_txt_QR_Left.Dock = System.Windows.Forms.DockStyle.Left;
			this.radio_txt_QR_Left.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.radio_txt_QR_Left.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radio_txt_QR_Left.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radio_txt_QR_Left.Location = new System.Drawing.Point(0, 0);
			this.radio_txt_QR_Left.Name = "radio_txt_QR_Left";
			this.radio_txt_QR_Left.Size = new System.Drawing.Size(32, 20);
			this.radio_txt_QR_Left.TabIndex = 11;
			this.radio_txt_QR_Left.TabStop = true;
			this.radio_txt_QR_Left.Text = "L";
			this.radio_txt_QR_Left.UseVisualStyleBackColor = true;
			this.checkBox_txt_QR.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_txt_QR.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_txt_QR.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_txt_QR.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_txt_QR.Location = new System.Drawing.Point(6, 17);
			this.checkBox_txt_QR.Name = "checkBox_txt_QR";
			this.checkBox_txt_QR.Size = new System.Drawing.Size(75, 17);
			this.checkBox_txt_QR.TabIndex = 7;
			this.checkBox_txt_QR.Text = "QR";
			this.checkBox_txt_QR.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_txt_QR.UseVisualStyleBackColor = true;
			this.checkBox_txt_Line.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_txt_Line.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_txt_Line.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_txt_Line.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_txt_Line.Location = new System.Drawing.Point(335, 116);
			this.checkBox_txt_Line.Name = "checkBox_txt_Line";
			this.checkBox_txt_Line.Size = new System.Drawing.Size(75, 17);
			this.checkBox_txt_Line.TabIndex = 6;
			this.checkBox_txt_Line.Text = "Линия";
			this.checkBox_txt_Line.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_txt_Line.UseVisualStyleBackColor = true;
			this.checkBox_txt_Image.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_txt_Image.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_txt_Image.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_txt_Image.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_txt_Image.Location = new System.Drawing.Point(6, 116);
			this.checkBox_txt_Image.Name = "checkBox_txt_Image";
			this.checkBox_txt_Image.Size = new System.Drawing.Size(75, 17);
			this.checkBox_txt_Image.TabIndex = 6;
			this.checkBox_txt_Image.Text = "Картинка";
			this.checkBox_txt_Image.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_txt_Image.UseVisualStyleBackColor = true;
			this.checkBox_txt_Barcode.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_txt_Barcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.checkBox_txt_Barcode.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_txt_Barcode.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_txt_Barcode.Location = new System.Drawing.Point(6, 77);
			this.checkBox_txt_Barcode.Name = "checkBox_txt_Barcode";
			this.checkBox_txt_Barcode.Size = new System.Drawing.Size(75, 17);
			this.checkBox_txt_Barcode.TabIndex = 6;
			this.checkBox_txt_Barcode.Text = "Штрихкод";
			this.checkBox_txt_Barcode.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_txt_Barcode.UseVisualStyleBackColor = true;
			this.button_CreateTXTDoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.button_CreateTXTDoc.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_CreateTXTDoc.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_CreateTXTDoc.Location = new System.Drawing.Point(6, 140);
			this.button_CreateTXTDoc.Name = "button_CreateTXTDoc";
			this.button_CreateTXTDoc.Size = new System.Drawing.Size(123, 44);
			this.button_CreateTXTDoc.TabIndex = 0;
			this.button_CreateTXTDoc.Text = "Печать";
			this.button_CreateTXTDoc.UseVisualStyleBackColor = true;
			this.button_CreateTXTDoc.Click += new System.EventHandler(button_CreateTXTDoc_Click);
			this.checkBox_IncludeHeader.AutoSize = true;
			this.checkBox_IncludeHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_IncludeHeader.ForeColor = System.Drawing.SystemColors.ControlText;
			this.checkBox_IncludeHeader.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_IncludeHeader.Location = new System.Drawing.Point(135, 158);
			this.checkBox_IncludeHeader.Name = "checkBox_IncludeHeader";
			this.checkBox_IncludeHeader.Size = new System.Drawing.Size(114, 17);
			this.checkBox_IncludeHeader.TabIndex = 1;
			this.checkBox_IncludeHeader.Text = "Включить подвал";
			this.checkBox_IncludeHeader.TextAlign = System.Drawing.ContentAlignment.TopLeft;
			this.checkBox_IncludeHeader.UseVisualStyleBackColor = true;
			this.checkBox_IncludeHeader.Visible = false;
			this.textBox_txt_Barcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_txt_Barcode.Location = new System.Drawing.Point(85, 75);
			this.textBox_txt_Barcode.MaxLength = 256;
			this.textBox_txt_Barcode.Name = "textBox_txt_Barcode";
			this.textBox_txt_Barcode.Size = new System.Drawing.Size(325, 20);
			this.textBox_txt_Barcode.TabIndex = 2;
			this.textBox_txt_Barcode.Text = "1234567890128";
			this.panel_TextEntries.BackColor = System.Drawing.Color.Transparent;
			this.panel_TextEntries.Controls.Add(this.panel_TextLines);
			this.panel_TextEntries.Controls.Add(this.panel_TextLinesCheckBoxes);
			this.panel_TextEntries.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel_TextEntries.Location = new System.Drawing.Point(1, 14);
			this.panel_TextEntries.Name = "panel_TextEntries";
			this.panel_TextEntries.Size = new System.Drawing.Size(602, 348);
			this.panel_TextEntries.TabIndex = 5;
			this.panel_TextLines.Controls.Add(this.label_TextLinesTip);
			this.panel_TextLines.Controls.Add(this.dataGrid_TextLines);
			this.panel_TextLines.Location = new System.Drawing.Point(60, 0);
			this.panel_TextLines.Name = "panel_TextLines";
			this.panel_TextLines.Size = new System.Drawing.Size(543, 153);
			this.panel_TextLines.TabIndex = 17;
			this.label_TextLinesTip.BackColor = System.Drawing.Color.Brown;
			this.label_TextLinesTip.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold);
			this.label_TextLinesTip.ForeColor = System.Drawing.SystemColors.ControlLightLight;
			this.label_TextLinesTip.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_TextLinesTip.Location = new System.Drawing.Point(524, 0);
			this.label_TextLinesTip.Name = "label_TextLinesTip";
			this.label_TextLinesTip.Size = new System.Drawing.Size(18, 20);
			this.label_TextLinesTip.TabIndex = 9;
			this.label_TextLinesTip.Text = "?";
			this.label_TextLinesTip.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.toolTip1.SetToolTip(this.label_TextLinesTip, resources.GetString("label_TextLinesTip.ToolTip"));
			this.dataGrid_TextLines.AllowUserToAddRows = false;
			this.dataGrid_TextLines.AllowUserToDeleteRows = false;
			this.dataGrid_TextLines.AllowUserToResizeColumns = false;
			this.dataGrid_TextLines.AllowUserToResizeRows = false;
			dataGridViewCellStyle35.BackColor = System.Drawing.Color.LightCyan;
			this.dataGrid_TextLines.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle35;
			this.dataGrid_TextLines.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dataGrid_TextLines.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
			this.dataGrid_TextLines.ColumnHeadersHeight = 15;
			this.dataGrid_TextLines.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this.dataGrid_TextLines.ColumnHeadersVisible = false;
			this.dataGrid_TextLines.Columns.AddRange(this.dataGridViewTextBoxColumn_TextLines);
			this.dataGrid_TextLines.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dataGrid_TextLines.GridColor = System.Drawing.SystemColors.WindowFrame;
			this.dataGrid_TextLines.Location = new System.Drawing.Point(0, 0);
			this.dataGrid_TextLines.MultiSelect = false;
			this.dataGrid_TextLines.Name = "dataGrid_TextLines";
			this.dataGrid_TextLines.RowHeadersVisible = false;
			this.dataGrid_TextLines.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
			this.dataGrid_TextLines.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 204);
			this.dataGrid_TextLines.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGrid_TextLines.RowTemplate.Height = 15;
			this.dataGrid_TextLines.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.dataGrid_TextLines.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
			this.dataGrid_TextLines.ShowCellToolTips = false;
			this.dataGrid_TextLines.ShowEditingIcon = false;
			this.dataGrid_TextLines.Size = new System.Drawing.Size(543, 153);
			this.dataGrid_TextLines.TabIndex = 7;
			this.dataGridViewTextBoxColumn_TextLines.HeaderText = "Column_TextLines";
			this.dataGridViewTextBoxColumn_TextLines.MaxInputLength = 2000;
			this.dataGridViewTextBoxColumn_TextLines.Name = "dataGridViewTextBoxColumn_TextLines";
			this.panel_TextLinesCheckBoxes.BackColor = System.Drawing.Color.Transparent;
			this.panel_TextLinesCheckBoxes.Controls.Add(this.checkedListBox_TextLines);
			this.panel_TextLinesCheckBoxes.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel_TextLinesCheckBoxes.Location = new System.Drawing.Point(0, 0);
			this.panel_TextLinesCheckBoxes.Name = "panel_TextLinesCheckBoxes";
			this.panel_TextLinesCheckBoxes.Size = new System.Drawing.Size(60, 348);
			this.panel_TextLinesCheckBoxes.TabIndex = 18;
			this.checkedListBox_TextLines.BackColor = System.Drawing.Color.White;
			this.checkedListBox_TextLines.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.checkedListBox_TextLines.CheckOnClick = true;
			this.checkedListBox_TextLines.Dock = System.Windows.Forms.DockStyle.Fill;
			this.checkedListBox_TextLines.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkedListBox_TextLines.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkedListBox_TextLines.FormattingEnabled = true;
			this.checkedListBox_TextLines.Items.AddRange(new object[10] { "Стр. 1", "Стр. 2", "Стр. 3", "Стр. 4", "Стр. 5", "Стр. 6", "Стр. 7", "Стр. 8", "Стр. 9", "Стр.10" });
			this.checkedListBox_TextLines.Location = new System.Drawing.Point(0, 0);
			this.checkedListBox_TextLines.Name = "checkedListBox_TextLines";
			this.checkedListBox_TextLines.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.checkedListBox_TextLines.Size = new System.Drawing.Size(60, 348);
			this.checkedListBox_TextLines.TabIndex = 4;
			this.tabPage_OFD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.tabPage_OFD.Controls.Add(this.groupBox_OFD_Ticket);
			this.tabPage_OFD.Controls.Add(this.groupBox_SendMSG);
			this.tabPage_OFD.Controls.Add(this.groupBox_ReadMSG);
			this.tabPage_OFD.Location = new System.Drawing.Point(154, 4);
			this.tabPage_OFD.Name = "tabPage_OFD";
			this.tabPage_OFD.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage_OFD.Size = new System.Drawing.Size(626, 424);
			this.tabPage_OFD.TabIndex = 6;
			this.tabPage_OFD.Text = "О Ф Д";
			this.tabPage_OFD.UseVisualStyleBackColor = true;
			this.groupBox_OFD_Ticket.Controls.Add(this.panel_OFD_Ticket);
			this.groupBox_OFD_Ticket.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox_OFD_Ticket.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_OFD_Ticket.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_OFD_Ticket.Location = new System.Drawing.Point(3, 283);
			this.groupBox_OFD_Ticket.Name = "groupBox_OFD_Ticket";
			this.groupBox_OFD_Ticket.Size = new System.Drawing.Size(618, 73);
			this.groupBox_OFD_Ticket.TabIndex = 11;
			this.groupBox_OFD_Ticket.TabStop = false;
			this.groupBox_OFD_Ticket.Text = "К в и т а н ц и я   О Ф Д";
			this.panel_OFD_Ticket.BackColor = System.Drawing.Color.LightCyan;
			this.panel_OFD_Ticket.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_OFD_Ticket.Controls.Add(this.label_OFD_Ticket);
			this.panel_OFD_Ticket.Controls.Add(this.numericUpDown_OFD_Ticket);
			this.panel_OFD_Ticket.Controls.Add(this.button_GetTicketXML);
			this.panel_OFD_Ticket.Controls.Add(this.button_GetTicketOFD);
			this.panel_OFD_Ticket.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel_OFD_Ticket.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_OFD_Ticket.ForeColor = System.Drawing.SystemColors.ControlText;
			this.panel_OFD_Ticket.Location = new System.Drawing.Point(3, 16);
			this.panel_OFD_Ticket.Name = "panel_OFD_Ticket";
			this.panel_OFD_Ticket.Padding = new System.Windows.Forms.Padding(3);
			this.panel_OFD_Ticket.Size = new System.Drawing.Size(612, 54);
			this.panel_OFD_Ticket.TabIndex = 18;
			this.label_OFD_Ticket.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_OFD_Ticket.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_OFD_Ticket.Location = new System.Drawing.Point(150, 1);
			this.label_OFD_Ticket.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
			this.label_OFD_Ticket.Name = "label_OFD_Ticket";
			this.label_OFD_Ticket.Size = new System.Drawing.Size(65, 17);
			this.label_OFD_Ticket.TabIndex = 5;
			this.label_OFD_Ticket.Text = "Номер";
			this.label_OFD_Ticket.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.numericUpDown_OFD_Ticket.Location = new System.Drawing.Point(150, 18);
			this.numericUpDown_OFD_Ticket.Margin = new System.Windows.Forms.Padding(0);
			this.numericUpDown_OFD_Ticket.Maximum = new decimal(new int[4] { 999999999, 0, 0, 0 });
			this.numericUpDown_OFD_Ticket.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			this.numericUpDown_OFD_Ticket.Name = "numericUpDown_OFD_Ticket";
			this.numericUpDown_OFD_Ticket.Size = new System.Drawing.Size(70, 20);
			this.numericUpDown_OFD_Ticket.TabIndex = 0;
			this.numericUpDown_OFD_Ticket.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.numericUpDown_OFD_Ticket.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			this.button_GetTicketXML.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_GetTicketXML.Location = new System.Drawing.Point(14, 14);
			this.button_GetTicketXML.Name = "button_GetTicketXML";
			this.button_GetTicketXML.Size = new System.Drawing.Size(111, 25);
			this.button_GetTicketXML.TabIndex = 0;
			this.button_GetTicketXML.Text = "Получить";
			this.button_GetTicketXML.UseVisualStyleBackColor = true;
			this.button_GetTicketXML.Click += new System.EventHandler(button_GetTicketXML_Click);
			this.button_GetTicketOFD.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_GetTicketOFD.Location = new System.Drawing.Point(14, 13);
			this.button_GetTicketOFD.Name = "button_GetTicketOFD";
			this.button_GetTicketOFD.Size = new System.Drawing.Size(111, 25);
			this.button_GetTicketOFD.TabIndex = 0;
			this.button_GetTicketOFD.Text = "Получить";
			this.button_GetTicketOFD.UseVisualStyleBackColor = true;
			this.button_GetTicketOFD.Visible = false;
			this.button_GetTicketOFD.Click += new System.EventHandler(button_GetTicketOFD_Click);
			this.groupBox_SendMSG.Controls.Add(this.panel_OFD_Send);
			this.groupBox_SendMSG.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox_SendMSG.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_SendMSG.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_SendMSG.Location = new System.Drawing.Point(3, 148);
			this.groupBox_SendMSG.Name = "groupBox_SendMSG";
			this.groupBox_SendMSG.Size = new System.Drawing.Size(618, 135);
			this.groupBox_SendMSG.TabIndex = 8;
			this.groupBox_SendMSG.TabStop = false;
			this.groupBox_SendMSG.Text = "О Ф Д";
			this.panel_OFD_Send.BackColor = System.Drawing.Color.LightCyan;
			this.panel_OFD_Send.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_OFD_Send.Controls.Add(this.button_StopSendAllToOFD);
			this.panel_OFD_Send.Controls.Add(this.textBox_PendingMSG);
			this.panel_OFD_Send.Controls.Add(this.button_SendAllToOFD);
			this.panel_OFD_Send.Controls.Add(this.checkBox_InternalOFD);
			this.panel_OFD_Send.Controls.Add(this.textBox_IP_OFD);
			this.panel_OFD_Send.Controls.Add(this.numericUpDown_Port_OFD);
			this.panel_OFD_Send.Controls.Add(this.button_OFD_MSG);
			this.panel_OFD_Send.Controls.Add(this.label_AddressOFD);
			this.panel_OFD_Send.Controls.Add(this.label_RemainingMSG);
			this.panel_OFD_Send.Controls.Add(this.label_PortOFD);
			this.panel_OFD_Send.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel_OFD_Send.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_OFD_Send.Location = new System.Drawing.Point(3, 16);
			this.panel_OFD_Send.Name = "panel_OFD_Send";
			this.panel_OFD_Send.Size = new System.Drawing.Size(612, 116);
			this.panel_OFD_Send.TabIndex = 0;
			this.button_StopSendAllToOFD.Enabled = false;
			this.button_StopSendAllToOFD.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.button_StopSendAllToOFD.ForeColor = System.Drawing.Color.Brown;
			this.button_StopSendAllToOFD.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_StopSendAllToOFD.Location = new System.Drawing.Point(14, 67);
			this.button_StopSendAllToOFD.Name = "button_StopSendAllToOFD";
			this.button_StopSendAllToOFD.Size = new System.Drawing.Size(111, 25);
			this.button_StopSendAllToOFD.TabIndex = 1;
			this.button_StopSendAllToOFD.Text = "Остановить";
			this.button_StopSendAllToOFD.UseVisualStyleBackColor = true;
			this.button_StopSendAllToOFD.Click += new System.EventHandler(button_StopSendAllToOFD_Click);
			this.textBox_PendingMSG.BackColor = System.Drawing.Color.Cyan;
			this.textBox_PendingMSG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.textBox_PendingMSG.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.textBox_PendingMSG.ForeColor = System.Drawing.Color.Blue;
			this.textBox_PendingMSG.Location = new System.Drawing.Point(150, 70);
			this.textBox_PendingMSG.Name = "textBox_PendingMSG";
			this.textBox_PendingMSG.ReadOnly = true;
			this.textBox_PendingMSG.Size = new System.Drawing.Size(73, 20);
			this.textBox_PendingMSG.TabIndex = 4;
			this.textBox_PendingMSG.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.button_SendAllToOFD.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.button_SendAllToOFD.ForeColor = System.Drawing.Color.Brown;
			this.button_SendAllToOFD.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_SendAllToOFD.Location = new System.Drawing.Point(14, 36);
			this.button_SendAllToOFD.Name = "button_SendAllToOFD";
			this.button_SendAllToOFD.Size = new System.Drawing.Size(111, 25);
			this.button_SendAllToOFD.TabIndex = 0;
			this.button_SendAllToOFD.Text = "Отправить все";
			this.button_SendAllToOFD.UseVisualStyleBackColor = true;
			this.button_SendAllToOFD.Click += new System.EventHandler(button_SendAllToOFD_Click);
			this.checkBox_InternalOFD.AutoSize = true;
			this.checkBox_InternalOFD.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_InternalOFD.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_InternalOFD.Location = new System.Drawing.Point(229, 72);
			this.checkBox_InternalOFD.Name = "checkBox_InternalOFD";
			this.checkBox_InternalOFD.Padding = new System.Windows.Forms.Padding(4, 0, 0, 0);
			this.checkBox_InternalOFD.Size = new System.Drawing.Size(161, 17);
			this.checkBox_InternalOFD.TabIndex = 0;
			this.checkBox_InternalOFD.Text = "Расшифровка сообщений";
			this.checkBox_InternalOFD.UseVisualStyleBackColor = true;
			this.checkBox_InternalOFD.Visible = false;
			this.textBox_IP_OFD.Location = new System.Drawing.Point(150, 25);
			this.textBox_IP_OFD.Name = "textBox_IP_OFD";
			this.textBox_IP_OFD.Size = new System.Drawing.Size(262, 20);
			this.textBox_IP_OFD.TabIndex = 0;
			this.textBox_IP_OFD.Text = "f1test.taxcom.ru";
			this.numericUpDown_Port_OFD.Location = new System.Drawing.Point(421, 25);
			this.numericUpDown_Port_OFD.Maximum = new decimal(new int[4] { 65535, 0, 0, 0 });
			this.numericUpDown_Port_OFD.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			this.numericUpDown_Port_OFD.Name = "numericUpDown_Port_OFD";
			this.numericUpDown_Port_OFD.Size = new System.Drawing.Size(65, 20);
			this.numericUpDown_Port_OFD.TabIndex = 1;
			this.numericUpDown_Port_OFD.Value = new decimal(new int[4] { 7778, 0, 0, 0 });
			this.button_OFD_MSG.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.button_OFD_MSG.ForeColor = System.Drawing.Color.Brown;
			this.button_OFD_MSG.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_OFD_MSG.Location = new System.Drawing.Point(14, 5);
			this.button_OFD_MSG.Name = "button_OFD_MSG";
			this.button_OFD_MSG.Size = new System.Drawing.Size(111, 25);
			this.button_OFD_MSG.TabIndex = 0;
			this.button_OFD_MSG.Text = "Отправить 1";
			this.button_OFD_MSG.UseVisualStyleBackColor = true;
			this.button_OFD_MSG.Click += new System.EventHandler(button_OFD_MSG_Click);
			this.label_AddressOFD.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_AddressOFD.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_AddressOFD.Location = new System.Drawing.Point(150, 5);
			this.label_AddressOFD.Name = "label_AddressOFD";
			this.label_AddressOFD.Size = new System.Drawing.Size(262, 17);
			this.label_AddressOFD.TabIndex = 0;
			this.label_AddressOFD.Text = "Сервер ОФД";
			this.label_AddressOFD.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.label_RemainingMSG.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_RemainingMSG.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_RemainingMSG.Location = new System.Drawing.Point(150, 50);
			this.label_RemainingMSG.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
			this.label_RemainingMSG.Name = "label_RemainingMSG";
			this.label_RemainingMSG.Size = new System.Drawing.Size(65, 17);
			this.label_RemainingMSG.TabIndex = 1;
			this.label_RemainingMSG.Text = "Осталось";
			this.label_RemainingMSG.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.label_PortOFD.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_PortOFD.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_PortOFD.Location = new System.Drawing.Point(421, 5);
			this.label_PortOFD.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
			this.label_PortOFD.Name = "label_PortOFD";
			this.label_PortOFD.Size = new System.Drawing.Size(65, 17);
			this.label_PortOFD.TabIndex = 1;
			this.label_PortOFD.Text = "Порт";
			this.label_PortOFD.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.groupBox_ReadMSG.Controls.Add(this.panel_ReadMSG);
			this.groupBox_ReadMSG.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox_ReadMSG.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_ReadMSG.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_ReadMSG.Location = new System.Drawing.Point(3, 3);
			this.groupBox_ReadMSG.Name = "groupBox_ReadMSG";
			this.groupBox_ReadMSG.Size = new System.Drawing.Size(618, 145);
			this.groupBox_ReadMSG.TabIndex = 6;
			this.groupBox_ReadMSG.TabStop = false;
			this.groupBox_ReadMSG.Text = "С о о б щ е н и я   ( Ф Д )";
			this.panel_ReadMSG.BackColor = System.Drawing.Color.LightCyan;
			this.panel_ReadMSG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_ReadMSG.Controls.Add(this.numericUpDown_LengthBlock);
			this.panel_ReadMSG.Controls.Add(this.label_LengthMSG);
			this.panel_ReadMSG.Controls.Add(this.numericUpDown_OffsetBlock);
			this.panel_ReadMSG.Controls.Add(this.label_OffsetMSG);
			this.panel_ReadMSG.Controls.Add(this.button_ReadBlockMSG);
			this.panel_ReadMSG.Controls.Add(this.button_CancelMSG);
			this.panel_ReadMSG.Controls.Add(this.button_EndMSG);
			this.panel_ReadMSG.Controls.Add(this.button_ReadMSG);
			this.panel_ReadMSG.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel_ReadMSG.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_ReadMSG.Location = new System.Drawing.Point(3, 16);
			this.panel_ReadMSG.Name = "panel_ReadMSG";
			this.panel_ReadMSG.Size = new System.Drawing.Size(612, 126);
			this.panel_ReadMSG.TabIndex = 0;
			this.numericUpDown_LengthBlock.Increment = new decimal(new int[4] { 50, 0, 0, 0 });
			this.numericUpDown_LengthBlock.Location = new System.Drawing.Point(150, 76);
			this.numericUpDown_LengthBlock.Maximum = new decimal(new int[4] { 1000, 0, 0, 0 });
			this.numericUpDown_LengthBlock.Minimum = new decimal(new int[4] { 100, 0, 0, 0 });
			this.numericUpDown_LengthBlock.Name = "numericUpDown_LengthBlock";
			this.numericUpDown_LengthBlock.Size = new System.Drawing.Size(70, 20);
			this.numericUpDown_LengthBlock.TabIndex = 0;
			this.numericUpDown_LengthBlock.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.numericUpDown_LengthBlock.Value = new decimal(new int[4] { 500, 0, 0, 0 });
			this.label_LengthMSG.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_LengthMSG.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_LengthMSG.Location = new System.Drawing.Point(150, 63);
			this.label_LengthMSG.Name = "label_LengthMSG";
			this.label_LengthMSG.Size = new System.Drawing.Size(70, 13);
			this.label_LengthMSG.TabIndex = 0;
			this.label_LengthMSG.Text = "Длина";
			this.label_LengthMSG.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.numericUpDown_OffsetBlock.Increment = new decimal(new int[4] { 50, 0, 0, 0 });
			this.numericUpDown_OffsetBlock.Location = new System.Drawing.Point(150, 37);
			this.numericUpDown_OffsetBlock.Maximum = new decimal(new int[4] { 32768, 0, 0, 0 });
			this.numericUpDown_OffsetBlock.Name = "numericUpDown_OffsetBlock";
			this.numericUpDown_OffsetBlock.Size = new System.Drawing.Size(70, 20);
			this.numericUpDown_OffsetBlock.TabIndex = 1;
			this.numericUpDown_OffsetBlock.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.label_OffsetMSG.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_OffsetMSG.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_OffsetMSG.Location = new System.Drawing.Point(150, 24);
			this.label_OffsetMSG.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
			this.label_OffsetMSG.Name = "label_OffsetMSG";
			this.label_OffsetMSG.Size = new System.Drawing.Size(70, 13);
			this.label_OffsetMSG.TabIndex = 1;
			this.label_OffsetMSG.Text = "Смещение";
			this.label_OffsetMSG.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.button_ReadBlockMSG.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_ReadBlockMSG.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_ReadBlockMSG.Location = new System.Drawing.Point(14, 33);
			this.button_ReadBlockMSG.Name = "button_ReadBlockMSG";
			this.button_ReadBlockMSG.Size = new System.Drawing.Size(111, 25);
			this.button_ReadBlockMSG.TabIndex = 0;
			this.button_ReadBlockMSG.Text = "Прочитать";
			this.button_ReadBlockMSG.UseVisualStyleBackColor = true;
			this.button_ReadBlockMSG.Click += new System.EventHandler(button_ReadBlockMSG_Click);
			this.button_CancelMSG.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_CancelMSG.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_CancelMSG.Location = new System.Drawing.Point(14, 93);
			this.button_CancelMSG.Name = "button_CancelMSG";
			this.button_CancelMSG.Size = new System.Drawing.Size(111, 25);
			this.button_CancelMSG.TabIndex = 2;
			this.button_CancelMSG.Text = "Отменить";
			this.button_CancelMSG.UseVisualStyleBackColor = true;
			this.button_CancelMSG.Click += new System.EventHandler(button_CancelMSG_Click);
			this.button_EndMSG.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_EndMSG.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_EndMSG.Location = new System.Drawing.Point(14, 63);
			this.button_EndMSG.Name = "button_EndMSG";
			this.button_EndMSG.Size = new System.Drawing.Size(111, 25);
			this.button_EndMSG.TabIndex = 1;
			this.button_EndMSG.Text = "Завершить";
			this.button_EndMSG.UseVisualStyleBackColor = true;
			this.button_EndMSG.Click += new System.EventHandler(button_EndMSG_Click);
			this.button_ReadMSG.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_ReadMSG.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_ReadMSG.Location = new System.Drawing.Point(14, 3);
			this.button_ReadMSG.Name = "button_ReadMSG";
			this.button_ReadMSG.Size = new System.Drawing.Size(111, 25);
			this.button_ReadMSG.TabIndex = 0;
			this.button_ReadMSG.Text = "Начать";
			this.button_ReadMSG.UseVisualStyleBackColor = true;
			this.button_ReadMSG.Click += new System.EventHandler(button_ReadMSG_Click);
			this.tabPage_OISM.AutoScroll = true;
			this.tabPage_OISM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.tabPage_OISM.Controls.Add(this.groupBox_OKP);
			this.tabPage_OISM.Controls.Add(this.groupBox_SendNotice);
			this.tabPage_OISM.Controls.Add(this.groupBox_ReadNotice);
			this.tabPage_OISM.Location = new System.Drawing.Point(154, 4);
			this.tabPage_OISM.Name = "tabPage_OISM";
			this.tabPage_OISM.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage_OISM.Size = new System.Drawing.Size(626, 424);
			this.tabPage_OISM.TabIndex = 3;
			this.tabPage_OISM.Text = "О И С М   и   О К П";
			this.tabPage_OISM.UseVisualStyleBackColor = true;
			this.groupBox_OKP.Controls.Add(this.panel_OKP_Update);
			this.groupBox_OKP.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox_OKP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_OKP.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_OKP.Location = new System.Drawing.Point(3, 283);
			this.groupBox_OKP.Name = "groupBox_OKP";
			this.groupBox_OKP.Size = new System.Drawing.Size(618, 71);
			this.groupBox_OKP.TabIndex = 12;
			this.groupBox_OKP.TabStop = false;
			this.groupBox_OKP.Text = "О К П";
			this.panel_OKP_Update.BackColor = System.Drawing.Color.LightCyan;
			this.panel_OKP_Update.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_OKP_Update.Controls.Add(this.textBox_AddressOKP);
			this.panel_OKP_Update.Controls.Add(this.numericUpDown_PortOKP);
			this.panel_OKP_Update.Controls.Add(this.label_AddressOKP);
			this.panel_OKP_Update.Controls.Add(this.label_PortOKP);
			this.panel_OKP_Update.Controls.Add(this.button_KeyUpdateAll);
			this.panel_OKP_Update.Controls.Add(this.button_KeyUpdate);
			this.panel_OKP_Update.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel_OKP_Update.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_OKP_Update.ForeColor = System.Drawing.SystemColors.ControlText;
			this.panel_OKP_Update.Location = new System.Drawing.Point(3, 16);
			this.panel_OKP_Update.Name = "panel_OKP_Update";
			this.panel_OKP_Update.Padding = new System.Windows.Forms.Padding(3);
			this.panel_OKP_Update.Size = new System.Drawing.Size(612, 52);
			this.panel_OKP_Update.TabIndex = 18;
			this.textBox_AddressOKP.Location = new System.Drawing.Point(150, 15);
			this.textBox_AddressOKP.Name = "textBox_AddressOKP";
			this.textBox_AddressOKP.Size = new System.Drawing.Size(160, 20);
			this.textBox_AddressOKP.TabIndex = 2;
			this.textBox_AddressOKP.Text = "test.okp.atlas-kard.ru";
			this.numericUpDown_PortOKP.Location = new System.Drawing.Point(316, 15);
			this.numericUpDown_PortOKP.Maximum = new decimal(new int[4] { 65535, 0, 0, 0 });
			this.numericUpDown_PortOKP.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			this.numericUpDown_PortOKP.Name = "numericUpDown_PortOKP";
			this.numericUpDown_PortOKP.Size = new System.Drawing.Size(65, 20);
			this.numericUpDown_PortOKP.TabIndex = 4;
			this.numericUpDown_PortOKP.Value = new decimal(new int[4] { 31101, 0, 0, 0 });
			this.label_AddressOKP.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_AddressOKP.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_AddressOKP.Location = new System.Drawing.Point(150, 1);
			this.label_AddressOKP.Name = "label_AddressOKP";
			this.label_AddressOKP.Size = new System.Drawing.Size(103, 13);
			this.label_AddressOKP.TabIndex = 3;
			this.label_AddressOKP.Text = "Адрес ОКП";
			this.label_AddressOKP.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.label_PortOKP.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_PortOKP.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_PortOKP.Location = new System.Drawing.Point(316, 1);
			this.label_PortOKP.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
			this.label_PortOKP.Name = "label_PortOKP";
			this.label_PortOKP.Size = new System.Drawing.Size(65, 13);
			this.label_PortOKP.TabIndex = 5;
			this.label_PortOKP.Text = "Порт";
			this.label_PortOKP.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.button_KeyUpdateAll.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_KeyUpdateAll.Location = new System.Drawing.Point(389, 13);
			this.button_KeyUpdateAll.Name = "button_KeyUpdateAll";
			this.button_KeyUpdateAll.Size = new System.Drawing.Size(111, 25);
			this.button_KeyUpdateAll.TabIndex = 0;
			this.button_KeyUpdateAll.Text = "Обновить все";
			this.button_KeyUpdateAll.UseVisualStyleBackColor = true;
			this.button_KeyUpdateAll.Visible = false;
			this.button_KeyUpdate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_KeyUpdate.Location = new System.Drawing.Point(14, 12);
			this.button_KeyUpdate.Name = "button_KeyUpdate";
			this.button_KeyUpdate.Size = new System.Drawing.Size(111, 25);
			this.button_KeyUpdate.TabIndex = 0;
			this.button_KeyUpdate.Text = "Обновить ключи";
			this.button_KeyUpdate.UseVisualStyleBackColor = true;
			this.button_KeyUpdate.Click += new System.EventHandler(button_KeyUpdate_Click);
			this.groupBox_SendNotice.Controls.Add(this.panel_OISM_Send);
			this.groupBox_SendNotice.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox_SendNotice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_SendNotice.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_SendNotice.Location = new System.Drawing.Point(3, 148);
			this.groupBox_SendNotice.Name = "groupBox_SendNotice";
			this.groupBox_SendNotice.Size = new System.Drawing.Size(618, 135);
			this.groupBox_SendNotice.TabIndex = 9;
			this.groupBox_SendNotice.TabStop = false;
			this.groupBox_SendNotice.Text = "О И С М";
			this.panel_OISM_Send.BackColor = System.Drawing.Color.LightCyan;
			this.panel_OISM_Send.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_OISM_Send.Controls.Add(this.button_SendNoticeStop);
			this.panel_OISM_Send.Controls.Add(this.textBox_PendingNotice);
			this.panel_OISM_Send.Controls.Add(this.button_SendNoticeAll);
			this.panel_OISM_Send.Controls.Add(this.checkBox_NoticeParse);
			this.panel_OISM_Send.Controls.Add(this.textBox_AddressOISM);
			this.panel_OISM_Send.Controls.Add(this.numericUpDown_PortOISM);
			this.panel_OISM_Send.Controls.Add(this.button_SendNoticeOne);
			this.panel_OISM_Send.Controls.Add(this.label_AddressOISM);
			this.panel_OISM_Send.Controls.Add(this.label_PendingNotice);
			this.panel_OISM_Send.Controls.Add(this.label_PortOISM);
			this.panel_OISM_Send.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel_OISM_Send.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_OISM_Send.Location = new System.Drawing.Point(3, 16);
			this.panel_OISM_Send.Name = "panel_OISM_Send";
			this.panel_OISM_Send.Size = new System.Drawing.Size(612, 116);
			this.panel_OISM_Send.TabIndex = 0;
			this.button_SendNoticeStop.Enabled = false;
			this.button_SendNoticeStop.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.button_SendNoticeStop.ForeColor = System.Drawing.Color.Brown;
			this.button_SendNoticeStop.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_SendNoticeStop.Location = new System.Drawing.Point(14, 67);
			this.button_SendNoticeStop.Name = "button_SendNoticeStop";
			this.button_SendNoticeStop.Size = new System.Drawing.Size(111, 25);
			this.button_SendNoticeStop.TabIndex = 1;
			this.button_SendNoticeStop.Text = "Остановить";
			this.button_SendNoticeStop.UseVisualStyleBackColor = true;
			this.button_SendNoticeStop.Click += new System.EventHandler(button_SendNoticeStop_Click);
			this.textBox_PendingNotice.BackColor = System.Drawing.Color.Cyan;
			this.textBox_PendingNotice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.textBox_PendingNotice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.textBox_PendingNotice.ForeColor = System.Drawing.Color.Blue;
			this.textBox_PendingNotice.Location = new System.Drawing.Point(150, 70);
			this.textBox_PendingNotice.Name = "textBox_PendingNotice";
			this.textBox_PendingNotice.Size = new System.Drawing.Size(73, 20);
			this.textBox_PendingNotice.TabIndex = 4;
			this.textBox_PendingNotice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.button_SendNoticeAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.button_SendNoticeAll.ForeColor = System.Drawing.Color.Brown;
			this.button_SendNoticeAll.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_SendNoticeAll.Location = new System.Drawing.Point(14, 36);
			this.button_SendNoticeAll.Name = "button_SendNoticeAll";
			this.button_SendNoticeAll.Size = new System.Drawing.Size(111, 25);
			this.button_SendNoticeAll.TabIndex = 0;
			this.button_SendNoticeAll.Text = "Отправить все";
			this.button_SendNoticeAll.UseVisualStyleBackColor = true;
			this.button_SendNoticeAll.Click += new System.EventHandler(button_SendNoticeAll_Click);
			this.checkBox_NoticeParse.AutoSize = true;
			this.checkBox_NoticeParse.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_NoticeParse.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_NoticeParse.Location = new System.Drawing.Point(251, 71);
			this.checkBox_NoticeParse.Name = "checkBox_NoticeParse";
			this.checkBox_NoticeParse.Padding = new System.Windows.Forms.Padding(4, 0, 0, 0);
			this.checkBox_NoticeParse.Size = new System.Drawing.Size(161, 17);
			this.checkBox_NoticeParse.TabIndex = 0;
			this.checkBox_NoticeParse.Text = "Расшифровка сообщений";
			this.checkBox_NoticeParse.UseVisualStyleBackColor = true;
			this.checkBox_NoticeParse.Visible = false;
			this.textBox_AddressOISM.Location = new System.Drawing.Point(150, 25);
			this.textBox_AddressOISM.Name = "textBox_AddressOISM";
			this.textBox_AddressOISM.Size = new System.Drawing.Size(262, 20);
			this.textBox_AddressOISM.TabIndex = 0;
			this.textBox_AddressOISM.Text = "f1test.taxcom.ru";
			this.numericUpDown_PortOISM.Location = new System.Drawing.Point(421, 25);
			this.numericUpDown_PortOISM.Maximum = new decimal(new int[4] { 65535, 0, 0, 0 });
			this.numericUpDown_PortOISM.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			this.numericUpDown_PortOISM.Name = "numericUpDown_PortOISM";
			this.numericUpDown_PortOISM.Size = new System.Drawing.Size(65, 20);
			this.numericUpDown_PortOISM.TabIndex = 1;
			this.numericUpDown_PortOISM.Value = new decimal(new int[4] { 7778, 0, 0, 0 });
			this.button_SendNoticeOne.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.button_SendNoticeOne.ForeColor = System.Drawing.Color.Brown;
			this.button_SendNoticeOne.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_SendNoticeOne.Location = new System.Drawing.Point(14, 5);
			this.button_SendNoticeOne.Name = "button_SendNoticeOne";
			this.button_SendNoticeOne.Size = new System.Drawing.Size(111, 25);
			this.button_SendNoticeOne.TabIndex = 0;
			this.button_SendNoticeOne.Text = "Отправить 1";
			this.button_SendNoticeOne.UseVisualStyleBackColor = true;
			this.button_SendNoticeOne.Click += new System.EventHandler(button_SendNoticeOne_Click);
			this.label_AddressOISM.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_AddressOISM.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_AddressOISM.Location = new System.Drawing.Point(150, 5);
			this.label_AddressOISM.Name = "label_AddressOISM";
			this.label_AddressOISM.Size = new System.Drawing.Size(262, 17);
			this.label_AddressOISM.TabIndex = 0;
			this.label_AddressOISM.Text = "Адрес ОИСМ";
			this.label_AddressOISM.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.label_PendingNotice.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_PendingNotice.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_PendingNotice.Location = new System.Drawing.Point(150, 50);
			this.label_PendingNotice.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
			this.label_PendingNotice.Name = "label_PendingNotice";
			this.label_PendingNotice.Size = new System.Drawing.Size(65, 17);
			this.label_PendingNotice.TabIndex = 1;
			this.label_PendingNotice.Text = "Осталось";
			this.label_PendingNotice.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.label_PortOISM.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_PortOISM.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_PortOISM.Location = new System.Drawing.Point(421, 5);
			this.label_PortOISM.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
			this.label_PortOISM.Name = "label_PortOISM";
			this.label_PortOISM.Size = new System.Drawing.Size(65, 17);
			this.label_PortOISM.TabIndex = 1;
			this.label_PortOISM.Text = "Порт";
			this.label_PortOISM.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.groupBox_ReadNotice.Controls.Add(this.panel_ReadNotice);
			this.groupBox_ReadNotice.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox_ReadNotice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_ReadNotice.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_ReadNotice.Location = new System.Drawing.Point(3, 3);
			this.groupBox_ReadNotice.Name = "groupBox_ReadNotice";
			this.groupBox_ReadNotice.Size = new System.Drawing.Size(618, 145);
			this.groupBox_ReadNotice.TabIndex = 7;
			this.groupBox_ReadNotice.TabStop = false;
			this.groupBox_ReadNotice.Text = "У в е д о м л е н и я";
			this.panel_ReadNotice.BackColor = System.Drawing.Color.LightCyan;
			this.panel_ReadNotice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_ReadNotice.Controls.Add(this.panel_NoticeOffline);
			this.panel_ReadNotice.Controls.Add(this.checkBox_NoticeAutonom);
			this.panel_ReadNotice.Controls.Add(this.numeric_ReadNoticeLength);
			this.panel_ReadNotice.Controls.Add(this.label_ReadNoticeLength);
			this.panel_ReadNotice.Controls.Add(this.numeric_ReadNoticeOffset);
			this.panel_ReadNotice.Controls.Add(this.label_ReadNoticeOffset);
			this.panel_ReadNotice.Controls.Add(this.button_ReadNotice);
			this.panel_ReadNotice.Controls.Add(this.button_ReadNoticeCancel);
			this.panel_ReadNotice.Controls.Add(this.button_ReadNoticeEnd);
			this.panel_ReadNotice.Controls.Add(this.button_ReadNoticeStart);
			this.panel_ReadNotice.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel_ReadNotice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_ReadNotice.Location = new System.Drawing.Point(3, 16);
			this.panel_ReadNotice.Name = "panel_ReadNotice";
			this.panel_ReadNotice.Size = new System.Drawing.Size(612, 126);
			this.panel_ReadNotice.TabIndex = 0;
			this.panel_NoticeOffline.Controls.Add(this.label_NoticeOffline);
			this.panel_NoticeOffline.Controls.Add(this.label_NoticeCRC);
			this.panel_NoticeOffline.Controls.Add(this.textBox_NoticeOffline);
			this.panel_NoticeOffline.Controls.Add(this.textBox_NoticeCRC);
			this.panel_NoticeOffline.Location = new System.Drawing.Point(300, 21);
			this.panel_NoticeOffline.Name = "panel_NoticeOffline";
			this.panel_NoticeOffline.Size = new System.Drawing.Size(106, 80);
			this.panel_NoticeOffline.TabIndex = 7;
			this.panel_NoticeOffline.Visible = false;
			this.label_NoticeOffline.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_NoticeOffline.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_NoticeOffline.Location = new System.Drawing.Point(3, 3);
			this.label_NoticeOffline.Margin = new System.Windows.Forms.Padding(3);
			this.label_NoticeOffline.Name = "label_NoticeOffline";
			this.label_NoticeOffline.Size = new System.Drawing.Size(45, 13);
			this.label_NoticeOffline.TabIndex = 1;
			this.label_NoticeOffline.Text = "Номер";
			this.label_NoticeOffline.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.label_NoticeCRC.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_NoticeCRC.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_NoticeCRC.Location = new System.Drawing.Point(3, 42);
			this.label_NoticeCRC.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
			this.label_NoticeCRC.Name = "label_NoticeCRC";
			this.label_NoticeCRC.Size = new System.Drawing.Size(61, 13);
			this.label_NoticeCRC.TabIndex = 6;
			this.label_NoticeCRC.Text = "CRC";
			this.label_NoticeCRC.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.textBox_NoticeOffline.BackColor = System.Drawing.Color.Cyan;
			this.textBox_NoticeOffline.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.textBox_NoticeOffline.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.textBox_NoticeOffline.ForeColor = System.Drawing.Color.Blue;
			this.textBox_NoticeOffline.Location = new System.Drawing.Point(3, 16);
			this.textBox_NoticeOffline.Name = "textBox_NoticeOffline";
			this.textBox_NoticeOffline.Size = new System.Drawing.Size(100, 20);
			this.textBox_NoticeOffline.TabIndex = 4;
			this.textBox_NoticeOffline.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.textBox_NoticeCRC.BackColor = System.Drawing.Color.Cyan;
			this.textBox_NoticeCRC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.textBox_NoticeCRC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.textBox_NoticeCRC.ForeColor = System.Drawing.Color.Blue;
			this.textBox_NoticeCRC.Location = new System.Drawing.Point(3, 55);
			this.textBox_NoticeCRC.Name = "textBox_NoticeCRC";
			this.textBox_NoticeCRC.Size = new System.Drawing.Size(100, 20);
			this.textBox_NoticeCRC.TabIndex = 5;
			this.textBox_NoticeCRC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.checkBox_NoticeAutonom.AutoSize = true;
			this.checkBox_NoticeAutonom.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_NoticeAutonom.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_NoticeAutonom.Location = new System.Drawing.Point(150, 3);
			this.checkBox_NoticeAutonom.Name = "checkBox_NoticeAutonom";
			this.checkBox_NoticeAutonom.Size = new System.Drawing.Size(127, 17);
			this.checkBox_NoticeAutonom.TabIndex = 3;
			this.checkBox_NoticeAutonom.Text = "Автономный режим";
			this.checkBox_NoticeAutonom.UseVisualStyleBackColor = true;
			this.checkBox_NoticeAutonom.CheckedChanged += new System.EventHandler(checkBox_NoticeAutonom_CheckedChanged);
			this.numeric_ReadNoticeLength.Increment = new decimal(new int[4] { 50, 0, 0, 0 });
			this.numeric_ReadNoticeLength.Location = new System.Drawing.Point(150, 76);
			this.numeric_ReadNoticeLength.Maximum = new decimal(new int[4] { 1000, 0, 0, 0 });
			this.numeric_ReadNoticeLength.Name = "numeric_ReadNoticeLength";
			this.numeric_ReadNoticeLength.Size = new System.Drawing.Size(70, 20);
			this.numeric_ReadNoticeLength.TabIndex = 0;
			this.numeric_ReadNoticeLength.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.numeric_ReadNoticeLength.Value = new decimal(new int[4] { 500, 0, 0, 0 });
			this.label_ReadNoticeLength.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_ReadNoticeLength.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_ReadNoticeLength.Location = new System.Drawing.Point(150, 63);
			this.label_ReadNoticeLength.Name = "label_ReadNoticeLength";
			this.label_ReadNoticeLength.Size = new System.Drawing.Size(70, 13);
			this.label_ReadNoticeLength.TabIndex = 0;
			this.label_ReadNoticeLength.Text = "Длина";
			this.label_ReadNoticeLength.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.numeric_ReadNoticeOffset.Increment = new decimal(new int[4] { 50, 0, 0, 0 });
			this.numeric_ReadNoticeOffset.Location = new System.Drawing.Point(150, 37);
			this.numeric_ReadNoticeOffset.Maximum = new decimal(new int[4] { 32768, 0, 0, 0 });
			this.numeric_ReadNoticeOffset.Name = "numeric_ReadNoticeOffset";
			this.numeric_ReadNoticeOffset.Size = new System.Drawing.Size(70, 20);
			this.numeric_ReadNoticeOffset.TabIndex = 1;
			this.numeric_ReadNoticeOffset.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.label_ReadNoticeOffset.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_ReadNoticeOffset.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_ReadNoticeOffset.Location = new System.Drawing.Point(150, 24);
			this.label_ReadNoticeOffset.Margin = new System.Windows.Forms.Padding(3, 2, 3, 0);
			this.label_ReadNoticeOffset.Name = "label_ReadNoticeOffset";
			this.label_ReadNoticeOffset.Size = new System.Drawing.Size(70, 13);
			this.label_ReadNoticeOffset.TabIndex = 1;
			this.label_ReadNoticeOffset.Text = "Смещение";
			this.label_ReadNoticeOffset.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.button_ReadNotice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.button_ReadNotice.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_ReadNotice.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_ReadNotice.Location = new System.Drawing.Point(14, 33);
			this.button_ReadNotice.Name = "button_ReadNotice";
			this.button_ReadNotice.Size = new System.Drawing.Size(111, 25);
			this.button_ReadNotice.TabIndex = 0;
			this.button_ReadNotice.Text = "Прочитать";
			this.button_ReadNotice.UseVisualStyleBackColor = true;
			this.button_ReadNotice.Click += new System.EventHandler(button_ReadNotice_Click);
			this.button_ReadNoticeCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.button_ReadNoticeCancel.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_ReadNoticeCancel.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_ReadNoticeCancel.Location = new System.Drawing.Point(14, 93);
			this.button_ReadNoticeCancel.Name = "button_ReadNoticeCancel";
			this.button_ReadNoticeCancel.Size = new System.Drawing.Size(111, 25);
			this.button_ReadNoticeCancel.TabIndex = 2;
			this.button_ReadNoticeCancel.Text = "Отменить";
			this.button_ReadNoticeCancel.UseVisualStyleBackColor = true;
			this.button_ReadNoticeCancel.Click += new System.EventHandler(button_ReadNoticeCancel_Click);
			this.button_ReadNoticeEnd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.button_ReadNoticeEnd.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_ReadNoticeEnd.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_ReadNoticeEnd.Location = new System.Drawing.Point(14, 63);
			this.button_ReadNoticeEnd.Name = "button_ReadNoticeEnd";
			this.button_ReadNoticeEnd.Size = new System.Drawing.Size(111, 25);
			this.button_ReadNoticeEnd.TabIndex = 1;
			this.button_ReadNoticeEnd.Text = "Завершить";
			this.button_ReadNoticeEnd.UseVisualStyleBackColor = true;
			this.button_ReadNoticeEnd.Click += new System.EventHandler(button_ReadNoticeEnd_Click);
			this.button_ReadNoticeStart.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_ReadNoticeStart.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_ReadNoticeStart.Location = new System.Drawing.Point(14, 3);
			this.button_ReadNoticeStart.Name = "button_ReadNoticeStart";
			this.button_ReadNoticeStart.Size = new System.Drawing.Size(111, 25);
			this.button_ReadNoticeStart.TabIndex = 0;
			this.button_ReadNoticeStart.Text = "Начать";
			this.button_ReadNoticeStart.UseVisualStyleBackColor = true;
			this.button_ReadNoticeStart.Click += new System.EventHandler(button_ReadNoticeStart_Click);
			this.tabPage_Electronic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.tabPage_Electronic.Controls.Add(this.panel_Unused);
			this.tabPage_Electronic.Controls.Add(this.panel_FD0);
			this.tabPage_Electronic.Controls.Add(this.panel_XML0);
			this.tabPage_Electronic.Location = new System.Drawing.Point(154, 4);
			this.tabPage_Electronic.Name = "tabPage_Electronic";
			this.tabPage_Electronic.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage_Electronic.Size = new System.Drawing.Size(626, 424);
			this.tabPage_Electronic.TabIndex = 9;
			this.tabPage_Electronic.Text = "Электронная форма";
			this.tabPage_Electronic.UseVisualStyleBackColor = true;
			this.panel_Unused.Controls.Add(this.groupBox_EForm);
			this.panel_Unused.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel_Unused.Location = new System.Drawing.Point(3, 286);
			this.panel_Unused.Name = "panel_Unused";
			this.panel_Unused.Size = new System.Drawing.Size(618, 133);
			this.panel_Unused.TabIndex = 20;
			this.panel_Unused.Visible = false;
			this.groupBox_EForm.Controls.Add(this.panel_CheckEF);
			this.groupBox_EForm.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox_EForm.Enabled = false;
			this.groupBox_EForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.groupBox_EForm.Location = new System.Drawing.Point(0, 0);
			this.groupBox_EForm.Name = "groupBox_EForm";
			this.groupBox_EForm.Size = new System.Drawing.Size(618, 50);
			this.groupBox_EForm.TabIndex = 9;
			this.groupBox_EForm.TabStop = false;
			this.groupBox_EForm.Text = "Чек в электронной форме";
			this.groupBox_EForm.Visible = false;
			this.panel_CheckEF.BackColor = System.Drawing.Color.LightCyan;
			this.panel_CheckEF.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_CheckEF.Controls.Add(this.textBox_Dump1);
			this.panel_CheckEF.Controls.Add(this.checkBox_XML_Archive);
			this.panel_CheckEF.Controls.Add(this.button_Log_Dump);
			this.panel_CheckEF.Controls.Add(this.textBox_Dump2);
			this.panel_CheckEF.Controls.Add(this.checkBox_SaveElCheck);
			this.panel_CheckEF.Controls.Add(this.button_ReadAllCheck);
			this.panel_CheckEF.Controls.Add(this.numericUpDown_EFCheckNumber);
			this.panel_CheckEF.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_CheckEF.Location = new System.Drawing.Point(3, 16);
			this.panel_CheckEF.Name = "panel_CheckEF";
			this.panel_CheckEF.Padding = new System.Windows.Forms.Padding(3);
			this.panel_CheckEF.Size = new System.Drawing.Size(612, 29);
			this.panel_CheckEF.TabIndex = 1;
			this.textBox_Dump1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.textBox_Dump1.Location = new System.Drawing.Point(460, 3);
			this.textBox_Dump1.Name = "textBox_Dump1";
			this.textBox_Dump1.Size = new System.Drawing.Size(25, 20);
			this.textBox_Dump1.TabIndex = 16;
			this.textBox_Dump1.Text = "0";
			this.textBox_Dump1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.checkBox_XML_Archive.AutoSize = true;
			this.checkBox_XML_Archive.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkBox_XML_Archive.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.checkBox_XML_Archive.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_XML_Archive.Location = new System.Drawing.Point(298, 3);
			this.checkBox_XML_Archive.Name = "checkBox_XML_Archive";
			this.checkBox_XML_Archive.Size = new System.Drawing.Size(100, 21);
			this.checkBox_XML_Archive.TabIndex = 14;
			this.checkBox_XML_Archive.Text = "Из архива ФН";
			this.checkBox_XML_Archive.UseVisualStyleBackColor = true;
			this.button_Log_Dump.Enabled = false;
			this.button_Log_Dump.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.button_Log_Dump.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_Log_Dump.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_Log_Dump.Location = new System.Drawing.Point(510, 3);
			this.button_Log_Dump.Name = "button_Log_Dump";
			this.button_Log_Dump.Size = new System.Drawing.Size(85, 21);
			this.button_Log_Dump.TabIndex = 6;
			this.button_Log_Dump.Text = "Log Dump";
			this.button_Log_Dump.UseVisualStyleBackColor = true;
			this.textBox_Dump2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.textBox_Dump2.Location = new System.Drawing.Point(485, 3);
			this.textBox_Dump2.Name = "textBox_Dump2";
			this.textBox_Dump2.Size = new System.Drawing.Size(25, 20);
			this.textBox_Dump2.TabIndex = 16;
			this.textBox_Dump2.Text = "0";
			this.textBox_Dump2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.checkBox_SaveElCheck.AutoSize = true;
			this.checkBox_SaveElCheck.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkBox_SaveElCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_SaveElCheck.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_SaveElCheck.Location = new System.Drawing.Point(181, 3);
			this.checkBox_SaveElCheck.Name = "checkBox_SaveElCheck";
			this.checkBox_SaveElCheck.Size = new System.Drawing.Size(117, 21);
			this.checkBox_SaveElCheck.TabIndex = 6;
			this.checkBox_SaveElCheck.Text = "Сохранять в файл";
			this.checkBox_SaveElCheck.UseVisualStyleBackColor = true;
			this.button_ReadAllCheck.Dock = System.Windows.Forms.DockStyle.Left;
			this.button_ReadAllCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.button_ReadAllCheck.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_ReadAllCheck.Location = new System.Drawing.Point(60, 3);
			this.button_ReadAllCheck.Name = "button_ReadAllCheck";
			this.button_ReadAllCheck.Size = new System.Drawing.Size(121, 21);
			this.button_ReadAllCheck.TabIndex = 0;
			this.button_ReadAllCheck.Text = "Прочитать";
			this.button_ReadAllCheck.UseVisualStyleBackColor = true;
			this.button_ReadAllCheck.Click += new System.EventHandler(button_ReadAllCheck_Click);
			this.numericUpDown_EFCheckNumber.Dock = System.Windows.Forms.DockStyle.Left;
			this.numericUpDown_EFCheckNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.numericUpDown_EFCheckNumber.Location = new System.Drawing.Point(3, 3);
			this.numericUpDown_EFCheckNumber.Maximum = new decimal(new int[4] { 999999999, 0, 0, 0 });
			this.numericUpDown_EFCheckNumber.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			this.numericUpDown_EFCheckNumber.Name = "numericUpDown_EFCheckNumber";
			this.numericUpDown_EFCheckNumber.Size = new System.Drawing.Size(57, 20);
			this.numericUpDown_EFCheckNumber.TabIndex = 0;
			this.numericUpDown_EFCheckNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.numericUpDown_EFCheckNumber.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			this.panel_FD0.Controls.Add(this.groupBox_FD);
			this.panel_FD0.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_FD0.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_FD0.Location = new System.Drawing.Point(3, 67);
			this.panel_FD0.Name = "panel_FD0";
			this.panel_FD0.Size = new System.Drawing.Size(618, 64);
			this.panel_FD0.TabIndex = 18;
			this.groupBox_FD.Controls.Add(this.panel_FD);
			this.groupBox_FD.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox_FD.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_FD.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_FD.Location = new System.Drawing.Point(0, 0);
			this.groupBox_FD.Name = "groupBox_FD";
			this.groupBox_FD.Size = new System.Drawing.Size(618, 50);
			this.groupBox_FD.TabIndex = 11;
			this.groupBox_FD.TabStop = false;
			this.groupBox_FD.Text = "П е ч а т ь   д о к у м е н т а";
			this.panel_FD.BackColor = System.Drawing.Color.LightCyan;
			this.panel_FD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_FD.Controls.Add(this.panel_FD_Type);
			this.panel_FD.Controls.Add(this.button_GetTypeDoc);
			this.panel_FD.Controls.Add(this.button_PrintDoc_Arc);
			this.panel_FD.Controls.Add(this.button_PrintDoc);
			this.panel_FD.Controls.Add(this.panel_FD2);
			this.panel_FD.Controls.Add(this.panel_FD1);
			this.panel_FD.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_FD.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_FD.ForeColor = System.Drawing.SystemColors.ControlText;
			this.panel_FD.Location = new System.Drawing.Point(3, 16);
			this.panel_FD.Name = "panel_FD";
			this.panel_FD.Padding = new System.Windows.Forms.Padding(3);
			this.panel_FD.Size = new System.Drawing.Size(612, 29);
			this.panel_FD.TabIndex = 18;
			this.panel_FD_Type.Controls.Add(this.textBox_TypeFD);
			this.panel_FD_Type.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel_FD_Type.Location = new System.Drawing.Point(344, 3);
			this.panel_FD_Type.Margin = new System.Windows.Forms.Padding(0);
			this.panel_FD_Type.Name = "panel_FD_Type";
			this.panel_FD_Type.Size = new System.Drawing.Size(263, 21);
			this.panel_FD_Type.TabIndex = 4;
			this.textBox_TypeFD.BackColor = System.Drawing.Color.Cyan;
			this.textBox_TypeFD.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox_TypeFD.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.textBox_TypeFD.Location = new System.Drawing.Point(0, 0);
			this.textBox_TypeFD.MaxLength = 60;
			this.textBox_TypeFD.Name = "textBox_TypeFD";
			this.textBox_TypeFD.ReadOnly = true;
			this.textBox_TypeFD.Size = new System.Drawing.Size(263, 20);
			this.textBox_TypeFD.TabIndex = 13;
			this.button_GetTypeDoc.Dock = System.Windows.Forms.DockStyle.Left;
			this.button_GetTypeDoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.button_GetTypeDoc.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_GetTypeDoc.Location = new System.Drawing.Point(269, 3);
			this.button_GetTypeDoc.Name = "button_GetTypeDoc";
			this.button_GetTypeDoc.Size = new System.Drawing.Size(75, 21);
			this.button_GetTypeDoc.TabIndex = 3;
			this.button_GetTypeDoc.Text = "Тип";
			this.button_GetTypeDoc.UseVisualStyleBackColor = true;
			this.button_GetTypeDoc.Click += new System.EventHandler(button_GetTypeDoc_Click);
			this.button_PrintDoc_Arc.Dock = System.Windows.Forms.DockStyle.Left;
			this.button_PrintDoc_Arc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.button_PrintDoc_Arc.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_PrintDoc_Arc.Location = new System.Drawing.Point(169, 3);
			this.button_PrintDoc_Arc.Name = "button_PrintDoc_Arc";
			this.button_PrintDoc_Arc.Size = new System.Drawing.Size(100, 21);
			this.button_PrintDoc_Arc.TabIndex = 3;
			this.button_PrintDoc_Arc.Text = "Из архива ФН";
			this.button_PrintDoc_Arc.UseVisualStyleBackColor = true;
			this.button_PrintDoc_Arc.Click += new System.EventHandler(button_PrintDoc_Click);
			this.button_PrintDoc.Dock = System.Windows.Forms.DockStyle.Left;
			this.button_PrintDoc.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_PrintDoc.Location = new System.Drawing.Point(79, 3);
			this.button_PrintDoc.Name = "button_PrintDoc";
			this.button_PrintDoc.Size = new System.Drawing.Size(90, 21);
			this.button_PrintDoc.TabIndex = 2;
			this.button_PrintDoc.Text = "Из ФН";
			this.button_PrintDoc.UseVisualStyleBackColor = true;
			this.button_PrintDoc.Click += new System.EventHandler(button_PrintDoc_Click);
			this.panel_FD2.Controls.Add(this.numericUpDown_FD);
			this.panel_FD2.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel_FD2.Location = new System.Drawing.Point(29, 3);
			this.panel_FD2.Name = "panel_FD2";
			this.panel_FD2.Size = new System.Drawing.Size(50, 21);
			this.panel_FD2.TabIndex = 1;
			this.numericUpDown_FD.Dock = System.Windows.Forms.DockStyle.Fill;
			this.numericUpDown_FD.Location = new System.Drawing.Point(0, 0);
			this.numericUpDown_FD.Maximum = new decimal(new int[4] { 999999999, 0, 0, 0 });
			this.numericUpDown_FD.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			this.numericUpDown_FD.Name = "numericUpDown_FD";
			this.numericUpDown_FD.Size = new System.Drawing.Size(50, 20);
			this.numericUpDown_FD.TabIndex = 0;
			this.numericUpDown_FD.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.numericUpDown_FD.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			this.panel_FD1.Controls.Add(this.label_FD);
			this.panel_FD1.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel_FD1.Location = new System.Drawing.Point(3, 3);
			this.panel_FD1.Name = "panel_FD1";
			this.panel_FD1.Padding = new System.Windows.Forms.Padding(3);
			this.panel_FD1.Size = new System.Drawing.Size(26, 21);
			this.panel_FD1.TabIndex = 2;
			this.label_FD.AutoSize = true;
			this.label_FD.Dock = System.Windows.Forms.DockStyle.Fill;
			this.label_FD.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_FD.ForeColor = System.Drawing.SystemColors.ControlText;
			this.label_FD.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_FD.Location = new System.Drawing.Point(3, 3);
			this.label_FD.Margin = new System.Windows.Forms.Padding(3);
			this.label_FD.Name = "label_FD";
			this.label_FD.Size = new System.Drawing.Size(18, 13);
			this.label_FD.TabIndex = 4;
			this.label_FD.Text = "№";
			this.label_FD.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.panel_XML0.Controls.Add(this.groupBox_XML_Document);
			this.panel_XML0.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_XML0.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_XML0.Location = new System.Drawing.Point(3, 3);
			this.panel_XML0.Name = "panel_XML0";
			this.panel_XML0.Size = new System.Drawing.Size(618, 64);
			this.panel_XML0.TabIndex = 0;
			this.groupBox_XML_Document.Controls.Add(this.panel_XML_Document);
			this.groupBox_XML_Document.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox_XML_Document.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_XML_Document.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_XML_Document.Location = new System.Drawing.Point(0, 0);
			this.groupBox_XML_Document.Name = "groupBox_XML_Document";
			this.groupBox_XML_Document.Size = new System.Drawing.Size(618, 50);
			this.groupBox_XML_Document.TabIndex = 11;
			this.groupBox_XML_Document.TabStop = false;
			this.groupBox_XML_Document.Text = "X M L  д о к у м е н т";
			this.panel_XML_Document.BackColor = System.Drawing.Color.LightCyan;
			this.panel_XML_Document.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_XML_Document.Controls.Add(this.panel_XML4);
			this.panel_XML_Document.Controls.Add(this.button_ReadXML_Arc);
			this.panel_XML_Document.Controls.Add(this.button_ReadXML);
			this.panel_XML_Document.Controls.Add(this.panel_XML2);
			this.panel_XML_Document.Controls.Add(this.panel_XML1);
			this.panel_XML_Document.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_XML_Document.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.panel_XML_Document.ForeColor = System.Drawing.SystemColors.ControlText;
			this.panel_XML_Document.Location = new System.Drawing.Point(3, 16);
			this.panel_XML_Document.Name = "panel_XML_Document";
			this.panel_XML_Document.Padding = new System.Windows.Forms.Padding(3);
			this.panel_XML_Document.Size = new System.Drawing.Size(612, 29);
			this.panel_XML_Document.TabIndex = 18;
			this.panel_XML4.Controls.Add(this.checkBox_XML_SaveToFile);
			this.panel_XML4.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel_XML4.Location = new System.Drawing.Point(269, 3);
			this.panel_XML4.Name = "panel_XML4";
			this.panel_XML4.Padding = new System.Windows.Forms.Padding(6, 0, 6, 0);
			this.panel_XML4.Size = new System.Drawing.Size(140, 21);
			this.panel_XML4.TabIndex = 4;
			this.checkBox_XML_SaveToFile.AutoSize = true;
			this.checkBox_XML_SaveToFile.Dock = System.Windows.Forms.DockStyle.Fill;
			this.checkBox_XML_SaveToFile.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_XML_SaveToFile.Location = new System.Drawing.Point(6, 0);
			this.checkBox_XML_SaveToFile.Name = "checkBox_XML_SaveToFile";
			this.checkBox_XML_SaveToFile.Size = new System.Drawing.Size(128, 21);
			this.checkBox_XML_SaveToFile.TabIndex = 5;
			this.checkBox_XML_SaveToFile.Text = "Сохранить в файл";
			this.checkBox_XML_SaveToFile.UseVisualStyleBackColor = true;
			this.button_ReadXML_Arc.Dock = System.Windows.Forms.DockStyle.Left;
			this.button_ReadXML_Arc.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_ReadXML_Arc.Location = new System.Drawing.Point(169, 3);
			this.button_ReadXML_Arc.Name = "button_ReadXML_Arc";
			this.button_ReadXML_Arc.Size = new System.Drawing.Size(100, 21);
			this.button_ReadXML_Arc.TabIndex = 5;
			this.button_ReadXML_Arc.Text = "Из архива ФН";
			this.button_ReadXML_Arc.UseVisualStyleBackColor = true;
			this.button_ReadXML_Arc.Click += new System.EventHandler(button_ReadXML_Click);
			this.button_ReadXML.Dock = System.Windows.Forms.DockStyle.Left;
			this.button_ReadXML.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_ReadXML.Location = new System.Drawing.Point(79, 3);
			this.button_ReadXML.Name = "button_ReadXML";
			this.button_ReadXML.Size = new System.Drawing.Size(90, 21);
			this.button_ReadXML.TabIndex = 0;
			this.button_ReadXML.Text = "Из ФН";
			this.button_ReadXML.UseVisualStyleBackColor = true;
			this.button_ReadXML.Click += new System.EventHandler(button_ReadXML_Click);
			this.panel_XML2.Controls.Add(this.numericUpDown_XMLDocNum);
			this.panel_XML2.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel_XML2.Location = new System.Drawing.Point(29, 3);
			this.panel_XML2.Name = "panel_XML2";
			this.panel_XML2.Size = new System.Drawing.Size(50, 21);
			this.panel_XML2.TabIndex = 1;
			this.numericUpDown_XMLDocNum.Dock = System.Windows.Forms.DockStyle.Fill;
			this.numericUpDown_XMLDocNum.Location = new System.Drawing.Point(0, 0);
			this.numericUpDown_XMLDocNum.Margin = new System.Windows.Forms.Padding(0);
			this.numericUpDown_XMLDocNum.Maximum = new decimal(new int[4] { 999999999, 0, 0, 0 });
			this.numericUpDown_XMLDocNum.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			this.numericUpDown_XMLDocNum.Name = "numericUpDown_XMLDocNum";
			this.numericUpDown_XMLDocNum.Size = new System.Drawing.Size(50, 20);
			this.numericUpDown_XMLDocNum.TabIndex = 0;
			this.numericUpDown_XMLDocNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.numericUpDown_XMLDocNum.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			this.panel_XML1.Controls.Add(this.label_XML1);
			this.panel_XML1.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel_XML1.Location = new System.Drawing.Point(3, 3);
			this.panel_XML1.Name = "panel_XML1";
			this.panel_XML1.Padding = new System.Windows.Forms.Padding(3);
			this.panel_XML1.Size = new System.Drawing.Size(26, 21);
			this.panel_XML1.TabIndex = 2;
			this.label_XML1.AutoSize = true;
			this.label_XML1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.label_XML1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_XML1.ForeColor = System.Drawing.SystemColors.ControlText;
			this.label_XML1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_XML1.Location = new System.Drawing.Point(3, 3);
			this.label_XML1.Margin = new System.Windows.Forms.Padding(3);
			this.label_XML1.Name = "label_XML1";
			this.label_XML1.Size = new System.Drawing.Size(18, 13);
			this.label_XML1.TabIndex = 4;
			this.label_XML1.Text = "№";
			this.label_XML1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.button_StatePrinter.AutoSize = true;
			this.button_StatePrinter.Dock = System.Windows.Forms.DockStyle.Right;
			this.button_StatePrinter.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.button_StatePrinter.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_StatePrinter.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_StatePrinter.Location = new System.Drawing.Point(637, 0);
			this.button_StatePrinter.Name = "button_StatePrinter";
			this.button_StatePrinter.Size = new System.Drawing.Size(72, 26);
			this.button_StatePrinter.TabIndex = 0;
			this.button_StatePrinter.Text = "Принтер ?";
			this.toolTip1.SetToolTip(this.button_StatePrinter, "Состояние принтера");
			this.button_StatePrinter.UseVisualStyleBackColor = true;
			this.button_StatePrinter.Click += new System.EventHandler(Button_StatePrinter_Click);
			this.checkBox_StatusPrint.Checked = true;
			this.checkBox_StatusPrint.CheckState = System.Windows.Forms.CheckState.Checked;
			this.checkBox_StatusPrint.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkBox_StatusPrint.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_StatusPrint.Location = new System.Drawing.Point(45, 0);
			this.checkBox_StatusPrint.Name = "checkBox_StatusPrint";
			this.checkBox_StatusPrint.Size = new System.Drawing.Size(62, 26);
			this.checkBox_StatusPrint.TabIndex = 2;
			this.checkBox_StatusPrint.Text = "Печать";
			this.toolTip1.SetToolTip(this.checkBox_StatusPrint, "Включить/выключить выдачу документов на печать");
			this.checkBox_StatusPrint.UseVisualStyleBackColor = true;
			this.checkBox_StatusLog.AutoSize = true;
			this.checkBox_StatusLog.Checked = true;
			this.checkBox_StatusLog.CheckState = System.Windows.Forms.CheckState.Checked;
			this.checkBox_StatusLog.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkBox_StatusLog.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_StatusLog.Location = new System.Drawing.Point(0, 0);
			this.checkBox_StatusLog.Name = "checkBox_StatusLog";
			this.checkBox_StatusLog.Size = new System.Drawing.Size(45, 26);
			this.checkBox_StatusLog.TabIndex = 2;
			this.checkBox_StatusLog.Text = "Лог";
			this.toolTip1.SetToolTip(this.checkBox_StatusLog, "Включить/выключить вывод в лог");
			this.checkBox_StatusLog.UseVisualStyleBackColor = true;
			this.openFileDialog1.ShowReadOnly = true;
			this.openFileDialog1.SupportMultiDottedExtensions = true;
			this.openFileDialog1.Title = "Выберите файл скрипта";
			this.panel_Bottom.BackColor = System.Drawing.Color.LightBlue;
			this.panel_Bottom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_Bottom.Controls.Add(this.button_PowerGet);
			this.panel_Bottom.Controls.Add(this.button_PowerSet);
			this.panel_Bottom.Controls.Add(this.checkBox_PowerFlag);
			this.panel_Bottom.Controls.Add(this.checkBox_StatusAutonom);
			this.panel_Bottom.Controls.Add(this.button_Duplicate0);
			this.panel_Bottom.Controls.Add(this.button_StatePrinter);
			this.panel_Bottom.Controls.Add(this.button_PowerReset);
			this.panel_Bottom.Controls.Add(this.checkBox_Footer);
			this.panel_Bottom.Controls.Add(this.checkBox_StatusPrint);
			this.panel_Bottom.Controls.Add(this.checkBox_StatusLog);
			this.panel_Bottom.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel_Bottom.Location = new System.Drawing.Point(0, 533);
			this.panel_Bottom.Name = "panel_Bottom";
			this.panel_Bottom.Size = new System.Drawing.Size(784, 28);
			this.panel_Bottom.TabIndex = 1;
			this.button_PowerGet.AutoSize = true;
			this.button_PowerGet.Dock = System.Windows.Forms.DockStyle.Left;
			this.button_PowerGet.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_PowerGet.Location = new System.Drawing.Point(451, 0);
			this.button_PowerGet.Name = "button_PowerGet";
			this.button_PowerGet.Size = new System.Drawing.Size(72, 26);
			this.button_PowerGet.TabIndex = 2;
			this.button_PowerGet.Text = "Проверить";
			this.button_PowerGet.UseVisualStyleBackColor = true;
			this.button_PowerGet.Click += new System.EventHandler(Button_PowerGet_Click);
			this.button_PowerSet.AutoSize = true;
			this.button_PowerSet.Dock = System.Windows.Forms.DockStyle.Left;
			this.button_PowerSet.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_PowerSet.Location = new System.Drawing.Point(379, 0);
			this.button_PowerSet.Name = "button_PowerSet";
			this.button_PowerSet.Size = new System.Drawing.Size(72, 26);
			this.button_PowerSet.TabIndex = 3;
			this.button_PowerSet.Text = "Задать";
			this.button_PowerSet.UseVisualStyleBackColor = true;
			this.button_PowerSet.Click += new System.EventHandler(Button_PowerSet_Click);
			this.checkBox_PowerFlag.AutoSize = true;
			this.checkBox_PowerFlag.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_PowerFlag.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkBox_PowerFlag.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_PowerFlag.Location = new System.Drawing.Point(301, 0);
			this.checkBox_PowerFlag.Name = "checkBox_PowerFlag";
			this.checkBox_PowerFlag.Size = new System.Drawing.Size(78, 26);
			this.checkBox_PowerFlag.TabIndex = 4;
			this.checkBox_PowerFlag.Text = "Флаг ККТ";
			this.toolTip1.SetToolTip(this.checkBox_PowerFlag, "Установить при запуске.\r\nПроверить, было ли отключение питания ККТ.");
			this.checkBox_PowerFlag.UseVisualStyleBackColor = true;
			this.checkBox_StatusAutonom.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkBox_StatusAutonom.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_StatusAutonom.Location = new System.Drawing.Point(171, 0);
			this.checkBox_StatusAutonom.Name = "checkBox_StatusAutonom";
			this.checkBox_StatusAutonom.Size = new System.Drawing.Size(130, 26);
			this.checkBox_StatusAutonom.TabIndex = 6;
			this.checkBox_StatusAutonom.Text = "Автономная ККТ";
			this.toolTip1.SetToolTip(this.checkBox_StatusAutonom, "Признак автономного режима ККТ");
			this.checkBox_StatusAutonom.UseVisualStyleBackColor = true;
			this.checkBox_StatusAutonom.CheckedChanged += new System.EventHandler(checkBox_StatusAutonom_CheckedChanged);
			this.button_Duplicate0.AutoSize = true;
			this.button_Duplicate0.Dock = System.Windows.Forms.DockStyle.Right;
			this.button_Duplicate0.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold);
			this.button_Duplicate0.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_Duplicate0.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_Duplicate0.Location = new System.Drawing.Point(565, 0);
			this.button_Duplicate0.Name = "button_Duplicate0";
			this.button_Duplicate0.Size = new System.Drawing.Size(72, 26);
			this.button_Duplicate0.TabIndex = 5;
			this.button_Duplicate0.Text = "Печать!";
			this.toolTip1.SetToolTip(this.button_Duplicate0, "Печать копии последнего документа ");
			this.button_Duplicate0.UseVisualStyleBackColor = true;
			this.button_Duplicate0.Click += new System.EventHandler(Button_Duplicate0_Click);
			this.button_PowerReset.AutoSize = true;
			this.button_PowerReset.BackColor = System.Drawing.Color.Transparent;
			this.button_PowerReset.Dock = System.Windows.Forms.DockStyle.Right;
			this.button_PowerReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 204);
			this.button_PowerReset.Image = MitsuCube.Properties.Resources.restart;
			this.button_PowerReset.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.button_PowerReset.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_PowerReset.Location = new System.Drawing.Point(709, 0);
			this.button_PowerReset.Name = "button_PowerReset";
			this.button_PowerReset.Size = new System.Drawing.Size(73, 26);
			this.button_PowerReset.TabIndex = 0;
			this.button_PowerReset.Text = "Рестарт";
			this.button_PowerReset.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.button_PowerReset.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
			this.toolTip1.SetToolTip(this.button_PowerReset, "Перезапуск ККТ");
			this.button_PowerReset.UseVisualStyleBackColor = false;
			this.button_PowerReset.Click += new System.EventHandler(Button_PowerReset_Click);
			this.checkBox_Footer.AutoSize = true;
			this.checkBox_Footer.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkBox_Footer.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_Footer.Location = new System.Drawing.Point(107, 0);
			this.checkBox_Footer.Name = "checkBox_Footer";
			this.checkBox_Footer.Size = new System.Drawing.Size(64, 26);
			this.checkBox_Footer.TabIndex = 7;
			this.checkBox_Footer.Text = "Подвал";
			this.toolTip1.SetToolTip(this.checkBox_Footer, "Включить/выключить печать клише/подвала в отчетах");
			this.checkBox_Footer.UseVisualStyleBackColor = true;
			this.toolTip1.AutoPopDelay = 5000;
			this.toolTip1.BackColor = System.Drawing.Color.Wheat;
			this.toolTip1.InitialDelay = 200;
			this.toolTip1.ReshowDelay = 500;
			this.toolTip1.ShowAlways = true;
			this.contextMenuStrip_Log.Items.AddRange(new System.Windows.Forms.ToolStripItem[3] { this.clearAllToolStripMenuItem, this.copyToolStripMenuItem, this.copyAllToolStripMenuItem });
			this.contextMenuStrip_Log.Name = "contextMenuStrip2";
			this.contextMenuStrip_Log.Size = new System.Drawing.Size(161, 70);
			this.clearAllToolStripMenuItem.Name = "clearAllToolStripMenuItem";
			this.clearAllToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
			this.clearAllToolStripMenuItem.Text = "Очистить";
			this.clearAllToolStripMenuItem.Click += new System.EventHandler(clearAllToolStripMenuItem_Click);
			this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
			this.copyToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
			this.copyToolStripMenuItem.Text = "Копировать";
			this.copyToolStripMenuItem.Click += new System.EventHandler(copyToolStripMenuItem_Click);
			this.copyAllToolStripMenuItem.Name = "copyAllToolStripMenuItem";
			this.copyAllToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
			this.copyAllToolStripMenuItem.Text = "Копировать все";
			this.copyAllToolStripMenuItem.Click += new System.EventHandler(copyAllToolStripMenuItem_Click);
			this.richTextBox_Log.BackColor = System.Drawing.Color.LightCyan;
			this.richTextBox_Log.ContextMenuStrip = this.contextMenuStrip_Log;
			this.richTextBox_Log.Dock = System.Windows.Forms.DockStyle.Fill;
			this.richTextBox_Log.Font = new System.Drawing.Font("Courier New", 8.25f);
			this.richTextBox_Log.ForeColor = System.Drawing.Color.Black;
			this.richTextBox_Log.Location = new System.Drawing.Point(0, 432);
			this.richTextBox_Log.Name = "richTextBox_Log";
			this.richTextBox_Log.ReadOnly = true;
			this.richTextBox_Log.Size = new System.Drawing.Size(784, 101);
			this.richTextBox_Log.TabIndex = 5;
			this.richTextBox_Log.Text = "";
			this.richTextBox_Log.WordWrap = false;
			this.saveFileDialog_Notice.DefaultExt = "crpt";
			this.saveFileDialog_Notice.Filter = "Файлы уведомлений|*.crpt|Все файлы|*.*\"";
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(784, 561);
			base.Controls.Add(this.richTextBox_Log);
			base.Controls.Add(this.tabControl_Main);
			base.Controls.Add(this.panel_Bottom);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.MinimumSize = new System.Drawing.Size(800, 600);
			base.Name = "MainForm";
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			base.FormClosed += new System.Windows.Forms.FormClosedEventHandler(Form1_FormClosed);
			base.Shown += new System.EventHandler(Form1_Shown);
			base.Resize += new System.EventHandler(Form1_Resize);
			this.tabControl_Main.ResumeLayout(false);
			this.tabPage_Main.ResumeLayout(false);
			this.panel_Reports.ResumeLayout(false);
			this.groupBox_Reports.ResumeLayout(false);
			this.panel_ReportControls.ResumeLayout(false);
			this.panel_DocumentFrame.ResumeLayout(false);
			this.groupBox_Document.ResumeLayout(false);
			this.panel_DocControls.ResumeLayout(false);
			this.panel_DocControls.PerformLayout();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_FromFN).EndInit();
			this.panel_ShiftFrame.ResumeLayout(false);
			this.groupBox_Shift.ResumeLayout(false);
			this.panel_ShiftControls.ResumeLayout(false);
			this.panel_ShiftControls.PerformLayout();
			this.panel_CashierFrame.ResumeLayout(false);
			this.groupBox_Cashier.ResumeLayout(false);
			this.panel_Cashier.ResumeLayout(false);
			this.panel_CashierName.ResumeLayout(false);
			this.panel_CashierName.PerformLayout();
			this.panel_CashierTaxID.ResumeLayout(false);
			this.panel_CashierTaxID.PerformLayout();
			this.panel_SetCashier.ResumeLayout(false);
			this.panel_GetCashier.ResumeLayout(false);
			this.panel_DateTimeFrame.ResumeLayout(false);
			this.groupBox_DateTime.ResumeLayout(false);
			this.panel_DateTimeFW.ResumeLayout(false);
			this.panel_KKTSerial.ResumeLayout(false);
			this.panel_KKTSerial.PerformLayout();
			((System.ComponentModel.ISupportInitialize)this.numeric_KKTSerial).EndInit();
			this.panel_Connection.ResumeLayout(false);
			this.groupBox_Connection.ResumeLayout(false);
			this.panel_RadioCOM.ResumeLayout(false);
			this.panel_COMRefresh.ResumeLayout(false);
			this.panel_LAN.ResumeLayout(false);
			this.panel_LAN.PerformLayout();
			this.panel_Service.ResumeLayout(false);
			this.panel_Service.PerformLayout();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_Service_ID).EndInit();
			this.panel_RadioButtons.ResumeLayout(false);
			this.panel_Baudrate.ResumeLayout(false);
			this.tabPage_Status.ResumeLayout(false);
			this.groupBox_Status_OFD.ResumeLayout(false);
			this.panel_Status_OFD.ResumeLayout(false);
			this.panel_Status_OFD3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.dataGrid_Status_DM3).EndInit();
			((System.ComponentModel.ISupportInitialize)this.dataGrid_Status_DM1).EndInit();
			((System.ComponentModel.ISupportInitialize)this.dataGrid_Status_DM2).EndInit();
			this.panel_DataMark.ResumeLayout(false);
			this.panel_Status_OFD2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.dataGrid_Status_OFD).EndInit();
			this.panel_Status_OFD1.ResumeLayout(false);
			this.groupBox_Status_FN.ResumeLayout(false);
			this.panel_Status_FN.ResumeLayout(false);
			this.panel_Status_FN3.ResumeLayout(false);
			this.panel_Status_FN3.PerformLayout();
			((System.ComponentModel.ISupportInitialize)this.dataGrid_Totals_FN).EndInit();
			((System.ComponentModel.ISupportInitialize)this.dataGrid_Tax_FN).EndInit();
			this.panel_Totals_FN.ResumeLayout(false);
			this.panel_Status_FN2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.dataGrid_Status_FN).EndInit();
			this.panel_Status_FN1.ResumeLayout(false);
			this.tabPage_Commands.ResumeLayout(false);
			this.panel_FWControlFrame.ResumeLayout(false);
			this.groupBox_FWControl.ResumeLayout(false);
			this.panel_FWControl.ResumeLayout(false);
			this.panel_FWControl.PerformLayout();
			this.panel_FNControlFrame.ResumeLayout(false);
			this.groupBox_FNControl.ResumeLayout(false);
			this.panel_FNControl.ResumeLayout(false);
			this.panel_ManualCommandFrame.ResumeLayout(false);
			this.groupBox_ManualCommand.ResumeLayout(false);
			this.panel_ManualCommand.ResumeLayout(false);
			this.panel_AutoReceiptFrame.ResumeLayout(false);
			this.groupBox_AutoReceipt.ResumeLayout(false);
			this.panel_AutoReceipt.ResumeLayout(false);
			this.panel_ItemName.ResumeLayout(false);
			this.panel_ItemName.PerformLayout();
			this.panel_ProduceRcpt.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_AutoReceiptItemNo).EndInit();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_AutoReceiptRepeat).EndInit();
			this.panel_ScriptFrame.ResumeLayout(false);
			this.groupBox_Script.ResumeLayout(false);
			this.panel_Script.ResumeLayout(false);
			this.tabPage_Settings.ResumeLayout(false);
			this.panel_LAN_Buttons.ResumeLayout(false);
			this.panel_OKP_Settings.ResumeLayout(false);
			this.groupBox_OKPSettings.ResumeLayout(false);
			this.groupBox_OKPSettings.PerformLayout();
			((System.ComponentModel.ISupportInitialize)this.dataGrid_OKP).EndInit();
			this.panel_OISM_Settings.ResumeLayout(false);
			this.groupBox_OISMSettings.ResumeLayout(false);
			this.groupBox_OISMSettings.PerformLayout();
			((System.ComponentModel.ISupportInitialize)this.dataGrid_OISM).EndInit();
			this.panel_OFDSettings.ResumeLayout(false);
			this.groupBox_OFDSettings.ResumeLayout(false);
			this.groupBox_OFDSettings.PerformLayout();
			this.panel_Setup_OFDClient.ResumeLayout(false);
			this.panel_Setup_OFDClient.PerformLayout();
			((System.ComponentModel.ISupportInitialize)this.dataGrid_OFD).EndInit();
			this.panel_Setup.ResumeLayout(false);
			this.groupBox_Setup.ResumeLayout(false);
			this.panel_Setup_PrstTime.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.numeric_Setup_PrstTime).EndInit();
			this.panel_Setup_Prst.ResumeLayout(false);
			this.panel_Setup_PrstValue.ResumeLayout(false);
			this.panel_Setup_DrawerFall.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_Setup_DrawerFall).EndInit();
			this.panel_Setup_DrawerPulse.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_Setup_DrawerPulse).EndInit();
			this.panel_Setup_DrawerPin.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_Setup_DrawerPin).EndInit();
			this.panel_Setup_ItemCnt.ResumeLayout(false);
			this.panel_ItemCntYesNo.ResumeLayout(false);
			this.panel_ItemCntYesNo.PerformLayout();
			this.panel_Setup_DrawerOpen.ResumeLayout(false);
			this.panel_Setup_DrawerOpen_Y_N.ResumeLayout(false);
			this.panel_Setup_DrawerOpen_Y_N.PerformLayout();
			this.panel_Setup_AutoTest.ResumeLayout(false);
			this.panel_Setup_AutoTest_Y_N.ResumeLayout(false);
			this.panel_Setup_AutoTest_Y_N.PerformLayout();
			this.panel_Setup_Beeper.ResumeLayout(false);
			this.panel_Setup_Beeper_Y_N.ResumeLayout(false);
			this.panel_Setup_Beeper_Y_N.PerformLayout();
			this.panel_Setup_PaperCut.ResumeLayout(false);
			this.panel_Setup_PaperCut_Y_N.ResumeLayout(false);
			this.panel_Setup_PaperCut_Y_N.PerformLayout();
			this.panel_Setup_QRText.ResumeLayout(false);
			this.panel_Setup_QRText_Y_N.ResumeLayout(false);
			this.panel_Setup_QRText_Y_N.PerformLayout();
			this.panel_Setup_FontType.ResumeLayout(false);
			this.panel_Setup_A_B.ResumeLayout(false);
			this.panel_Setup_A_B.PerformLayout();
			this.panel_Setup_PaperWidth.ResumeLayout(false);
			this.panel_Setup_80_57.ResumeLayout(false);
			this.panel_Setup_80_57.PerformLayout();
			this.panel_Setup_LineType.ResumeLayout(false);
			this.panel_Setup_LineTypeValue.ResumeLayout(false);
			this.panel_Setup_Rounding.ResumeLayout(false);
			this.panel_Setup_RoundingValue.ResumeLayout(false);
			this.panel_Setup_QRAlign.ResumeLayout(false);
			this.panel_Setup_QRAlignValue.ResumeLayout(false);
			this.panel_PrinterModel.ResumeLayout(false);
			this.panel_PrinterModelValue.ResumeLayout(false);
			this.panel_Setup_Buttons.ResumeLayout(false);
			this.panel_Setup_PrBaudrate.ResumeLayout(false);
			this.panel_Setup_PrBaudrateValue.ResumeLayout(false);
			this.panel_Setup_COMBaudrate.ResumeLayout(false);
			this.panel_Setup_COMBaudrateValue.ResumeLayout(false);
			this.panel_Setup_SelectAll.ResumeLayout(false);
			this.panel_LANSettings.ResumeLayout(false);
			this.groupBox_LANSettings.ResumeLayout(false);
			this.groupBox_LANSettings.PerformLayout();
			((System.ComponentModel.ISupportInitialize)this.dataGrid_LAN).EndInit();
			this.tabPage_Header.ResumeLayout(false);
			this.panel_LogoPic.ResumeLayout(false);
			this.groupBox_Picture.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.pictureBox_Picture).EndInit();
			this.panel_Picture.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_Picture).EndInit();
			this.groupBox_Logo.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.pictureBox_Logo).EndInit();
			this.panel_Logo.ResumeLayout(false);
			this.panel_Logo.PerformLayout();
			this.groupBox_Header.ResumeLayout(false);
			this.panel_Header.ResumeLayout(false);
			this.panel_HeaderSet.ResumeLayout(false);
			this.groupBox_HeaderAlign.ResumeLayout(false);
			this.groupBox_HeaderUnderline.ResumeLayout(false);
			this.groupBox_HeaderFont.ResumeLayout(false);
			this.groupBox_CharHeight.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_CharHeight).EndInit();
			this.groupBox_CharWidth.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_CharWidth).EndInit();
			this.groupBox_HeaderInverse.ResumeLayout(false);
			this.groupBox_HeaderInverse.PerformLayout();
			this.panel_HeaderList.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.dataGrid_Header2).EndInit();
			((System.ComponentModel.ISupportInitialize)this.dataGrid_Header1).EndInit();
			((System.ComponentModel.ISupportInitialize)this.dataGrid_Header4).EndInit();
			((System.ComponentModel.ISupportInitialize)this.dataGrid_Header3).EndInit();
			this.panel_HeaderCheckList.ResumeLayout(false);
			this.panel_HeaderCheckList.PerformLayout();
			this.panel_HeaderSel.ResumeLayout(false);
			this.panel_HeaderSel.PerformLayout();
			this.tabPage_Registration.ResumeLayout(false);
			this.tabPage_Registration.PerformLayout();
			this.panel_RegNo.ResumeLayout(false);
			this.panel_Reg3.ResumeLayout(false);
			this.groupBox_Reason11.ResumeLayout(false);
			this.panel_Reg1.ResumeLayout(false);
			this.panel_RegBottom.ResumeLayout(false);
			this.panel_RegBottom.PerformLayout();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_ReRegNumber).EndInit();
			this.panel_Reg2.ResumeLayout(false);
			this.groupBox_OpMode.ResumeLayout(false);
			this.groupBox_Taxes.ResumeLayout(false);
			this.groupBox_RegData.ResumeLayout(false);
			this.groupBox_RegData.PerformLayout();
			this.contextMenuStrip_Reg.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.dataGrid_RegData).EndInit();
			this.tabPage_Transaction.ResumeLayout(false);
			this.panel_beznal.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.dataGrid_beznal).EndInit();
			this.panel_AddItem.ResumeLayout(false);
			this.groupBox_AddItem.ResumeLayout(false);
			this.panel_Ticket_Item.ResumeLayout(false);
			this.groupBox_Mark.ResumeLayout(false);
			this.panel_Mark_Data.ResumeLayout(false);
			this.panel_Mark_Data.PerformLayout();
			this.panel_Mark_Header.ResumeLayout(false);
			this.panel_ItemMark.ResumeLayout(false);
			this.panel_ItemMark.PerformLayout();
			this.panel_Ticket_Option4.ResumeLayout(false);
			this.panel_Ticket_Option4.PerformLayout();
			this.panel_Ticket_Option41.ResumeLayout(false);
			this.panel_Ticket_Option3.ResumeLayout(false);
			this.panel_Ticket_Option3.PerformLayout();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_PricePerPiece).EndInit();
			((System.ComponentModel.ISupportInitialize)this.numeric_QtyDenom).EndInit();
			((System.ComponentModel.ISupportInitialize)this.numeric_QtyNom).EndInit();
			this.panel_Ticket_Option31.ResumeLayout(false);
			this.panel_Ticket_Option2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.numeric_ItemAmount).EndInit();
			((System.ComponentModel.ISupportInitialize)this.numeric_ItemExcise).EndInit();
			((System.ComponentModel.ISupportInitialize)this.numeric_ItemPrice).EndInit();
			this.panel_Ticket_Option21.ResumeLayout(false);
			this.panel_Ticket_Option1.ResumeLayout(false);
			this.panel_Ticket_Option1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)this.numeric_ItemQty).EndInit();
			this.panel_Ticket_ItemAddTest.ResumeLayout(false);
			this.panel_Ticket_ItemAddTest.PerformLayout();
			this.panel_TicketClose.ResumeLayout(false);
			this.panel_TicketClose.PerformLayout();
			this.panel_Ticket_Total.ResumeLayout(false);
			this.panel_Ticket_Total.PerformLayout();
			((System.ComponentModel.ISupportInitialize)this.numeric_Discount).EndInit();
			this.panel_TicketOpen.ResumeLayout(false);
			this.groupBox_TicketOpen.ResumeLayout(false);
			this.panel_Ticket_Open.ResumeLayout(false);
			this.panel_Ticket_Open.PerformLayout();
			this.panel_TicketPay.ResumeLayout(false);
			this.panel_TicketPay.PerformLayout();
			((System.ComponentModel.ISupportInitialize)this.nUpDown_VpCheck).EndInit();
			((System.ComponentModel.ISupportInitialize)this.nUpDown_CrCheck).EndInit();
			((System.ComponentModel.ISupportInitialize)this.nUpDown_AvCheck).EndInit();
			((System.ComponentModel.ISupportInitialize)this.nUpDown_ElCheck).EndInit();
			((System.ComponentModel.ISupportInitialize)this.nUpDown_NalCheck).EndInit();
			this.panel_Ticket_Type_and_Tax.ResumeLayout(false);
			this.groupBox_TransactionTax.ResumeLayout(false);
			this.panel_Ticket_Tax.ResumeLayout(false);
			this.panel_Ticket_Tax.PerformLayout();
			this.groupBox_TransactionType.ResumeLayout(false);
			this.panel_Ticket_Type.ResumeLayout(false);
			this.panel_Ticket_Type.PerformLayout();
			this.tabPage_NonFiscal.ResumeLayout(false);
			this.groupBox_TextLines.ResumeLayout(false);
			this.panel_TextFormat.ResumeLayout(false);
			this.panel_TextFormat.PerformLayout();
			((System.ComponentModel.ISupportInitialize)this.numeric_txt_PictureNo).EndInit();
			((System.ComponentModel.ISupportInitialize)this.numeric_txt_BarcodeHeight).EndInit();
			((System.ComponentModel.ISupportInitialize)this.numeric_txt_BarcodeWidth).EndInit();
			((System.ComponentModel.ISupportInitialize)this.numeric_txt_QR_DotSize).EndInit();
			((System.ComponentModel.ISupportInitialize)this.numeric_txt_QR_Level).EndInit();
			this.panel_txt_Pic_Align.ResumeLayout(false);
			this.panel_txt_Pic_Align.PerformLayout();
			this.panel_txt_QR_Align.ResumeLayout(false);
			this.panel_txt_QR_Align.PerformLayout();
			this.panel_TextEntries.ResumeLayout(false);
			this.panel_TextLines.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.dataGrid_TextLines).EndInit();
			this.panel_TextLinesCheckBoxes.ResumeLayout(false);
			this.tabPage_OFD.ResumeLayout(false);
			this.groupBox_OFD_Ticket.ResumeLayout(false);
			this.panel_OFD_Ticket.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_OFD_Ticket).EndInit();
			this.groupBox_SendMSG.ResumeLayout(false);
			this.panel_OFD_Send.ResumeLayout(false);
			this.panel_OFD_Send.PerformLayout();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_Port_OFD).EndInit();
			this.groupBox_ReadMSG.ResumeLayout(false);
			this.panel_ReadMSG.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_LengthBlock).EndInit();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_OffsetBlock).EndInit();
			this.tabPage_OISM.ResumeLayout(false);
			this.groupBox_OKP.ResumeLayout(false);
			this.panel_OKP_Update.ResumeLayout(false);
			this.panel_OKP_Update.PerformLayout();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_PortOKP).EndInit();
			this.groupBox_SendNotice.ResumeLayout(false);
			this.panel_OISM_Send.ResumeLayout(false);
			this.panel_OISM_Send.PerformLayout();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_PortOISM).EndInit();
			this.groupBox_ReadNotice.ResumeLayout(false);
			this.panel_ReadNotice.ResumeLayout(false);
			this.panel_ReadNotice.PerformLayout();
			this.panel_NoticeOffline.ResumeLayout(false);
			this.panel_NoticeOffline.PerformLayout();
			((System.ComponentModel.ISupportInitialize)this.numeric_ReadNoticeLength).EndInit();
			((System.ComponentModel.ISupportInitialize)this.numeric_ReadNoticeOffset).EndInit();
			this.tabPage_Electronic.ResumeLayout(false);
			this.panel_Unused.ResumeLayout(false);
			this.groupBox_EForm.ResumeLayout(false);
			this.panel_CheckEF.ResumeLayout(false);
			this.panel_CheckEF.PerformLayout();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_EFCheckNumber).EndInit();
			this.panel_FD0.ResumeLayout(false);
			this.groupBox_FD.ResumeLayout(false);
			this.panel_FD.ResumeLayout(false);
			this.panel_FD_Type.ResumeLayout(false);
			this.panel_FD_Type.PerformLayout();
			this.panel_FD2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_FD).EndInit();
			this.panel_FD1.ResumeLayout(false);
			this.panel_FD1.PerformLayout();
			this.panel_XML0.ResumeLayout(false);
			this.groupBox_XML_Document.ResumeLayout(false);
			this.panel_XML_Document.ResumeLayout(false);
			this.panel_XML4.ResumeLayout(false);
			this.panel_XML4.PerformLayout();
			this.panel_XML2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_XMLDocNum).EndInit();
			this.panel_XML1.ResumeLayout(false);
			this.panel_XML1.PerformLayout();
			this.panel_Bottom.ResumeLayout(false);
			this.panel_Bottom.PerformLayout();
			this.contextMenuStrip_Log.ResumeLayout(false);
			base.ResumeLayout(false);
		}
	}
}
