using System;
using System.Drawing;
using System.IO.Ports;
using System.Windows.Forms;

namespace MitsuCube
{
	public class ComButtons
	{
		public RadioButton[] Buttons;

		public RadioButton Selected;

		public ComButtons()
		{
			Buttons = null;
			Selected = null;
		}

		public int SetButtons()
		{
			Dispose();
			string[] portNames = SerialPort.GetPortNames();
			if (portNames.Length == 0)
			{
				return 0;
			}
			Buttons = new RadioButton[portNames.Length];
			int num = 3;
			int num2 = 0;
			string[] array = portNames;
			foreach (string text in array)
			{
				Buttons[num2] = new RadioButton
				{
					Visible = true,
					Enabled = false,
					Checked = false,
					Dock = DockStyle.Left,
					ForeColor = SystemColors.ControlText,
					UseVisualStyleBackColor = true,
					Font = new Font("Microsoft Sans Serif", 8f),
					Text = text,
					Name = text,
					Size = new Size(32 + text.Length * 6, 21)
				};
				num += Buttons[num2].Width;
				num2++;
			}
			Selected = null;
			return num;
		}

		public void Dispose()
		{
			if (Buttons != null)
			{
				RadioButton[] buttons = Buttons;
				foreach (RadioButton radioButton in buttons)
				{
					radioButton.Dispose();
				}
				Array.Resize(ref Buttons, 0);
				Buttons = null;
			}
		}
	}
}
