using System.Text.RegularExpressions;

namespace MitsuCube
{
	public class ItemCode
	{
		private static int TestApplyingCodes(string km)
		{
			int num = km.IndexOf("\u001d91");
			int num2 = km.IndexOf("\u001d92");
			if (num < 0 && num2 < 0)
			{
				return -1;
			}
			if (num2 - num != 7)
			{
				return -1;
			}
			return num2;
		}

		private static bool IsShortMI(string km)
		{
			return km.Length == 20 && Regex.IsMatch(km, "^[A-Z0-9]{2}-[A-Z0-9]{6}-[A-Z0-9]{10}$");
		}

		private static bool IsShortKM(string km)
		{
			return km.Length == 29 && Regex.IsMatch(km, "^[a-zA-Z0-9!\"%-/:-?_]{29}$");
		}

		private static bool Is88KM(string km)
		{
			int num = TestApplyingCodes(km);
			return num >= 26 && (num == km.Length - 47 || num == km.Length - 91) && km.Substring(0, 2) == "01" && km.Substring(16, 2) == "21";
		}

		private static bool Is4KM(string km)
		{
			int num = km.IndexOf("\u001d93");
			if (num < 0 || num != km.Length - 7)
			{
				return false;
			}
			return km.Substring(0, 2) == "01" && km.Substring(16, 2) == "21";
		}

		public static int GetTypeOfKM(string km)
		{
			if (string.IsNullOrEmpty(km))
			{
				return 0;
			}
			if (Regex.IsMatch(km, "^[0-9]{8}$"))
			{
				return 1301;
			}
			if (Regex.IsMatch(km, "^[0-9]{13}$"))
			{
				return 1302;
			}
			if (Regex.IsMatch(km, "^[0][0-9]{13}$"))
			{
				return 1303;
			}
			if (IsShortMI(km))
			{
				return 1307;
			}
			if (IsShortKM(km))
			{
				return 1306;
			}
			if (Is88KM(km))
			{
				return 1305;
			}
			if (Is4KM(km))
			{
				return 1305;
			}
			if (Regex.IsMatch(km, "^[A-Z0-9]{68}$"))
			{
				return 1308;
			}
			if (Regex.IsMatch(km, "^[A-Z0-9]{150}$"))
			{
				return 1309;
			}
			return 1300;
		}

		public static string GetKMID(string km)
		{
			int num = km.IndexOf('\u001d');
			if (num > 38)
			{
				num = 38;
			}
			return GetTypeOfKM(km) switch
			{
				1300 => (km.Length < 32) ? km : km.Substring(0, 32), 
				1301 => km, 
				1302 => km, 
				1303 => km, 
				1304 => km, 
				1305 => km.Substring(0, num), 
				1306 => "01" + km.Substring(0, 14) + "21" + km.Substring(14), 
				1307 => km, 
				1308 => km.Substring(8, 23), 
				1309 => km.Substring(0, 14), 
				_ => km, 
			};
		}

		public static int CreateKMType(string km)
		{
			if (IsShortMI(km))
			{
				return 1307;
			}
			if (IsShortKM(km))
			{
				return 1306;
			}
			if (Is88KM(km))
			{
				return 1305;
			}
			if (Is4KM(km))
			{
				return 1305;
			}
			return 1300;
		}
	}
}
