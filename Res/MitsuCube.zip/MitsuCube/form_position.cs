namespace MitsuCube
{
	public class form_position
	{
		private int left = 0;

		private int top = 0;

		private int width = 0;

		private int height = 0;

		public int Left
		{
			get
			{
				return left;
			}
			set
			{
				if (value < 0)
				{
					left = 0;
				}
				else
				{
					left = value;
				}
			}
		}

		public int Top
		{
			get
			{
				return top;
			}
			set
			{
				if (value < 0)
				{
					top = 0;
				}
				else
				{
					top = value;
				}
			}
		}

		public int Width
		{
			get
			{
				return width;
			}
			set
			{
				if (value < 0)
				{
					width = 0;
				}
				else
				{
					width = value;
				}
			}
		}

		public int Height
		{
			get
			{
				return height;
			}
			set
			{
				if (value < 0)
				{
					height = 0;
				}
				else
				{
					height = value;
				}
			}
		}
	}
}
