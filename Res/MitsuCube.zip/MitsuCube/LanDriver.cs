using System;
using System.Net;
using System.Net.Sockets;

namespace MitsuCube
{
	public class LanDriver : IDisposable
	{
		private readonly IPAddress _address;

		private readonly int _port;

		private TcpClient _client;

		private NetworkStream _stream;

		public bool Available => _stream.DataAvailable;

		public LanDriver(IPAddress address, int port = 8200)
		{
			_address = address;
			_port = port;
		}

		public void WriteData(byte[] data)
		{
			_client = new TcpClient(_address.ToString(), _port);
			_stream = _client.GetStream();
			_stream.Write(data, 0, data.Length);
		}

		public byte[] ReadData(int length, out int read_length)
		{
			read_length = 0;
			if (_client == null || _stream == null)
			{
				return null;
			}
			byte[] array = new byte[length];
			if ((read_length = _stream.Read(array, 0, length)) == 0)
			{
				return null;
			}
			return array;
		}

		public void Close()
		{
			if (_stream != null)
			{
				_stream.Close();
				_stream.Dispose();
				_stream = null;
			}
			if (_client != null)
			{
				_client.Close();
				_client = null;
			}
			GC.Collect();
		}

		public void Dispose()
		{
			Close();
		}
	}
}
