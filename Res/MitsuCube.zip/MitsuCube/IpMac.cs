using System.Net;

namespace MitsuCube
{
	public struct IpMac
	{
		public IPAddress ip;

		public string mac;

		public int type;

		public IpMac(IPAddress _ip, string _mac, int _type)
		{
			ip = _ip;
			mac = _mac;
			type = _type;
		}
	}
}
