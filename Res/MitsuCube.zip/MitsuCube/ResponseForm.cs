using System;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;
using System.Xml.Linq;

namespace MitsuCube
{
	public class ResponseForm : Form
	{
		private CultureInfo ci = CultureInfo.InvariantCulture;

		private readonly string[] TestFN_message = new string[5] { "   КМ проверен в ФН.", "   КМ не подлежит проверке в ФН.", "   ФН не содержит ключ проверки кода проверки этого КМ.", "   Проверка невозможна, отсутствуют идентификаторы применения GS1 91/92, или их формат неверный.", "   Внутренняя ошибка в ФН при проверке этого КМ." };

		private readonly string[] TestFN2004_message = new string[2] { " Результат отрицательный.", " Результат положительный." };

		private readonly string[] TestFN2006_message = new string[2] { "2006: Проверка всех КМ в уведомлении дала положительный результат", "2006: При проверке хотя бы одного из КМ в уведомлении получен отрицательный результат" };

		private readonly string TestReq_message = "   Запрос от ФН на проверку в ОИСМ получен.";

		private readonly string Rezult = "RES";

		private IContainer components = null;

		private Button buttonOK;

		private Panel panel1;

		private RichTextBox richTextBox_Response;

		private Panel panel3;

		private Panel panel2;

		private Button buttonCancel;

		public ResponseForm()
		{
			InitializeComponent();
		}

		public void AddLine(string text, int highlight = 0)
		{
			if (string.IsNullOrEmpty(text))
			{
				return;
			}
			int length = richTextBox_Response.Text.Length;
			RichTextBox richTextBox = richTextBox_Response;
			richTextBox.Text = richTextBox.Text + text + "\n";
			if (highlight != 0)
			{
				richTextBox_Response.SelectionStart = length;
				richTextBox_Response.SelectionLength = text.Length;
				if (((uint)highlight & (true ? 1u : 0u)) != 0)
				{
					richTextBox_Response.SelectionColor = Color.OrangeRed;
				}
				if (((uint)highlight & 2u) != 0)
				{
					richTextBox_Response.SelectionFont = new Font(richTextBox_Response.Font, FontStyle.Bold);
				}
				if (((uint)highlight & 4u) != 0)
				{
					richTextBox_Response.SelectionAlignment = HorizontalAlignment.Center;
				}
				richTextBox_Response.SelectionLength = 0;
			}
		}

		public void ClearText()
		{
			richTextBox_Response.Text = "";
		}

		private void buttonOK_Click(object sender, EventArgs e)
		{
			Close();
			base.DialogResult = DialogResult.OK;
		}

		private string T(int num)
		{
			return $"T{num}";
		}

		public bool res_2004(XDocument x, string title)
		{
			XAttribute xAttribute;
			if ((xAttribute = x.Root.Attribute(Rezult)) == null)
			{
				return false;
			}
			AddLine(title, 2);
			int num = int.Parse(xAttribute.Value);
			string text = TestFN_message[num];
			if (num == 0 && (xAttribute = x.Root.Attribute(T(2004))) != null && byte.TryParse(xAttribute.Value.Substring(2, 2), NumberStyles.HexNumber, ci, out var result))
			{
				text += TestFN2004_message[result >> 1];
			}
			AddLine(text);
			return true;
		}

		public void res_2004R(XDocument x, string title)
		{
			if (res_2004(x, title) && !string.IsNullOrEmpty(x.Root.Value))
			{
				AddLine(TestReq_message);
			}
		}

		public bool res_2005(XDocument x, string title)
		{
			XAttribute xAttribute;
			if ((xAttribute = x.Root.Attribute(T(2106))) != null)
			{
				AddLine(title + " Результаты:", 2);
				if (string.IsNullOrEmpty(xAttribute.Value) || xAttribute.Value.Length != 4)
				{
					return false;
				}
				if (!byte.TryParse(xAttribute.Value.Substring(2, 2), NumberStyles.HexNumber, ci, out var result))
				{
					return false;
				}
				AddLine($"Тег 2106 = 0x{result:X2}:", 2);
				switch (result & 3)
				{
				case 3:
					AddLine("\tКМ проверен. Результат положительный.");
					break;
				case 1:
					AddLine("\tКМ проверен. Результат отрицательный.");
					break;
				case 2:
					AddLine("\tКМ не проверен ФН и/или ОИСМ. Результат положительный?");
					break;
				case 0:
					AddLine("\tКМ не проверен ФН и/или ОИСМ. Результат отсутствует.");
					break;
				}
				switch (result & 0xC)
				{
				case 12:
					AddLine("\tСтатус товара в ОИСМ проверен. Планируемый статус корректен.");
					break;
				case 4:
					AddLine("\tСтатус товара в ОИСМ проверен. Планируемый статус некорректен.");
					break;
				case 8:
					AddLine("\tСведения о статусе товара от ОИСМ не получены.");
					break;
				case 0:
					AddLine("\tСведения о статусе товара от ОИСМ не получены.");
					break;
				}
				AddLine("\t" + (((result & 0x10u) != 0) ? "КМ проверен ККТ в автономном режиме" : "КМ и статус товара проверены ККТ в режиме передачи данных."));
			}
			if ((xAttribute = x.Root.Attribute(T(2105))) != null)
			{
				if (string.IsNullOrEmpty(xAttribute.Value) || xAttribute.Value.Length != 1)
				{
					return false;
				}
				string text = "Тег 2105 = " + xAttribute.Value + ": ";
				switch (xAttribute.Value[0])
				{
				case '0':
					text += "Форматы кода маркировки и запроса в целом корректны.";
					break;
				case '1':
					text += "Формат запроса в целом некорректен.";
					break;
				case '2':
					text += "Формат кода маркировки в запросе не распознан.";
					break;
				}
				AddLine(text);
			}
			if ((xAttribute = x.Root.Attribute(T(2005))) != null)
			{
				if (string.IsNullOrEmpty(xAttribute.Value) || xAttribute.Value.Length != 4)
				{
					return false;
				}
				if (!byte.TryParse(xAttribute.Value.Substring(2, 2), NumberStyles.HexNumber, ci, out var result2))
				{
					return false;
				}
				AddLine($"Тег 2005 = 0x{result2:X2}:", 2);
				string text2 = (((result2 & 2u) != 0) ? "\tРезультат проверки КМ положительный. " : "\tРезультат проверки КМ отрицательный. ");
				text2 += (((result2 & 8u) != 0) ? "Статус товара корректен. \nТег 2109 (ответ ОИСМ) равен 1." : "Статус товара некорректен. \nТег 2109 (ответ ОИСМ) равен 2 или 3.");
				AddLine(text2);
			}
			if ((xAttribute = x.Root.Attribute(T(2109))) != null)
			{
				if (string.IsNullOrEmpty(xAttribute.Value) || xAttribute.Value.Length != 1)
				{
					return false;
				}
				string text3 = "Тег 2109 = " + xAttribute.Value + ": ";
				switch (xAttribute.Value[0])
				{
				case '1':
					text3 += "Планируемый статус товара корректен";
					break;
				case '2':
					text3 += "Планируемый статус товара некорректен";
					break;
				case '3':
					text3 += "Оборот товара приостановлен";
					break;
				}
				AddLine(text3);
			}
			return true;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.buttonOK = new System.Windows.Forms.Button();
			this.panel1 = new System.Windows.Forms.Panel();
			this.richTextBox_Response = new System.Windows.Forms.RichTextBox();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.panel2 = new System.Windows.Forms.Panel();
			this.panel3 = new System.Windows.Forms.Panel();
			this.panel1.SuspendLayout();
			this.panel2.SuspendLayout();
			this.panel3.SuspendLayout();
			base.SuspendLayout();
			this.buttonOK.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonOK.Dock = System.Windows.Forms.DockStyle.Fill;
			this.buttonOK.Location = new System.Drawing.Point(5, 5);
			this.buttonOK.Name = "buttonOK";
			this.buttonOK.Size = new System.Drawing.Size(100, 30);
			this.buttonOK.TabIndex = 1;
			this.buttonOK.Text = "OK";
			this.buttonOK.UseVisualStyleBackColor = true;
			this.buttonOK.Click += new System.EventHandler(buttonOK_Click);
			this.panel1.Controls.Add(this.panel3);
			this.panel1.Controls.Add(this.panel2);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel1.Location = new System.Drawing.Point(0, 311);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(389, 40);
			this.panel1.TabIndex = 2;
			this.richTextBox_Response.BackColor = System.Drawing.Color.LightCyan;
			this.richTextBox_Response.Dock = System.Windows.Forms.DockStyle.Fill;
			this.richTextBox_Response.Font = new System.Drawing.Font("Courier New", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 204);
			this.richTextBox_Response.ForeColor = System.Drawing.Color.Blue;
			this.richTextBox_Response.Location = new System.Drawing.Point(0, 0);
			this.richTextBox_Response.Name = "richTextBox_Response";
			this.richTextBox_Response.ReadOnly = true;
			this.richTextBox_Response.Size = new System.Drawing.Size(389, 311);
			this.richTextBox_Response.TabIndex = 2;
			this.richTextBox_Response.Text = "";
			this.richTextBox_Response.WordWrap = false;
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.Dock = System.Windows.Forms.DockStyle.Fill;
			this.buttonCancel.Location = new System.Drawing.Point(5, 5);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.Size = new System.Drawing.Size(100, 30);
			this.buttonCancel.TabIndex = 2;
			this.buttonCancel.Text = "Отмена";
			this.buttonCancel.UseVisualStyleBackColor = true;
			this.panel2.Controls.Add(this.buttonCancel);
			this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel2.Location = new System.Drawing.Point(279, 0);
			this.panel2.Name = "panel2";
			this.panel2.Padding = new System.Windows.Forms.Padding(5);
			this.panel2.Size = new System.Drawing.Size(110, 40);
			this.panel2.TabIndex = 0;
			this.panel3.Controls.Add(this.buttonOK);
			this.panel3.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel3.Location = new System.Drawing.Point(169, 0);
			this.panel3.Name = "panel3";
			this.panel3.Padding = new System.Windows.Forms.Padding(5);
			this.panel3.Size = new System.Drawing.Size(110, 40);
			this.panel3.TabIndex = 1;
			base.AcceptButton = this.buttonOK;
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.CancelButton = this.buttonCancel;
			base.ClientSize = new System.Drawing.Size(389, 351);
			base.Controls.Add(this.richTextBox_Response);
			base.Controls.Add(this.panel1);
			base.Name = "ResponseForm";
			base.ShowIcon = false;
			base.ShowInTaskbar = false;
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "XML: состав тегов документа из ФН";
			this.panel1.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.panel3.ResumeLayout(false);
			base.ResumeLayout(false);
		}
	}
}
