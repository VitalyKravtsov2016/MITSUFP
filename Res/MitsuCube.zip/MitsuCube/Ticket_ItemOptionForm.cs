using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace MitsuCube
{
	public class Ticket_ItemOptionForm : Form
	{
		private IContainer components = null;

		private Button button_ItemOptionsCancel;

		private Button button_ItemOptionsOK;

		private Panel panel1;

		public DataGridView dataGrid_ItemOptions;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_TextLines;

		private CheckedListBox checkedListBox_ItemOptions;

		private ComboBox comboBox_AgentSign;

		public string Value
		{
			get
			{
				string text = "";
				string text2 = "";
				string text3 = "";
				foreach (DataGridViewRow item in (IEnumerable)dataGrid_ItemOptions.Rows)
				{
					text = ((!checkedListBox_ItemOptions.GetItemChecked(item.Index + 1)) ? "" : TagValue(int.Parse(item.HeaderCell.Value.ToString()), item.Cells[0].Value.ToString()));
					if (item.Index < 7)
					{
						text2 += text;
					}
					else if (item.Index < 9)
					{
						text3 += text;
					}
				}
				text += TagValue(1222, string.IsNullOrEmpty(comboBox_AgentSign.Text) ? "" : comboBox_AgentSign.SelectedIndex.ToString());
				text += TagValue(1223, text2);
				return text + TagValue(1224, text3);
			}
		}

		public Ticket_ItemOptionForm()
		{
			InitializeComponent();
			dataGrid_ItemOptions.Rows.Add(10);
			dataGrid_ItemOptions.Rows[0].HeaderCell.Value = "1044";
			dataGrid_ItemOptions.Rows[0].Cells[0].Value = "Оплата связи";
			dataGrid_ItemOptions.Rows[1].HeaderCell.Value = "1073";
			dataGrid_ItemOptions.Rows[1].Cells[0].Value = "+78008005223;+78008005224";
			dataGrid_ItemOptions.Rows[2].HeaderCell.Value = "1074";
			dataGrid_ItemOptions.Rows[2].Cells[0].Value = "+72223334444";
			dataGrid_ItemOptions.Rows[3].HeaderCell.Value = "1075";
			dataGrid_ItemOptions.Rows[3].Cells[0].Value = "+78008004545;+78008004646";
			dataGrid_ItemOptions.Rows[4].HeaderCell.Value = "1026";
			dataGrid_ItemOptions.Rows[4].Cells[0].Value = "ООО \"Перевод\"";
			dataGrid_ItemOptions.Rows[5].HeaderCell.Value = "1005";
			dataGrid_ItemOptions.Rows[5].Cells[0].Value = "ул.Пушкина д.123";
			dataGrid_ItemOptions.Rows[6].HeaderCell.Value = "1016";
			dataGrid_ItemOptions.Rows[6].Cells[0].Value = "7627019317";
			dataGrid_ItemOptions.Rows[7].HeaderCell.Value = "1225";
			dataGrid_ItemOptions.Rows[7].Cells[0].Value = "ООО \"Поставщик\"";
			dataGrid_ItemOptions.Rows[8].HeaderCell.Value = "1171";
			dataGrid_ItemOptions.Rows[8].Cells[0].Value = "+75554441212;+75554442323";
			dataGrid_ItemOptions.Rows[9].HeaderCell.Value = "1226";
			dataGrid_ItemOptions.Rows[9].Cells[0].Value = "3729025520";
		}

		private string TagValue(int num, string value)
		{
			return string.IsNullOrEmpty(value) ? "" : $"<T{num}>{value}</T{num}>";
		}

		private void comboBox_AgentSign_SelectedIndexChanged(object sender, EventArgs e)
		{
			checkedListBox_ItemOptions.SetItemChecked(0, value: true);
		}

		private void dataGrid_ItemOptions_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
		{
			checkedListBox_ItemOptions.SetItemChecked(e.RowIndex + 1, value: true);
			dataGrid_ItemOptions.Rows[e.RowIndex].Cells[0].Style.ForeColor = SystemColors.ControlText;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle = new System.Windows.Forms.DataGridViewCellStyle();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MitsuCube.Ticket_ItemOptionForm));
			this.button_ItemOptionsCancel = new System.Windows.Forms.Button();
			this.button_ItemOptionsOK = new System.Windows.Forms.Button();
			this.panel1 = new System.Windows.Forms.Panel();
			this.dataGrid_ItemOptions = new System.Windows.Forms.DataGridView();
			this.dataGridViewTextBoxColumn_TextLines = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.comboBox_AgentSign = new System.Windows.Forms.ComboBox();
			this.checkedListBox_ItemOptions = new System.Windows.Forms.CheckedListBox();
			this.panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.dataGrid_ItemOptions).BeginInit();
			base.SuspendLayout();
			this.button_ItemOptionsCancel.BackColor = System.Drawing.Color.Transparent;
			this.button_ItemOptionsCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.button_ItemOptionsCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold);
			this.button_ItemOptionsCancel.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_ItemOptionsCancel.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_ItemOptionsCancel.Location = new System.Drawing.Point(404, 193);
			this.button_ItemOptionsCancel.Name = "button_ItemOptionsCancel";
			this.button_ItemOptionsCancel.Size = new System.Drawing.Size(128, 37);
			this.button_ItemOptionsCancel.TabIndex = 22;
			this.button_ItemOptionsCancel.Text = "Отмена";
			this.button_ItemOptionsCancel.UseVisualStyleBackColor = false;
			this.button_ItemOptionsOK.BackColor = System.Drawing.Color.Transparent;
			this.button_ItemOptionsOK.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.button_ItemOptionsOK.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold);
			this.button_ItemOptionsOK.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_ItemOptionsOK.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_ItemOptionsOK.Location = new System.Drawing.Point(270, 193);
			this.button_ItemOptionsOK.Name = "button_ItemOptionsOK";
			this.button_ItemOptionsOK.Size = new System.Drawing.Size(128, 37);
			this.button_ItemOptionsOK.TabIndex = 23;
			this.button_ItemOptionsOK.Text = "OK";
			this.button_ItemOptionsOK.UseVisualStyleBackColor = false;
			this.panel1.BackColor = System.Drawing.Color.LightCyan;
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel1.Controls.Add(this.dataGrid_ItemOptions);
			this.panel1.Controls.Add(this.comboBox_AgentSign);
			this.panel1.Controls.Add(this.checkedListBox_ItemOptions);
			this.panel1.Controls.Add(this.button_ItemOptionsCancel);
			this.panel1.Controls.Add(this.button_ItemOptionsOK);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(545, 243);
			this.panel1.TabIndex = 24;
			this.dataGrid_ItemOptions.AllowUserToAddRows = false;
			this.dataGrid_ItemOptions.AllowUserToDeleteRows = false;
			this.dataGrid_ItemOptions.AllowUserToResizeColumns = false;
			this.dataGrid_ItemOptions.AllowUserToResizeRows = false;
			dataGridViewCellStyle.BackColor = System.Drawing.Color.LightCyan;
			this.dataGrid_ItemOptions.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle;
			this.dataGrid_ItemOptions.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
			this.dataGrid_ItemOptions.ColumnHeadersHeight = 15;
			this.dataGrid_ItemOptions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this.dataGrid_ItemOptions.ColumnHeadersVisible = false;
			this.dataGrid_ItemOptions.Columns.AddRange(this.dataGridViewTextBoxColumn_TextLines);
			this.dataGrid_ItemOptions.GridColor = System.Drawing.SystemColors.WindowFrame;
			this.dataGrid_ItemOptions.Location = new System.Drawing.Point(232, 27);
			this.dataGrid_ItemOptions.MultiSelect = false;
			this.dataGrid_ItemOptions.Name = "dataGrid_ItemOptions";
			this.dataGrid_ItemOptions.RowHeadersVisible = false;
			this.dataGrid_ItemOptions.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
			this.dataGrid_ItemOptions.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 204);
			this.dataGrid_ItemOptions.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.ControlDark;
			this.dataGrid_ItemOptions.RowTemplate.Height = 15;
			this.dataGrid_ItemOptions.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.dataGrid_ItemOptions.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
			this.dataGrid_ItemOptions.ShowCellToolTips = false;
			this.dataGrid_ItemOptions.ShowEditingIcon = false;
			this.dataGrid_ItemOptions.Size = new System.Drawing.Size(300, 154);
			this.dataGrid_ItemOptions.TabIndex = 8;
			this.dataGrid_ItemOptions.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(dataGrid_ItemOptions_CellContentClick_1);
			this.dataGridViewTextBoxColumn_TextLines.HeaderText = "Column_TextLines";
			this.dataGridViewTextBoxColumn_TextLines.MaxInputLength = 2000;
			this.dataGridViewTextBoxColumn_TextLines.Name = "dataGridViewTextBoxColumn_TextLines";
			this.dataGridViewTextBoxColumn_TextLines.Width = 290;
			this.comboBox_AgentSign.FormattingEnabled = true;
			this.comboBox_AgentSign.Items.AddRange(new object[7] { "Банковский платежный агент", "Банковский платежный субагент", "Платежный агент", "Платежный субагент", "Поверенный", "Комиссонер", "Агент" });
			this.comboBox_AgentSign.Location = new System.Drawing.Point(232, 9);
			this.comboBox_AgentSign.Name = "comboBox_AgentSign";
			this.comboBox_AgentSign.Size = new System.Drawing.Size(300, 21);
			this.comboBox_AgentSign.TabIndex = 24;
			this.comboBox_AgentSign.SelectedIndexChanged += new System.EventHandler(comboBox_AgentSign_SelectedIndexChanged);
			this.checkedListBox_ItemOptions.BackColor = System.Drawing.Color.LightCyan;
			this.checkedListBox_ItemOptions.CheckOnClick = true;
			this.checkedListBox_ItemOptions.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkedListBox_ItemOptions.Items.AddRange(new object[11]
			{
				"Признак агента по предмету расчета", "Операция платежного агента ", "Тел. платежного агента", "Тел. оператора по приему платежей", "Тел. оператора перевода    ", "Наименование оператора перевода ", "Адрес оператора перевода ", "ИНН оператора перевода ", "Наименование поставщика", "Телефон поставщика",
				"ИНН поставщика"
			});
			this.checkedListBox_ItemOptions.Location = new System.Drawing.Point(10, 10);
			this.checkedListBox_ItemOptions.Name = "checkedListBox_ItemOptions";
			this.checkedListBox_ItemOptions.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.checkedListBox_ItemOptions.Size = new System.Drawing.Size(220, 169);
			this.checkedListBox_ItemOptions.TabIndex = 9;
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
			base.ClientSize = new System.Drawing.Size(545, 243);
			base.Controls.Add(this.panel1);
			base.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "Ticket_ItemOptionForm";
			base.ShowIcon = false;
			base.ShowInTaskbar = false;
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Агент и поставщик";
			this.panel1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.dataGrid_ItemOptions).EndInit();
			base.ResumeLayout(false);
		}
	}
}
