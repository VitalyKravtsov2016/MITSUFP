using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace MitsuCube
{
	public class ShiftOptionForm : Form
	{
		private string[] data;

		private IContainer components = null;

		private Label label_ShiftData;

		private Button button_ShiftDataOK;

		private Button button_ShiftDataCancel;

		public DataGridView dataGrid_ShiftOptions;

		private DataGridViewTextBoxColumn Column_ShiftOptions;

		private Panel panel_ShiftOption2;

		public string Options_ShiftOpen => data[0] + data[1] + data[2] + data[3];

		public string Options_ShiftClose => data[0] + data[1] + data[4] + data[5];

		public string Options_Report => data[0] + data[1] + data[6] + data[7];

		public string Options_CloseFN => data[0] + data[1] + data[8] + data[9];

		private void set_row(int i, string header, string val)
		{
			DataGridViewRow dataGridViewRow = dataGrid_ShiftOptions.Rows[i];
			dataGridViewRow.HeaderCell.Value = header;
			dataGridViewRow.Cells[0].Value = val;
			data[i] = "";
		}

		public ShiftOptionForm(char tag_prefix)
		{
			InitializeComponent();
			dataGrid_ShiftOptions.Columns[0].Width = 230;
			data = new string[10];
			dataGrid_ShiftOptions.Rows.Add(10);
			set_row(0, tag_prefix + "1009", "Новый адрес расчетов");
			set_row(1, tag_prefix + "1187", "Новое место расчетов");
			set_row(2, tag_prefix + "1276", "Дополнительный реквизит ООС");
			set_row(3, tag_prefix + "1277", "303132333435363738393A3B3C3D3E3F");
			set_row(4, tag_prefix + "1278", "Дополнительный реквизит ОЗС");
			set_row(5, tag_prefix + "1279", "404142434445464748494A4B4C4D4E4F");
			set_row(6, tag_prefix + "1280", "Дополнительный реквизит ОТР");
			set_row(7, tag_prefix + "1281", "11223344556677889900AABBCCDDEEFF");
			set_row(8, tag_prefix + "1282", "Дополнительный реквизит ОЗФН");
			set_row(9, tag_prefix + "1283", "11223344556677889900AABBCCDDEEFF");
		}

		private void button_ShiftOptionsOK_Click(object sender, EventArgs e)
		{
			for (int i = 3; i < dataGrid_ShiftOptions.RowCount; i += 2)
			{
				DataGridViewCell dataGridViewCell = dataGrid_ShiftOptions.Rows[i].Cells[0];
				if (dataGridViewCell.Value == null)
				{
					continue;
				}
				bool flag = dataGridViewCell.Value.ToString().Length % 2 == 0;
				int num = 0;
				while (flag && num < dataGridViewCell.Value.ToString().Length)
				{
					flag = byte.TryParse(dataGridViewCell.Value.ToString().Substring(num, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out var _);
					num += 2;
				}
				if (!flag)
				{
					string text = Lng.GetStr("Incorrect data, line ", "Некорректные данные в строке ") + i + ". ";
					text = text + Lng.GetStr("Valid symbols are", "Допустимы символы") + " 0..9,A..F\n";
					text += Lng.GetStr("Include anyway?", "Включить все равно?");
					if (DialogResult.OK != MessageBox.Show(text, Text, MessageBoxButtons.OKCancel, MessageBoxIcon.Question))
					{
						return;
					}
				}
			}
			foreach (DataGridViewRow item in (IEnumerable)dataGrid_ShiftOptions.Rows)
			{
				string text2 = item.HeaderCell.Value.ToString();
				string text3 = ((item.Cells[0].Value == null) ? "" : item.Cells[0].Value.ToString());
				data[item.Index] = (string.IsNullOrEmpty(text3) ? "" : ("<" + text2 + ">" + text3 + "</" + text2 + ">"));
			}
			Close();
		}

		private void button_ShiftOptionsCancel_Click(object sender, EventArgs e)
		{
			for (int i = 0; i < dataGrid_ShiftOptions.RowCount; i++)
			{
				data[i] = "";
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MitsuCube.ShiftOptionForm));
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle = new System.Windows.Forms.DataGridViewCellStyle();
			this.label_ShiftData = new System.Windows.Forms.Label();
			this.button_ShiftDataOK = new System.Windows.Forms.Button();
			this.button_ShiftDataCancel = new System.Windows.Forms.Button();
			this.dataGrid_ShiftOptions = new System.Windows.Forms.DataGridView();
			this.Column_ShiftOptions = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.panel_ShiftOption2 = new System.Windows.Forms.Panel();
			((System.ComponentModel.ISupportInitialize)this.dataGrid_ShiftOptions).BeginInit();
			this.panel_ShiftOption2.SuspendLayout();
			base.SuspendLayout();
			resources.ApplyResources(this.label_ShiftData, "label_ShiftData");
			this.label_ShiftData.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_ShiftData.Name = "label_ShiftData";
			resources.ApplyResources(this.button_ShiftDataOK, "button_ShiftDataOK");
			this.button_ShiftDataOK.Name = "button_ShiftDataOK";
			this.button_ShiftDataOK.UseVisualStyleBackColor = true;
			this.button_ShiftDataOK.Click += new System.EventHandler(button_ShiftOptionsOK_Click);
			resources.ApplyResources(this.button_ShiftDataCancel, "button_ShiftDataCancel");
			this.button_ShiftDataCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.button_ShiftDataCancel.Name = "button_ShiftDataCancel";
			this.button_ShiftDataCancel.UseVisualStyleBackColor = true;
			this.button_ShiftDataCancel.Click += new System.EventHandler(button_ShiftOptionsCancel_Click);
			resources.ApplyResources(this.dataGrid_ShiftOptions, "dataGrid_ShiftOptions");
			this.dataGrid_ShiftOptions.AllowUserToAddRows = false;
			this.dataGrid_ShiftOptions.AllowUserToDeleteRows = false;
			this.dataGrid_ShiftOptions.AllowUserToResizeColumns = false;
			this.dataGrid_ShiftOptions.AllowUserToResizeRows = false;
			dataGridViewCellStyle.BackColor = System.Drawing.Color.LightCyan;
			this.dataGrid_ShiftOptions.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle;
			this.dataGrid_ShiftOptions.BackgroundColor = System.Drawing.Color.LightCyan;
			this.dataGrid_ShiftOptions.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.dataGrid_ShiftOptions.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
			this.dataGrid_ShiftOptions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this.dataGrid_ShiftOptions.ColumnHeadersVisible = false;
			this.dataGrid_ShiftOptions.Columns.AddRange(this.Column_ShiftOptions);
			this.dataGrid_ShiftOptions.GridColor = System.Drawing.SystemColors.ActiveBorder;
			this.dataGrid_ShiftOptions.MultiSelect = false;
			this.dataGrid_ShiftOptions.Name = "dataGrid_ShiftOptions";
			this.dataGrid_ShiftOptions.RowHeadersVisible = false;
			this.dataGrid_ShiftOptions.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 204);
			this.dataGrid_ShiftOptions.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGrid_ShiftOptions.RowTemplate.DividerHeight = 1;
			this.dataGrid_ShiftOptions.RowTemplate.Height = 15;
			this.dataGrid_ShiftOptions.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
			this.dataGrid_ShiftOptions.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
			this.Column_ShiftOptions.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
			this.Column_ShiftOptions.DividerWidth = 1;
			resources.ApplyResources(this.Column_ShiftOptions, "Column_ShiftOptions");
			this.Column_ShiftOptions.MaxInputLength = 256;
			this.Column_ShiftOptions.Name = "Column_ShiftOptions";
			this.Column_ShiftOptions.Resizable = System.Windows.Forms.DataGridViewTriState.False;
			this.Column_ShiftOptions.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			resources.ApplyResources(this.panel_ShiftOption2, "panel_ShiftOption2");
			this.panel_ShiftOption2.Controls.Add(this.button_ShiftDataOK);
			this.panel_ShiftOption2.Controls.Add(this.button_ShiftDataCancel);
			this.panel_ShiftOption2.Name = "panel_ShiftOption2";
			base.AcceptButton = this.button_ShiftDataOK;
			resources.ApplyResources(this, "$this");
			base.CancelButton = this.button_ShiftDataCancel;
			base.Controls.Add(this.panel_ShiftOption2);
			base.Controls.Add(this.dataGrid_ShiftOptions);
			base.Controls.Add(this.label_ShiftData);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "ShiftOptionForm";
			base.ShowIcon = false;
			base.ShowInTaskbar = false;
			((System.ComponentModel.ISupportInitialize)this.dataGrid_ShiftOptions).EndInit();
			this.panel_ShiftOption2.ResumeLayout(false);
			base.ResumeLayout(false);
		}
	}
}
