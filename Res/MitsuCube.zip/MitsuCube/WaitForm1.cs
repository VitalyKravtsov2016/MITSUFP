using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace MitsuCube
{
	public class WaitForm1 : Form
	{
		public int Value;

		private IContainer components = null;

		private ProgressBar progressBar;

		public WaitForm1()
		{
			InitializeComponent();
			base.StartPosition = FormStartPosition.Manual;
		}

		public void Start(int max, int step = 500)
		{
			progressBar.Maximum = max;
			progressBar.Step = step;
			progressBar.Value = (Value = 0);
			progressBar.Visible = true;
			Show();
		}

		public void PerformStep()
		{
			progressBar.PerformStep();
			Value = progressBar.Value;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.progressBar = new System.Windows.Forms.ProgressBar();
			base.SuspendLayout();
			this.progressBar.Dock = System.Windows.Forms.DockStyle.Top;
			this.progressBar.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.progressBar.Location = new System.Drawing.Point(0, 0);
			this.progressBar.Name = "progressBar";
			this.progressBar.Size = new System.Drawing.Size(784, 15);
			this.progressBar.TabIndex = 5;
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			base.ClientSize = new System.Drawing.Size(784, 15);
			base.ControlBox = false;
			base.Controls.Add(this.progressBar);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Location = new System.Drawing.Point(0, 432);
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "WaitForm";
			base.ShowIcon = false;
			base.ShowInTaskbar = false;
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			base.TopMost = true;
			base.TransparencyKey = System.Drawing.SystemColors.Control;
			base.ResumeLayout(false);
		}
	}
}
