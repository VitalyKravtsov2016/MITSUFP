using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace MitsuCube
{
	public class Ticket_TextForm : Form
	{
		public string[] text_form = new string[4];

		public string[] text_line = new string[4];

		public string barcode_no = "";

		public string barcode_atr = "";

		public string barcode_val = "";

		public string qrcode_atr = "";

		public string qrcode_val = "";

		public string picture_no = "";

		public string picture_atr = "";

		public string line_atr = "";

		private IContainer components = null;

		private ComboBox comboBox_LineType;

		private ComboBox comboBox_BarcodeType;

		private NumericUpDown numericUpDown_BarcodeWidth;

		private NumericUpDown numericUpDown_BarcodeHeight;

		private NumericUpDown numericUpDown_PictureNo;

		private GroupBox groupBox_TextLines;

		private Panel panel_txt_Pic_Align;

		private RadioButton radio_txt_Pic_Right;

		private RadioButton radio_txt_Pic_Center;

		private RadioButton radio_txt_Pic_Left;

		private Panel panel_txt_QR_Align;

		private RadioButton radio_txt_QR_Right;

		private RadioButton radio_txt_QR_Center;

		private RadioButton radio_txt_QR_Left;

		private CheckBox checkBox_txt_QR;

		private CheckBox checkBox_txt_Line;

		private CheckBox checkBox_txt_Image;

		private CheckBox checkBox_txt_Barcode;

		private Button button_TextOK;

		private TextBox textBox_txt_QR;

		private TextBox textBox_txt_Barcode;

		private Panel panel_TextLines;

		public DataGridView dataGrid_TextLines;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_TextLines;

		private Panel panel_TextLinesCheckBoxes;

		private CheckedListBox checkedListBox_TextLines;

		private Label label_Format;

		private CheckBox checkBox_txt_QRText;

		private TextBox textBox_QRText;

		private GroupBox groupBox_QR;

		private Panel panel_QR;

		private GroupBox groupBox_Barcode;

		private Panel panel_Barcode;

		private GroupBox groupBox_Picture;

		private Panel panel_Picture;

		private Panel panel_Line;

		private Label label_LineType;

		private Button button_TextCancel;

		private NumericUpDown numericUpDown_QRcodeLevel;

		private NumericUpDown numericUpDown_QRcodeDotSize;

		private Label label_txt_QR_Align;

		private Label label_QRcodeLevel;

		private Label label4;

		private Label label1;

		private Label label3;

		private Label label8;

		private Label label7;

		private Label label6;

		private Label label9;

		private Label label10;

		private Label label_QRcodeDotSize;

		public Ticket_TextForm()
		{
			InitializeComponent();
			dataGrid_TextLines.Columns.Add(Lng.GetStr("Inverse", "Инверсия"), "0");
			dataGrid_TextLines.Columns.Add(Lng.GetStr("Width", "Ширина"), "0");
			dataGrid_TextLines.Columns.Add(Lng.GetStr("Height", "Высота"), "0");
			dataGrid_TextLines.Columns.Add(Lng.GetStr("Font", "Шрифт"), "0");
			dataGrid_TextLines.Columns.Add(Lng.GetStr("Underline", "Подчеркивание"), "0");
			dataGrid_TextLines.Columns.Add(Lng.GetStr("Align", "Выравнивание"), "0");
			dataGrid_TextLines.Rows.Add(0, 4, 4, 0, 2, 1, "ЗАКАЗ No 090");
			dataGrid_TextLines.Rows.Add(0, 0, 0, 0, 0, 1, "Дата и время приготовления продуктов: " + DateTime.Now.ToString("dd/MM/yyyy HH:mm"));
			dataGrid_TextLines.Rows.Add(0, 0, 0, 0, 0, 0, "01.04.23 15:12     ПАО СБЕРБАНК    ЧЕК 0358");
			dataGrid_TextLines.Rows.Add(0, 0, 0, 0, 0, 1, "************************************************");
			for (int i = 0; i < 6; i++)
			{
				dataGrid_TextLines.Columns[i].Width = 16;
				dataGrid_TextLines.Columns[i].CellTemplate.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
				dataGrid_TextLines.Columns[i].Resizable = DataGridViewTriState.False;
			}
			for (int j = 0; j < checkedListBox_TextLines.Items.Count; j++)
			{
				checkedListBox_TextLines.SetItemChecked(j, value: true);
			}
			label_Format.Location = new Point(35, 80);
			comboBox_LineType.SelectedIndex = 0;
			comboBox_BarcodeType.SelectedIndex = 2;
		}

		private void dataGridViewTextBoxColumn_TextLines_ShowTip(object sender, EventArgs e)
		{
			label_Format.Visible = true;
		}

		private void dataGridViewTextBoxColumn_TextLines_HideTip(object sender, EventArgs e)
		{
			label_Format.Visible = false;
		}

		private void SetTextLines()
		{
			for (int i = 0; i < dataGrid_TextLines.Rows.Count; i++)
			{
				string text = "";
				text_form[i] = (text_line[i] = "");
				if (checkedListBox_TextLines.GetItemChecked(i))
				{
					for (int j = 0; j < 6; j++)
					{
						text += dataGrid_TextLines.Rows[i].Cells[j].Value.ToString();
					}
					if (text.Length > 0)
					{
						text_form[i] = text;
					}
					text_line[i] = dataGrid_TextLines.Rows[i].Cells[6].Value.ToString();
				}
			}
			qrcode_atr = (qrcode_val = "");
			if (checkBox_txt_QR.Checked && textBox_txt_QR.Text.Length > 0)
			{
				string text2 = (radio_txt_QR_Right.Checked ? "2" : (radio_txt_QR_Center.Checked ? "1" : "0"));
				if (0m < numericUpDown_QRcodeLevel.Value)
				{
					qrcode_atr += $" X='{numericUpDown_QRcodeLevel.Value - 1m}'";
				}
				qrcode_atr += $" Y='{numericUpDown_QRcodeDotSize.Value}'";
				qrcode_atr = qrcode_atr + " ALIGN='" + text2 + "'";
				qrcode_val = "<VAL>" + textBox_txt_QR.Text + "</VAL>";
				if (textBox_QRText.Text.Length > 0)
				{
					qrcode_val = qrcode_val + "<TEXT>" + textBox_QRText.Text + "</TEXT>";
				}
			}
			barcode_no = (barcode_atr = (barcode_val = ""));
			if (checkBox_txt_Barcode.Checked && textBox_txt_Barcode.Text.Length > 0)
			{
				barcode_no = comboBox_BarcodeType.SelectedIndex.ToString();
				barcode_atr = $" X='{numericUpDown_BarcodeWidth.Value}'" + $" Y='{numericUpDown_BarcodeHeight.Value}'";
				barcode_val = "<VAL>" + textBox_txt_Barcode.Text + "</VAL>";
			}
			picture_no = (picture_atr = "");
			if (checkBox_txt_Image.Checked && numericUpDown_PictureNo.Value > 0m)
			{
				string text3 = (radio_txt_Pic_Right.Checked ? "2" : (radio_txt_Pic_Center.Checked ? "1" : "0"));
				picture_no = numericUpDown_PictureNo.Value.ToString();
				picture_atr = " POS='" + text3 + "'";
			}
			line_atr = "";
			if (checkBox_txt_Line.Checked)
			{
				line_atr = comboBox_LineType.SelectedIndex.ToString();
			}
		}

		private void button_TextOK_Click(object sender, EventArgs e)
		{
			SetTextLines();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle = new System.Windows.Forms.DataGridViewCellStyle();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MitsuCube.Ticket_TextForm));
			this.comboBox_LineType = new System.Windows.Forms.ComboBox();
			this.comboBox_BarcodeType = new System.Windows.Forms.ComboBox();
			this.numericUpDown_BarcodeWidth = new System.Windows.Forms.NumericUpDown();
			this.numericUpDown_BarcodeHeight = new System.Windows.Forms.NumericUpDown();
			this.numericUpDown_PictureNo = new System.Windows.Forms.NumericUpDown();
			this.groupBox_TextLines = new System.Windows.Forms.GroupBox();
			this.panel_TextLinesCheckBoxes = new System.Windows.Forms.Panel();
			this.panel_TextLines = new System.Windows.Forms.Panel();
			this.dataGrid_TextLines = new System.Windows.Forms.DataGridView();
			this.dataGridViewTextBoxColumn_TextLines = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.checkedListBox_TextLines = new System.Windows.Forms.CheckedListBox();
			this.panel_txt_Pic_Align = new System.Windows.Forms.Panel();
			this.radio_txt_Pic_Right = new System.Windows.Forms.RadioButton();
			this.radio_txt_Pic_Center = new System.Windows.Forms.RadioButton();
			this.radio_txt_Pic_Left = new System.Windows.Forms.RadioButton();
			this.panel_txt_QR_Align = new System.Windows.Forms.Panel();
			this.radio_txt_QR_Right = new System.Windows.Forms.RadioButton();
			this.radio_txt_QR_Center = new System.Windows.Forms.RadioButton();
			this.radio_txt_QR_Left = new System.Windows.Forms.RadioButton();
			this.checkBox_txt_QR = new System.Windows.Forms.CheckBox();
			this.checkBox_txt_Line = new System.Windows.Forms.CheckBox();
			this.checkBox_txt_Image = new System.Windows.Forms.CheckBox();
			this.checkBox_txt_Barcode = new System.Windows.Forms.CheckBox();
			this.button_TextOK = new System.Windows.Forms.Button();
			this.textBox_txt_QR = new System.Windows.Forms.TextBox();
			this.textBox_txt_Barcode = new System.Windows.Forms.TextBox();
			this.checkBox_txt_QRText = new System.Windows.Forms.CheckBox();
			this.textBox_QRText = new System.Windows.Forms.TextBox();
			this.label_Format = new System.Windows.Forms.Label();
			this.groupBox_QR = new System.Windows.Forms.GroupBox();
			this.panel_QR = new System.Windows.Forms.Panel();
			this.label_txt_QR_Align = new System.Windows.Forms.Label();
			this.label_QRcodeDotSize = new System.Windows.Forms.Label();
			this.label_QRcodeLevel = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.numericUpDown_QRcodeDotSize = new System.Windows.Forms.NumericUpDown();
			this.numericUpDown_QRcodeLevel = new System.Windows.Forms.NumericUpDown();
			this.groupBox_Barcode = new System.Windows.Forms.GroupBox();
			this.panel_Barcode = new System.Windows.Forms.Panel();
			this.label3 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.groupBox_Picture = new System.Windows.Forms.GroupBox();
			this.panel_Line = new System.Windows.Forms.Panel();
			this.label_LineType = new System.Windows.Forms.Label();
			this.button_TextCancel = new System.Windows.Forms.Button();
			this.panel_Picture = new System.Windows.Forms.Panel();
			this.label9 = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_BarcodeWidth).BeginInit();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_BarcodeHeight).BeginInit();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_PictureNo).BeginInit();
			this.groupBox_TextLines.SuspendLayout();
			this.panel_TextLinesCheckBoxes.SuspendLayout();
			this.panel_TextLines.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.dataGrid_TextLines).BeginInit();
			this.panel_txt_Pic_Align.SuspendLayout();
			this.panel_txt_QR_Align.SuspendLayout();
			this.groupBox_QR.SuspendLayout();
			this.panel_QR.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_QRcodeDotSize).BeginInit();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_QRcodeLevel).BeginInit();
			this.groupBox_Barcode.SuspendLayout();
			this.panel_Barcode.SuspendLayout();
			this.groupBox_Picture.SuspendLayout();
			this.panel_Line.SuspendLayout();
			this.panel_Picture.SuspendLayout();
			base.SuspendLayout();
			this.comboBox_LineType.DropDownHeight = 44;
			this.comboBox_LineType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox_LineType.DropDownWidth = 40;
			this.comboBox_LineType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.comboBox_LineType.IntegralHeight = false;
			this.comboBox_LineType.Items.AddRange(new object[3] { "Одинарная", "Двойная", "Жирная" });
			this.comboBox_LineType.Location = new System.Drawing.Point(23, 17);
			this.comboBox_LineType.MaxDropDownItems = 3;
			this.comboBox_LineType.Name = "comboBox_LineType";
			this.comboBox_LineType.Size = new System.Drawing.Size(83, 21);
			this.comboBox_LineType.TabIndex = 7;
			this.comboBox_BarcodeType.DropDownHeight = 168;
			this.comboBox_BarcodeType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox_BarcodeType.DropDownWidth = 40;
			this.comboBox_BarcodeType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.comboBox_BarcodeType.IntegralHeight = false;
			this.comboBox_BarcodeType.Items.AddRange(new object[9] { "UPC-A", "UPC-E", "EAN-13", "EAN-8", "Code39", "ITF", "Codabar", "Code93", "Code128" });
			this.comboBox_BarcodeType.Location = new System.Drawing.Point(414, 17);
			this.comboBox_BarcodeType.MaxDropDownItems = 9;
			this.comboBox_BarcodeType.Name = "comboBox_BarcodeType";
			this.comboBox_BarcodeType.Size = new System.Drawing.Size(80, 21);
			this.comboBox_BarcodeType.TabIndex = 10;
			this.numericUpDown_BarcodeWidth.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.numericUpDown_BarcodeWidth.Location = new System.Drawing.Point(498, 17);
			this.numericUpDown_BarcodeWidth.Maximum = new decimal(new int[4] { 4, 0, 0, 0 });
			this.numericUpDown_BarcodeWidth.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			this.numericUpDown_BarcodeWidth.Name = "numericUpDown_BarcodeWidth";
			this.numericUpDown_BarcodeWidth.Size = new System.Drawing.Size(45, 20);
			this.numericUpDown_BarcodeWidth.TabIndex = 9;
			this.numericUpDown_BarcodeWidth.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.numericUpDown_BarcodeWidth.Value = new decimal(new int[4] { 2, 0, 0, 0 });
			this.numericUpDown_BarcodeHeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.numericUpDown_BarcodeHeight.Increment = new decimal(new int[4] { 10, 0, 0, 0 });
			this.numericUpDown_BarcodeHeight.Location = new System.Drawing.Point(550, 17);
			this.numericUpDown_BarcodeHeight.Maximum = new decimal(new int[4] { 200, 0, 0, 0 });
			this.numericUpDown_BarcodeHeight.Minimum = new decimal(new int[4] { 10, 0, 0, 0 });
			this.numericUpDown_BarcodeHeight.Name = "numericUpDown_BarcodeHeight";
			this.numericUpDown_BarcodeHeight.Size = new System.Drawing.Size(45, 20);
			this.numericUpDown_BarcodeHeight.TabIndex = 8;
			this.numericUpDown_BarcodeHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.numericUpDown_BarcodeHeight.Value = new decimal(new int[4] { 50, 0, 0, 0 });
			this.numericUpDown_PictureNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.numericUpDown_PictureNo.Location = new System.Drawing.Point(24, 17);
			this.numericUpDown_PictureNo.Maximum = new decimal(new int[4] { 22, 0, 0, 0 });
			this.numericUpDown_PictureNo.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			this.numericUpDown_PictureNo.Name = "numericUpDown_PictureNo";
			this.numericUpDown_PictureNo.Size = new System.Drawing.Size(50, 20);
			this.numericUpDown_PictureNo.TabIndex = 7;
			this.numericUpDown_PictureNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.numericUpDown_PictureNo.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			this.groupBox_TextLines.BackColor = System.Drawing.Color.Transparent;
			this.groupBox_TextLines.Controls.Add(this.panel_TextLinesCheckBoxes);
			this.groupBox_TextLines.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox_TextLines.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_TextLines.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_TextLines.Location = new System.Drawing.Point(4, 4);
			this.groupBox_TextLines.Name = "groupBox_TextLines";
			this.groupBox_TextLines.Padding = new System.Windows.Forms.Padding(1);
			this.groupBox_TextLines.Size = new System.Drawing.Size(612, 80);
			this.groupBox_TextLines.TabIndex = 19;
			this.groupBox_TextLines.TabStop = false;
			this.groupBox_TextLines.Text = "Т е к с т о в ы е   с т р о к и";
			this.panel_TextLinesCheckBoxes.BackColor = System.Drawing.Color.White;
			this.panel_TextLinesCheckBoxes.Controls.Add(this.panel_TextLines);
			this.panel_TextLinesCheckBoxes.Controls.Add(this.checkedListBox_TextLines);
			this.panel_TextLinesCheckBoxes.Location = new System.Drawing.Point(4, 14);
			this.panel_TextLinesCheckBoxes.Name = "panel_TextLinesCheckBoxes";
			this.panel_TextLinesCheckBoxes.Padding = new System.Windows.Forms.Padding(4, 0, 0, 0);
			this.panel_TextLinesCheckBoxes.Size = new System.Drawing.Size(604, 61);
			this.panel_TextLinesCheckBoxes.TabIndex = 18;
			this.panel_TextLines.Controls.Add(this.dataGrid_TextLines);
			this.panel_TextLines.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel_TextLines.Location = new System.Drawing.Point(24, 0);
			this.panel_TextLines.Name = "panel_TextLines";
			this.panel_TextLines.Size = new System.Drawing.Size(580, 61);
			this.panel_TextLines.TabIndex = 17;
			this.dataGrid_TextLines.AllowUserToAddRows = false;
			this.dataGrid_TextLines.AllowUserToDeleteRows = false;
			this.dataGrid_TextLines.AllowUserToResizeColumns = false;
			this.dataGrid_TextLines.AllowUserToResizeRows = false;
			dataGridViewCellStyle.BackColor = System.Drawing.Color.LightCyan;
			this.dataGrid_TextLines.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle;
			this.dataGrid_TextLines.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dataGrid_TextLines.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
			this.dataGrid_TextLines.ColumnHeadersHeight = 15;
			this.dataGrid_TextLines.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this.dataGrid_TextLines.ColumnHeadersVisible = false;
			this.dataGrid_TextLines.Columns.AddRange(this.dataGridViewTextBoxColumn_TextLines);
			this.dataGrid_TextLines.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dataGrid_TextLines.GridColor = System.Drawing.SystemColors.WindowFrame;
			this.dataGrid_TextLines.Location = new System.Drawing.Point(0, 0);
			this.dataGrid_TextLines.MultiSelect = false;
			this.dataGrid_TextLines.Name = "dataGrid_TextLines";
			this.dataGrid_TextLines.RowHeadersVisible = false;
			this.dataGrid_TextLines.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
			this.dataGrid_TextLines.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 204);
			this.dataGrid_TextLines.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGrid_TextLines.RowTemplate.Height = 15;
			this.dataGrid_TextLines.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.dataGrid_TextLines.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
			this.dataGrid_TextLines.ShowCellToolTips = false;
			this.dataGrid_TextLines.ShowEditingIcon = false;
			this.dataGrid_TextLines.Size = new System.Drawing.Size(580, 61);
			this.dataGrid_TextLines.TabIndex = 7;
			this.dataGrid_TextLines.MouseLeave += new System.EventHandler(dataGridViewTextBoxColumn_TextLines_HideTip);
			this.dataGrid_TextLines.MouseHover += new System.EventHandler(dataGridViewTextBoxColumn_TextLines_ShowTip);
			this.dataGridViewTextBoxColumn_TextLines.HeaderText = "Column_TextLines";
			this.dataGridViewTextBoxColumn_TextLines.MaxInputLength = 2000;
			this.dataGridViewTextBoxColumn_TextLines.Name = "dataGridViewTextBoxColumn_TextLines";
			this.checkedListBox_TextLines.BackColor = System.Drawing.Color.White;
			this.checkedListBox_TextLines.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.checkedListBox_TextLines.CheckOnClick = true;
			this.checkedListBox_TextLines.Dock = System.Windows.Forms.DockStyle.Left;
			this.checkedListBox_TextLines.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkedListBox_TextLines.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkedListBox_TextLines.FormattingEnabled = true;
			this.checkedListBox_TextLines.Items.AddRange(new object[4] { " ", " ", " ", " " });
			this.checkedListBox_TextLines.Location = new System.Drawing.Point(4, 0);
			this.checkedListBox_TextLines.Name = "checkedListBox_TextLines";
			this.checkedListBox_TextLines.Size = new System.Drawing.Size(20, 61);
			this.checkedListBox_TextLines.TabIndex = 4;
			this.panel_txt_Pic_Align.Controls.Add(this.radio_txt_Pic_Right);
			this.panel_txt_Pic_Align.Controls.Add(this.radio_txt_Pic_Center);
			this.panel_txt_Pic_Align.Controls.Add(this.radio_txt_Pic_Left);
			this.panel_txt_Pic_Align.Location = new System.Drawing.Point(100, 18);
			this.panel_txt_Pic_Align.Name = "panel_txt_Pic_Align";
			this.panel_txt_Pic_Align.Size = new System.Drawing.Size(102, 20);
			this.panel_txt_Pic_Align.TabIndex = 19;
			this.radio_txt_Pic_Right.Dock = System.Windows.Forms.DockStyle.Left;
			this.radio_txt_Pic_Right.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.radio_txt_Pic_Right.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radio_txt_Pic_Right.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radio_txt_Pic_Right.Location = new System.Drawing.Point(68, 0);
			this.radio_txt_Pic_Right.Name = "radio_txt_Pic_Right";
			this.radio_txt_Pic_Right.Size = new System.Drawing.Size(34, 20);
			this.radio_txt_Pic_Right.TabIndex = 12;
			this.radio_txt_Pic_Right.Text = "R";
			this.radio_txt_Pic_Right.UseVisualStyleBackColor = true;
			this.radio_txt_Pic_Center.Dock = System.Windows.Forms.DockStyle.Left;
			this.radio_txt_Pic_Center.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.radio_txt_Pic_Center.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radio_txt_Pic_Center.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radio_txt_Pic_Center.Location = new System.Drawing.Point(34, 0);
			this.radio_txt_Pic_Center.Name = "radio_txt_Pic_Center";
			this.radio_txt_Pic_Center.Size = new System.Drawing.Size(34, 20);
			this.radio_txt_Pic_Center.TabIndex = 13;
			this.radio_txt_Pic_Center.Text = "C";
			this.radio_txt_Pic_Center.UseVisualStyleBackColor = true;
			this.radio_txt_Pic_Left.Checked = true;
			this.radio_txt_Pic_Left.Dock = System.Windows.Forms.DockStyle.Left;
			this.radio_txt_Pic_Left.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.radio_txt_Pic_Left.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radio_txt_Pic_Left.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radio_txt_Pic_Left.Location = new System.Drawing.Point(0, 0);
			this.radio_txt_Pic_Left.Name = "radio_txt_Pic_Left";
			this.radio_txt_Pic_Left.Size = new System.Drawing.Size(34, 20);
			this.radio_txt_Pic_Left.TabIndex = 11;
			this.radio_txt_Pic_Left.TabStop = true;
			this.radio_txt_Pic_Left.Text = "L";
			this.radio_txt_Pic_Left.UseVisualStyleBackColor = true;
			this.panel_txt_QR_Align.Controls.Add(this.radio_txt_QR_Right);
			this.panel_txt_QR_Align.Controls.Add(this.radio_txt_QR_Center);
			this.panel_txt_QR_Align.Controls.Add(this.radio_txt_QR_Left);
			this.panel_txt_QR_Align.Location = new System.Drawing.Point(498, 52);
			this.panel_txt_QR_Align.Name = "panel_txt_QR_Align";
			this.panel_txt_QR_Align.Size = new System.Drawing.Size(102, 20);
			this.panel_txt_QR_Align.TabIndex = 18;
			this.radio_txt_QR_Right.Dock = System.Windows.Forms.DockStyle.Left;
			this.radio_txt_QR_Right.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.radio_txt_QR_Right.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radio_txt_QR_Right.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radio_txt_QR_Right.Location = new System.Drawing.Point(68, 0);
			this.radio_txt_QR_Right.Name = "radio_txt_QR_Right";
			this.radio_txt_QR_Right.Size = new System.Drawing.Size(34, 20);
			this.radio_txt_QR_Right.TabIndex = 12;
			this.radio_txt_QR_Right.Text = "R";
			this.radio_txt_QR_Right.UseVisualStyleBackColor = true;
			this.radio_txt_QR_Center.Dock = System.Windows.Forms.DockStyle.Left;
			this.radio_txt_QR_Center.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.radio_txt_QR_Center.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radio_txt_QR_Center.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radio_txt_QR_Center.Location = new System.Drawing.Point(34, 0);
			this.radio_txt_QR_Center.Name = "radio_txt_QR_Center";
			this.radio_txt_QR_Center.Size = new System.Drawing.Size(34, 20);
			this.radio_txt_QR_Center.TabIndex = 13;
			this.radio_txt_QR_Center.Text = "C";
			this.radio_txt_QR_Center.UseVisualStyleBackColor = true;
			this.radio_txt_QR_Left.Checked = true;
			this.radio_txt_QR_Left.Dock = System.Windows.Forms.DockStyle.Left;
			this.radio_txt_QR_Left.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.radio_txt_QR_Left.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radio_txt_QR_Left.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.radio_txt_QR_Left.Location = new System.Drawing.Point(0, 0);
			this.radio_txt_QR_Left.Name = "radio_txt_QR_Left";
			this.radio_txt_QR_Left.Size = new System.Drawing.Size(34, 20);
			this.radio_txt_QR_Left.TabIndex = 11;
			this.radio_txt_QR_Left.TabStop = true;
			this.radio_txt_QR_Left.Text = "L";
			this.radio_txt_QR_Left.UseVisualStyleBackColor = true;
			this.checkBox_txt_QR.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_txt_QR.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_txt_QR.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_txt_QR.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_txt_QR.Location = new System.Drawing.Point(4, 19);
			this.checkBox_txt_QR.Name = "checkBox_txt_QR";
			this.checkBox_txt_QR.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.checkBox_txt_QR.Size = new System.Drawing.Size(20, 17);
			this.checkBox_txt_QR.TabIndex = 7;
			this.checkBox_txt_QR.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_txt_QR.UseVisualStyleBackColor = true;
			this.checkBox_txt_Line.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_txt_Line.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_txt_Line.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_txt_Line.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_txt_Line.Location = new System.Drawing.Point(4, 19);
			this.checkBox_txt_Line.Name = "checkBox_txt_Line";
			this.checkBox_txt_Line.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.checkBox_txt_Line.Size = new System.Drawing.Size(20, 17);
			this.checkBox_txt_Line.TabIndex = 6;
			this.checkBox_txt_Line.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_txt_Line.UseVisualStyleBackColor = true;
			this.checkBox_txt_Image.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_txt_Image.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.checkBox_txt_Image.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_txt_Image.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_txt_Image.Location = new System.Drawing.Point(4, 19);
			this.checkBox_txt_Image.Name = "checkBox_txt_Image";
			this.checkBox_txt_Image.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.checkBox_txt_Image.Size = new System.Drawing.Size(20, 17);
			this.checkBox_txt_Image.TabIndex = 6;
			this.checkBox_txt_Image.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_txt_Image.UseVisualStyleBackColor = true;
			this.checkBox_txt_Barcode.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_txt_Barcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.checkBox_txt_Barcode.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_txt_Barcode.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_txt_Barcode.Location = new System.Drawing.Point(4, 19);
			this.checkBox_txt_Barcode.Name = "checkBox_txt_Barcode";
			this.checkBox_txt_Barcode.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.checkBox_txt_Barcode.Size = new System.Drawing.Size(20, 17);
			this.checkBox_txt_Barcode.TabIndex = 6;
			this.checkBox_txt_Barcode.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_txt_Barcode.UseVisualStyleBackColor = true;
			this.button_TextOK.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.button_TextOK.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.button_TextOK.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_TextOK.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_TextOK.Location = new System.Drawing.Point(344, 14);
			this.button_TextOK.Name = "button_TextOK";
			this.button_TextOK.Size = new System.Drawing.Size(128, 37);
			this.button_TextOK.TabIndex = 0;
			this.button_TextOK.Text = "Печать";
			this.button_TextOK.UseVisualStyleBackColor = true;
			this.button_TextOK.Click += new System.EventHandler(button_TextOK_Click);
			this.textBox_txt_QR.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_txt_QR.Location = new System.Drawing.Point(24, 17);
			this.textBox_txt_QR.MaxLength = 256;
			this.textBox_txt_QR.Name = "textBox_txt_QR";
			this.textBox_txt_QR.Size = new System.Drawing.Size(470, 20);
			this.textBox_txt_QR.TabIndex = 2;
			this.textBox_txt_QR.Text = "https://u.kfcvisit.com/RUS?&S=1&D=160822&T=1453&U=100321&V=1&O=6&Source=QR&SMG-Email=True&LanguageID=ru";
			this.textBox_txt_Barcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_txt_Barcode.Location = new System.Drawing.Point(24, 17);
			this.textBox_txt_Barcode.MaxLength = 256;
			this.textBox_txt_Barcode.Name = "textBox_txt_Barcode";
			this.textBox_txt_Barcode.Size = new System.Drawing.Size(384, 20);
			this.textBox_txt_Barcode.TabIndex = 2;
			this.textBox_txt_Barcode.Text = "1234567890128";
			this.checkBox_txt_QRText.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_txt_QRText.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.checkBox_txt_QRText.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.checkBox_txt_QRText.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.checkBox_txt_QRText.Location = new System.Drawing.Point(4, 54);
			this.checkBox_txt_QRText.Name = "checkBox_txt_QRText";
			this.checkBox_txt_QRText.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.checkBox_txt_QRText.Size = new System.Drawing.Size(20, 17);
			this.checkBox_txt_QRText.TabIndex = 6;
			this.checkBox_txt_QRText.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox_txt_QRText.UseVisualStyleBackColor = true;
			this.textBox_QRText.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_QRText.Location = new System.Drawing.Point(24, 52);
			this.textBox_QRText.MaxLength = 256;
			this.textBox_QRText.Name = "textBox_QRText";
			this.textBox_QRText.Size = new System.Drawing.Size(470, 20);
			this.textBox_QRText.TabIndex = 2;
			this.textBox_QRText.Text = "Подари нам шанс стать еще лучше!\\x0AОставь свой отзыв о посещении KFC на сайте KFCFEEDBACKRUS.com (на страницу можно попасть, отсканировав QR-код)";
			this.label_Format.AutoSize = true;
			this.label_Format.BackColor = System.Drawing.Color.Cyan;
			this.label_Format.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.label_Format.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_Format.Location = new System.Drawing.Point(34, 80);
			this.label_Format.Name = "label_Format";
			this.label_Format.Size = new System.Drawing.Size(315, 93);
			this.label_Format.TabIndex = 21;
			this.label_Format.Text = resources.GetString("label_Format.Text");
			this.label_Format.Visible = false;
			this.groupBox_QR.BackColor = System.Drawing.Color.Transparent;
			this.groupBox_QR.Controls.Add(this.panel_QR);
			this.groupBox_QR.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox_QR.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_QR.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_QR.Location = new System.Drawing.Point(4, 84);
			this.groupBox_QR.Name = "groupBox_QR";
			this.groupBox_QR.Padding = new System.Windows.Forms.Padding(1);
			this.groupBox_QR.Size = new System.Drawing.Size(612, 98);
			this.groupBox_QR.TabIndex = 19;
			this.groupBox_QR.TabStop = false;
			this.groupBox_QR.Text = "Q R   к о д";
			this.panel_QR.BackColor = System.Drawing.Color.LightCyan;
			this.panel_QR.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_QR.Controls.Add(this.label_txt_QR_Align);
			this.panel_QR.Controls.Add(this.label_QRcodeDotSize);
			this.panel_QR.Controls.Add(this.label_QRcodeLevel);
			this.panel_QR.Controls.Add(this.label4);
			this.panel_QR.Controls.Add(this.label1);
			this.panel_QR.Controls.Add(this.numericUpDown_QRcodeDotSize);
			this.panel_QR.Controls.Add(this.numericUpDown_QRcodeLevel);
			this.panel_QR.Controls.Add(this.textBox_txt_QR);
			this.panel_QR.Controls.Add(this.textBox_QRText);
			this.panel_QR.Controls.Add(this.checkBox_txt_QRText);
			this.panel_QR.Controls.Add(this.checkBox_txt_QR);
			this.panel_QR.Controls.Add(this.panel_txt_QR_Align);
			this.panel_QR.Location = new System.Drawing.Point(4, 14);
			this.panel_QR.Name = "panel_QR";
			this.panel_QR.Size = new System.Drawing.Size(604, 78);
			this.panel_QR.TabIndex = 0;
			this.label_txt_QR_Align.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_txt_QR_Align.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_txt_QR_Align.Location = new System.Drawing.Point(495, 40);
			this.label_txt_QR_Align.Name = "label_txt_QR_Align";
			this.label_txt_QR_Align.Size = new System.Drawing.Size(100, 13);
			this.label_txt_QR_Align.TabIndex = 22;
			this.label_txt_QR_Align.Text = "Положение";
			this.label_txt_QR_Align.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label_QRcodeDotSize.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_QRcodeDotSize.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_QRcodeDotSize.Location = new System.Drawing.Point(550, 1);
			this.label_QRcodeDotSize.Name = "label_QRcodeDotSize";
			this.label_QRcodeDotSize.Size = new System.Drawing.Size(48, 13);
			this.label_QRcodeDotSize.TabIndex = 22;
			this.label_QRcodeDotSize.Text = "Размер";
			this.label_QRcodeDotSize.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label_QRcodeLevel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_QRcodeLevel.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_QRcodeLevel.Location = new System.Drawing.Point(492, 1);
			this.label_QRcodeLevel.Name = "label_QRcodeLevel";
			this.label_QRcodeLevel.Size = new System.Drawing.Size(52, 13);
			this.label_QRcodeLevel.TabIndex = 22;
			this.label_QRcodeLevel.Text = "Уровень";
			this.label_QRcodeLevel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label4.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label4.Location = new System.Drawing.Point(24, 38);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(201, 13);
			this.label4.TabIndex = 21;
			this.label4.Text = "Текст для печати рядом с QR кодом";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label1.Location = new System.Drawing.Point(24, 3);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(125, 13);
			this.label1.TabIndex = 21;
			this.label1.Text = "Значение QR кода";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.numericUpDown_QRcodeDotSize.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.numericUpDown_QRcodeDotSize.Location = new System.Drawing.Point(550, 17);
			this.numericUpDown_QRcodeDotSize.Maximum = new decimal(new int[4] { 4, 0, 0, 0 });
			this.numericUpDown_QRcodeDotSize.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			this.numericUpDown_QRcodeDotSize.Name = "numericUpDown_QRcodeDotSize";
			this.numericUpDown_QRcodeDotSize.Size = new System.Drawing.Size(45, 20);
			this.numericUpDown_QRcodeDotSize.TabIndex = 20;
			this.numericUpDown_QRcodeDotSize.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.numericUpDown_QRcodeDotSize.Value = new decimal(new int[4] { 4, 0, 0, 0 });
			this.numericUpDown_QRcodeLevel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.numericUpDown_QRcodeLevel.Location = new System.Drawing.Point(498, 17);
			this.numericUpDown_QRcodeLevel.Maximum = new decimal(new int[4] { 4, 0, 0, 0 });
			this.numericUpDown_QRcodeLevel.Name = "numericUpDown_QRcodeLevel";
			this.numericUpDown_QRcodeLevel.Size = new System.Drawing.Size(45, 20);
			this.numericUpDown_QRcodeLevel.TabIndex = 19;
			this.numericUpDown_QRcodeLevel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.numericUpDown_QRcodeLevel.Value = new decimal(new int[4] { 2, 0, 0, 0 });
			this.groupBox_Barcode.BackColor = System.Drawing.Color.Transparent;
			this.groupBox_Barcode.Controls.Add(this.panel_Barcode);
			this.groupBox_Barcode.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox_Barcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_Barcode.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_Barcode.Location = new System.Drawing.Point(4, 182);
			this.groupBox_Barcode.Name = "groupBox_Barcode";
			this.groupBox_Barcode.Padding = new System.Windows.Forms.Padding(1);
			this.groupBox_Barcode.Size = new System.Drawing.Size(612, 63);
			this.groupBox_Barcode.TabIndex = 20;
			this.groupBox_Barcode.TabStop = false;
			this.groupBox_Barcode.Text = "Ш т р и х  к о д";
			this.panel_Barcode.BackColor = System.Drawing.Color.LightCyan;
			this.panel_Barcode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_Barcode.Controls.Add(this.label3);
			this.panel_Barcode.Controls.Add(this.label8);
			this.panel_Barcode.Controls.Add(this.label7);
			this.panel_Barcode.Controls.Add(this.label6);
			this.panel_Barcode.Controls.Add(this.numericUpDown_BarcodeHeight);
			this.panel_Barcode.Controls.Add(this.numericUpDown_BarcodeWidth);
			this.panel_Barcode.Controls.Add(this.textBox_txt_Barcode);
			this.panel_Barcode.Controls.Add(this.comboBox_BarcodeType);
			this.panel_Barcode.Controls.Add(this.checkBox_txt_Barcode);
			this.panel_Barcode.Location = new System.Drawing.Point(4, 14);
			this.panel_Barcode.Name = "panel_Barcode";
			this.panel_Barcode.Size = new System.Drawing.Size(604, 44);
			this.panel_Barcode.TabIndex = 0;
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label3.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label3.Location = new System.Drawing.Point(544, 3);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(54, 13);
			this.label3.TabIndex = 22;
			this.label3.Text = "Высота";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label8.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label8.Location = new System.Drawing.Point(411, 3);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(56, 13);
			this.label8.TabIndex = 22;
			this.label8.Text = "Тип";
			this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label7.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label7.Location = new System.Drawing.Point(487, 3);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(56, 13);
			this.label7.TabIndex = 22;
			this.label7.Text = "Толщина";
			this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label6.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label6.Location = new System.Drawing.Point(24, 3);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(125, 13);
			this.label6.TabIndex = 22;
			this.label6.Text = "Значение штрих-кода";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.groupBox_Picture.BackColor = System.Drawing.Color.Transparent;
			this.groupBox_Picture.Controls.Add(this.button_TextOK);
			this.groupBox_Picture.Controls.Add(this.panel_Line);
			this.groupBox_Picture.Controls.Add(this.button_TextCancel);
			this.groupBox_Picture.Controls.Add(this.panel_Picture);
			this.groupBox_Picture.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox_Picture.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
			this.groupBox_Picture.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_Picture.Location = new System.Drawing.Point(4, 245);
			this.groupBox_Picture.Name = "groupBox_Picture";
			this.groupBox_Picture.Padding = new System.Windows.Forms.Padding(1);
			this.groupBox_Picture.Size = new System.Drawing.Size(612, 62);
			this.groupBox_Picture.TabIndex = 21;
			this.groupBox_Picture.TabStop = false;
			this.groupBox_Picture.Text = "К а р т и н к а   и   л и н и я";
			this.panel_Line.BackColor = System.Drawing.Color.LightCyan;
			this.panel_Line.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_Line.Controls.Add(this.comboBox_LineType);
			this.panel_Line.Controls.Add(this.checkBox_txt_Line);
			this.panel_Line.Controls.Add(this.label_LineType);
			this.panel_Line.Location = new System.Drawing.Point(217, 14);
			this.panel_Line.Name = "panel_Line";
			this.panel_Line.Size = new System.Drawing.Size(116, 44);
			this.panel_Line.TabIndex = 0;
			this.label_LineType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label_LineType.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_LineType.Location = new System.Drawing.Point(23, 0);
			this.label_LineType.Name = "label_LineType";
			this.label_LineType.Size = new System.Drawing.Size(83, 13);
			this.label_LineType.TabIndex = 20;
			this.label_LineType.Text = "Тип линии";
			this.label_LineType.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.button_TextCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.button_TextCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold);
			this.button_TextCancel.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_TextCancel.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_TextCancel.Location = new System.Drawing.Point(478, 14);
			this.button_TextCancel.Name = "button_TextCancel";
			this.button_TextCancel.Size = new System.Drawing.Size(128, 37);
			this.button_TextCancel.TabIndex = 0;
			this.button_TextCancel.Text = "Отмена";
			this.button_TextCancel.UseVisualStyleBackColor = true;
			this.panel_Picture.BackColor = System.Drawing.Color.LightCyan;
			this.panel_Picture.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_Picture.Controls.Add(this.label9);
			this.panel_Picture.Controls.Add(this.label10);
			this.panel_Picture.Controls.Add(this.numericUpDown_PictureNo);
			this.panel_Picture.Controls.Add(this.panel_txt_Pic_Align);
			this.panel_Picture.Controls.Add(this.checkBox_txt_Image);
			this.panel_Picture.Location = new System.Drawing.Point(4, 14);
			this.panel_Picture.Name = "panel_Picture";
			this.panel_Picture.Size = new System.Drawing.Size(207, 44);
			this.panel_Picture.TabIndex = 0;
			this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label9.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label9.Location = new System.Drawing.Point(24, 3);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(91, 13);
			this.label9.TabIndex = 22;
			this.label9.Text = "Номер картинки";
			this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.label10.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label10.Location = new System.Drawing.Point(115, 3);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(75, 13);
			this.label10.TabIndex = 22;
			this.label10.Text = "Положение";
			this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			base.AcceptButton = this.button_TextOK;
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.CancelButton = this.button_TextCancel;
			base.ClientSize = new System.Drawing.Size(620, 310);
			base.Controls.Add(this.groupBox_Picture);
			base.Controls.Add(this.label_Format);
			base.Controls.Add(this.groupBox_Barcode);
			base.Controls.Add(this.groupBox_QR);
			base.Controls.Add(this.groupBox_TextLines);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			base.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "Ticket_TextForm";
			base.Padding = new System.Windows.Forms.Padding(4);
			base.ShowIcon = false;
			base.ShowInTaskbar = false;
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Текстовые и графические элементы";
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_BarcodeWidth).EndInit();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_BarcodeHeight).EndInit();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_PictureNo).EndInit();
			this.groupBox_TextLines.ResumeLayout(false);
			this.panel_TextLinesCheckBoxes.ResumeLayout(false);
			this.panel_TextLines.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.dataGrid_TextLines).EndInit();
			this.panel_txt_Pic_Align.ResumeLayout(false);
			this.panel_txt_QR_Align.ResumeLayout(false);
			this.groupBox_QR.ResumeLayout(false);
			this.panel_QR.ResumeLayout(false);
			this.panel_QR.PerformLayout();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_QRcodeDotSize).EndInit();
			((System.ComponentModel.ISupportInitialize)this.numericUpDown_QRcodeLevel).EndInit();
			this.groupBox_Barcode.ResumeLayout(false);
			this.panel_Barcode.ResumeLayout(false);
			this.panel_Barcode.PerformLayout();
			this.groupBox_Picture.ResumeLayout(false);
			this.panel_Line.ResumeLayout(false);
			this.panel_Picture.ResumeLayout(false);
			base.ResumeLayout(false);
			base.PerformLayout();
		}
	}
}
