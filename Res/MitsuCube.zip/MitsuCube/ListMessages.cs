using System.Collections.Generic;

namespace MitsuCube
{
	public class ListMessages : List<CodeMsg>
	{
		public CodeMsg FindMsgForCode(int c)
		{
			if (c != 0)
			{
				for (int i = 0; i < base.Count; i++)
				{
					if (base[i].code == c)
					{
						return base[i];
					}
				}
			}
			return null;
		}

		public CodeMsg FindMsgForCode(string c)
		{
			for (int i = 0; i < base.Count; i++)
			{
				if (base[i].message.ToString() == c)
				{
					return base[i];
				}
			}
			return null;
		}
	}
}
