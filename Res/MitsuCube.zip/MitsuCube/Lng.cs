using System.Globalization;
using System.Threading;

namespace MitsuCube
{
	internal class Lng
	{
		private enum Languages
		{
			en,
			ru
		}

		private static Languages current;

		private static CultureInfo CultureEN;

		private static CultureInfo CultureRU;

		public static string Current
		{
			get
			{
				return Thread.CurrentThread.CurrentCulture.Name.ToString();
			}
			set
			{
				if (value.Equals("en"))
				{
					SetLngEN();
				}
				else
				{
					SetLngRU();
				}
			}
		}

		static Lng()
		{
			CultureEN = new CultureInfo("en");
			CultureRU = new CultureInfo("ru");
			Current = Thread.CurrentThread.CurrentUICulture.Name.Substring(0, 2);
		}

		public static void SetLngEN()
		{
			current = Languages.en;
			Thread.CurrentThread.CurrentCulture = CultureEN;
			Thread.CurrentThread.CurrentUICulture = CultureEN;
		}

		public static void SetLngRU()
		{
			current = Languages.ru;
			Thread.CurrentThread.CurrentCulture = CultureRU;
			Thread.CurrentThread.CurrentUICulture = CultureRU;
		}

		public static string GetStr(string enStr, string ruStr)
		{
			return current switch
			{
				Languages.en => enStr, 
				Languages.ru => ruStr, 
				_ => ruStr, 
			};
		}
	}
}
