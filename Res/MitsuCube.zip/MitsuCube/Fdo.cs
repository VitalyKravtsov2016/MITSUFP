using System;
using System.Linq;
using System.Net.Sockets;

namespace MitsuCube
{
	internal class Fdo
	{
		public enum OPERATOR
		{
			OFD,
			OISM,
			OKP
		}

		private static readonly byte[] Signature_OFD = new byte[4] { 42, 8, 65, 10 };

		private static readonly byte[] Signature_OISM = new byte[4] { 221, 128, 202, 161 };

		private static readonly byte[] Signature_OKP = new byte[4] { 221, 128, 202, 161 };

		private static readonly byte[][] Signature = new byte[3][] { Signature_OFD, Signature_OISM, Signature_OKP };

		private static readonly string[] server = new string[3] { "ОФД", "ОИСМ", "ОКП" };

		public byte[] SendPacket(byte[] packet, string host, int port, OPERATOR to = OPERATOR.OFD)
		{
			Socket socket = null;
			try
			{
				socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
				socket.Connect(host, port);
				socket.Send(packet);
				socket.ReceiveTimeout = 5000;
				byte[] signature = new byte[4];
				if (socket.Receive(signature) == 0)
				{
					throw new Exception("Отсутствует ответ от сервера " + server[(byte)to]);
				}
				byte[] array = new byte[26];
				if (socket.Receive(array) == 0)
				{
					throw new Exception("Таймаут ответа от сервера " + server[(byte)to]);
				}
				byte[] array2 = new byte[array[21] * 256 + array[20]];
				if (socket.Receive(array2) == 0)
				{
					throw new Exception("Таймаут ответа от сервера " + server[(byte)to]);
				}
				if (Signature[(byte)to].Where((byte t, int i) => signature[i] != t).Any())
				{
					throw new ArgumentException("Неверная сигнатура ответа " + server[(byte)to]);
				}
				byte[] array3 = new byte[signature.Length + array.Length + array2.Length];
				signature.CopyTo(array3, 0);
				array.CopyTo(array3, signature.Length);
				array2.CopyTo(array3, signature.Length + array.Length);
				return array3;
			}
			catch (Exception ex)
			{
				throw new Exception("Ошибка при работе с внешним сервером: " + ex.Message);
			}
			finally
			{
				socket?.Close();
			}
		}
	}
}
