using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace MitsuCube
{
	internal class LocalFDO_Server
	{
		private delegate void AddRowListBox(string str, bool ans = true);

		private static readonly byte[] Signature = new byte[4] { 42, 8, 65, 10 };

		private AddRowListBox add_row;

		private byte[] INNOFD = new byte[16]
		{
			249, 3, 12, 0, 55, 55, 57, 57, 57, 57,
			57, 57, 57, 57, 32, 32
		};

		private byte[] FN_TAG = new byte[4] { 17, 4, 16, 0 };

		private byte[] FD_TAG = new byte[4] { 16, 4, 4, 0 };

		private byte[] DT_TAG = new byte[4] { 244, 3, 4, 0 };

		private byte[] OP_TAG = new byte[8] { 44, 4, 5, 0, 254, 3, 1, 0 };

		private byte[] FO_TAG = new byte[22]
		{
			54, 4, 18, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0
		};

		private byte[] SessionHeader;

		private List<byte> container;

		public ListBox Console { get; set; }

		public LocalFDO_Server()
		{
			Console = null;
			container = new List<byte>();
			SessionHeader = new byte[30];
			add_row = (AddRowListBox)Delegate.Combine(add_row, (AddRowListBox)delegate(string s, bool a)
			{
				try
				{
					AddRowConsole(s, a);
				}
				catch
				{
				}
			});
		}

		public LocalFDO_Server(ListBox console)
			: this()
		{
			Console = console;
		}

		public ushort CRC16_CCITT(byte[] Data)
		{
			ushort num = ushort.MaxValue;
			ushort num2 = 4129;
			for (int i = 0; i < Data.Length; i++)
			{
				num ^= (ushort)(Data[i] << 8);
				for (int j = 0; j < 8; j++)
				{
					num = (((num & 0x8000) == 0) ? ((ushort)(num << 1)) : ((ushort)((num << 1) ^ num2)));
				}
			}
			return num;
		}

		public void ReadMessage(byte[] Data)
		{
			if (Data == null || Data.Length == 0)
			{
				return;
			}
			WriteConsole("Получено сообщение от ККТ", is_answer: false);
			WriteConsole("Разбор заголовка", is_answer: false);
			if (Signature.Where((byte t, int i) => Data[i] != t).Any())
			{
				WriteConsole("Неверная сигнатура ответа ОФД", is_answer: false);
				throw new ArgumentException("Неверная сигнатура ответа ОФД");
			}
			ushort num = 0;
			uint num2 = 0u;
			string text = "";
			byte[] array = null;
			WriteConsole("Версия P-протокола: 0x" + Data[6].ToString("X2") + Data[7].ToString("X2"), is_answer: false);
			for (int j = 8; j < 24; j++)
			{
				text += Convert.ToChar(Data[j]);
			}
			WriteConsole("Номер ФН: " + text, is_answer: false);
			WriteConsole("Размер тела сообщения: " + (ushort)(Data[24] + (ushort)(Data[25] << 8)), is_answer: false);
			if ((Data[26] & 3) == 0)
			{
				WriteConsole("Проверочный код не вычисляется", is_answer: false);
			}
			else
			{
				WriteConsole("Проверочный код: " + (ushort)(Data[28] + (ushort)(Data[29] << 8)), is_answer: false);
			}
			WriteConsole("--------------------------------", is_answer: false);
			WriteConsole("Разбор тела сообщения", is_answer: false);
			num = (ushort)(Data[30] + (ushort)(Data[31] << 8));
			WriteConsole("Размер данных Контейнера: " + num, is_answer: false);
			array = new byte[num - 2];
			for (int k = 0; k < num; k++)
			{
				if (k != 2 && k != 3)
				{
					array[(k < 2) ? k : (k - 2)] = Data[k + 30];
				}
			}
			ushort num3 = CRC16_CCITT(array);
			array = null;
			num = (ushort)(Data[32] + (ushort)(Data[33] << 8));
			if (num == num3)
			{
				WriteConsole("Контрольный проверочный код Контейнера: " + num, is_answer: false);
				WriteConsole("Тип Контейнера: 0x" + Data[34].ToString("X2"), is_answer: false);
				WriteConsole("Тип данных Контейнера: " + GetDocName(Data[35]), is_answer: false);
				WriteConsole("Версия формата Контейнера: 0x" + Data[36].ToString("X2"), is_answer: false);
				array = new byte[8];
				for (int l = 9; l < 17; l++)
				{
					array[l - 9] = Data[l + 30];
				}
				WriteConsole("Номер ФН: " + GetFNFromCont(array), is_answer: false);
				array = null;
				WriteConsole("ФД: " + (uint)((Data[47] << 16) + (Data[48] << 8) + Data[49]), is_answer: false);
				array = FindTag(Data, 1077);
				if (array.Length >= 4)
				{
					WriteConsole("ФП: " + ((uint)((array[array.Length - 4] << 24) + (array[array.Length - 4 + 1] << 16) + (array[array.Length - 4 + 2] << 8) + array[array.Length - 4 + 3])).ToString("D10"), is_answer: false);
				}
				else
				{
					WriteConsole("ФП не определен", is_answer: false);
				}
				array = null;
				return;
			}
			WriteConsole("Контрольный проверочный код Контейнера не совпал с расчетным: " + num, is_answer: false);
			WriteConsole("- из сообщения " + num, is_answer: false);
			WriteConsole("- расчетный " + num3, is_answer: false);
			throw new ArgumentException("Контрольный проверочный код Контейнера не совпал с расчетным");
		}

		public byte[] CreateTicket(byte[] Data)
		{
			if (Data == null || Data.Length == 0)
			{
				return null;
			}
			byte[] array = null;
			int num = 0;
			container.Clear();
			for (int i = 0; i < 4; i++)
			{
				container.Add(0);
			}
			container.Add(165);
			container.Add(7);
			for (int j = 36; j < 54; j++)
			{
				container.Add(Data[j]);
			}
			for (int k = 0; k < 12; k++)
			{
				container.Add(0);
			}
			container.AddRange(INNOFD);
			container.AddRange(FN_TAG);
			for (int l = 0; l < 16; l++)
			{
				container.Add(Data[l + 8]);
			}
			array = FindTag(Data, 1040);
			if (array != null && array.Length == 4)
			{
				container.AddRange(FD_TAG);
				container.AddRange(array);
			}
			container.AddRange(DT_TAG);
			num = GetNowGMTUnixDateTime();
			array = new byte[4]
			{
				(byte)(num << 24 >> 24),
				(byte)(num << 16 >> 24),
				(byte)(num << 8 >> 24),
				(byte)(num >> 24)
			};
			container.AddRange(array);
			container.AddRange(OP_TAG);
			container.Add(0);
			container.AddRange(FO_TAG);
			container[0] = (byte)(container.Count << 24 >> 24);
			container[1] = (byte)(container.Count << 16 >> 24);
			array = new byte[container.Count - 2];
			array[0] = container[0];
			array[1] = container[1];
			for (int m = 2; m < array.Length; m++)
			{
				array[m] = container[m + 2];
			}
			ushort num2 = CRC16_CCITT(array);
			container[2] = (byte)(num2 << 8 >> 8);
			container[3] = (byte)(num2 >> 8);
			array = new byte[container.Count];
			for (int n = 0; n < array.Length; n++)
			{
				array[n] = container[n];
			}
			return array;
		}

		public void DecriptTicket(byte[] Data)
		{
			if (Data == null || Data.Length == 0)
			{
				return;
			}
			ushort num = 0;
			uint num2 = 0u;
			string text = "";
			byte[] array = null;
			WriteConsole("--------------------------------", is_answer: false, "..");
			WriteConsole("Получена квитанция от ОФД", is_answer: false, "..");
			WriteConsole("Разбор заголовка", is_answer: false, "..");
			WriteConsole("Версия P-протокола: 0x" + Data[6].ToString("X2") + Data[7].ToString("X2"), is_answer: false, "..");
			for (int i = 8; i < 24; i++)
			{
				text += Convert.ToChar(Data[i]);
			}
			WriteConsole("Номер ФН: " + text, is_answer: false, "..");
			WriteConsole("Размер тела квитанции: " + (ushort)(Data[24] + (ushort)(Data[25] << 8)), is_answer: false, "..");
			if ((Data[26] & 3) == 0)
			{
				WriteConsole("Проверочный код не вычисляется", is_answer: false, "..");
			}
			else
			{
				WriteConsole("Проверочный код: " + (ushort)(Data[28] + (ushort)(Data[29] << 8)), is_answer: false, "..");
			}
			WriteConsole(" ", is_answer: false, "..");
			WriteConsole("Разбор тела квитанции", is_answer: false, "..");
			num = (ushort)(Data[30] + (ushort)(Data[31] << 8));
			WriteConsole("Размер данных Контейнера: " + num, is_answer: false, "..");
			array = new byte[num - 2];
			for (int j = 0; j < num; j++)
			{
				if (j != 2 && j != 3)
				{
					array[(j < 2) ? j : (j - 2)] = Data[j + 30];
				}
			}
			ushort num3 = CRC16_CCITT(array);
			array = null;
			num = (ushort)(Data[32] + (ushort)(Data[33] << 8));
			if (num == num3)
			{
				WriteConsole("Контрольный проверочный код Контейнера: " + num, is_answer: false, "..");
				WriteConsole("Тип Контейнера: 0x" + Data[34].ToString("X2"), is_answer: false, "..");
				WriteConsole("Тип данных Контейнера: " + GetDocName(Data[35]), is_answer: false, "..");
				WriteConsole("Версия формата Контейнера: 0x" + Data[36].ToString("X2"), is_answer: false, "..");
				array = new byte[8];
				for (int k = 9; k < 17; k++)
				{
					array[k - 9] = Data[k + 30];
				}
				WriteConsole("Номер ФН: " + GetFNFromCont(array), is_answer: false, "..");
				array = null;
				WriteConsole("ФД: " + (uint)((Data[47] << 16) + (Data[48] << 8) + Data[49]), is_answer: false, "..");
				array = FindTag(Data, 1017);
				if (array != null)
				{
					text = "";
					byte[] array2 = array;
					foreach (byte value in array2)
					{
						text += Convert.ToChar(value);
					}
					WriteConsole("ИНН ОФД: " + text, is_answer: false, "..");
				}
				array = FindTag(Data, 1012);
				if (array != null && array.Length == 4)
				{
					num2 = (uint)((array[3] << 24) + (array[2] << 16) + (array[1] << 8) + array[0]);
					WriteConsole("Время приема ФД: " + GetNowGMTDateTime((int)num2).ToString("yyyy-MM-dd HH:mm:ss"), is_answer: false, "..");
				}
				array = FindTag(Data, 1206);
				if (array != null)
				{
					WriteConsole("Сообщение оператора: 0x" + array[0].ToString("X2"), is_answer: false, "..");
				}
				array = FindTag(Data, 1068);
				if (array != null && array.Length == 5)
				{
					WriteConsole("Сообщение оператора для ФН: 0x" + array[4].ToString("X2"), is_answer: false, "..");
				}
				return;
			}
			WriteConsole("Контрольный проверочный код Контейнера не совпал с расчетным: " + num, is_answer: false, "..");
			WriteConsole("- из Контейнера " + num, is_answer: false, "..");
			WriteConsole("- расчетный " + num3, is_answer: false, "..");
			throw new ArgumentException("Контрольный проверочный код Контейнера не совпал с расчетным");
		}

		private void ClearByteArray(byte[] Data)
		{
			if (Data != null && Data.Length != 0)
			{
				for (int i = 0; i < Data.Length; i++)
				{
					Data[i] = 0;
				}
			}
		}

		private DateTime GetNowGMTDateTime(int unixtime)
		{
			if (unixtime < 0)
			{
				return DateTime.MinValue;
			}
			return new DateTime(1970, 1, 1).AddSeconds(unixtime);
		}

		private int GetNowGMTUnixDateTime()
		{
			return (int)DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1)).TotalSeconds;
		}

		private byte[] FindTag(byte[] Data, ushort tag, bool is_header = true)
		{
			byte[] array = null;
			byte[] array2 = null;
			if (Data == null || Data.Length <= 36 + (is_header ? 30 : 0))
			{
				return null;
			}
			ushort num = (ushort)(Data[is_header ? 30 : 0] + (ushort)(Data[1 + (is_header ? 30 : 0)] << 8));
			if (num == 0 || num > Data.Length - (is_header ? 30 : 0) || num <= 36)
			{
				return null;
			}
			array = new byte[num - 36];
			for (int i = 0; i < array.Length; i++)
			{
				array[i] = Data[i + (is_header ? 66 : 36)];
			}
			ushort num2 = 0;
			ushort num3 = 0;
			for (int j = 0; j < array.Length; j += 4 + num3)
			{
				num2 = (ushort)(array[j] + (ushort)(array[j + 1] << 8));
				if (num2 <= 1000 || num2 > 1233)
				{
					num2 = 0;
					return null;
				}
				num3 = (ushort)(array[j + 2] + (ushort)(array[j + 3] << 8));
				if (tag == num2)
				{
					array2 = new byte[num3];
					for (int k = 0; k < num3; k++)
					{
						array2[k] = array[j + 4 + k];
					}
					break;
				}
			}
			return array2;
		}

		private string GetFNFromCont(byte[] Data)
		{
			if (Data == null || Data.Length == 0)
			{
				return "";
			}
			string text = "";
			string text2 = "";
			for (int i = 0; i < Data.Length; i++)
			{
				text += Data[i].ToString("X2");
			}
			for (int j = 0; j < text.Length && text[j] >= '0' && text[j] <= '9'; j++)
			{
				text2 += text[j];
			}
			return text2;
		}

		private string GetDocName(byte code)
		{
			return code switch
			{
				1 => "Отчет о регистрации", 
				2 => "Отчет об открытии смены", 
				3 => "Кассовый чек", 
				4 => "Бланк строгой отчетности", 
				5 => "Отчет о закрытии смены", 
				6 => "Отчет о закрытии фискального накопителя", 
				7 => "Подтверждение оператора", 
				11 => "Отчет об изменении параметров регистрации", 
				21 => "Отчет о текущем состоянии расчетов", 
				31 => "Кассовый чек коррекции", 
				41 => "Бланк строгой отчетности коррекции", 
				_ => "Документ не установлен", 
			};
		}

		private void WriteConsole(string row_str, bool is_answer, string prefix = "--")
		{
			if (Console != null)
			{
				if (string.IsNullOrEmpty(prefix) || prefix.Length != 2)
				{
					prefix = "  ";
				}
				Console.Invoke(add_row, DateTime.Now.ToString("HH:mm:ss.fff ") + prefix + " " + row_str, is_answer);
			}
		}

		private void AddRowConsole(string row_str, bool is_answer = true, bool is_command = false)
		{
			if (Console == null)
			{
				return;
			}
			if (is_answer)
			{
				string text = "\\x" + Convert.ToUInt32(row_str[row_str.Length - 1]).ToString("X2");
				row_str = row_str.Substring(0, row_str.Length - 1) + text;
			}
			for (int i = 0; i < row_str.Length; i++)
			{
				if (row_str[i] < ' ')
				{
					row_str = row_str.Replace(row_str[i].ToString(), "\\x" + Convert.ToUInt32(row_str[i]).ToString("X2"));
					i = -1;
				}
			}
			Console.Items.Add(row_str);
			if (Console.Items.Count > 1000)
			{
				Console.Items.RemoveAt(0);
			}
			int num = Console.Height / Console.ItemHeight;
			if (Console.Items.Count > num)
			{
				Console.TopIndex = Console.Items.Count - num;
			}
			Console.Refresh();
		}
	}
}
