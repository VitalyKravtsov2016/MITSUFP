using System.Drawing;
using System.Windows.Forms;

namespace MitsuCube
{
	public class Progress_Bar
	{
		public enum MODE
		{
			NONE,
			CMD,
			OPE
		}

		private MODE Mode;

		public ProgressBar Bar;

		public bool Cmd_Visible => Mode == MODE.CMD && Bar.Visible;

		public Progress_Bar(string name, int width)
		{
			Bar = new ProgressBar
			{
				ImeMode = ImeMode.NoControl,
				Location = new Point(0, 422),
				Name = name,
				Size = new Size(width, 10),
				Visible = false
			};
			Mode = MODE.NONE;
		}

		public void Resize(int width)
		{
			Bar.Width = width;
		}

		public void Start(MODE mode, int max, int step = 1)
		{
			Mode = mode;
			Bar.Maximum = max;
			Bar.Step = step;
			Bar.Value = 0;
			Bar.Show();
		}

		public void Stop()
		{
			Mode = MODE.NONE;
			Bar.Hide();
		}
	}
}
