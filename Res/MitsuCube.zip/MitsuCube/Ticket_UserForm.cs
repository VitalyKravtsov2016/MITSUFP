using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace MitsuCube
{
	public class Ticket_UserForm : Form
	{
		private IContainer components = null;

		private Panel panel_Ticket_User;

		private GroupBox groupBox_Ticket_User;

		private TextBox textBox_SMail;

		private Label label38;

		private TextBox textBox_CAutomatNumber;

		private Label label70;

		private TextBox textBox_CPlaceCalc;

		private Label label60;

		private TextBox textBox_CAdressCalc;

		private Label label61;

		private Button button_UserOptionOK;

		private Button button_UserOptionCancel;

		public string UserOptionValue => TagValue(T(1009), textBox_CAdressCalc) + TagValue(T(1036), textBox_CAutomatNumber) + TagValue(T(1117), textBox_SMail) + TagValue(T(1187), textBox_CPlaceCalc);

		public Ticket_UserForm()
		{
			InitializeComponent();
		}

		private void textBox_CAdressCalc_TextChanged(object sender, EventArgs e)
		{
			((TextBox)sender).ForeColor = SystemColors.ControlText;
		}

		private string TagValue(string tag, TextBox t)
		{
			if (string.IsNullOrEmpty(t.Text) || t.ForeColor != SystemColors.ControlText)
			{
				return "";
			}
			return "<" + tag + ">" + t.Text + "</" + tag + ">";
		}

		private string T(int num)
		{
			return $"T{num}";
		}

		private void button_UserOptionOK_Click(object sender, EventArgs e)
		{
			Close();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MitsuCube.Ticket_UserForm));
			this.panel_Ticket_User = new System.Windows.Forms.Panel();
			this.groupBox_Ticket_User = new System.Windows.Forms.GroupBox();
			this.textBox_SMail = new System.Windows.Forms.TextBox();
			this.label38 = new System.Windows.Forms.Label();
			this.textBox_CAutomatNumber = new System.Windows.Forms.TextBox();
			this.label70 = new System.Windows.Forms.Label();
			this.textBox_CPlaceCalc = new System.Windows.Forms.TextBox();
			this.label60 = new System.Windows.Forms.Label();
			this.textBox_CAdressCalc = new System.Windows.Forms.TextBox();
			this.label61 = new System.Windows.Forms.Label();
			this.button_UserOptionOK = new System.Windows.Forms.Button();
			this.button_UserOptionCancel = new System.Windows.Forms.Button();
			this.panel_Ticket_User.SuspendLayout();
			this.groupBox_Ticket_User.SuspendLayout();
			base.SuspendLayout();
			this.panel_Ticket_User.BackColor = System.Drawing.Color.LightCyan;
			this.panel_Ticket_User.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_Ticket_User.Controls.Add(this.groupBox_Ticket_User);
			resources.ApplyResources(this.panel_Ticket_User, "panel_Ticket_User");
			this.panel_Ticket_User.Name = "panel_Ticket_User";
			this.groupBox_Ticket_User.Controls.Add(this.textBox_SMail);
			this.groupBox_Ticket_User.Controls.Add(this.label38);
			this.groupBox_Ticket_User.Controls.Add(this.textBox_CAutomatNumber);
			this.groupBox_Ticket_User.Controls.Add(this.label70);
			this.groupBox_Ticket_User.Controls.Add(this.textBox_CPlaceCalc);
			this.groupBox_Ticket_User.Controls.Add(this.label60);
			this.groupBox_Ticket_User.Controls.Add(this.textBox_CAdressCalc);
			this.groupBox_Ticket_User.Controls.Add(this.label61);
			resources.ApplyResources(this.groupBox_Ticket_User, "groupBox_Ticket_User");
			this.groupBox_Ticket_User.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_Ticket_User.Name = "groupBox_Ticket_User";
			this.groupBox_Ticket_User.TabStop = false;
			resources.ApplyResources(this.textBox_SMail, "textBox_SMail");
			this.textBox_SMail.ForeColor = System.Drawing.Color.DarkGray;
			this.textBox_SMail.Name = "textBox_SMail";
			this.textBox_SMail.Click += new System.EventHandler(textBox_CAdressCalc_TextChanged);
			resources.ApplyResources(this.label38, "label38");
			this.label38.ForeColor = System.Drawing.SystemColors.ControlText;
			this.label38.Name = "label38";
			resources.ApplyResources(this.textBox_CAutomatNumber, "textBox_CAutomatNumber");
			this.textBox_CAutomatNumber.Name = "textBox_CAutomatNumber";
			this.textBox_CAutomatNumber.Click += new System.EventHandler(textBox_CAdressCalc_TextChanged);
			resources.ApplyResources(this.label70, "label70");
			this.label70.ForeColor = System.Drawing.SystemColors.ControlText;
			this.label70.Name = "label70";
			resources.ApplyResources(this.textBox_CPlaceCalc, "textBox_CPlaceCalc");
			this.textBox_CPlaceCalc.ForeColor = System.Drawing.Color.DarkGray;
			this.textBox_CPlaceCalc.Name = "textBox_CPlaceCalc";
			this.textBox_CPlaceCalc.Click += new System.EventHandler(textBox_CAdressCalc_TextChanged);
			resources.ApplyResources(this.label60, "label60");
			this.label60.ForeColor = System.Drawing.SystemColors.ControlText;
			this.label60.Name = "label60";
			resources.ApplyResources(this.textBox_CAdressCalc, "textBox_CAdressCalc");
			this.textBox_CAdressCalc.ForeColor = System.Drawing.Color.DarkGray;
			this.textBox_CAdressCalc.Name = "textBox_CAdressCalc";
			this.textBox_CAdressCalc.Click += new System.EventHandler(textBox_CAdressCalc_TextChanged);
			resources.ApplyResources(this.label61, "label61");
			this.label61.ForeColor = System.Drawing.SystemColors.ControlText;
			this.label61.Name = "label61";
			this.button_UserOptionOK.BackColor = System.Drawing.Color.Transparent;
			this.button_UserOptionOK.DialogResult = System.Windows.Forms.DialogResult.OK;
			resources.ApplyResources(this.button_UserOptionOK, "button_UserOptionOK");
			this.button_UserOptionOK.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_UserOptionOK.Name = "button_UserOptionOK";
			this.button_UserOptionOK.UseVisualStyleBackColor = false;
			this.button_UserOptionOK.Click += new System.EventHandler(button_UserOptionOK_Click);
			this.button_UserOptionCancel.BackColor = System.Drawing.Color.Transparent;
			this.button_UserOptionCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			resources.ApplyResources(this.button_UserOptionCancel, "button_UserOptionCancel");
			this.button_UserOptionCancel.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_UserOptionCancel.Name = "button_UserOptionCancel";
			this.button_UserOptionCancel.UseVisualStyleBackColor = false;
			base.AcceptButton = this.button_UserOptionOK;
			base.CancelButton = this.button_UserOptionCancel;
			resources.ApplyResources(this, "$this");
			base.Controls.Add(this.button_UserOptionCancel);
			base.Controls.Add(this.button_UserOptionOK);
			base.Controls.Add(this.panel_Ticket_User);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "Ticket_UserForm";
			base.ShowIcon = false;
			base.ShowInTaskbar = false;
			this.panel_Ticket_User.ResumeLayout(false);
			this.groupBox_Ticket_User.ResumeLayout(false);
			this.groupBox_Ticket_User.PerformLayout();
			base.ResumeLayout(false);
		}
	}
}
