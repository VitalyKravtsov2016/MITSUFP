using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace MitsuCube
{
	public class Ticket_OptionForm : Form
	{
		private IContainer components = null;

		private Panel panel_Ticket_Options;

		private GroupBox groupBox_Ticket_Options;

		private Panel panel_Ticket_Option6;

		private Label label_Ticket_Option_BranchNo;

		private TextBox textBox_Ticket_Option_BranchNo;

		private Label label_Ticket_Option_BranchTime;

		private DateTimePicker dateTimePicker_Ticket_Option_BranchTime;

		private Panel panel_Ticket_Option4;

		private TextBox textBox_Ticket_Option_BranchValue;

		private Label label_Ticket_Option_BranchValue;

		private TextBox textBox_Ticket_Option_BranchID;

		private Label label_Ticket_Option_Branch;

		private Panel panel_Ticket_Option5;

		private Label label_Ticket_Option_OperTime;

		private DateTimePicker dateTimePicker_Ticket_Option_OperTime;

		private Panel panel_Ticket_Option2;

		private TextBox textBox_Ticket_Option_OperValue;

		private Label label_Ticket_Option_OperData;

		private TextBox textBox_Ticket_Option_OperID;

		private Label label_Ticket_Option_Oper;

		private Panel panel_Ticket_Option3;

		private TextBox textBox_Ticket_Option_UserValue;

		private Label label_Ticket_Option_UserValue;

		private TextBox textBox_Ticket_Option_UserID;

		private Label label_Ticket_Option_User;

		private Panel panel_Ticket_Option1;

		private TextBox textBox_Ticket_Option_Reference;

		private Label label_Ticket_Option2;

		private Label label_Ticket_Option1;

		private Button button_OptionsCancel;

		private Button button_OptionsOK;

		public string Value
		{
			get
			{
				string value = TagValue(1085, textBox_Ticket_Option_UserID) + TagValue(1086, textBox_Ticket_Option_UserValue);
				string value2 = TagValue(1262, textBox_Ticket_Option_BranchID) + ((!dateTimePicker_Ticket_Option_BranchTime.Checked) ? "" : TagValue(1263, dateTimePicker_Ticket_Option_BranchTime.Value.ToString("dd.MM.yyyy"))) + TagValue(1264, textBox_Ticket_Option_BranchNo) + TagValue(1265, textBox_Ticket_Option_BranchValue);
				string value3 = TagValue(1271, textBox_Ticket_Option_OperID) + TagValue(1272, textBox_Ticket_Option_OperValue) + ((!dateTimePicker_Ticket_Option_OperTime.Checked) ? "" : TagValue(1273, dateTimePicker_Ticket_Option_OperTime.Value.ToString("yyyy-MM-ddTHH:mm:ss")));
				return TagValue(1192, textBox_Ticket_Option_Reference) + TagValue(1084, value) + TagValue(1261, value2) + TagValue(1270, value3);
			}
		}

		public Ticket_OptionForm()
		{
			InitializeComponent();
		}

		private string TagValue(int num, string value)
		{
			return string.IsNullOrEmpty(value) ? "" : $"<T{num}>{value}</T{num}>";
		}

		private string TagValue(int num, TextBox t)
		{
			return (t.ForeColor != SystemColors.ControlText) ? "" : TagValue(num, t.Text);
		}

		private void textBox_Ticket_Option_Reference_TextChanged(object sender, EventArgs e)
		{
			((TextBox)sender).ForeColor = SystemColors.ControlText;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MitsuCube.Ticket_OptionForm));
			this.panel_Ticket_Options = new System.Windows.Forms.Panel();
			this.groupBox_Ticket_Options = new System.Windows.Forms.GroupBox();
			this.panel_Ticket_Option6 = new System.Windows.Forms.Panel();
			this.label_Ticket_Option_BranchNo = new System.Windows.Forms.Label();
			this.textBox_Ticket_Option_BranchNo = new System.Windows.Forms.TextBox();
			this.label_Ticket_Option_BranchTime = new System.Windows.Forms.Label();
			this.dateTimePicker_Ticket_Option_BranchTime = new System.Windows.Forms.DateTimePicker();
			this.panel_Ticket_Option4 = new System.Windows.Forms.Panel();
			this.textBox_Ticket_Option_BranchValue = new System.Windows.Forms.TextBox();
			this.label_Ticket_Option_BranchValue = new System.Windows.Forms.Label();
			this.textBox_Ticket_Option_BranchID = new System.Windows.Forms.TextBox();
			this.label_Ticket_Option_Branch = new System.Windows.Forms.Label();
			this.panel_Ticket_Option5 = new System.Windows.Forms.Panel();
			this.label_Ticket_Option_OperTime = new System.Windows.Forms.Label();
			this.dateTimePicker_Ticket_Option_OperTime = new System.Windows.Forms.DateTimePicker();
			this.panel_Ticket_Option2 = new System.Windows.Forms.Panel();
			this.textBox_Ticket_Option_OperValue = new System.Windows.Forms.TextBox();
			this.label_Ticket_Option_OperData = new System.Windows.Forms.Label();
			this.textBox_Ticket_Option_OperID = new System.Windows.Forms.TextBox();
			this.label_Ticket_Option_Oper = new System.Windows.Forms.Label();
			this.panel_Ticket_Option3 = new System.Windows.Forms.Panel();
			this.textBox_Ticket_Option_UserValue = new System.Windows.Forms.TextBox();
			this.label_Ticket_Option_UserValue = new System.Windows.Forms.Label();
			this.textBox_Ticket_Option_UserID = new System.Windows.Forms.TextBox();
			this.label_Ticket_Option_User = new System.Windows.Forms.Label();
			this.panel_Ticket_Option1 = new System.Windows.Forms.Panel();
			this.textBox_Ticket_Option_Reference = new System.Windows.Forms.TextBox();
			this.label_Ticket_Option2 = new System.Windows.Forms.Label();
			this.label_Ticket_Option1 = new System.Windows.Forms.Label();
			this.button_OptionsCancel = new System.Windows.Forms.Button();
			this.button_OptionsOK = new System.Windows.Forms.Button();
			this.panel_Ticket_Options.SuspendLayout();
			this.groupBox_Ticket_Options.SuspendLayout();
			this.panel_Ticket_Option6.SuspendLayout();
			this.panel_Ticket_Option4.SuspendLayout();
			this.panel_Ticket_Option5.SuspendLayout();
			this.panel_Ticket_Option2.SuspendLayout();
			this.panel_Ticket_Option3.SuspendLayout();
			this.panel_Ticket_Option1.SuspendLayout();
			base.SuspendLayout();
			this.panel_Ticket_Options.AllowDrop = true;
			this.panel_Ticket_Options.BackColor = System.Drawing.Color.LightCyan;
			this.panel_Ticket_Options.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_Ticket_Options.Controls.Add(this.groupBox_Ticket_Options);
			this.panel_Ticket_Options.Location = new System.Drawing.Point(12, 12);
			this.panel_Ticket_Options.Name = "panel_Ticket_Options";
			this.panel_Ticket_Options.Padding = new System.Windows.Forms.Padding(3);
			this.panel_Ticket_Options.Size = new System.Drawing.Size(539, 168);
			this.panel_Ticket_Options.TabIndex = 19;
			this.groupBox_Ticket_Options.Controls.Add(this.panel_Ticket_Option6);
			this.groupBox_Ticket_Options.Controls.Add(this.panel_Ticket_Option4);
			this.groupBox_Ticket_Options.Controls.Add(this.panel_Ticket_Option5);
			this.groupBox_Ticket_Options.Controls.Add(this.panel_Ticket_Option2);
			this.groupBox_Ticket_Options.Controls.Add(this.panel_Ticket_Option3);
			this.groupBox_Ticket_Options.Controls.Add(this.panel_Ticket_Option1);
			this.groupBox_Ticket_Options.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox_Ticket_Options.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold);
			this.groupBox_Ticket_Options.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_Ticket_Options.Location = new System.Drawing.Point(3, 3);
			this.groupBox_Ticket_Options.Name = "groupBox_Ticket_Options";
			this.groupBox_Ticket_Options.Size = new System.Drawing.Size(531, 156);
			this.groupBox_Ticket_Options.TabIndex = 3;
			this.groupBox_Ticket_Options.TabStop = false;
			this.groupBox_Ticket_Options.Text = "Дополнительные реквизиты чека";
			this.panel_Ticket_Option6.Controls.Add(this.label_Ticket_Option_BranchNo);
			this.panel_Ticket_Option6.Controls.Add(this.textBox_Ticket_Option_BranchNo);
			this.panel_Ticket_Option6.Controls.Add(this.label_Ticket_Option_BranchTime);
			this.panel_Ticket_Option6.Controls.Add(this.dateTimePicker_Ticket_Option_BranchTime);
			this.panel_Ticket_Option6.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Ticket_Option6.Location = new System.Drawing.Point(3, 127);
			this.panel_Ticket_Option6.Name = "panel_Ticket_Option6";
			this.panel_Ticket_Option6.Padding = new System.Windows.Forms.Padding(1);
			this.panel_Ticket_Option6.Size = new System.Drawing.Size(525, 22);
			this.panel_Ticket_Option6.TabIndex = 25;
			this.label_Ticket_Option_BranchNo.Dock = System.Windows.Forms.DockStyle.Right;
			this.label_Ticket_Option_BranchNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_Ticket_Option_BranchNo.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Ticket_Option_BranchNo.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Ticket_Option_BranchNo.Location = new System.Drawing.Point(212, 1);
			this.label_Ticket_Option_BranchNo.Margin = new System.Windows.Forms.Padding(3);
			this.label_Ticket_Option_BranchNo.Name = "label_Ticket_Option_BranchNo";
			this.label_Ticket_Option_BranchNo.Size = new System.Drawing.Size(52, 20);
			this.label_Ticket_Option_BranchNo.TabIndex = 13;
			this.label_Ticket_Option_BranchNo.Text = "Номер";
			this.label_Ticket_Option_BranchNo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.textBox_Ticket_Option_BranchNo.Dock = System.Windows.Forms.DockStyle.Right;
			this.textBox_Ticket_Option_BranchNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_Ticket_Option_BranchNo.ForeColor = System.Drawing.SystemColors.GrayText;
			this.textBox_Ticket_Option_BranchNo.Location = new System.Drawing.Point(264, 1);
			this.textBox_Ticket_Option_BranchNo.MaxLength = 32;
			this.textBox_Ticket_Option_BranchNo.Name = "textBox_Ticket_Option_BranchNo";
			this.textBox_Ticket_Option_BranchNo.Size = new System.Drawing.Size(53, 20);
			this.textBox_Ticket_Option_BranchNo.TabIndex = 12;
			this.textBox_Ticket_Option_BranchNo.Text = "123";
			this.textBox_Ticket_Option_BranchNo.Click += new System.EventHandler(textBox_Ticket_Option_Reference_TextChanged);
			this.label_Ticket_Option_BranchTime.Dock = System.Windows.Forms.DockStyle.Right;
			this.label_Ticket_Option_BranchTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_Ticket_Option_BranchTime.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Ticket_Option_BranchTime.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Ticket_Option_BranchTime.Location = new System.Drawing.Point(317, 1);
			this.label_Ticket_Option_BranchTime.Margin = new System.Windows.Forms.Padding(3);
			this.label_Ticket_Option_BranchTime.Name = "label_Ticket_Option_BranchTime";
			this.label_Ticket_Option_BranchTime.Size = new System.Drawing.Size(43, 20);
			this.label_Ticket_Option_BranchTime.TabIndex = 19;
			this.label_Ticket_Option_BranchTime.Text = "Дата";
			this.label_Ticket_Option_BranchTime.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.dateTimePicker_Ticket_Option_BranchTime.Checked = false;
			this.dateTimePicker_Ticket_Option_BranchTime.CustomFormat = "dd.MM.yyyy HH:mm";
			this.dateTimePicker_Ticket_Option_BranchTime.Dock = System.Windows.Forms.DockStyle.Right;
			this.dateTimePicker_Ticket_Option_BranchTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.dateTimePicker_Ticket_Option_BranchTime.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			this.dateTimePicker_Ticket_Option_BranchTime.ImeMode = System.Windows.Forms.ImeMode.Off;
			this.dateTimePicker_Ticket_Option_BranchTime.Location = new System.Drawing.Point(360, 1);
			this.dateTimePicker_Ticket_Option_BranchTime.MaxDate = new System.DateTime(2099, 12, 31, 0, 0, 0, 0);
			this.dateTimePicker_Ticket_Option_BranchTime.MinDate = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
			this.dateTimePicker_Ticket_Option_BranchTime.Name = "dateTimePicker_Ticket_Option_BranchTime";
			this.dateTimePicker_Ticket_Option_BranchTime.ShowCheckBox = true;
			this.dateTimePicker_Ticket_Option_BranchTime.Size = new System.Drawing.Size(164, 20);
			this.dateTimePicker_Ticket_Option_BranchTime.TabIndex = 18;
			this.dateTimePicker_Ticket_Option_BranchTime.Value = new System.DateTime(2023, 3, 13, 23, 26, 21, 0);
			this.panel_Ticket_Option4.Controls.Add(this.textBox_Ticket_Option_BranchValue);
			this.panel_Ticket_Option4.Controls.Add(this.label_Ticket_Option_BranchValue);
			this.panel_Ticket_Option4.Controls.Add(this.textBox_Ticket_Option_BranchID);
			this.panel_Ticket_Option4.Controls.Add(this.label_Ticket_Option_Branch);
			this.panel_Ticket_Option4.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Ticket_Option4.Location = new System.Drawing.Point(3, 105);
			this.panel_Ticket_Option4.Name = "panel_Ticket_Option4";
			this.panel_Ticket_Option4.Padding = new System.Windows.Forms.Padding(1);
			this.panel_Ticket_Option4.Size = new System.Drawing.Size(525, 22);
			this.panel_Ticket_Option4.TabIndex = 23;
			this.textBox_Ticket_Option_BranchValue.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox_Ticket_Option_BranchValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_Ticket_Option_BranchValue.ForeColor = System.Drawing.SystemColors.GrayText;
			this.textBox_Ticket_Option_BranchValue.Location = new System.Drawing.Point(196, 1);
			this.textBox_Ticket_Option_BranchValue.MaxLength = 256;
			this.textBox_Ticket_Option_BranchValue.Name = "textBox_Ticket_Option_BranchValue";
			this.textBox_Ticket_Option_BranchValue.Size = new System.Drawing.Size(328, 20);
			this.textBox_Ticket_Option_BranchValue.TabIndex = 11;
			this.textBox_Ticket_Option_BranchValue.Text = "303132333435363738393A3B3C3D3E3F";
			this.textBox_Ticket_Option_BranchValue.Click += new System.EventHandler(textBox_Ticket_Option_Reference_TextChanged);
			this.label_Ticket_Option_BranchValue.Dock = System.Windows.Forms.DockStyle.Left;
			this.label_Ticket_Option_BranchValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_Ticket_Option_BranchValue.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Ticket_Option_BranchValue.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Ticket_Option_BranchValue.Location = new System.Drawing.Point(141, 1);
			this.label_Ticket_Option_BranchValue.Margin = new System.Windows.Forms.Padding(3);
			this.label_Ticket_Option_BranchValue.Name = "label_Ticket_Option_BranchValue";
			this.label_Ticket_Option_BranchValue.Size = new System.Drawing.Size(55, 20);
			this.label_Ticket_Option_BranchValue.TabIndex = 10;
			this.label_Ticket_Option_BranchValue.Text = "Значение";
			this.label_Ticket_Option_BranchValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.textBox_Ticket_Option_BranchID.Dock = System.Windows.Forms.DockStyle.Left;
			this.textBox_Ticket_Option_BranchID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_Ticket_Option_BranchID.ForeColor = System.Drawing.SystemColors.GrayText;
			this.textBox_Ticket_Option_BranchID.Location = new System.Drawing.Point(101, 1);
			this.textBox_Ticket_Option_BranchID.MaxLength = 3;
			this.textBox_Ticket_Option_BranchID.Name = "textBox_Ticket_Option_BranchID";
			this.textBox_Ticket_Option_BranchID.Size = new System.Drawing.Size(40, 20);
			this.textBox_Ticket_Option_BranchID.TabIndex = 1;
			this.textBox_Ticket_Option_BranchID.Text = "001";
			this.textBox_Ticket_Option_BranchID.Click += new System.EventHandler(textBox_Ticket_Option_Reference_TextChanged);
			this.label_Ticket_Option_Branch.Dock = System.Windows.Forms.DockStyle.Left;
			this.label_Ticket_Option_Branch.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Italic);
			this.label_Ticket_Option_Branch.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Ticket_Option_Branch.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Ticket_Option_Branch.Location = new System.Drawing.Point(1, 1);
			this.label_Ticket_Option_Branch.Margin = new System.Windows.Forms.Padding(3);
			this.label_Ticket_Option_Branch.Name = "label_Ticket_Option_Branch";
			this.label_Ticket_Option_Branch.Size = new System.Drawing.Size(100, 20);
			this.label_Ticket_Option_Branch.TabIndex = 2;
			this.label_Ticket_Option_Branch.Text = "ФОИВ:";
			this.label_Ticket_Option_Branch.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.panel_Ticket_Option5.Controls.Add(this.label_Ticket_Option_OperTime);
			this.panel_Ticket_Option5.Controls.Add(this.dateTimePicker_Ticket_Option_OperTime);
			this.panel_Ticket_Option5.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Ticket_Option5.Location = new System.Drawing.Point(3, 83);
			this.panel_Ticket_Option5.Name = "panel_Ticket_Option5";
			this.panel_Ticket_Option5.Padding = new System.Windows.Forms.Padding(1);
			this.panel_Ticket_Option5.Size = new System.Drawing.Size(525, 22);
			this.panel_Ticket_Option5.TabIndex = 24;
			this.label_Ticket_Option_OperTime.Dock = System.Windows.Forms.DockStyle.Right;
			this.label_Ticket_Option_OperTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_Ticket_Option_OperTime.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Ticket_Option_OperTime.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Ticket_Option_OperTime.Location = new System.Drawing.Point(274, 1);
			this.label_Ticket_Option_OperTime.Margin = new System.Windows.Forms.Padding(3);
			this.label_Ticket_Option_OperTime.Name = "label_Ticket_Option_OperTime";
			this.label_Ticket_Option_OperTime.Size = new System.Drawing.Size(88, 20);
			this.label_Ticket_Option_OperTime.TabIndex = 19;
			this.label_Ticket_Option_OperTime.Text = "Дата и время";
			this.label_Ticket_Option_OperTime.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.dateTimePicker_Ticket_Option_OperTime.Checked = false;
			this.dateTimePicker_Ticket_Option_OperTime.CustomFormat = "dd.MM.yyyy HH:mm:ss";
			this.dateTimePicker_Ticket_Option_OperTime.Dock = System.Windows.Forms.DockStyle.Right;
			this.dateTimePicker_Ticket_Option_OperTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.dateTimePicker_Ticket_Option_OperTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dateTimePicker_Ticket_Option_OperTime.ImeMode = System.Windows.Forms.ImeMode.Off;
			this.dateTimePicker_Ticket_Option_OperTime.Location = new System.Drawing.Point(362, 1);
			this.dateTimePicker_Ticket_Option_OperTime.MaxDate = new System.DateTime(2099, 12, 31, 0, 0, 0, 0);
			this.dateTimePicker_Ticket_Option_OperTime.MinDate = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
			this.dateTimePicker_Ticket_Option_OperTime.Name = "dateTimePicker_Ticket_Option_OperTime";
			this.dateTimePicker_Ticket_Option_OperTime.ShowCheckBox = true;
			this.dateTimePicker_Ticket_Option_OperTime.Size = new System.Drawing.Size(162, 20);
			this.dateTimePicker_Ticket_Option_OperTime.TabIndex = 18;
			this.dateTimePicker_Ticket_Option_OperTime.Value = new System.DateTime(2023, 3, 13, 23, 27, 0, 0);
			this.panel_Ticket_Option2.Controls.Add(this.textBox_Ticket_Option_OperValue);
			this.panel_Ticket_Option2.Controls.Add(this.label_Ticket_Option_OperData);
			this.panel_Ticket_Option2.Controls.Add(this.textBox_Ticket_Option_OperID);
			this.panel_Ticket_Option2.Controls.Add(this.label_Ticket_Option_Oper);
			this.panel_Ticket_Option2.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Ticket_Option2.Location = new System.Drawing.Point(3, 61);
			this.panel_Ticket_Option2.Name = "panel_Ticket_Option2";
			this.panel_Ticket_Option2.Padding = new System.Windows.Forms.Padding(1);
			this.panel_Ticket_Option2.Size = new System.Drawing.Size(525, 22);
			this.panel_Ticket_Option2.TabIndex = 21;
			this.textBox_Ticket_Option_OperValue.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox_Ticket_Option_OperValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_Ticket_Option_OperValue.ForeColor = System.Drawing.SystemColors.GrayText;
			this.textBox_Ticket_Option_OperValue.Location = new System.Drawing.Point(196, 1);
			this.textBox_Ticket_Option_OperValue.MaxLength = 64;
			this.textBox_Ticket_Option_OperValue.Name = "textBox_Ticket_Option_OperValue";
			this.textBox_Ticket_Option_OperValue.Size = new System.Drawing.Size(328, 20);
			this.textBox_Ticket_Option_OperValue.TabIndex = 1;
			this.textBox_Ticket_Option_OperValue.Text = "Данные операции";
			this.textBox_Ticket_Option_OperValue.Click += new System.EventHandler(textBox_Ticket_Option_Reference_TextChanged);
			this.label_Ticket_Option_OperData.Dock = System.Windows.Forms.DockStyle.Left;
			this.label_Ticket_Option_OperData.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_Ticket_Option_OperData.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Ticket_Option_OperData.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Ticket_Option_OperData.Location = new System.Drawing.Point(141, 1);
			this.label_Ticket_Option_OperData.Margin = new System.Windows.Forms.Padding(3);
			this.label_Ticket_Option_OperData.Name = "label_Ticket_Option_OperData";
			this.label_Ticket_Option_OperData.Size = new System.Drawing.Size(55, 20);
			this.label_Ticket_Option_OperData.TabIndex = 1;
			this.label_Ticket_Option_OperData.Text = "Значение";
			this.label_Ticket_Option_OperData.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.textBox_Ticket_Option_OperID.Dock = System.Windows.Forms.DockStyle.Left;
			this.textBox_Ticket_Option_OperID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_Ticket_Option_OperID.ForeColor = System.Drawing.SystemColors.GrayText;
			this.textBox_Ticket_Option_OperID.Location = new System.Drawing.Point(101, 1);
			this.textBox_Ticket_Option_OperID.MaxLength = 3;
			this.textBox_Ticket_Option_OperID.Name = "textBox_Ticket_Option_OperID";
			this.textBox_Ticket_Option_OperID.Size = new System.Drawing.Size(40, 20);
			this.textBox_Ticket_Option_OperID.TabIndex = 2;
			this.textBox_Ticket_Option_OperID.Text = "111";
			this.textBox_Ticket_Option_OperID.Click += new System.EventHandler(textBox_Ticket_Option_Reference_TextChanged);
			this.label_Ticket_Option_Oper.Dock = System.Windows.Forms.DockStyle.Left;
			this.label_Ticket_Option_Oper.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Italic);
			this.label_Ticket_Option_Oper.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Ticket_Option_Oper.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Ticket_Option_Oper.Location = new System.Drawing.Point(1, 1);
			this.label_Ticket_Option_Oper.Margin = new System.Windows.Forms.Padding(3);
			this.label_Ticket_Option_Oper.Name = "label_Ticket_Option_Oper";
			this.label_Ticket_Option_Oper.Size = new System.Drawing.Size(100, 20);
			this.label_Ticket_Option_Oper.TabIndex = 2;
			this.label_Ticket_Option_Oper.Text = "Операция:";
			this.label_Ticket_Option_Oper.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.panel_Ticket_Option3.Controls.Add(this.textBox_Ticket_Option_UserValue);
			this.panel_Ticket_Option3.Controls.Add(this.label_Ticket_Option_UserValue);
			this.panel_Ticket_Option3.Controls.Add(this.textBox_Ticket_Option_UserID);
			this.panel_Ticket_Option3.Controls.Add(this.label_Ticket_Option_User);
			this.panel_Ticket_Option3.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Ticket_Option3.Location = new System.Drawing.Point(3, 38);
			this.panel_Ticket_Option3.Name = "panel_Ticket_Option3";
			this.panel_Ticket_Option3.Padding = new System.Windows.Forms.Padding(1);
			this.panel_Ticket_Option3.Size = new System.Drawing.Size(525, 23);
			this.panel_Ticket_Option3.TabIndex = 22;
			this.textBox_Ticket_Option_UserValue.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox_Ticket_Option_UserValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_Ticket_Option_UserValue.ForeColor = System.Drawing.SystemColors.GrayText;
			this.textBox_Ticket_Option_UserValue.Location = new System.Drawing.Point(196, 1);
			this.textBox_Ticket_Option_UserValue.MaxLength = 256;
			this.textBox_Ticket_Option_UserValue.MinimumSize = new System.Drawing.Size(4, 21);
			this.textBox_Ticket_Option_UserValue.Name = "textBox_Ticket_Option_UserValue";
			this.textBox_Ticket_Option_UserValue.Size = new System.Drawing.Size(328, 20);
			this.textBox_Ticket_Option_UserValue.TabIndex = 7;
			this.textBox_Ticket_Option_UserValue.Text = "Дополнительный реквизит пользователя";
			this.textBox_Ticket_Option_UserValue.Click += new System.EventHandler(textBox_Ticket_Option_Reference_TextChanged);
			this.label_Ticket_Option_UserValue.Dock = System.Windows.Forms.DockStyle.Left;
			this.label_Ticket_Option_UserValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_Ticket_Option_UserValue.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Ticket_Option_UserValue.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Ticket_Option_UserValue.Location = new System.Drawing.Point(141, 1);
			this.label_Ticket_Option_UserValue.Margin = new System.Windows.Forms.Padding(3);
			this.label_Ticket_Option_UserValue.Name = "label_Ticket_Option_UserValue";
			this.label_Ticket_Option_UserValue.Size = new System.Drawing.Size(55, 21);
			this.label_Ticket_Option_UserValue.TabIndex = 9;
			this.label_Ticket_Option_UserValue.Text = "Значение";
			this.label_Ticket_Option_UserValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.textBox_Ticket_Option_UserID.Dock = System.Windows.Forms.DockStyle.Left;
			this.textBox_Ticket_Option_UserID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_Ticket_Option_UserID.ForeColor = System.Drawing.SystemColors.GrayText;
			this.textBox_Ticket_Option_UserID.Location = new System.Drawing.Point(101, 1);
			this.textBox_Ticket_Option_UserID.MaxLength = 64;
			this.textBox_Ticket_Option_UserID.MinimumSize = new System.Drawing.Size(4, 21);
			this.textBox_Ticket_Option_UserID.Name = "textBox_Ticket_Option_UserID";
			this.textBox_Ticket_Option_UserID.Size = new System.Drawing.Size(40, 20);
			this.textBox_Ticket_Option_UserID.TabIndex = 8;
			this.textBox_Ticket_Option_UserID.Text = "1085";
			this.textBox_Ticket_Option_UserID.Click += new System.EventHandler(textBox_Ticket_Option_Reference_TextChanged);
			this.label_Ticket_Option_User.Dock = System.Windows.Forms.DockStyle.Left;
			this.label_Ticket_Option_User.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Italic);
			this.label_Ticket_Option_User.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Ticket_Option_User.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Ticket_Option_User.Location = new System.Drawing.Point(1, 1);
			this.label_Ticket_Option_User.Margin = new System.Windows.Forms.Padding(3);
			this.label_Ticket_Option_User.Name = "label_Ticket_Option_User";
			this.label_Ticket_Option_User.Size = new System.Drawing.Size(100, 21);
			this.label_Ticket_Option_User.TabIndex = 5;
			this.label_Ticket_Option_User.Text = "Пользователь:";
			this.label_Ticket_Option_User.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.panel_Ticket_Option1.Controls.Add(this.textBox_Ticket_Option_Reference);
			this.panel_Ticket_Option1.Controls.Add(this.label_Ticket_Option2);
			this.panel_Ticket_Option1.Controls.Add(this.label_Ticket_Option1);
			this.panel_Ticket_Option1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Ticket_Option1.Location = new System.Drawing.Point(3, 16);
			this.panel_Ticket_Option1.Name = "panel_Ticket_Option1";
			this.panel_Ticket_Option1.Padding = new System.Windows.Forms.Padding(1);
			this.panel_Ticket_Option1.Size = new System.Drawing.Size(525, 22);
			this.panel_Ticket_Option1.TabIndex = 20;
			this.textBox_Ticket_Option_Reference.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox_Ticket_Option_Reference.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_Ticket_Option_Reference.ForeColor = System.Drawing.SystemColors.GrayText;
			this.textBox_Ticket_Option_Reference.Location = new System.Drawing.Point(196, 1);
			this.textBox_Ticket_Option_Reference.MaxLength = 16;
			this.textBox_Ticket_Option_Reference.Name = "textBox_Ticket_Option_Reference";
			this.textBox_Ticket_Option_Reference.Size = new System.Drawing.Size(328, 20);
			this.textBox_Ticket_Option_Reference.TabIndex = 0;
			this.textBox_Ticket_Option_Reference.Text = "1234567890123456";
			this.textBox_Ticket_Option_Reference.Click += new System.EventHandler(textBox_Ticket_Option_Reference_TextChanged);
			this.label_Ticket_Option2.Dock = System.Windows.Forms.DockStyle.Left;
			this.label_Ticket_Option2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_Ticket_Option2.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Ticket_Option2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Ticket_Option2.Location = new System.Drawing.Point(141, 1);
			this.label_Ticket_Option2.Margin = new System.Windows.Forms.Padding(3);
			this.label_Ticket_Option2.Name = "label_Ticket_Option2";
			this.label_Ticket_Option2.Size = new System.Drawing.Size(55, 20);
			this.label_Ticket_Option2.TabIndex = 1;
			this.label_Ticket_Option2.Text = "Значение";
			this.label_Ticket_Option2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.label_Ticket_Option1.Dock = System.Windows.Forms.DockStyle.Left;
			this.label_Ticket_Option1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Italic);
			this.label_Ticket_Option1.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Ticket_Option1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Ticket_Option1.Location = new System.Drawing.Point(1, 1);
			this.label_Ticket_Option1.Margin = new System.Windows.Forms.Padding(3);
			this.label_Ticket_Option1.Name = "label_Ticket_Option1";
			this.label_Ticket_Option1.Size = new System.Drawing.Size(140, 20);
			this.label_Ticket_Option1.TabIndex = 0;
			this.label_Ticket_Option1.Text = "Доп. реквизит чека:";
			this.label_Ticket_Option1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.button_OptionsCancel.BackColor = System.Drawing.Color.Transparent;
			this.button_OptionsCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.button_OptionsCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold);
			this.button_OptionsCancel.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_OptionsCancel.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_OptionsCancel.Location = new System.Drawing.Point(423, 199);
			this.button_OptionsCancel.Name = "button_OptionsCancel";
			this.button_OptionsCancel.Size = new System.Drawing.Size(128, 37);
			this.button_OptionsCancel.TabIndex = 20;
			this.button_OptionsCancel.Text = "Отмена";
			this.button_OptionsCancel.UseVisualStyleBackColor = false;
			this.button_OptionsOK.BackColor = System.Drawing.Color.Transparent;
			this.button_OptionsOK.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.button_OptionsOK.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold);
			this.button_OptionsOK.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_OptionsOK.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_OptionsOK.Location = new System.Drawing.Point(289, 199);
			this.button_OptionsOK.Name = "button_OptionsOK";
			this.button_OptionsOK.Size = new System.Drawing.Size(128, 37);
			this.button_OptionsOK.TabIndex = 21;
			this.button_OptionsOK.Text = "Добавить в чек";
			this.button_OptionsOK.UseVisualStyleBackColor = false;
			base.AcceptButton = this.button_OptionsOK;
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.CancelButton = this.button_OptionsCancel;
			base.ClientSize = new System.Drawing.Size(566, 251);
			base.Controls.Add(this.button_OptionsCancel);
			base.Controls.Add(this.button_OptionsOK);
			base.Controls.Add(this.panel_Ticket_Options);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			base.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "Ticket_OptionForm";
			base.ShowIcon = false;
			base.ShowInTaskbar = false;
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Реквизиты чека";
			this.panel_Ticket_Options.ResumeLayout(false);
			this.groupBox_Ticket_Options.ResumeLayout(false);
			this.panel_Ticket_Option6.ResumeLayout(false);
			this.panel_Ticket_Option6.PerformLayout();
			this.panel_Ticket_Option4.ResumeLayout(false);
			this.panel_Ticket_Option4.PerformLayout();
			this.panel_Ticket_Option5.ResumeLayout(false);
			this.panel_Ticket_Option2.ResumeLayout(false);
			this.panel_Ticket_Option2.PerformLayout();
			this.panel_Ticket_Option3.ResumeLayout(false);
			this.panel_Ticket_Option3.PerformLayout();
			this.panel_Ticket_Option1.ResumeLayout(false);
			this.panel_Ticket_Option1.PerformLayout();
			base.ResumeLayout(false);
		}
	}
}
