using System.IO;

namespace MitsuCube
{
	public class Crc32Calculator
	{
		private const uint _InitialResidueValue = uint.MaxValue;

		private uint _residue = uint.MaxValue;

		private static object _globalSync = new object();

		private static uint[] _Crc32Table;

		private static byte[][] _maskingBitTable = new byte[32][]
		{
			new byte[1] { 2 },
			new byte[2] { 0, 3 },
			new byte[3] { 0, 1, 4 },
			new byte[3] { 1, 2, 5 },
			new byte[4] { 0, 2, 3, 6 },
			new byte[4] { 1, 3, 4, 7 },
			new byte[2] { 4, 5 },
			new byte[3] { 0, 5, 6 },
			new byte[3] { 1, 6, 7 },
			new byte[1] { 7 },
			new byte[1] { 2 },
			new byte[1] { 3 },
			new byte[2] { 0, 4 },
			new byte[3] { 0, 1, 5 },
			new byte[3] { 1, 2, 6 },
			new byte[3] { 2, 3, 7 },
			new byte[4] { 0, 2, 3, 4 },
			new byte[5] { 0, 1, 3, 4, 5 },
			new byte[6] { 0, 1, 2, 4, 5, 6 },
			new byte[6] { 1, 2, 3, 5, 6, 7 },
			new byte[4] { 3, 4, 6, 7 },
			new byte[4] { 2, 4, 5, 7 },
			new byte[4] { 2, 3, 5, 6 },
			new byte[4] { 3, 4, 6, 7 },
			new byte[5] { 0, 2, 4, 5, 7 },
			new byte[6] { 0, 1, 2, 3, 5, 6 },
			new byte[7] { 0, 1, 2, 3, 4, 6, 7 },
			new byte[5] { 1, 3, 4, 5, 7 },
			new byte[4] { 0, 4, 5, 6 },
			new byte[5] { 0, 1, 5, 6, 7 },
			new byte[4] { 0, 1, 6, 7 },
			new byte[2] { 1, 7 }
		};

		internal uint Crc => ~_residue;

		internal Crc32Calculator()
		{
			lock (_globalSync)
			{
				if (_Crc32Table == null)
				{
					PrepareTable();
				}
			}
		}

		public uint CalculateStreamCrc(FileStream file)
		{
			byte[] array = new byte[4096];
			while (true)
			{
				int num = file.Read(array, 0, array.Length);
				if (num > 0)
				{
					Accumulate(array, 0, num);
					continue;
				}
				break;
			}
			return Crc;
		}

		internal void Accumulate(byte[] buffer, int offset, int count)
		{
			for (int i = offset; i < count + offset; i++)
			{
				_residue = ((_residue >> 8) & 0xFFFFFFu) ^ _Crc32Table[(_residue ^ buffer[i]) & 0xFF];
			}
		}

		internal void ClearCrc()
		{
			_residue = uint.MaxValue;
		}

		private static void PrepareTable()
		{
			_Crc32Table = new uint[256];
			for (uint num = 0u; num < _Crc32Table.Length; num++)
			{
				for (byte b = 0; b < 32; b++)
				{
					bool flag = false;
					byte[] array = _maskingBitTable[b];
					foreach (byte bitOrdinal in array)
					{
						flag ^= GetBit(bitOrdinal, num);
					}
					SetBit(b, ref _Crc32Table[num], flag);
				}
			}
		}

		private static bool GetBit(byte bitOrdinal, uint data)
		{
			return ((data >> (int)bitOrdinal) & 1) == 1;
		}

		private static void SetBit(byte bitOrdinal, ref uint data, bool value)
		{
			if (value)
			{
				data |= (uint)(1 << (int)bitOrdinal);
			}
		}
	}
}
