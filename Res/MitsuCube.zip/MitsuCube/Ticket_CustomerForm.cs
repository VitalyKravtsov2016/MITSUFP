using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace MitsuCube
{
	public class Ticket_CustomerForm : Form
	{
		private IContainer components = null;

		private Button button_CustomerCancel;

		private Button button_CustomerOK;

		private Panel panel_Ticket_Customer;

		private GroupBox groupBox_Ticket_Customer;

		private Panel panel_Ticket_Customer4;

		private TextBox textBox_Ticket_Customer_Address;

		private Label label_Ticket_Customer_Address;

		private Panel panel_Ticket_Customer3;

		private TextBox textBox_Ticket_Customer_Doc;

		private ComboBox comboBox_Ticket_Customer_DocType;

		private Label label1;

		private NumericUpDown numeric_Ticket_Customer_Country;

		private Label label_Ticket_Customer_Country;

		private Panel panel_Ticket_Customer2;

		private TextBox textBox_Ticket_Customer_Email;

		private Label label_Ticket_Customer_Birthday;

		private DateTimePicker dateTimePicker_Ticket_Customer_Birth;

		private Label label_Ticket_Customer_Email;

		private Panel panel_Ticket_Customer1;

		private TextBox textBox_Ticket_Customer_Name;

		private Label label_Ticket_Customer_Name;

		private Label label_Ticket_Customer_INN;

		private TextBox textBox_Ticket_Customer_INN;

		public string Value
		{
			get
			{
				string value = TagValue(1227, textBox_Ticket_Customer_Name) + TagValue(1228, textBox_Ticket_Customer_INN) + Birthday + Country + DocType + TagValue(1246, textBox_Ticket_Customer_Doc) + TagValue(1254, textBox_Ticket_Customer_Address);
				return TagValue(1008, textBox_Ticket_Customer_Email) + TagValue(1256, value);
			}
		}

		private string DocType => (comboBox_Ticket_Customer_DocType.ForeColor != SystemColors.ControlText) ? "" : TagValue(1245, comboBox_Ticket_Customer_DocType.Text);

		private string Birthday => (!dateTimePicker_Ticket_Customer_Birth.Checked) ? "" : TagValue(1243, $"{dateTimePicker_Ticket_Customer_Birth.Value:dd.MM.yyyy}");

		private string Country => (numeric_Ticket_Customer_Country.ForeColor != SystemColors.ControlText) ? "" : TagValue(1244, numeric_Ticket_Customer_Country.Value.ToString());

		public Ticket_CustomerForm()
		{
			InitializeComponent();
		}

		private string TagValue(int num, string value)
		{
			return string.IsNullOrEmpty(value) ? "" : $"<T{num}>{value}</T{num}>";
		}

		private string TagValue(int num, TextBox t)
		{
			return (t.ForeColor != SystemColors.ControlText) ? "" : TagValue(num, t.Text);
		}

		private void ItemChanged(object sender, EventArgs e)
		{
			if (sender.GetType() == typeof(TextBox))
			{
				((TextBox)sender).ForeColor = SystemColors.ControlText;
			}
			else if (sender.GetType() == typeof(ComboBox))
			{
				((ComboBox)sender).ForeColor = SystemColors.ControlText;
			}
			else if (sender.GetType() == typeof(NumericUpDown))
			{
				((NumericUpDown)sender).ForeColor = SystemColors.ControlText;
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MitsuCube.Ticket_CustomerForm));
			this.button_CustomerCancel = new System.Windows.Forms.Button();
			this.button_CustomerOK = new System.Windows.Forms.Button();
			this.panel_Ticket_Customer = new System.Windows.Forms.Panel();
			this.groupBox_Ticket_Customer = new System.Windows.Forms.GroupBox();
			this.panel_Ticket_Customer4 = new System.Windows.Forms.Panel();
			this.textBox_Ticket_Customer_Address = new System.Windows.Forms.TextBox();
			this.label_Ticket_Customer_Address = new System.Windows.Forms.Label();
			this.panel_Ticket_Customer3 = new System.Windows.Forms.Panel();
			this.textBox_Ticket_Customer_Doc = new System.Windows.Forms.TextBox();
			this.comboBox_Ticket_Customer_DocType = new System.Windows.Forms.ComboBox();
			this.label1 = new System.Windows.Forms.Label();
			this.numeric_Ticket_Customer_Country = new System.Windows.Forms.NumericUpDown();
			this.label_Ticket_Customer_Country = new System.Windows.Forms.Label();
			this.panel_Ticket_Customer2 = new System.Windows.Forms.Panel();
			this.textBox_Ticket_Customer_Email = new System.Windows.Forms.TextBox();
			this.label_Ticket_Customer_Birthday = new System.Windows.Forms.Label();
			this.dateTimePicker_Ticket_Customer_Birth = new System.Windows.Forms.DateTimePicker();
			this.label_Ticket_Customer_Email = new System.Windows.Forms.Label();
			this.panel_Ticket_Customer1 = new System.Windows.Forms.Panel();
			this.textBox_Ticket_Customer_Name = new System.Windows.Forms.TextBox();
			this.label_Ticket_Customer_Name = new System.Windows.Forms.Label();
			this.label_Ticket_Customer_INN = new System.Windows.Forms.Label();
			this.textBox_Ticket_Customer_INN = new System.Windows.Forms.TextBox();
			this.panel_Ticket_Customer.SuspendLayout();
			this.groupBox_Ticket_Customer.SuspendLayout();
			this.panel_Ticket_Customer4.SuspendLayout();
			this.panel_Ticket_Customer3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.numeric_Ticket_Customer_Country).BeginInit();
			this.panel_Ticket_Customer2.SuspendLayout();
			this.panel_Ticket_Customer1.SuspendLayout();
			base.SuspendLayout();
			this.button_CustomerCancel.BackColor = System.Drawing.Color.Transparent;
			this.button_CustomerCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.button_CustomerCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold);
			this.button_CustomerCancel.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_CustomerCancel.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_CustomerCancel.Location = new System.Drawing.Point(423, 148);
			this.button_CustomerCancel.Name = "button_CustomerCancel";
			this.button_CustomerCancel.Size = new System.Drawing.Size(128, 37);
			this.button_CustomerCancel.TabIndex = 10;
			this.button_CustomerCancel.Text = "Отмена";
			this.button_CustomerCancel.UseVisualStyleBackColor = false;
			this.button_CustomerOK.BackColor = System.Drawing.Color.Transparent;
			this.button_CustomerOK.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.button_CustomerOK.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold);
			this.button_CustomerOK.ForeColor = System.Drawing.SystemColors.ControlText;
			this.button_CustomerOK.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.button_CustomerOK.Location = new System.Drawing.Point(289, 148);
			this.button_CustomerOK.Name = "button_CustomerOK";
			this.button_CustomerOK.Size = new System.Drawing.Size(128, 37);
			this.button_CustomerOK.TabIndex = 11;
			this.button_CustomerOK.Text = "Добавить в чек";
			this.button_CustomerOK.UseVisualStyleBackColor = false;
			this.panel_Ticket_Customer.AllowDrop = true;
			this.panel_Ticket_Customer.BackColor = System.Drawing.Color.LightCyan;
			this.panel_Ticket_Customer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel_Ticket_Customer.Controls.Add(this.groupBox_Ticket_Customer);
			this.panel_Ticket_Customer.Location = new System.Drawing.Point(12, 12);
			this.panel_Ticket_Customer.Name = "panel_Ticket_Customer";
			this.panel_Ticket_Customer.Padding = new System.Windows.Forms.Padding(3);
			this.panel_Ticket_Customer.Size = new System.Drawing.Size(539, 120);
			this.panel_Ticket_Customer.TabIndex = 18;
			this.groupBox_Ticket_Customer.Controls.Add(this.panel_Ticket_Customer4);
			this.groupBox_Ticket_Customer.Controls.Add(this.panel_Ticket_Customer3);
			this.groupBox_Ticket_Customer.Controls.Add(this.panel_Ticket_Customer2);
			this.groupBox_Ticket_Customer.Controls.Add(this.panel_Ticket_Customer1);
			this.groupBox_Ticket_Customer.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox_Ticket_Customer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f, System.Drawing.FontStyle.Bold);
			this.groupBox_Ticket_Customer.ForeColor = System.Drawing.Color.Blue;
			this.groupBox_Ticket_Customer.Location = new System.Drawing.Point(3, 3);
			this.groupBox_Ticket_Customer.Name = "groupBox_Ticket_Customer";
			this.groupBox_Ticket_Customer.Size = new System.Drawing.Size(531, 110);
			this.groupBox_Ticket_Customer.TabIndex = 3;
			this.groupBox_Ticket_Customer.TabStop = false;
			this.groupBox_Ticket_Customer.Text = "Покупатель (клиент)";
			this.panel_Ticket_Customer4.Controls.Add(this.textBox_Ticket_Customer_Address);
			this.panel_Ticket_Customer4.Controls.Add(this.label_Ticket_Customer_Address);
			this.panel_Ticket_Customer4.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Ticket_Customer4.Location = new System.Drawing.Point(3, 83);
			this.panel_Ticket_Customer4.Name = "panel_Ticket_Customer4";
			this.panel_Ticket_Customer4.Padding = new System.Windows.Forms.Padding(1);
			this.panel_Ticket_Customer4.Size = new System.Drawing.Size(525, 22);
			this.panel_Ticket_Customer4.TabIndex = 23;
			this.textBox_Ticket_Customer_Address.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox_Ticket_Customer_Address.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_Ticket_Customer_Address.ForeColor = System.Drawing.SystemColors.GrayText;
			this.textBox_Ticket_Customer_Address.Location = new System.Drawing.Point(71, 1);
			this.textBox_Ticket_Customer_Address.MaxLength = 128;
			this.textBox_Ticket_Customer_Address.Name = "textBox_Ticket_Customer_Address";
			this.textBox_Ticket_Customer_Address.Size = new System.Drawing.Size(453, 20);
			this.textBox_Ticket_Customer_Address.TabIndex = 1;
			this.textBox_Ticket_Customer_Address.Text = "Адрес покупателя";
			this.textBox_Ticket_Customer_Address.Click += new System.EventHandler(ItemChanged);
			this.label_Ticket_Customer_Address.Dock = System.Windows.Forms.DockStyle.Left;
			this.label_Ticket_Customer_Address.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_Ticket_Customer_Address.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Ticket_Customer_Address.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Ticket_Customer_Address.Location = new System.Drawing.Point(1, 1);
			this.label_Ticket_Customer_Address.Margin = new System.Windows.Forms.Padding(3);
			this.label_Ticket_Customer_Address.Name = "label_Ticket_Customer_Address";
			this.label_Ticket_Customer_Address.Size = new System.Drawing.Size(70, 20);
			this.label_Ticket_Customer_Address.TabIndex = 2;
			this.label_Ticket_Customer_Address.Text = "Адрес";
			this.label_Ticket_Customer_Address.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.panel_Ticket_Customer3.Controls.Add(this.textBox_Ticket_Customer_Doc);
			this.panel_Ticket_Customer3.Controls.Add(this.comboBox_Ticket_Customer_DocType);
			this.panel_Ticket_Customer3.Controls.Add(this.label1);
			this.panel_Ticket_Customer3.Controls.Add(this.numeric_Ticket_Customer_Country);
			this.panel_Ticket_Customer3.Controls.Add(this.label_Ticket_Customer_Country);
			this.panel_Ticket_Customer3.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Ticket_Customer3.Location = new System.Drawing.Point(3, 60);
			this.panel_Ticket_Customer3.Name = "panel_Ticket_Customer3";
			this.panel_Ticket_Customer3.Padding = new System.Windows.Forms.Padding(1);
			this.panel_Ticket_Customer3.Size = new System.Drawing.Size(525, 23);
			this.panel_Ticket_Customer3.TabIndex = 22;
			this.textBox_Ticket_Customer_Doc.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox_Ticket_Customer_Doc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_Ticket_Customer_Doc.ForeColor = System.Drawing.SystemColors.GrayText;
			this.textBox_Ticket_Customer_Doc.Location = new System.Drawing.Point(215, 1);
			this.textBox_Ticket_Customer_Doc.MaxLength = 64;
			this.textBox_Ticket_Customer_Doc.MinimumSize = new System.Drawing.Size(4, 21);
			this.textBox_Ticket_Customer_Doc.Name = "textBox_Ticket_Customer_Doc";
			this.textBox_Ticket_Customer_Doc.Size = new System.Drawing.Size(309, 20);
			this.textBox_Ticket_Customer_Doc.TabIndex = 7;
			this.textBox_Ticket_Customer_Doc.Text = "Паспорт 4545-123456";
			this.textBox_Ticket_Customer_Doc.Click += new System.EventHandler(ItemChanged);
			this.comboBox_Ticket_Customer_DocType.Dock = System.Windows.Forms.DockStyle.Left;
			this.comboBox_Ticket_Customer_DocType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.comboBox_Ticket_Customer_DocType.ForeColor = System.Drawing.SystemColors.GrayText;
			this.comboBox_Ticket_Customer_DocType.FormattingEnabled = true;
			this.comboBox_Ticket_Customer_DocType.Items.AddRange(new object[15]
			{
				"21", "22", "26", "27", "28", "31", "32", "33", "34", "35",
				"36", "37", "38", "39", "40"
			});
			this.comboBox_Ticket_Customer_DocType.Location = new System.Drawing.Point(173, 1);
			this.comboBox_Ticket_Customer_DocType.Name = "comboBox_Ticket_Customer_DocType";
			this.comboBox_Ticket_Customer_DocType.Size = new System.Drawing.Size(42, 21);
			this.comboBox_Ticket_Customer_DocType.TabIndex = 6;
			this.comboBox_Ticket_Customer_DocType.Text = "21";
			this.comboBox_Ticket_Customer_DocType.SelectedIndexChanged += new System.EventHandler(ItemChanged);
			this.comboBox_Ticket_Customer_DocType.Click += new System.EventHandler(ItemChanged);
			this.label1.Dock = System.Windows.Forms.DockStyle.Left;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label1.Location = new System.Drawing.Point(113, 1);
			this.label1.Margin = new System.Windows.Forms.Padding(3);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(60, 21);
			this.label1.TabIndex = 5;
			this.label1.Text = "Документ";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.numeric_Ticket_Customer_Country.Dock = System.Windows.Forms.DockStyle.Left;
			this.numeric_Ticket_Customer_Country.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.numeric_Ticket_Customer_Country.ForeColor = System.Drawing.SystemColors.GrayText;
			this.numeric_Ticket_Customer_Country.Location = new System.Drawing.Point(71, 1);
			this.numeric_Ticket_Customer_Country.Maximum = new decimal(new int[4] { 999, 0, 0, 0 });
			this.numeric_Ticket_Customer_Country.Name = "numeric_Ticket_Customer_Country";
			this.numeric_Ticket_Customer_Country.Size = new System.Drawing.Size(42, 20);
			this.numeric_Ticket_Customer_Country.TabIndex = 4;
			this.numeric_Ticket_Customer_Country.Value = new decimal(new int[4] { 4, 0, 0, 0 });
			this.numeric_Ticket_Customer_Country.ValueChanged += new System.EventHandler(ItemChanged);
			this.numeric_Ticket_Customer_Country.Click += new System.EventHandler(ItemChanged);
			this.label_Ticket_Customer_Country.Dock = System.Windows.Forms.DockStyle.Left;
			this.label_Ticket_Customer_Country.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_Ticket_Customer_Country.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Ticket_Customer_Country.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Ticket_Customer_Country.Location = new System.Drawing.Point(1, 1);
			this.label_Ticket_Customer_Country.Margin = new System.Windows.Forms.Padding(3);
			this.label_Ticket_Customer_Country.Name = "label_Ticket_Customer_Country";
			this.label_Ticket_Customer_Country.Size = new System.Drawing.Size(70, 21);
			this.label_Ticket_Customer_Country.TabIndex = 3;
			this.label_Ticket_Customer_Country.Text = "Страна";
			this.label_Ticket_Customer_Country.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.panel_Ticket_Customer2.Controls.Add(this.textBox_Ticket_Customer_Email);
			this.panel_Ticket_Customer2.Controls.Add(this.label_Ticket_Customer_Birthday);
			this.panel_Ticket_Customer2.Controls.Add(this.dateTimePicker_Ticket_Customer_Birth);
			this.panel_Ticket_Customer2.Controls.Add(this.label_Ticket_Customer_Email);
			this.panel_Ticket_Customer2.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Ticket_Customer2.Location = new System.Drawing.Point(3, 38);
			this.panel_Ticket_Customer2.Name = "panel_Ticket_Customer2";
			this.panel_Ticket_Customer2.Padding = new System.Windows.Forms.Padding(1);
			this.panel_Ticket_Customer2.Size = new System.Drawing.Size(525, 22);
			this.panel_Ticket_Customer2.TabIndex = 21;
			this.textBox_Ticket_Customer_Email.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox_Ticket_Customer_Email.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_Ticket_Customer_Email.ForeColor = System.Drawing.SystemColors.GrayText;
			this.textBox_Ticket_Customer_Email.Location = new System.Drawing.Point(71, 1);
			this.textBox_Ticket_Customer_Email.MaxLength = 64;
			this.textBox_Ticket_Customer_Email.Name = "textBox_Ticket_Customer_Email";
			this.textBox_Ticket_Customer_Email.Size = new System.Drawing.Size(313, 20);
			this.textBox_Ticket_Customer_Email.TabIndex = 2;
			this.textBox_Ticket_Customer_Email.Text = "1008@customer-mail.ru";
			this.textBox_Ticket_Customer_Email.Click += new System.EventHandler(ItemChanged);
			this.textBox_Ticket_Customer_Email.TextChanged += new System.EventHandler(ItemChanged);
			this.label_Ticket_Customer_Birthday.Dock = System.Windows.Forms.DockStyle.Right;
			this.label_Ticket_Customer_Birthday.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_Ticket_Customer_Birthday.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Ticket_Customer_Birthday.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Ticket_Customer_Birthday.Location = new System.Drawing.Point(384, 1);
			this.label_Ticket_Customer_Birthday.Margin = new System.Windows.Forms.Padding(3);
			this.label_Ticket_Customer_Birthday.Name = "label_Ticket_Customer_Birthday";
			this.label_Ticket_Customer_Birthday.Size = new System.Drawing.Size(50, 20);
			this.label_Ticket_Customer_Birthday.TabIndex = 19;
			this.label_Ticket_Customer_Birthday.Text = "Рожд.";
			this.label_Ticket_Customer_Birthday.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.dateTimePicker_Ticket_Customer_Birth.CalendarTitleBackColor = System.Drawing.SystemColors.Window;
			this.dateTimePicker_Ticket_Customer_Birth.CalendarTitleForeColor = System.Drawing.SystemColors.ControlText;
			this.dateTimePicker_Ticket_Customer_Birth.Checked = false;
			this.dateTimePicker_Ticket_Customer_Birth.CustomFormat = "";
			this.dateTimePicker_Ticket_Customer_Birth.Dock = System.Windows.Forms.DockStyle.Right;
			this.dateTimePicker_Ticket_Customer_Birth.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f);
			this.dateTimePicker_Ticket_Customer_Birth.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			this.dateTimePicker_Ticket_Customer_Birth.ImeMode = System.Windows.Forms.ImeMode.Off;
			this.dateTimePicker_Ticket_Customer_Birth.Location = new System.Drawing.Point(434, 1);
			this.dateTimePicker_Ticket_Customer_Birth.MaxDate = new System.DateTime(2099, 12, 31, 0, 0, 0, 0);
			this.dateTimePicker_Ticket_Customer_Birth.MinDate = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
			this.dateTimePicker_Ticket_Customer_Birth.Name = "dateTimePicker_Ticket_Customer_Birth";
			this.dateTimePicker_Ticket_Customer_Birth.ShowCheckBox = true;
			this.dateTimePicker_Ticket_Customer_Birth.Size = new System.Drawing.Size(90, 20);
			this.dateTimePicker_Ticket_Customer_Birth.TabIndex = 18;
			this.dateTimePicker_Ticket_Customer_Birth.Value = new System.DateTime(2011, 11, 11, 0, 0, 0, 0);
			this.label_Ticket_Customer_Email.Dock = System.Windows.Forms.DockStyle.Left;
			this.label_Ticket_Customer_Email.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_Ticket_Customer_Email.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Ticket_Customer_Email.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Ticket_Customer_Email.Location = new System.Drawing.Point(1, 1);
			this.label_Ticket_Customer_Email.Margin = new System.Windows.Forms.Padding(3);
			this.label_Ticket_Customer_Email.Name = "label_Ticket_Customer_Email";
			this.label_Ticket_Customer_Email.Size = new System.Drawing.Size(70, 20);
			this.label_Ticket_Customer_Email.TabIndex = 2;
			this.label_Ticket_Customer_Email.Text = "Тел/Email";
			this.label_Ticket_Customer_Email.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.panel_Ticket_Customer1.Controls.Add(this.textBox_Ticket_Customer_Name);
			this.panel_Ticket_Customer1.Controls.Add(this.label_Ticket_Customer_Name);
			this.panel_Ticket_Customer1.Controls.Add(this.label_Ticket_Customer_INN);
			this.panel_Ticket_Customer1.Controls.Add(this.textBox_Ticket_Customer_INN);
			this.panel_Ticket_Customer1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel_Ticket_Customer1.Location = new System.Drawing.Point(3, 16);
			this.panel_Ticket_Customer1.Name = "panel_Ticket_Customer1";
			this.panel_Ticket_Customer1.Padding = new System.Windows.Forms.Padding(1);
			this.panel_Ticket_Customer1.Size = new System.Drawing.Size(525, 22);
			this.panel_Ticket_Customer1.TabIndex = 20;
			this.textBox_Ticket_Customer_Name.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox_Ticket_Customer_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_Ticket_Customer_Name.ForeColor = System.Drawing.SystemColors.GrayText;
			this.textBox_Ticket_Customer_Name.Location = new System.Drawing.Point(71, 1);
			this.textBox_Ticket_Customer_Name.MaxLength = 128;
			this.textBox_Ticket_Customer_Name.Name = "textBox_Ticket_Customer_Name";
			this.textBox_Ticket_Customer_Name.Size = new System.Drawing.Size(313, 20);
			this.textBox_Ticket_Customer_Name.TabIndex = 0;
			this.textBox_Ticket_Customer_Name.Text = "Новый хороший покупатель (1227)";
			this.textBox_Ticket_Customer_Name.Click += new System.EventHandler(ItemChanged);
			this.label_Ticket_Customer_Name.Dock = System.Windows.Forms.DockStyle.Left;
			this.label_Ticket_Customer_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_Ticket_Customer_Name.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Ticket_Customer_Name.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Ticket_Customer_Name.Location = new System.Drawing.Point(1, 1);
			this.label_Ticket_Customer_Name.Margin = new System.Windows.Forms.Padding(3);
			this.label_Ticket_Customer_Name.Name = "label_Ticket_Customer_Name";
			this.label_Ticket_Customer_Name.Size = new System.Drawing.Size(70, 20);
			this.label_Ticket_Customer_Name.TabIndex = 0;
			this.label_Ticket_Customer_Name.Text = "Имя";
			this.label_Ticket_Customer_Name.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.label_Ticket_Customer_INN.Dock = System.Windows.Forms.DockStyle.Right;
			this.label_Ticket_Customer_INN.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.label_Ticket_Customer_INN.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.label_Ticket_Customer_INN.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label_Ticket_Customer_INN.Location = new System.Drawing.Point(384, 1);
			this.label_Ticket_Customer_INN.Margin = new System.Windows.Forms.Padding(3);
			this.label_Ticket_Customer_INN.Name = "label_Ticket_Customer_INN";
			this.label_Ticket_Customer_INN.Size = new System.Drawing.Size(50, 20);
			this.label_Ticket_Customer_INN.TabIndex = 1;
			this.label_Ticket_Customer_INN.Text = "ИНН";
			this.label_Ticket_Customer_INN.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.textBox_Ticket_Customer_INN.Dock = System.Windows.Forms.DockStyle.Right;
			this.textBox_Ticket_Customer_INN.Font = new System.Drawing.Font("Microsoft Sans Serif", 8f);
			this.textBox_Ticket_Customer_INN.ForeColor = System.Drawing.SystemColors.GrayText;
			this.textBox_Ticket_Customer_INN.Location = new System.Drawing.Point(434, 1);
			this.textBox_Ticket_Customer_INN.MaxLength = 12;
			this.textBox_Ticket_Customer_INN.Name = "textBox_Ticket_Customer_INN";
			this.textBox_Ticket_Customer_INN.Size = new System.Drawing.Size(90, 20);
			this.textBox_Ticket_Customer_INN.TabIndex = 1;
			this.textBox_Ticket_Customer_INN.Text = "9876543210";
			this.textBox_Ticket_Customer_INN.Click += new System.EventHandler(ItemChanged);
			base.AcceptButton = this.button_CustomerOK;
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.CancelButton = this.button_CustomerCancel;
			base.ClientSize = new System.Drawing.Size(565, 193);
			base.Controls.Add(this.panel_Ticket_Customer);
			base.Controls.Add(this.button_CustomerCancel);
			base.Controls.Add(this.button_CustomerOK);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			base.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "Ticket_CustomerForm";
			base.ShowIcon = false;
			base.ShowInTaskbar = false;
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Покупатель (клиент)";
			this.panel_Ticket_Customer.ResumeLayout(false);
			this.groupBox_Ticket_Customer.ResumeLayout(false);
			this.panel_Ticket_Customer4.ResumeLayout(false);
			this.panel_Ticket_Customer4.PerformLayout();
			this.panel_Ticket_Customer3.ResumeLayout(false);
			this.panel_Ticket_Customer3.PerformLayout();
			((System.ComponentModel.ISupportInitialize)this.numeric_Ticket_Customer_Country).EndInit();
			this.panel_Ticket_Customer2.ResumeLayout(false);
			this.panel_Ticket_Customer2.PerformLayout();
			this.panel_Ticket_Customer1.ResumeLayout(false);
			this.panel_Ticket_Customer1.PerformLayout();
			base.ResumeLayout(false);
		}
	}
}
