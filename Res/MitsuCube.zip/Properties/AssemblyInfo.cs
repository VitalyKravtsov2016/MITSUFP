using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Security;
using System.Security.Permissions;

[assembly: AssemblyTitle("MitsuCube")]
[assembly: AssemblyDescription("Утилита для ККТ MITSU-1-F")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("ООО ВиЭйВи")]
[assembly: AssemblyProduct("MitsuCube")]
[assembly: AssemblyCopyright("VAV LLC. © 2023")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("251ebdc4-5900-4f00-86bc-13746172d1b7")]
[assembly: AssemblyFileVersion("1.1.13")]
[assembly: AssemblyVersion("1.1.13.0")]
