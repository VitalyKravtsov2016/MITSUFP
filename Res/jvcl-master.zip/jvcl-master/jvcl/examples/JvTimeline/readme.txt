This is a fairly exhaustive example program for the TTimeLine component. 

When first loading it, make sure that the Imagelists have images in them by double-clicking their icon on the form. If they are empty, load the im16.bmp bitmap into Imagelist1 by selecting Add and selecting it in the dialog (answer Yes when prompted to separate into several bitmaps). Load the im32.bmp bitmap into ImageList2 the same way.

Please provide suggestions, bug reports etc to:

http://jvcl.sourceforge.net/

Enjoy.