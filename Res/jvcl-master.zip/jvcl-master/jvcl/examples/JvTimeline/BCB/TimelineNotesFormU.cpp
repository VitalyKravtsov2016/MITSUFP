//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "TimelineNotesFormU.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TTimelineNotesForm *TimelineNotesForm;
//---------------------------------------------------------------------------
__fastcall TTimelineNotesForm::TTimelineNotesForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
